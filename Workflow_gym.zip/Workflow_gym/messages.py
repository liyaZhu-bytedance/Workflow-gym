from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .records import new_id, now_text


@dataclass(frozen=True)
class Envelope:
    run_id: str
    message_type: str
    payload: dict[str, Any]
    task_id: str = ""
    sample_index: int | None = None
    message_id: str = field(default_factory=lambda: new_id("msg"))
    correlation_id: str = ""
    reply_to: str = ""
    attempt: int = 0
    schema_version: int = 1
    created_at: str = field(default_factory=now_text)


def ack_for(message: Envelope, status: str = "received", error: str = "") -> Envelope:
    return Envelope(
        run_id=message.run_id,
        message_type="Ack",
        task_id=message.task_id,
        sample_index=message.sample_index,
        correlation_id=message.message_id,
        payload={"status": status, "error": error},
    )

