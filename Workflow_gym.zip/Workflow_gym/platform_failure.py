from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .envs.volcengine_env import is_cloud_assistant_platform_mismatch_text, platform_to_os_type_label
from .records import TaskFileResult, TaskRecord, TrajectoryResult, now_text
from .states import SampleStatus


ERROR_SCORE = -100000
PLATFORM_MATCH_UNAVAILABLE = "platform_match_unavailable"
PLATFORM_MISMATCH_EXHAUSTED = "platform_mismatch_exhausted"


def _load_exception_records(sample_dir: str) -> list[dict[str, Any]]:
    path = Path(sample_dir) / "exception.json"
    if not path.exists():
        return []
    try:
        with open(path, "r", encoding="utf-8") as file_obj:
            loaded = json.load(file_obj)
    except Exception:
        return []
    if isinstance(loaded, list):
        return [item for item in loaded if isinstance(item, dict)]
    if isinstance(loaded, dict):
        return [loaded]
    return []


def is_platform_mismatch_failure(trajectory: TrajectoryResult) -> bool:
    if (trajectory.status or "") != SampleStatus.SAMPLE_FAILED.value:
        return False
    if is_cloud_assistant_platform_mismatch_text(trajectory.error or ""):
        return True
    for record in _load_exception_records(trajectory.sample_dir):
        if record.get("exception_type") == "CloudAssistantPlatformMismatchError":
            return True
        if is_cloud_assistant_platform_mismatch_text(str(record.get("message") or "")):
            return True
    return False


def platform_mismatch_context_from_trajectory(trajectory: TrajectoryResult) -> dict[str, str]:
    for record in _load_exception_records(trajectory.sample_dir):
        context = {
            key: str(record.get(key) or "").strip()
            for key in (
                "instance_id",
                "instance_name",
                "instance_platform",
                "instance_os_type",
                "expected_platform",
                "expected_os_type",
                "image_id",
                "task_expected_platform",
                "task_expected_os_type",
            )
            if str(record.get(key) or "").strip()
        }
        if context:
            return context
    return {}


def build_platform_failure_error(
    *,
    reason: str,
    required_platform: str,
    image_id: str = "",
    tried_instance_ids: list[str] | None = None,
    mismatch_context: dict[str, str] | None = None,
) -> str:
    platform_label = platform_to_os_type_label(required_platform) if required_platform else "<unknown>"
    image_part = " image_id=%s" % image_id if image_id else ""
    tried = [item for item in (tried_instance_ids or []) if item]
    if reason == PLATFORM_MATCH_UNAVAILABLE:
        return (
            "无与镜像平台匹配的可用实例，停止采样: required_platform=%s(%s)%s tried_instances=%s"
            % (required_platform or "<unknown>", platform_label, image_part, ",".join(tried) or "<none>")
        )
    context = mismatch_context or {}
    return (
        "实例平台与镜像平台不一致，已尝试全部匹配实例后仍失败，停止采样: "
        "instance_id=%s instance_platform=%s expected_platform=%s(%s)%s tried_instances=%s"
        % (
            context.get("instance_id") or "<unknown>",
            context.get("instance_platform") or "<unknown>",
            context.get("expected_platform") or required_platform or "<unknown>",
            context.get("expected_os_type") or platform_label,
            image_part,
            ",".join(tried) or "<none>",
        )
    )


def build_platform_failure_evidence(
    *,
    reason: str,
    required_platform: str,
    image_id: str = "",
    tried_instance_ids: list[str] | None = None,
    mismatch_context: dict[str, str] | None = None,
) -> str:
    platform_label = platform_to_os_type_label(required_platform) if required_platform else "<unknown>"
    tried = [item for item in (tried_instance_ids or []) if item]
    parts = ["平台匹配失败，未进入正常判分", "answer_score=%s" % ERROR_SCORE]
    if reason == PLATFORM_MATCH_UNAVAILABLE:
        parts.extend(
            [
                "reason=no_matching_instance",
                "required_platform=%s" % (required_platform or "<unknown>"),
                "required_os_type=%s" % platform_label,
            ]
        )
    else:
        context = mismatch_context or {}
        parts.extend(
            [
                "reason=platform_mismatch_exhausted",
                "instance_id=%s" % (context.get("instance_id") or "<unknown>"),
                "instance_platform=%s" % (context.get("instance_platform") or "<unknown>"),
                "expected_platform=%s" % (context.get("expected_platform") or required_platform or "<unknown>"),
                "expected_os_type=%s" % (context.get("expected_os_type") or platform_label),
            ]
        )
    if image_id:
        parts.append("image_id=%s" % image_id)
    if tried:
        parts.append("tried_instances=%s" % ",".join(tried))
    parts.append(
        "说明=实例云助手平台必须与目标镜像 OS 一致（open_workflow_gym_ubuntu / open_workflow_gym_windows），"
        "无法在错误平台实例上换盘执行采样"
    )
    return "；".join(parts)


def write_platform_failure_artifacts(
    *,
    record: TaskRecord,
    sample_index: int,
    sample_dir: str,
    reason: str,
    required_platform: str,
    tried_instance_ids: list[str] | None = None,
    mismatch_context: dict[str, str] | None = None,
) -> TrajectoryResult:
    image_id = str(record.image_id or record.fields.get("image") or "").strip()
    error = build_platform_failure_error(
        reason=reason,
        required_platform=required_platform,
        image_id=image_id,
        tried_instance_ids=tried_instance_ids,
        mismatch_context=mismatch_context,
    )
    exception_record = {
        "run_id": record.run_id,
        "task_id": record.task_id,
        "sample_index": sample_index,
        "stage": "initialize_env",
        "step_index": -1,
        "screenshot": "",
        "exception_type": "PlatformMatchUnavailableError",
        "reason": reason,
        "message": error,
        "required_platform": required_platform,
        "required_os_type": platform_to_os_type_label(required_platform) if required_platform else "",
        "image_id": image_id,
        "tried_instance_ids": list(tried_instance_ids or ()),
        "timestamp": now_text(),
    }
    if mismatch_context:
        exception_record.update(mismatch_context)

    os.makedirs(sample_dir, exist_ok=True)
    id_path = os.path.join(sample_dir, "sample_metadata.json")
    traj_json_path = os.path.join(sample_dir, "traj.json")
    traj_md_path = os.path.join(sample_dir, "traj.md")
    exception_json_path = os.path.join(sample_dir, "exception.json")
    sample_status_path = os.path.join(sample_dir, "sample_status.json")

    id_payload = {
        "run_id": record.run_id,
        "task_id": record.task_id,
        "sample_index": sample_index,
        "env": {
            "platform_failure_reason": reason,
            "required_platform": required_platform,
            "image_id": image_id,
            "tried_instance_ids": list(tried_instance_ids or ()),
        },
        "task_files": {},
    }
    status = SampleStatus.SAMPLE_FAILED.value
    sample_status_payload = {
        "run_id": record.run_id,
        "task_id": record.task_id,
        "sample_index": sample_index,
        "status": status,
        "last_step": -1,
        "error": error,
        "updated_at": now_text(),
    }
    _write_json(id_path, id_payload)
    _write_json(traj_json_path, [])
    Path(traj_md_path).write_text("", encoding="utf-8")
    _write_json(exception_json_path, [exception_record])
    _write_json(sample_status_path, sample_status_payload)

    return TrajectoryResult(
        run_id=record.run_id,
        task_id=record.task_id,
        sample_index=sample_index,
        status=status,
        sample_dir=sample_dir,
        traj_json_path=traj_json_path,
        traj_md_path=traj_md_path,
        id_json_path=id_path,
        sample_status_path=sample_status_path,
        last_step=-1,
        error=error,
        task_files=TaskFileResult(),
        task_fields=record.fields,
    )


def _write_json(path: str, payload: Any) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as file_obj:
        json.dump(payload, file_obj, ensure_ascii=False, indent=2)
