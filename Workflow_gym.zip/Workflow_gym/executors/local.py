from __future__ import annotations

import signal
from concurrent.futures import Future, ProcessPoolExecutor
from typing import Callable

from ..records import SampleJob, TrajectoryResult


class LocalExecutorBackend:
    """Synchronous local backend for the first implementation.

    It keeps the ExecutorBackend interface but avoids multiprocessing while the
    core state machine is being validated.
    """

    def __init__(self, sample_runner: Callable[[SampleJob], TrajectoryResult]):
        self.sample_runner = sample_runner

    def submit_sample(self, job: SampleJob) -> TrajectoryResult:
        return self.sample_runner(job)

    def shutdown(self, cancel_futures: bool = False) -> None:
        return None


class ProcessPoolExecutorBackend:
    """Process pool backend for sampling workers.

    The parent process owns scheduling state, leases, scoring, and Feishu writes.
    Worker processes only execute one SampleJob and return a TrajectoryResult.
    """

    supports_async = True

    def __init__(self, max_workers: int):
        self.max_workers = max(1, int(max_workers))
        self.pool = ProcessPoolExecutor(
            max_workers=self.max_workers,
            initializer=ignore_sigint_in_worker,
        )

    def submit_sample(self, job: SampleJob) -> TrajectoryResult:
        return self.submit_sample_async(job).result()

    def submit_sample_async(self, job: SampleJob) -> Future:
        return self.pool.submit(run_sample_in_worker, job)

    def shutdown(self, cancel_futures: bool = False) -> None:
        self.pool.shutdown(wait=False, cancel_futures=cancel_futures)


def ignore_sigint_in_worker() -> None:
    signal.signal(signal.SIGINT, signal.SIG_IGN)


def build_worker_env(job: SampleJob):
    """按 lease_backend 选择 worker 环境：redis→Gateway，local→Volcengine。"""
    from ..envs.gateway_volcengine_env import GatewayVolcengineEnv
    from ..envs.volcengine_env import VolcengineEnv
    from ..lease_renewal import build_lease_renew_context

    cloud_dry_run = "" if job.config.enable_real_cloud else (job.config.dry_run or "local")
    lease_backend = str(getattr(job.config, "lease_backend", "local") or "local").strip().lower()
    lease_ctx = build_lease_renew_context(job)
    if lease_backend in ("redis", "wgm", "remote"):
        env = GatewayVolcengineEnv(
            dry_run=cloud_dry_run,
            region=job.config.region,
            wgm_api_base=getattr(job.config, "wgm_api_base", "") or None,
            wgm_token=getattr(job.config, "wgm_token", "") or None,
            ttl_seconds=max(60, int(getattr(job.config, "lease_ttl_seconds", 1800) or 1800)),
        )
        env.lease_renew_context = lease_ctx
        return env
    return VolcengineEnv(
        dry_run=cloud_dry_run,
        region=job.config.region,
        lease_renew_context=lease_ctx,
    )


def run_sample_in_worker(job: SampleJob) -> TrajectoryResult:
    from ..agents.factory import AgentFactory
    from ..cancellation import is_cancel_requested
    from ..sampler import Sampler

    env = build_worker_env(job)
    sampler = Sampler(AgentFactory(), env, shutdown_requested=lambda: is_cancel_requested(job.config.output_root))
    return sampler.run_sample(job)

