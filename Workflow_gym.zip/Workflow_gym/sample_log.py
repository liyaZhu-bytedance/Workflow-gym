from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .records import json_dumps, now_text, to_jsonable


def append_sample_log(
    sample_dir: str,
    message: str,
    *,
    source: str,
    timestamp: str | None = None,
    line: str = "",
    task_id: str = "",
    sample_index: int | None = None,
    extra: dict[str, Any] | None = None,
) -> None:
    if not sample_dir:
        return
    event = {
        "timestamp": timestamp or now_text(),
        "source": source,
        "message": message,
    }
    if line:
        event["line"] = line
    if task_id:
        event["task_id"] = task_id
    if sample_index is not None:
        event["sample_index"] = sample_index
    if extra:
        event["extra"] = to_jsonable(extra)

    path = Path(sample_dir) / "sample_log.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    ensure_jsonl_log(path)
    with open(path, "a", encoding="utf-8") as file_obj:
        file_obj.write(json_dumps(event))
        file_obj.write("\n")


def ensure_jsonl_log(path: Path) -> None:
    if not path.exists():
        return
    try:
        text = path.read_text(encoding="utf-8")
    except Exception:
        return
    stripped = text.lstrip()
    if not stripped.startswith("["):
        return
    events = read_existing_events(path)
    tmp_path = path.with_name("%s.tmp.%s" % (path.name, os.getpid()))
    tmp_path.write_text("".join(json_dumps(event) + "\n" for event in events), encoding="utf-8")
    os.replace(tmp_path, path)


def read_existing_events(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    try:
        text = path.read_text(encoding="utf-8")
    except Exception:
        return []
    stripped = text.strip()
    if not stripped:
        return []
    if stripped.startswith("["):
        try:
            value = json.loads(stripped)
        except Exception:
            return []
        if not isinstance(value, list):
            return []
        return [item for item in value if isinstance(item, dict)]
    events = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            value = json.loads(line)
        except Exception:
            continue
        if isinstance(value, dict):
            events.append(value)
    return events
