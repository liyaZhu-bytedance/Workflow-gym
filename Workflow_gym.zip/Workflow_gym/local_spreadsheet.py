from __future__ import annotations

import csv
import os
import re
import shutil
from pathlib import Path
from typing import Any

from .feishu_client import column_to_number, normalize_sheet_cell_value


DEFAULT_SOURCE_CSV_PATH = "data/tasks.csv"


class LocalSpreadsheetClient:
    """Offline CSV spreadsheet backend compatible with FeishuClient write APIs."""

    def __init__(self, report_dir: str):
        self.report_dir = Path(report_dir)
        self.report_dir.mkdir(parents=True, exist_ok=True)
        self.dry_run = False
        self._sheets: dict[str, list[list[Any]]] = {}

    def create_or_get_report(self, title: str) -> dict[str, str]:
        return {
            "spreadsheet_token": str(self.report_dir),
            "spreadsheet_url": self.report_dir.resolve().as_uri(),
            "validation_sheet_id": "validation",
            "samples_sheet_id": "samples",
            "agent_config_sheet_id": "agent_config",
        }

    def read_values(self, spreadsheet_token: str, cell_range: str) -> list[list[Any]]:
        path = Path(spreadsheet_token)
        if path.is_file():
            return read_csv_rows(path)
        return []

    def write_values(self, spreadsheet_token: str, sheet_id: str, start_cell: str, values: list[list[Any]]) -> None:
        if not values:
            return None
        rows = self._sheet_rows(sheet_id)
        row_index, column_index = parse_cell(start_cell)
        for offset, row in enumerate(values):
            target_row = row_index + offset
            while len(rows) <= target_row:
                rows.append([])
            normalized = [normalize_sheet_cell_value(cell) for cell in row]
            if column_index:
                existing = rows[target_row]
                if len(existing) < column_index:
                    existing.extend([""] * (column_index - len(existing)))
                for cell_offset, cell in enumerate(normalized):
                    target_col = column_index + cell_offset
                    while len(existing) <= target_col:
                        existing.append("")
                    existing[target_col] = cell
                rows[target_row] = existing
            else:
                rows[target_row] = normalized
        self._flush_sheet(sheet_id)
        return None

    def write_file_cell(self, spreadsheet_token: str, sheet_id: str, cell: str, file_token: str) -> None:
        value = file_token or ""
        self.write_values(spreadsheet_token, sheet_id, cell, [[value]])
        return None

    def upload_attachment(self, spreadsheet_token: str, file_path: str, file_name: str = "") -> str:
        source = Path(file_path)
        if not source.is_file():
            return str(source)
        attachments_dir = self.report_dir / "attachments"
        attachments_dir.mkdir(parents=True, exist_ok=True)
        target_name = file_name or source.name
        target = attachments_dir / target_name
        if source.resolve() != target.resolve():
            shutil.copy2(source, target)
        return str(target.resolve())

    def _sheet_rows(self, sheet_id: str) -> list[list[Any]]:
        if sheet_id not in self._sheets:
            path = self._sheet_path(sheet_id)
            self._sheets[sheet_id] = read_csv_rows(path) if path.is_file() else []
        return self._sheets[sheet_id]

    def _sheet_path(self, sheet_id: str) -> Path:
        return self.report_dir / ("%s.csv" % sheet_id)

    def _flush_sheet(self, sheet_id: str) -> None:
        rows = self._sheets.get(sheet_id) or []
        write_csv_rows(self._sheet_path(sheet_id), rows)


def read_csv_rows(path: str | Path) -> list[list[Any]]:
    csv_path = Path(path)
    if not csv_path.is_file():
        return []
    with csv_path.open(newline="", encoding="utf-8-sig") as file_obj:
        return [list(row) for row in csv.reader(file_obj)]


def write_csv_rows(path: str | Path, rows: list[list[Any]]) -> None:
    csv_path = Path(path)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with csv_path.open("w", newline="", encoding="utf-8") as file_obj:
        writer = csv.writer(file_obj)
        for row in rows:
            writer.writerow([normalize_sheet_cell_value(cell) for cell in row])


def parse_cell(cell: str) -> tuple[int, int]:
    match = re.match(r"^([A-Z]+)([0-9]+)$", cell)
    if not match:
        raise ValueError("非法单元格坐标: %s" % cell)
    return int(match.group(2)) - 1, column_to_number(match.group(1)) - 1


def resolve_source_csv_path(configured_path: str = "") -> str:
    if configured_path:
        return configured_path
    candidates = [
        Path(os.getenv("SOURCE_CSV_PATH", DEFAULT_SOURCE_CSV_PATH)),
        Path(__file__).resolve().parent / DEFAULT_SOURCE_CSV_PATH,
    ]
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)
    return str(candidates[0])


def resolve_report_csv_dir(configured_dir: str, output_root: str) -> str:
    if configured_dir:
        return configured_dir
    return str(Path(output_root) / "report")


def resolve_local_samples_csv_path(configured_dir: str, output_root: str) -> str:
    return str(Path(resolve_report_csv_dir(configured_dir, output_root)) / "samples.csv")


class MirroringSpreadsheetClient:
    """Mirror spreadsheet writes to a local CSV backend while using a remote primary client."""

    def __init__(self, primary: Any, local: LocalSpreadsheetClient):
        self.primary = primary
        self.local = local
        self.dry_run = getattr(primary, "dry_run", False)
        self._local_report: dict[str, str] | None = None
        self._attachment_local_paths: dict[str, str] = {}

    @property
    def report_dir(self) -> Path:
        return self.local.report_dir

    def create_or_get_report(self, title: str) -> dict[str, str]:
        report = dict(self.primary.create_or_get_report(title))
        self._local_report = self.local.create_or_get_report(title)
        report["local_report_dir"] = str(self.local.report_dir.resolve())
        report["local_samples_csv"] = str(self.local.report_dir / "samples.csv")
        return report

    def read_values(self, spreadsheet_token: str, cell_range: str) -> list[list[Any]]:
        return self.primary.read_values(spreadsheet_token, cell_range)

    def write_values(self, spreadsheet_token: str, sheet_id: str, start_cell: str, values: list[list[Any]]) -> None:
        self.primary.write_values(spreadsheet_token, sheet_id, start_cell, values)
        self.local.write_values(self._local_spreadsheet_token(), sheet_id, start_cell, values)
        return None

    def write_file_cell(self, spreadsheet_token: str, sheet_id: str, cell: str, file_token: str) -> None:
        self.primary.write_file_cell(spreadsheet_token, sheet_id, cell, file_token)
        local_path = self._resolve_local_attachment_path(file_token)
        self.local.write_file_cell(self._local_spreadsheet_token(), sheet_id, cell, local_path)
        return None

    def upload_attachment(self, spreadsheet_token: str, file_path: str, file_name: str = "") -> str:
        primary_token = self.primary.upload_attachment(spreadsheet_token, file_path, file_name)
        local_path = self.local.upload_attachment(self._local_spreadsheet_token(), file_path, file_name)
        if primary_token:
            self._attachment_local_paths[str(primary_token)] = local_path
        return primary_token

    def _local_spreadsheet_token(self) -> str:
        if not self._local_report:
            self._local_report = self.local.create_or_get_report("WorkflowGym Report")
        return self._local_report["spreadsheet_token"]

    def _resolve_local_attachment_path(self, file_token: str) -> str:
        token = str(file_token or "").strip()
        if not token:
            return ""
        if token in self._attachment_local_paths:
            return self._attachment_local_paths[token]
        if Path(token).is_file():
            return token
        return token

    def __getattr__(self, name: str) -> Any:
        return getattr(self.primary, name)


def feishu_credentials_configured() -> bool:
    return bool(os.getenv("APP_ID", "").strip() and os.getenv("APP_SECRET", "").strip())


def feishu_sheet_admin_configured() -> bool:
    return bool(os.getenv("FEISHU_SHEET_ADMIN_MEMBER_ID", "").strip())


def should_use_local_spreadsheet(enable_real_feishu: bool) -> bool:
    if not enable_real_feishu:
        return True
    if not feishu_credentials_configured():
        return True
    return not feishu_sheet_admin_configured()


def local_spreadsheet_reason(enable_real_feishu: bool) -> str:
    if not enable_real_feishu:
        return "未启用 --enable-real-feishu"
    if not feishu_credentials_configured():
        return "未配置 APP_ID / APP_SECRET"
    if not feishu_sheet_admin_configured():
        return "未配置 FEISHU_SHEET_ADMIN_MEMBER_ID"
    return ""


def should_load_tasks_from_feishu(source_feishu_url: str) -> bool:
    return bool(str(source_feishu_url or "").strip())
