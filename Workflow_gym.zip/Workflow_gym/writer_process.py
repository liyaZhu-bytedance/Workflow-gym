from __future__ import annotations

import json
import os
from pathlib import Path

from .agents.factory import AgentFactory
from .attachment_uploader import AttachmentUploader, UploadResult
from .feishu_client import FeishuClient
from .records import ScoreResult, TaskFileResult, TrajectoryResult
from .sample_log import append_sample_log, read_existing_events


TASK_FIELD_COLUMNS = [
    "source_id",
    "题目",
    "启动方式",
    "采样次数",
    "tos_url",
    "输入文件路径",
    "输出文件路径",
    "final answer文件",
    "final answer 文件名",
    "image",
    "answer_type",
    "metric_type",
]

SAMPLES_SHEET_COLUMNS = {
    "output_files": "H",
    "traj_json": "I",
    "traj_md": "J",
    "sample_metadata_json": "K",
    "sample_log_json": "L",
    "answer_score": "M",
    "evidence": "N",
    "score_json": "O",
}


class WriterProcess:
    def __init__(self, client: FeishuClient, uploader: AttachmentUploader, agent_factory: AgentFactory):
        self.client = client
        self.uploader = uploader
        self.agent_factory = agent_factory
        self.report = self.client.create_or_get_report("WorkflowGym Report")
        self._samples_next_row = 2
        self._validation_next_row = 2
        self._sample_rows: dict[tuple[str, int], int] = {}
        self.write_report_headers()

    def write_agent_config(self) -> None:
        rows = [[
            "agent_name",
            "adapter_class",
            "enabled_hooks",
            "middlewares",
            "dynamic_prompts",
            "coordinate_transformer",
            "model",
            "base_url",
            "api_version",
            "request_kwargs",
            "default_headers",
        ]]
        for item in self.agent_factory.registrations():
            rows.append([
                item["agent_name"],
                item["adapter_class"],
                ",".join(item["enabled_hooks"]),
                ",".join(item["middlewares"]),
                str(item["dynamic_prompts"]),
                item["coordinate_transformer"],
                item.get("model", ""),
                item.get("base_url", ""),
                item.get("api_version", ""),
                str(item.get("request_kwargs") or {}),
                str(item.get("default_headers") or {}),
            ])
        self.client.write_values(
            self.report["spreadsheet_token"],
            self.report["agent_config_sheet_id"],
            "A1",
            rows,
        )

    def write_report_headers(self) -> None:
        self.client.write_values(
            self.report["spreadsheet_token"],
            self.report["validation_sheet_id"],
            "A1",
            [["task_id", "row_number", "status", "passed", "reason"]],
        )
        self.client.write_values(
            self.report["spreadsheet_token"],
            self.report["samples_sheet_id"],
            "A1",
            [[
                "record_type",
                "task_id",
                "sample_index",
                "status",
                "last_step",
                "error",
                "sample_dir_or_score_path",
                "output_files",
                "traj_json_upload",
                "traj_md_upload",
                "sample_metadata.json",
                "sample_log.json",
                "answer_score",
                "evidence",
                "score.json",
                *TASK_FIELD_COLUMNS,
            ]],
        )

    def write_validation_summary(self, payload: dict) -> None:
        validation = payload.get("validation") or {}
        values = [[
            validation.get("task_id") or payload.get("task_id", ""),
            validation.get("row_number", ""),
            validation.get("status", ""),
            validation.get("passed", ""),
            validation.get("reason", ""),
        ]]
        self.client.write_values(
            self.report["spreadsheet_token"],
            self.report["validation_sheet_id"],
            "A%s" % self._next_validation_row(),
            values,
        )

    def write_trajectory_payload(self, payload: dict) -> None:
        task_files = payload.get("task_files") or {}
        result = TrajectoryResult(
            run_id=payload["run_id"],
            task_id=payload["task_id"],
            sample_index=payload["sample_index"],
            status=payload.get("status", ""),
            sample_dir=payload["sample_dir"],
            traj_json_path=payload["traj_json_path"],
            traj_md_path=payload["traj_md_path"],
            id_json_path=payload["id_json_path"],
            sample_status_path=payload["sample_status_path"],
            last_step=payload.get("last_step", -1),
            error=payload.get("error", ""),
            task_files=TaskFileResult(**task_files),
            task_fields=payload.get("task_fields") or {},
        )
        self.write_trajectory_summary(result)

    def write_score_payload(self, payload: dict) -> None:
        score = score_result_from_payload(payload)
        row = self._sample_rows.get((str(score.task_id), int(score.sample_index)))
        if row:
            self._write_score_cells(row, score)
            return None
        self.write_score_summary(score)
        return None

    def write_trajectory_summary(self, result: TrajectoryResult) -> None:
        traj_json_upload = self.uploader.upload(self.report["spreadsheet_token"], result.traj_json_path)
        traj_md_upload = self.uploader.upload(self.report["spreadsheet_token"], result.traj_md_path)
        metadata_path = sample_metadata_path(result)
        metadata_upload = self.uploader.upload(self.report["spreadsheet_token"], metadata_path) if metadata_path else UploadResult(local_path="", status="missing")
        gt_production_files = gt_production_attachment_paths(result.sample_dir)
        values = [[
            "trajectory",
            result.task_id,
            result.sample_index,
            result.status,
            result.last_step,
            result.error,
            result.sample_dir,
            output_files_status(gt_production_files),
            traj_json_upload.status,
            traj_md_upload.status,
            metadata_upload.status,
            "",
            "",
            "",
            "",
            *task_field_values(result.task_fields, result.sample_index),
        ]]
        row = self._next_samples_row()
        self._sample_rows[(str(result.task_id), int(result.sample_index))] = row
        self.client.write_values(
            self.report["spreadsheet_token"],
            self.report["samples_sheet_id"],
            "A%s" % row,
            values,
        )
        self._sync_gt_production_attachments(row, result.sample_dir)
        self._write_upload_file_cell(row, "traj_json", traj_json_upload)
        self._write_upload_file_cell(row, "traj_md", traj_md_upload)
        self._write_upload_file_cell(row, "sample_metadata_json", metadata_upload)
        self._finalize_sample_log(row, result.sample_dir, result.task_id, result.sample_index)

    def write_score_summary(self, score: ScoreResult) -> None:
        score_upload = self.uploader.upload(self.report["spreadsheet_token"], score.score_json_path)
        metadata_path = sample_metadata_path_from_score(score)
        metadata_upload = self.uploader.upload(self.report["spreadsheet_token"], metadata_path) if metadata_path else UploadResult(local_path="", status="missing")
        values = [[
            "score",
            score.task_id,
            score.sample_index,
            "scored",
            "",
            score.check.get("error"),
            score.score_json_path,
            "",
            "",
            "",
            metadata_upload.status,
            "",
            score.check.get("answer_score"),
            score.check.get("evidence"),
            score_upload.status,
            *task_field_values(score.task_fields, score.sample_index),
        ]]
        row = self._next_samples_row()
        self.client.write_values(
            self.report["spreadsheet_token"],
            self.report["samples_sheet_id"],
            "A%s" % row,
            values,
        )
        self._write_upload_file_cell(row, "sample_metadata_json", metadata_upload)
        sample_dir = os.path.dirname(score.score_json_path) if score.score_json_path else ""
        self._finalize_sample_log(row, sample_dir, score.task_id, score.sample_index)
        self._write_upload_file_cell(row, "score_json", score_upload)

    def _write_score_cells(self, row: int, score: ScoreResult) -> None:
        score_upload = self.uploader.upload(self.report["spreadsheet_token"], score.score_json_path)
        self.client.write_values(
            self.report["spreadsheet_token"],
            self.report["samples_sheet_id"],
            "%s%s" % (SAMPLES_SHEET_COLUMNS["answer_score"], row),
            [[
                score.check.get("answer_score"),
                score.check.get("evidence"),
                score_upload.status,
            ]],
        )
        self._write_upload_file_cell(row, "score_json", score_upload)
        sample_dir = os.path.dirname(score.score_json_path) if score.score_json_path else ""
        self._finalize_sample_log(row, sample_dir, score.task_id, score.sample_index)

    def _finalize_sample_log(self, row: int, sample_dir: str, task_id: str, sample_index: int) -> None:
        if not sample_dir:
            return None
        self._append_report_url_to_sample_log(sample_dir, task_id, sample_index)
        sample_log_file = sample_log_path(
            TrajectoryResult(
                run_id="",
                task_id=str(task_id),
                sample_index=int(sample_index),
                status="",
                sample_dir=sample_dir,
                traj_json_path="",
                traj_md_path="",
                id_json_path="",
                sample_status_path="",
            )
        )
        if not sample_log_file:
            return None
        sample_log_upload = self.uploader.upload(self.report["spreadsheet_token"], sample_log_file)
        self.client.write_values(
            self.report["spreadsheet_token"],
            self.report["samples_sheet_id"],
            "%s%s" % (SAMPLES_SHEET_COLUMNS["sample_log_json"], row),
            [[sample_log_upload.status]],
        )
        self._write_upload_file_cell(row, "sample_log_json", sample_log_upload)
        return None

    def _append_report_url_to_sample_log(self, sample_dir: str, task_id: str, sample_index: int) -> None:
        report_url = str(self.report.get("spreadsheet_url") or "").strip()
        if not report_url:
            return None
        path = os.path.join(sample_dir, "sample_log.json")
        for event in reversed(read_existing_events(Path(path))):
            if event.get("source") != "writer":
                continue
            if (event.get("extra") or {}).get("report_url") == report_url:
                return None
        append_sample_log(
            sample_dir,
            "报表链接: %s" % report_url,
            source="writer",
            task_id=str(task_id),
            sample_index=int(sample_index),
            extra={"report_url": report_url},
        )
        return None

    def _sync_gt_production_attachments(self, row: int, sample_dir: str) -> None:
        for path in gt_production_attachment_paths(sample_dir):
            upload = self.uploader.upload(self.report["spreadsheet_token"], path)
            if upload.file_token:
                self._write_upload_file_cell(row, "output_files", upload)
                return None
        return None

    def _write_upload_file_cell(self, row: int, column_key: str, upload_result) -> None:
        if not upload_result.file_token:
            return None
        self.client.write_file_cell(
            self.report["spreadsheet_token"],
            self.report["samples_sheet_id"],
            "%s%s" % (SAMPLES_SHEET_COLUMNS[column_key], row),
            upload_result.file_token,
        )
        return None

    def _next_samples_row(self) -> int:
        row = self._samples_next_row
        self._samples_next_row += 1
        return row

    def _next_validation_row(self) -> int:
        row = self._validation_next_row
        self._validation_next_row += 1
        return row


def gt_production_attachment_paths(sample_dir: str) -> list[str]:
    base = Path(sample_dir) / "gt_production"
    if not sample_dir or not base.is_dir():
        return []
    return sorted(str(path) for path in base.rglob("*") if path.is_file())


def output_files_status(paths: list[str]) -> str:
    if not paths:
        return ""
    if len(paths) == 1:
        return Path(paths[0]).name
    return "uploaded:%s" % len(paths)


def task_field_values(fields: dict, sample_index: int) -> list:
    return [
        first_field(fields, "id", "ID", "task_id", "任务ID", "题目ID"),
        first_field(fields, "题目", "up", "UP", "task"),
        first_field(fields, "启动方式", "launch_mode", "launchMode"),
        sample_index,
        first_field(fields, "tos_url", "TOS_URL"),
        first_field(fields, "输入文件路径", "input_path"),
        first_field(fields, "输出文件路径", "output_path"),
        first_field(fields, "final answer文件", "final answer 文件", "final_answer_urls"),
        first_field(fields, "final answer 文件名", "final_answer文件名", "final_answer_names"),
        first_field(fields, "image", "image_id", "镜像ID"),
        first_field(fields, "answer_type"),
        first_field(fields, "metric_type", "判分类型"),
    ]


def first_field(fields: dict, *keys: str):
    for key in keys:
        value = fields.get(key)
        if value not in (None, ""):
            return value
    return ""


def score_result_from_payload(payload: dict) -> ScoreResult:
    score_json_path = str(payload.get("score_json_path") or "")
    check = dict(payload.get("check") or {})
    saved_at = str(payload.get("saved_at") or "")
    vm_screen_pixel_size = dict(payload.get("vm_screen_pixel_size") or {})
    if score_json_path and os.path.isfile(score_json_path):
        with open(score_json_path, encoding="utf-8") as file_obj:
            file_payload = json.load(file_obj)
        check = {**(file_payload.get("check") or {}), **check}
        saved_at = saved_at or str(file_payload.get("saved_at") or "")
        if not vm_screen_pixel_size:
            vm_screen_pixel_size = dict(file_payload.get("vm_screen_pixel_size") or {})
    return ScoreResult(
        run_id=payload["run_id"],
        task_id=str(payload["task_id"]),
        sample_index=int(payload["sample_index"]),
        score_json_path=score_json_path,
        saved_at=saved_at,
        check=check,
        vm_screen_pixel_size=vm_screen_pixel_size,
        task_fields=dict(payload.get("task_fields") or {}),
    )


def sample_metadata_path(result: TrajectoryResult) -> str:
    candidates = [
        result.id_json_path,
        os.path.join(result.sample_dir or "", "sample_metadata.json"),
    ]
    for path in candidates:
        if path and os.path.isfile(path):
            return path
    return ""


def sample_metadata_path_from_score(score: ScoreResult) -> str:
    if not score.score_json_path:
        return ""
    return sample_metadata_path(
        TrajectoryResult(
            run_id=score.run_id,
            task_id=score.task_id,
            sample_index=score.sample_index,
            status="",
            sample_dir=os.path.dirname(score.score_json_path),
            traj_json_path="",
            traj_md_path="",
            id_json_path=os.path.join(os.path.dirname(score.score_json_path), "sample_metadata.json"),
            sample_status_path="",
        )
    )


def sample_log_path(result: TrajectoryResult) -> str:
    path = os.path.join(result.sample_dir or "", "sample_log.json")
    return path if path and os.path.isfile(path) else ""


def sample_log_path_from_score(score: ScoreResult) -> str:
    if not score.score_json_path:
        return ""
    return sample_log_path(
        TrajectoryResult(
            run_id=score.run_id,
            task_id=score.task_id,
            sample_index=score.sample_index,
            status="",
            sample_dir=os.path.dirname(score.score_json_path),
            traj_json_path="",
            traj_md_path="",
            id_json_path="",
            sample_status_path="",
        )
    )

