#!/usr/bin/env python3
"""按 D 列镜像名前缀匹配 zZQpb4，更新 Ve8a1Q 的 E/G 列并标绿。

Ubuntu：zZQpb4 排除 .qcow2_bj / _bj_gui 结尾后做前缀匹配。
Windows：同时存在 _bj / _cloud 候选时优先 _cloud。
"""
from __future__ import annotations

import argparse
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.feishu_client import FeishuClient, column_to_number
from open_workflowgym.local_spreadsheet import feishu_credentials_configured
from open_workflowgym.tools.match_feishu_image_ids import (
    cell_address,
    cell_value,
    is_preview_windows2022_name,
    load_bashrc_env,
    normalize_image_key,
    read_sheet_rows_chunked,
    resolve_spreadsheet_token,
    write_single_cell_value,
)

DEFAULT_WIKI_URL = os.getenv("FEISHU_WIKI_URL", "https://example.feishu.local/wiki/PLACEHOLDER")
DEFAULT_SOURCE_SHEET_ID = "zZQpb4"
DEFAULT_TARGET_SHEET_ID = "Ve8a1Q"
SOURCE_IMAGE_NAME_COLUMN = column_to_number("B") - 1
SOURCE_IMAGE_ID_COLUMN = column_to_number("C") - 1
TARGET_IMAGE_NAME_COLUMN = column_to_number("D") - 1
TARGET_IMAGE_ID_COLUMN = column_to_number("E") - 1
TARGET_EXPORT_NAME_COLUMN = column_to_number("G") - 1
UPDATED_BACK_COLOR = "#d9f7be"
EXCLUDED_SOURCE_SUFFIXES = (".qcow2_bj", "_bj_gui")


def should_exclude_source_image_name(name: object) -> bool:
    text = cell_value([name], 0) if not isinstance(name, str) else str(name or "").strip()
    lowered = text.lower()
    return lowered.endswith(".qcow2_bj") or lowered.endswith("_bj_gui")


def sheet_cell_range(sheet_id: str, row_index: int, column_index: int) -> str:
    address = cell_address(row_index, column_index)
    return "%s!%s:%s" % (sheet_id, address, address)


def build_prefix_lookup(
    source_rows: list[list[Any]],
) -> dict[str, list[tuple[str, str]]]:
    lookup: dict[str, list[tuple[str, str]]] = defaultdict(list)
    for row_index, row in enumerate(source_rows):
        if row_index == 0:
            continue
        image_name = cell_value(row, SOURCE_IMAGE_NAME_COLUMN)
        image_id = cell_value(row, SOURCE_IMAGE_ID_COLUMN)
        if not image_name or not image_id or should_exclude_source_image_name(image_name):
            continue
        key = normalize_image_key(image_name)
        if not key:
            continue
        entry = (image_name, image_id)
        if entry not in lookup[key]:
            lookup[key].append(entry)
    return dict(lookup)


def is_windows_image_name(name: object) -> bool:
    text = cell_value([name], 0) if not isinstance(name, str) else str(name or "").strip()
    if not text:
        return False
    lowered = text.lower()
    return is_preview_windows2022_name(text) or "windows" in lowered


def ends_with_cloud_suffix(name: str) -> bool:
    return name.lower().endswith("_cloud")


def ends_with_bj_suffix(name: str) -> bool:
    lowered = name.lower()
    return lowered.endswith("_bj") and not lowered.endswith("_bj_gui")


def resolve_prefix_match(
    target_image_name: str,
    candidates: list[tuple[str, str]],
) -> tuple[str, str] | None:
    if not candidates:
        return None
    for image_name, image_id in candidates:
        if image_name == target_image_name:
            return image_name, image_id
    if len(candidates) == 1:
        return candidates[0]
    if is_windows_image_name(target_image_name):
        cloud_candidates = [item for item in candidates if ends_with_cloud_suffix(item[0])]
        if cloud_candidates:
            return cloud_candidates[0]
        bj_candidates = [item for item in candidates if ends_with_bj_suffix(item[0])]
        if bj_candidates:
            return bj_candidates[0]
        return candidates[0]
    non_bj = [item for item in candidates if not ends_with_bj_suffix(item[0])]
    if len(non_bj) == 1:
        return non_bj[0]
    if non_bj:
        return non_bj[0]
    bj_candidates = [item for item in candidates if ends_with_bj_suffix(item[0])]
    if bj_candidates:
        return bj_candidates[0]
    return candidates[0]


def find_updates(
    target_rows: list[list[Any]],
    lookup: dict[str, list[tuple[str, str]]],
) -> list[dict[str, Any]]:
    updates: list[dict[str, Any]] = []
    for row_index, row in enumerate(target_rows):
        if row_index == 0:
            continue
        target_image_name = cell_value(row, TARGET_IMAGE_NAME_COLUMN)
        if not target_image_name:
            continue
        match_key = normalize_image_key(target_image_name)
        if not match_key:
            continue
        resolved = resolve_prefix_match(target_image_name, lookup.get(match_key, []))
        if resolved is None:
            continue
        expected_image_name, expected_image_id = resolved
        current_image_id = cell_value(row, TARGET_IMAGE_ID_COLUMN)
        current_export_name = cell_value(row, TARGET_EXPORT_NAME_COLUMN)
        if current_image_id == expected_image_id and current_export_name == expected_image_name:
            continue
        updates.append(
            {
                "row_index": row_index,
                "match_key": match_key,
                "target_image_name": target_image_name,
                "current_image_id": current_image_id,
                "current_export_name": current_export_name,
                "expected_image_id": expected_image_id,
                "expected_export_name": expected_image_name,
            }
        )
    return updates


def apply_updates(
    client: FeishuClient,
    spreadsheet_token: str,
    sheet_id: str,
    updates: list[dict[str, Any]],
    *,
    dry_run: bool = False,
) -> dict[str, Any]:
    updated_ranges: list[str] = []
    updated_row_count = 0
    failed_updates: list[dict[str, Any]] = []

    for item in updates:
        row_index = int(item["row_index"])
        expected_image_id = str(item["expected_image_id"])
        expected_export_name = str(item["expected_export_name"])
        image_id_range = sheet_cell_range(sheet_id, row_index, TARGET_IMAGE_ID_COLUMN)
        export_name_range = sheet_cell_range(sheet_id, row_index, TARGET_EXPORT_NAME_COLUMN)
        if dry_run:
            updated_ranges.extend([image_id_range, export_name_range])
            updated_row_count += 1
            continue
        try:
            write_single_cell_value(
                client,
                spreadsheet_token,
                sheet_id,
                row_index,
                TARGET_IMAGE_ID_COLUMN,
                expected_image_id,
            )
            write_single_cell_value(
                client,
                spreadsheet_token,
                sheet_id,
                row_index,
                TARGET_EXPORT_NAME_COLUMN,
                expected_export_name,
            )
            client.set_cells_background(
                spreadsheet_token,
                [image_id_range, export_name_range],
                back_color=UPDATED_BACK_COLOR,
            )
            updated_ranges.extend([image_id_range, export_name_range])
            updated_row_count += 1
        except Exception as exc:
            failed_updates.append({**item, "error": str(exc)})

    return {
        "updated_count": updated_row_count,
        "failed_count": len(failed_updates),
        "updated_ranges": updated_ranges,
        "failed_updates": failed_updates,
    }


def run_sync(
    client: FeishuClient,
    *,
    wiki_url: str = DEFAULT_WIKI_URL,
    source_sheet_id: str = DEFAULT_SOURCE_SHEET_ID,
    target_sheet_id: str = DEFAULT_TARGET_SHEET_ID,
    dry_run: bool = False,
) -> dict[str, Any]:
    spreadsheet_token = resolve_spreadsheet_token(client, wiki_url)
    source_rows = read_sheet_rows_chunked(client, spreadsheet_token, source_sheet_id)
    target_rows = read_sheet_rows_chunked(client, spreadsheet_token, target_sheet_id)
    lookup = build_prefix_lookup(source_rows)
    updates = find_updates(target_rows, lookup)
    apply_result = apply_updates(
        client,
        spreadsheet_token,
        target_sheet_id,
        updates,
        dry_run=dry_run,
    )

    matched_count = 0
    consistent_count = 0
    for row_index, row in enumerate(target_rows):
        if row_index == 0:
            continue
        target_image_name = cell_value(row, TARGET_IMAGE_NAME_COLUMN)
        if not target_image_name:
            continue
        match_key = normalize_image_key(target_image_name)
        resolved = resolve_prefix_match(target_image_name, lookup.get(match_key, []))
        if resolved is None:
            continue
        matched_count += 1
        expected_image_name, expected_image_id = resolved
        if (
            cell_value(row, TARGET_IMAGE_ID_COLUMN) == expected_image_id
            and cell_value(row, TARGET_EXPORT_NAME_COLUMN) == expected_image_name
        ):
            consistent_count += 1

    return {
        "spreadsheet_token": spreadsheet_token,
        "source_sheet_id": source_sheet_id,
        "target_sheet_id": target_sheet_id,
        "source_rows": len(source_rows),
        "target_rows": len(target_rows),
        "lookup_count": len(lookup),
        "matched_count": matched_count,
        "consistent_count": consistent_count,
        "need_update_count": len(updates),
        "preview_updates": updates[:10],
        **apply_result,
    }


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "按 Ve8a1Q.D 镜像名前缀匹配 zZQpb4.B："
            "Ubuntu 排除 .qcow2_bj / _bj_gui 结尾；"
            "Windows 同时存在 _bj / _cloud 时优先 _cloud；"
            "将 zZQpb4.C 写入 Ve8a1Q.E、zZQpb4.B 写入 Ve8a1Q.G，并标绿"
        )
    )
    parser.add_argument("--wiki-url", default=DEFAULT_WIKI_URL)
    parser.add_argument("--source-sheet-id", default=DEFAULT_SOURCE_SHEET_ID)
    parser.add_argument("--target-sheet-id", default=DEFAULT_TARGET_SHEET_ID)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--bashrc", default="")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    load_bashrc_env(bashrc_path=args.bashrc)
    if not feishu_credentials_configured():
        print("缺少 APP_ID 或 APP_SECRET，请确认已写入 ~/.bashrc 或当前环境变量", file=sys.stderr)
        return 1

    client = FeishuClient(dry_run=False)
    result = run_sync(
        client,
        wiki_url=args.wiki_url,
        source_sheet_id=args.source_sheet_id,
        target_sheet_id=args.target_sheet_id,
        dry_run=args.dry_run,
    )

    print("Ve8a1Q 前缀匹配 zZQpb4 同步完成")
    print("  source sheet: %s (%s 行)" % (result["source_sheet_id"], result["source_rows"]))
    print("  target sheet: %s (%s 行)" % (result["target_sheet_id"], result["target_rows"]))
    print("  来源前缀映射: %s" % result["lookup_count"])
    print("  D 列匹配行数: %s" % result["matched_count"])
    print("  已一致行数: %s" % result["consistent_count"])
    print("  需更新行数: %s" % result["need_update_count"])
    if args.dry_run:
        print("预览前 10 条待更新:")
        for item in result["preview_updates"]:
            print(
                "  row=%s key=%s D=%s"
                % (item["row_index"] + 1, item["match_key"], item["target_image_name"])
            )
            print(
                "    E: %s -> %s"
                % (item["current_image_id"] or "(空)", item["expected_image_id"])
            )
            print(
                "    G: %s -> %s"
                % (item["current_export_name"] or "(空)", item["expected_export_name"])
            )
    else:
        print("  已更新: %s" % result["updated_count"])
        print("  更新失败: %s" % result["failed_count"])
        if result["failed_updates"]:
            for item in result["failed_updates"][:5]:
                print("  失败 row=%s error=%s" % (item["row_index"] + 1, item["error"]))
        print(
            "已写入: %s?sheet=%s"
            % (args.wiki_url.split("?")[0], result["target_sheet_id"])
        )
    return 0 if result["failed_count"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
