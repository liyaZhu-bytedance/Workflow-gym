#!/usr/bin/env python3
"""获取 cn-guangzhou 区域自定义镜像（visibility=private），并写入飞书电子表格。

示例:
  export AK=... SK=... APP_ID=... APP_SECRET=...
  python tools/sync_guangzhou_images_to_feishu.py

  # 仅预览，不写入飞书
  python tools/sync_guangzhou_images_to_feishu.py --dry-run
"""
from __future__ import annotations

import argparse
import os
import shlex
import subprocess
import sys
import warnings
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

import volcenginesdkcore
import volcenginesdkecs

from open_workflowgym.envs.volcengine_env import get_result_payload, image_os_type_label, image_record_field, to_plain_dict
from open_workflowgym.feishu_client import FeishuClient
from open_workflowgym.local_spreadsheet import feishu_credentials_configured
from open_workflowgym.tools.match_feishu_image_ids import (
    WriteSheetResult,
    resolve_spreadsheet_token,
    write_output_sheet,
)

DEFAULT_WIKI_URL = os.getenv("FEISHU_WIKI_URL", "https://example.feishu.local/wiki/PLACEHOLDER")
DEFAULT_OUTPUT_SHEET_ID = "zZQpb4"
DEFAULT_REGION = "cn-guangzhou"
DEFAULT_LIST_LIMIT = 5000
DEFAULT_PAGE_SIZE = 100
DEFAULT_IMAGE_VISIBILITY = "private"
SHEET_HEADERS = ("序号", "镜像名称", "镜像id", "镜像的操作系统")
BASHRC_ENV_NAMES = ("AK", "SK", "APP_ID", "APP_SECRET")


def load_shell_env(names: tuple[str, ...] = BASHRC_ENV_NAMES, shell_config_paths: list[str] | None = None) -> None:
    missing = [name for name in names if not os.getenv(name, "").strip()]
    if not missing:
        return
    candidates = shell_config_paths or [
        os.path.expanduser("~/.bashrc"),
        os.path.expanduser("~/.zshrc"),
        os.path.expanduser("~/.profile"),
    ]
    for config_path in candidates:
        config = Path(config_path)
        if not config.is_file():
            continue
        config_quoted = shlex.quote(str(config))
        shell = "zsh" if config.name.endswith("zshrc") else "bash"
        for name in list(missing):
            try:
                completed = subprocess.run(
                    [
                        shell,
                        "-lc",
                        "set -a; source %s >/dev/null 2>&1; set +a; printf '%%s' \"${%s:-}\""
                        % (config_quoted, name),
                    ],
                    capture_output=True,
                    text=True,
                    timeout=15,
                    check=False,
                )
            except (OSError, subprocess.TimeoutExpired):
                continue
            value = (completed.stdout or "").strip()
            if value:
                os.environ[name] = value
                missing.remove(name)
        if not missing:
            return


def create_api_instance(region: str) -> volcenginesdkecs.ECSApi:
    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = region
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkecs.ECSApi()


def image_display_name(image: dict[str, Any]) -> str:
    return image_record_field(image, "ImageName", "image_name") or image_record_field(image, "ImageId", "image_id")


def image_visibility(image: dict[str, Any]) -> str:
    return image_record_field(image, "Visibility", "visibility").lower()


def is_custom_image(image: dict[str, Any]) -> bool:
    return image_visibility(image) == DEFAULT_IMAGE_VISIBILITY


def list_region_images(
    api_instance: volcenginesdkecs.ECSApi,
    *,
    limit: int = DEFAULT_LIST_LIMIT,
    page_size: int = DEFAULT_PAGE_SIZE,
    visibility: str = DEFAULT_IMAGE_VISIBILITY,
) -> list[dict[str, Any]]:
    images: list[dict[str, Any]] = []
    next_token = ""
    while len(images) < limit:
        request_kwargs: dict[str, Any] = {
            "max_results": min(page_size, limit - len(images)),
            "visibility": visibility,
        }
        if next_token:
            request_kwargs["next_token"] = next_token
        response = api_instance.describe_images(volcenginesdkecs.DescribeImagesRequest(**request_kwargs))
        result = get_result_payload(to_plain_dict(response))
        page_images = result.get("Images") or result.get("images") or []
        images.extend(page_images)
        next_token = result.get("NextToken") or result.get("next_token") or ""
        if not next_token or not page_images:
            break
    return [image for image in images[:limit] if is_custom_image(image)]


def build_sheet_rows(images: list[dict[str, Any]]) -> list[list[str]]:
    sorted_images = sorted(images, key=lambda item: image_display_name(item).lower())
    rows: list[list[str]] = [list(SHEET_HEADERS)]
    for index, image in enumerate(sorted_images, start=1):
        rows.append(
            [
                str(index),
                image_display_name(image),
                image_record_field(image, "ImageId", "image_id"),
                image_os_type_label(image),
            ]
        )
    return rows


def run_sync(
    client: FeishuClient,
    api_instance: volcenginesdkecs.ECSApi,
    *,
    wiki_url: str = DEFAULT_WIKI_URL,
    output_sheet_id: str = DEFAULT_OUTPUT_SHEET_ID,
    list_limit: int = DEFAULT_LIST_LIMIT,
    dry_run: bool = False,
) -> dict[str, Any]:
    images = list_region_images(api_instance, limit=list_limit)
    output_rows = build_sheet_rows(images)
    spreadsheet_token = resolve_spreadsheet_token(client, wiki_url)

    if not dry_run:
        write_result = write_output_sheet(client, spreadsheet_token, output_sheet_id, output_rows)
    else:
        write_result = WriteSheetResult()

    return {
        "spreadsheet_token": spreadsheet_token,
        "output_sheet_id": output_sheet_id,
        "image_count": len(images),
        "output_rows": len(output_rows),
        "attachment_count": write_result.attachment_count,
        "failed_cell_count": write_result.failed_cell_count,
        "failed_row_count": write_result.failed_row_count,
        "output_preview": output_rows[:5],
    }


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="获取 cn-guangzhou 自定义镜像，按序号/镜像名称/镜像id/镜像的操作系统 写入飞书表格"
    )
    parser.add_argument("--wiki-url", default=DEFAULT_WIKI_URL, help="飞书 wiki 表格 URL")
    parser.add_argument("--output-sheet-id", default=DEFAULT_OUTPUT_SHEET_ID, help="目标 sheet id")
    parser.add_argument("--region", default=DEFAULT_REGION, help="火山引擎区域，默认 cn-guangzhou")
    parser.add_argument("--list-limit", type=int, default=DEFAULT_LIST_LIMIT, help="最多拉取镜像数量")
    parser.add_argument("--dry-run", action="store_true", help="只拉取镜像并预览，不写入飞书")
    parser.add_argument("--bashrc", default="", help="可选，指定 shell 配置文件路径")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    if args.bashrc:
        load_shell_env(BASHRC_ENV_NAMES, [args.bashrc])
    else:
        load_shell_env(BASHRC_ENV_NAMES)

    if not os.getenv("AK", "").strip() or not os.getenv("SK", "").strip():
        print("缺少 AK 或 SK，请确认已写入 ~/.bashrc 或当前环境变量", file=sys.stderr)
        return 1
    if not feishu_credentials_configured():
        print("缺少 APP_ID 或 APP_SECRET，请确认已写入 ~/.bashrc 或当前环境变量", file=sys.stderr)
        return 1

    client = FeishuClient(dry_run=False)
    api_instance = create_api_instance(args.region)
    result = run_sync(
        client,
        api_instance,
        wiki_url=args.wiki_url,
        output_sheet_id=args.output_sheet_id,
        list_limit=args.list_limit,
        dry_run=args.dry_run,
    )

    print("cn-guangzhou 自定义镜像同步完成")
    print("  region: %s" % args.region)
    print("  spreadsheet_token: %s" % result["spreadsheet_token"])
    print("  output sheet: %s (%s 行)" % (result["output_sheet_id"], result["output_rows"]))
    print("  镜像数量: %s" % result["image_count"])
    if args.dry_run:
        print("预览前 5 行:")
        for row in result["output_preview"]:
            print("  %s" % row)
    else:
        print(
            "已写入: %s?sheet=%s"
            % (args.wiki_url.split("?")[0], result["output_sheet_id"])
        )
        print("  附件单元格: %s" % result["attachment_count"])
        print("  写入失败单元格: %s" % result["failed_cell_count"])
        print("  写入失败整行: %s" % result["failed_row_count"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
