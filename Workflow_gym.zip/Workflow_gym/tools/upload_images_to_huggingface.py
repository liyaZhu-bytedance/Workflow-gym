#!/usr/bin/env python3
"""将本地镜像/大文件夹上传到 Hugging Face Hub（推荐 upload_large_folder）。

适用：文件夹很大（>5GB）或文件很多（>1000），支持断点续传与多线程。

示例:
  export HF_TOKEN=hf_xxx   # 或 HUGGINGFACE_HUB_TOKEN
  python tools/upload_images_to_huggingface.py \\
    --repo-id your-org/workflowgym-images \\
    --folder-path /path/to/local/images \\
    --repo-type model

  # 上传数据集仓库
  python tools/upload_images_to_huggingface.py \\
    --repo-id your-org/workflowgym-images \\
    --folder-path ./exports/images \\
    --repo-type dataset

  # 仅预览将上传的文件统计，不实际上传
  python tools/upload_images_to_huggingface.py \\
    --repo-id your-org/workflowgym-images \\
    --folder-path ./exports/images \\
    --dry-run

  # 可选：大带宽上传
  export HF_XET_HIGH_PERFORMANCE=1

依赖:
  pip install 'huggingface_hub>=0.25.0'
"""
from __future__ import annotations

import argparse
import os
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Iterable

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

HF_ENV_NAMES = ("HF_TOKEN", "HUGGINGFACE_HUB_TOKEN", "HUGGING_FACE_HUB_TOKEN")
DEFAULT_REPO_TYPE = "model"
DEFAULT_MIN_HF_HUB_VERSION = "0.25.0"
DEFAULT_UPLOAD_CONCURRENCY = 10


def normalize_upload_workers(num_workers: int | None) -> int:
    if num_workers is None:
        env_value = (os.getenv("HF_UPLOAD_NUM_WORKERS") or os.getenv("IMAGE_UPLOAD_CONCURRENCY") or "").strip()
        if env_value:
            num_workers = int(env_value)
        else:
            num_workers = DEFAULT_UPLOAD_CONCURRENCY
    return max(1, min(int(num_workers), DEFAULT_UPLOAD_CONCURRENCY))


def load_shell_env(names: tuple[str, ...] = HF_ENV_NAMES) -> None:
    if resolve_hf_token():
        return
    missing = [name for name in names if not os.getenv(name, "").strip()]
    if not missing:
        return
    for config_name in (".zshrc", ".bashrc", ".profile"):
        config_path = Path.home() / config_name
        if not config_path.is_file():
            continue
        config_quoted = shlex.quote(str(config_path))
        shell = "zsh" if config_name == ".zshrc" else "bash"
        for name in list(missing):
            try:
                completed = subprocess.run(
                    [
                        shell,
                        "-lc",
                        "set -a; source %s >/dev/null 2>&1; set +a; printf '%%s' \"${%s:-}\""
                        % (config_quoted, name),
                    ],
                    capture_output=True,
                    text=True,
                    timeout=15,
                    check=False,
                )
            except (OSError, subprocess.TimeoutExpired):
                continue
            value = (completed.stdout or "").strip()
            if value:
                os.environ[name] = value
                if name != "HF_TOKEN":
                    os.environ.setdefault("HF_TOKEN", value)
                missing.remove(name)


def resolve_hf_token() -> str:
    for name in HF_ENV_NAMES:
        value = (os.getenv(name) or "").strip()
        if value:
            os.environ.setdefault("HF_TOKEN", value)
            return value
    return ""


def parse_patterns(values: list[str] | None) -> list[str] | None:
    if not values:
        return None
    patterns: list[str] = []
    for item in values:
        patterns.extend(part.strip() for part in item.split(",") if part.strip())
    return patterns or None


def iter_local_files(folder_path: Path, *, allow_patterns: list[str] | None, ignore_patterns: list[str] | None) -> list[Path]:
    from huggingface_hub.utils import filter_repo_objects

    files = [path for path in folder_path.rglob("*") if path.is_file()]
    relative_paths = [str(path.relative_to(folder_path).as_posix()) for path in files]
    filtered = filter_repo_objects(
        relative_paths,
        allow_patterns=allow_patterns,
        ignore_patterns=ignore_patterns,
    )
    allowed = set(filtered)
    return [path for path in files if path.relative_to(folder_path).as_posix() in allowed]


def summarize_folder(
    folder_path: Path,
    *,
    allow_patterns: list[str] | None,
    ignore_patterns: list[str] | None,
) -> dict[str, object]:
    files = iter_local_files(folder_path, allow_patterns=allow_patterns, ignore_patterns=ignore_patterns)
    total_bytes = sum(path.stat().st_size for path in files)
    return {
        "file_count": len(files),
        "total_bytes": total_bytes,
        "total_gib": round(total_bytes / (1024 ** 3), 3),
        "sample_files": [str(path.relative_to(folder_path)) for path in files[:10]],
    }


def ensure_hf_hub_version(min_version: str = DEFAULT_MIN_HF_HUB_VERSION) -> str:
    try:
        from huggingface_hub import __version__ as hf_version
    except ImportError as exc:
        raise SystemExit(
            "缺少 huggingface_hub，请先安装: pip install 'huggingface_hub>=%s'" % min_version
        ) from exc
    try:
        from packaging.version import Version

        if Version(hf_version) < Version(min_version):
            raise SystemExit(
                "huggingface_hub 版本过低: %s，upload_large_folder 需要 >= %s"
                % (hf_version, min_version)
            )
    except ImportError:
        pass
    return hf_version


def upload_large_folder_to_hub(
    *,
    repo_id: str,
    folder_path: Path,
    repo_type: str,
    revision: str | None,
    private: bool | None,
    allow_patterns: list[str] | None,
    ignore_patterns: list[str] | None,
    num_workers: int | None,
    use_cli: bool,
) -> str:
    token = resolve_hf_token()
    if not token:
        raise SystemExit("缺少 HF_TOKEN（或 HUGGINGFACE_HUB_TOKEN），无法上传到 Hugging Face")

    resolved_workers = normalize_upload_workers(num_workers)
    print("HF 上传并发数: %s" % resolved_workers)

    if use_cli:
        command = [
            "huggingface-cli",
            "upload-large-folder",
            repo_id,
            str(folder_path),
            "--repo-type",
            repo_type,
        ]
        if revision:
            command.extend(["--revision", revision])
        command.extend(["--num-workers", str(resolved_workers)])
        patterns = parse_cli_patterns(allow_patterns, "--allow-pattern")
        command.extend(patterns)
        patterns = parse_cli_patterns(ignore_patterns, "--ignore-pattern")
        command.extend(patterns)
        env = os.environ.copy()
        env.setdefault("HF_TOKEN", token)
        completed = subprocess.run(command, check=False, env=env)
        if completed.returncode != 0:
            raise SystemExit("huggingface-cli upload-large-folder 失败，exit_code=%s" % completed.returncode)
        return "cli://%s" % repo_id

    from huggingface_hub import HfApi

    api = HfApi(token=token)
    create_private = True if private is None else bool(private)
    api.create_repo(
        repo_id=repo_id,
        repo_type=repo_type,
        private=create_private,
        exist_ok=True,
    )
    upload_kwargs = {
        "repo_id": repo_id,
        "folder_path": str(folder_path),
        "repo_type": repo_type,
    }
    if revision:
        upload_kwargs["revision"] = revision
    if private is not None:
        upload_kwargs["private"] = private
    if allow_patterns:
        upload_kwargs["allow_patterns"] = allow_patterns
    if ignore_patterns:
        upload_kwargs["ignore_patterns"] = ignore_patterns
    upload_kwargs["num_workers"] = resolved_workers

    if hasattr(api, "upload_large_folder"):
        api.upload_large_folder(**upload_kwargs)
        return "https://huggingface.co/%s" % repo_id

    print("当前 huggingface_hub 无 upload_large_folder，回退到 upload_folder（支持断点续传）")
    upload_kwargs.pop("num_workers", None)
    api.upload_folder(**upload_kwargs)
    return "https://huggingface.co/%s" % repo_id


def parse_cli_patterns(patterns: list[str] | None, flag: str) -> list[str]:
    if not patterns:
        return []
    args: list[str] = []
    for pattern in patterns:
        args.extend([flag, pattern])
    return args


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="上传本地大文件夹到 Hugging Face Hub")
    parser.add_argument("--repo-id", required=True, help="HF 仓库 ID，如 org/repo-name")
    parser.add_argument("--folder-path", required=True, help="本地文件夹路径")
    parser.add_argument(
        "--repo-type",
        default=os.getenv("HF_REPO_TYPE", DEFAULT_REPO_TYPE),
        choices=("model", "dataset", "space"),
        help="仓库类型，默认 model",
    )
    parser.add_argument("--revision", default=os.getenv("HF_REVISION", "").strip() or None, help="目标分支/tag")
    parser.add_argument(
        "--private",
        dest="private",
        action="store_true",
        default=None,
        help="若仓库不存在则创建为私有仓库",
    )
    parser.add_argument(
        "--public",
        dest="private",
        action="store_false",
        help="若仓库不存在则创建为公开仓库",
    )
    parser.add_argument(
        "--num-workers",
        type=int,
        default=None,
        help="上传并发 worker 数，默认 10，最大 10",
    )
    parser.add_argument(
        "--allow-pattern",
        action="append",
        default=None,
        help="仅上传匹配的文件（可重复，或用逗号分隔）",
    )
    parser.add_argument(
        "--ignore-pattern",
        action="append",
        default=None,
        help="忽略匹配的文件（可重复，或用逗号分隔）",
    )
    parser.add_argument(
        "--use-cli",
        action="store_true",
        help="改用 huggingface-cli upload-large-folder，而不是 Python API",
    )
    parser.add_argument("--dry-run", action="store_true", help="只统计本地文件，不实际上传")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    folder_path = Path(args.folder_path).expanduser().resolve()
    if not folder_path.is_dir():
        raise SystemExit("folder-path 不是有效目录: %s" % folder_path)

    load_shell_env()
    hf_version = ensure_hf_hub_version()
    allow_patterns = parse_patterns(args.allow_pattern)
    ignore_patterns = parse_patterns(args.ignore_pattern)
    summary = summarize_folder(folder_path, allow_patterns=allow_patterns, ignore_patterns=ignore_patterns)

    print("huggingface_hub version:", hf_version)
    print("repo_id:", args.repo_id)
    print("repo_type:", args.repo_type)
    print("folder_path:", folder_path)
    print("file_count:", summary["file_count"])
    print("total_size_gib:", summary["total_gib"])
    if summary["sample_files"]:
        print("sample_files:")
        for item in summary["sample_files"]:
            print("  -", item)

    if args.dry_run:
        print("dry-run 完成，未上传。")
        return 0

    repo_url = upload_large_folder_to_hub(
        repo_id=args.repo_id,
        folder_path=folder_path,
        repo_type=args.repo_type,
        revision=args.revision,
        private=args.private,
        allow_patterns=allow_patterns,
        ignore_patterns=ignore_patterns,
        num_workers=args.num_workers,
        use_cli=args.use_cli,
    )
    print("上传完成:", repo_url)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
