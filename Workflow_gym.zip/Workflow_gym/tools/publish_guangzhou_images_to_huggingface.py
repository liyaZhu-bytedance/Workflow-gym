#!/usr/bin/env python3
"""从飞书 image 列（或本地 CSV）读取镜像 ID，匹配 cn-guangzhou 非 Windows 镜像后发布。

本脚本可单独拷贝到任意目录运行（不依赖同仓库其它 tools/ 或 open_workflowgym 包内模块）。

pip 依赖:
  pip install 'volcengine-python-sdk>=1.0.0' 'huggingface_hub>=0.25.0'

另需: AK/SK；上传 HF 时 HF_TOKEN + HF_REPO_ID；读飞书时 APP_ID/APP_SECRET（--from-csv 可省）。
tosutil 会自动下载到本地缓存（也可自备 TOSUTIL_BINARY）。

默认流程（生产者-消费者）:
  1. 读取飞书 wiki sheet 的 image 列，去重（或 --from-csv）
  2. 在 cn-guangzhou 私有镜像中按 ImageId 精确匹配
  3. 过滤掉 Windows 镜像
  4. 启动时扫描 TOS + 对照 HF 仓实际文件，回写已成功上传状态
  5. 生产者: ExportImage -> TOS（已存在则跳过）成功即入队
  6. 消费者(并发): 本地下载 -> Hugging Face 上传 -> 删本地/清回收站
  7. 同步写入本地 CSV 进度表

空间与仓库策略:
  - 启动时扫描 TOS 桶，把已存在的目标 *_system.qcow2 与真实 Size 写入 manifest/CSV
  - 启动时扫描 HF_REPO_ID / -2 / -3...：仓内已有对应路径则标 uploaded（优先写基仓路径）
  - TOS 已有对象时跳过 ExportImage，直接作为生产者结果入队
  - 本地下载前按 TOS 真实大小检查磁盘；不够则跳过该镜像继续下一个
  - 上传 HF 成功后删除本地 qcow2，并清空本机回收站以尽快释放空间
  - HF 按 HF_REPO_ID 递增自动 create_repo（name, name-2, name-3...）
  - 当前仓软上限不够则换下一仓；全部满则停本地下载/HF，TOS 导出仍继续
  - --export-concurrency 控制导出并发；--num-workers 控制消费管道并发（下→传→删）

示例:
  export AK=... SK=... HF_TOKEN=hf_xxx HF_REPO_ID=user/openworkflowgym
  python publish_guangzhou_images_to_huggingface.py --from-csv --all --export-concurrency 5 --num-workers 1 --resume
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import platform
import re
import shlex
import shutil
import stat
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from queue import Queue
from typing import Any

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

import volcenginesdkcore
import volcenginesdkecs
from volcenginesdkcore.rest import ApiException

# =============================================================================
# --- env helpers ---
# =============================================================================

ECS_ENV_NAMES = ("AK", "SK")
HF_ENV_NAMES = ("HF_TOKEN", "HUGGINGFACE_HUB_TOKEN", "HUGGING_FACE_HUB_TOKEN")
FEISHU_ENV_NAMES = ("APP_ID", "APP_SECRET")
COMBINED_ENV_NAMES = tuple(dict.fromkeys(ECS_ENV_NAMES + HF_ENV_NAMES + FEISHU_ENV_NAMES))


def load_shell_env(names: tuple[str, ...] = COMBINED_ENV_NAMES) -> None:
    missing = [name for name in names if not os.getenv(name, "").strip()]
    if not missing:
        return
    for config_name in (".zshrc", ".bashrc", ".profile"):
        config_path = Path.home() / config_name
        if not config_path.is_file():
            continue
        config_quoted = shlex.quote(str(config_path))
        shell = "zsh" if config_name == ".zshrc" else "bash"
        for name in list(missing):
            try:
                completed = subprocess.run(
                    [
                        shell,
                        "-lc",
                        "set -a; source %s >/dev/null 2>&1; set +a; printf '%%s' \"${%s:-}\""
                        % (config_quoted, name),
                    ],
                    capture_output=True,
                    text=True,
                    timeout=15,
                    check=False,
                )
            except (OSError, subprocess.TimeoutExpired):
                continue
            value = (completed.stdout or "").strip()
            if value:
                os.environ[name] = value
                if name in HF_ENV_NAMES and name != "HF_TOKEN":
                    os.environ.setdefault("HF_TOKEN", value)
                missing.remove(name)


def load_ecs_shell_env(names: tuple[str, ...] = ECS_ENV_NAMES) -> None:
    load_shell_env(names)


def load_hf_shell_env(names: tuple[str, ...] = HF_ENV_NAMES) -> None:
    if any(os.getenv(n, "").strip() for n in HF_ENV_NAMES):
        resolve_hf_token()
        return
    load_shell_env(names)


def load_feishu_shell_env(names: tuple[str, ...] = FEISHU_ENV_NAMES) -> None:
    load_shell_env(names)


def load_bashrc_env(names: tuple[str, ...] = FEISHU_ENV_NAMES, bashrc_path: str = "") -> None:
    load_shell_env(names)

# =============================================================================
# --- volcengine image helpers ---
# =============================================================================

def to_plain_dict(response):
    if isinstance(response, dict):
        return response
    if hasattr(response, "to_dict"):
        return response.to_dict()
    return response


def get_result_payload(response_data):
    if isinstance(response_data, dict):
        return response_data.get("Result", response_data)
    return response_data
def image_record_field(image: dict[str, Any], *keys: str) -> str:
    for key in keys:
        value = str(image.get(key) or "").strip()
        if value:
            return value
    return ""


def image_os_type_label(image: dict[str, Any]) -> str:
    os_type = image_record_field(image, "OsType", "os_type", "OSType")
    platform = image_record_field(image, "Platform", "platform")
    if os_type and platform:
        return "%s/%s" % (os_type, platform)
    return os_type or platform or image_os_type(image)


def image_record_platform(image: dict[str, Any]) -> str:
    os_type = image_record_field(image, "OsType", "os_type", "OSType")
    platform = image_record_field(image, "Platform", "platform")
    if is_windows_os(os_type) or is_windows_os(platform):
        return "windows"
    if is_linux_os(os_type) or is_linux_os(platform):
        return "ubuntu"
    image_name = str(image.get("ImageName") or image.get("image_name") or "").lower()
    if "windows" in image_name:
        return "windows"
    if any(item in image_name for item in ("ubuntu", "linux", "debian", "centos")):
        return "ubuntu"
    return ""
def image_os_type(image: dict[str, Any]) -> str:
    for key in (
        "OsType",
        "os_type",
        "OSType",
        "Platform",
        "platform",
        "OperatingSystem",
        "operating_system",
        "OsName",
        "os_name",
    ):
        value = str(image.get(key) or "").strip()
        if value:
            return value
    image_name = str(image.get("ImageName") or image.get("image_name") or "").lower()
    if "windows" in image_name:
        return "Windows"
    if any(item in image_name for item in ("ubuntu", "linux", "debian", "centos")):
        return "Ubuntu"
    return ""
def is_windows_os(os_type: str) -> bool:
    return "windows" in str(os_type or "").lower()


def is_linux_os(os_type: str) -> bool:
    text = str(os_type or "").lower()
    return any(item in text for item in ("linux", "ubuntu", "debian", "centos", "rocky", "almalinux", "fedora"))

# =============================================================================
# --- ECS export ---
# =============================================================================

SOURCE_REGION = "cn-guangzhou"
DEFAULT_LIST_LIMIT = 5000
DEFAULT_PAGE_SIZE = 100
DEFAULT_IMAGE_VISIBILITY = "private"
DEFAULT_TOS_BUCKET = "open-workflowgym-sample"
DEFAULT_EXPORT_OBJECT_SUFFIX = "_system.qcow2"
ORIGINAL_IMAGE_ID_PATTERN = re.compile(r"^image-[a-z0-9]+")
DEFAULT_EXPORT_CONCURRENCY = 10
DEFAULT_EXPORT_TIMEOUT_SECONDS = 1200
ECS_ENV_NAMES = ("AK", "SK")


def create_api_instance(region: str) -> volcenginesdkecs.ECSApi:
    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = region
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkecs.ECSApi()


def image_display_name(image: dict[str, Any]) -> str:
    return image_record_field(image, "ImageName", "image_name") or image_record_field(image, "ImageId", "image_id")


def is_ubuntu_image(image: dict[str, Any]) -> bool:
    if image_record_platform(image) == "ubuntu":
        return True
    label = image_os_type_label(image).lower()
    return "ubuntu" in label or "linux" in label


def has_gui_suffix(image: dict[str, Any]) -> bool:
    return "gui" in image_display_name(image).lower()


def normalize_tos_bucket(bucket: str) -> str:
    value = bucket.strip()
    if value.lower().startswith("tos://"):
        value = value[6:]
    return value.strip("/")


def strip_image_id_prefix(image_id: str) -> str:
    value = (image_id or "").strip()
    if value.lower().startswith("image-"):
        return value[6:]
    return value


def extract_original_image_id(image_name: str, image_id: str) -> str:
    """从镜像名提取原始 image-xxx；若名称不含则回退到当前广州 ImageId。"""
    name = (image_name or "").strip()
    match = ORIGINAL_IMAGE_ID_PATTERN.match(name)
    if match:
        return match.group(0)
    return (image_id or "").strip()


def build_export_tos_prefix(image_name: str, image_id: str) -> str:
    """ExportImage 的 tos_prefix 使用原始镜像 ID（去掉 image- 前缀）。"""
    original_image_id = extract_original_image_id(image_name, image_id)
    return strip_image_id_prefix(original_image_id)


def predict_export_object_key(tos_prefix: str, image_id: str) -> str:
    if not image_id:
        raise ValueError("predict_export_object_key 需要 image_id")
    prefix = (tos_prefix or "").strip("/")
    if not prefix:
        raise ValueError("predict_export_object_key 需要 tos_prefix")
    return "%s_%s%s" % (prefix, image_id, DEFAULT_EXPORT_OBJECT_SUFFIX)


def predict_export_object_uri(bucket: str, tos_prefix: str, image_id: str) -> str:
    return "tos://%s/%s" % (
        normalize_tos_bucket(bucket),
        predict_export_object_key(tos_prefix, image_id),
    )


def local_export_filename(image_name: str, image_id: str) -> str:
    """下载到本地后使用的原始镜像文件名。"""
    original_name = (image_name or image_id).strip() or image_id
    if original_name.endswith(".qcow2"):
        return original_name
    return "%s%s" % (original_name, DEFAULT_EXPORT_OBJECT_SUFFIX)


def safe_local_path_name(image_name: str, image_id: str) -> str:
    original_name = (image_name or image_id).strip() or image_id
    cleaned = re.sub(r"[^\w.\-]+", "_", original_name)
    return cleaned or image_id


def tos_export_uri(bucket: str, prefix: str) -> str:
    normalized_bucket = normalize_tos_bucket(bucket)
    normalized_prefix = prefix.strip("/")
    if normalized_prefix:
        return "tos://%s/%s/" % (normalized_bucket, normalized_prefix)
    return "tos://%s/" % normalized_bucket


def list_region_images(
    api_instance: volcenginesdkecs.ECSApi,
    *,
    limit: int = DEFAULT_LIST_LIMIT,
    page_size: int = DEFAULT_PAGE_SIZE,
    visibility: str = DEFAULT_IMAGE_VISIBILITY,
) -> list[dict[str, Any]]:
    images: list[dict[str, Any]] = []
    next_token = ""
    while len(images) < limit:
        request_kwargs: dict[str, Any] = {
            "max_results": min(page_size, limit - len(images)),
            "visibility": visibility,
        }
        if next_token:
            request_kwargs["next_token"] = next_token
        response = api_instance.describe_images(volcenginesdkecs.DescribeImagesRequest(**request_kwargs))
        result = get_result_payload(to_plain_dict(response))
        page_images = result.get("Images") or result.get("images") or []
        images.extend(page_images)
        next_token = result.get("NextToken") or result.get("next_token") or ""
        if not next_token or not page_images:
            break
    return images[:limit]


def has_bj_name_suffix(image: dict[str, Any]) -> bool:
    name = image_display_name(image).lower()
    return name.endswith("_bj") or name.endswith("_bjopen")


def select_export_candidates(
    images: list[dict[str, Any]],
    *,
    exclude_bj_suffix: bool = False,
    ubuntu_only: bool = True,
    exclude_gui: bool = True,
) -> list[dict[str, Any]]:
    """筛选导出候选。

    publish 全量上传时用 ubuntu_only=False / exclude_gui=False，
    以覆盖 cn-guangzhou 全部私有镜像。
    """
    candidates = []
    for image in images:
        if ubuntu_only and not is_ubuntu_image(image):
            continue
        if exclude_gui and has_gui_suffix(image):
            continue
        if exclude_bj_suffix and has_bj_name_suffix(image):
            continue
        candidates.append(image)
    return sorted(
        candidates,
        key=lambda item: (
            1 if has_bj_name_suffix(item) else 0,
            image_display_name(item).lower(),
        ),
    )


def describe_image_tasks(api_instance: volcenginesdkecs.ECSApi, image_id: str) -> list[dict[str, Any]]:
    response = api_instance.describe_tasks(
        volcenginesdkecs.DescribeTasksRequest(resource_ids=[image_id])
    )
    result = get_result_payload(to_plain_dict(response))
    return result.get("Tasks") or result.get("tasks") or []


def task_record_id(task: dict[str, Any]) -> str:
    return task.get("Id") or task.get("id") or ""


def wait_image_task(
    api_instance: volcenginesdkecs.ECSApi,
    image_id: str,
    *,
    task_label: str,
    poll_interval_seconds: int,
    timeout_seconds: int,
    task_id: str = "",
) -> list[dict[str, Any]]:
    deadline = time.time() + timeout_seconds
    last_tasks: list[dict[str, Any]] = []
    expected_task_id = (task_id or "").strip()
    while time.time() < deadline:
        tasks = describe_image_tasks(api_instance, image_id)
        if tasks:
            last_tasks = tasks
            tracked_tasks = tasks
            if expected_task_id:
                tracked_tasks = [
                    task for task in tasks if task_record_id(task) == expected_task_id
                ]
                if not tracked_tasks:
                    time.sleep(poll_interval_seconds)
                    continue
            for task in tracked_tasks:
                status = task.get("Status") or task.get("status")
                process = task.get("Process")
                if process is None:
                    process = task.get("process")
                print(
                    "%s任务进展: id=%s status=%s process=%s resource=%s"
                    % (
                        task_label,
                        task_record_id(task),
                        status,
                        process,
                        task.get("ResourceId") or task.get("resource_id"),
                    )
                )
                if status in ("Failed", "FAILED", "Error", "ERROR"):
                    raise RuntimeError("%s任务失败: %s" % (task_label, task))
                if status in (
                    "Success",
                    "SUCCESS",
                    "Succeeded",
                    "SUCCEEDED",
                    "Finished",
                    "FINISHED",
                ) or process == 100:
                    return tasks
        time.sleep(poll_interval_seconds)
    raise TimeoutError("等待%s任务完成超时，最后任务信息: %s" % (task_label, last_tasks))


def export_image_to_tos(
    api_instance: volcenginesdkecs.ECSApi,
    image: dict[str, Any],
    *,
    tos_bucket: str,
    poll_interval_seconds: int,
    timeout_seconds: int,
) -> dict[str, Any]:
    image_id = image_record_field(image, "ImageId", "image_id")
    image_name = image_display_name(image)
    original_image_id = extract_original_image_id(image_name, image_id)
    normalized_bucket = normalize_tos_bucket(tos_bucket)
    normalized_prefix = build_export_tos_prefix(image_name, image_id)
    request = volcenginesdkecs.ExportImageRequest(
        image_id=image_id,
        tos_bucket=normalized_bucket,
        tos_prefix=normalized_prefix,
    )
    response = api_instance.export_image(request)
    result = get_result_payload(to_plain_dict(response))
    export_uri = predict_export_object_uri(normalized_bucket, normalized_prefix, image_id)
    print("已提交导出任务: %s" % image_name)
    print("广州 ImageId: %s" % image_id)
    print("原始 ImageId: %s" % original_image_id)
    print("TOS 前缀: %s" % normalized_prefix)
    print("预计 TOS 对象: %s" % export_uri)
    if result:
        print("ExportImage 响应: %s" % result)
    export_task_id = result.get("task_id") or result.get("TaskId") or ""
    tasks = wait_image_task(
        api_instance,
        image_id,
        task_label="导出",
        poll_interval_seconds=poll_interval_seconds,
        timeout_seconds=timeout_seconds,
        task_id=export_task_id,
    )
    return {
        "image_id": image_id,
        "image_name": image_name,
        "original_image_id": original_image_id,
        "tos_bucket": normalized_bucket,
        "tos_prefix": normalized_prefix,
        "tos_uri": export_uri,
        "tos_object_uri": export_uri,
        "local_filename": local_export_filename(image_name, image_id),
        "export_tasks": tasks,
        "export_response": result,
    }


def export_images_concurrently(
    images: list[dict[str, Any]],
    *,
    tos_bucket: str,
    poll_interval_seconds: int,
    timeout_seconds: int,
    max_concurrency: int = DEFAULT_EXPORT_CONCURRENCY,
    raise_on_error: bool = True,
) -> tuple[list[dict[str, Any]], list[tuple[str, str, Exception]]]:
    if not images:
        return [], []
    worker_count = max(1, min(max_concurrency, DEFAULT_EXPORT_CONCURRENCY, len(images)))
    print("导出并发数: %s" % worker_count)
    results: list[dict[str, Any]] = []
    errors: list[tuple[str, str, Exception]] = []

    def _export_one(image: dict[str, Any]) -> dict[str, Any]:
        api = create_api_instance(SOURCE_REGION)
        return export_image_to_tos(
            api,
            image,
            tos_bucket=tos_bucket,
            poll_interval_seconds=poll_interval_seconds,
            timeout_seconds=timeout_seconds,
        )

    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        futures = {executor.submit(_export_one, image): image for image in images}
        for future in as_completed(futures):
            image = futures[future]
            image_name = image_display_name(image)
            image_id = image_record_field(image, "ImageId", "image_id")
            try:
                result = future.result()
                results.append(result)
                print("导出完成: %s -> %s" % (result["image_name"], result["tos_object_uri"]))
            except Exception as exc:
                errors.append((image_id, image_name, exc))
                print("导出失败: %s error=%s" % (image_name, exc))

    if errors and raise_on_error:
        detail = "; ".join("%s: %s" % (name, error) for _, name, error in errors)
        raise RuntimeError("部分镜像导出失败: %s" % detail)
    return sorted(results, key=lambda item: item["image_name"].lower()), errors


# =============================================================================
# --- tosutil ---
# =============================================================================

TOSUTIL_DOWNLOAD_BASE = "https://m645b3e1bb36e-mrap.mrap.accesspoint.tos-global.volces.com"
TOSUTIL_DOWNLOAD_URLS: dict[tuple[str, str], str] = {
    ("linux", "amd64"): f"{TOSUTIL_DOWNLOAD_BASE}/linux/amd64/tosutil",
    ("linux", "arm64"): f"{TOSUTIL_DOWNLOAD_BASE}/linux/arm64/tosutil",
    ("darwin", "amd64"): f"{TOSUTIL_DOWNLOAD_BASE}/darwin/amd64/tosutil",
    ("darwin", "arm64"): f"{TOSUTIL_DOWNLOAD_BASE}/darwin/arm64/tosutil",
    ("windows", "amd64"): f"{TOSUTIL_DOWNLOAD_BASE}/windows/tosutil",
}

_configured_binary: str | None = None


def normalize_arch(machine: str) -> str:
    normalized = (machine or "").lower()
    if normalized in {"x86_64", "amd64"}:
        return "amd64"
    if normalized in {"aarch64", "arm64"}:
        return "arm64"
    return normalized or "amd64"


def local_platform_key() -> tuple[str, str]:
    system = platform.system().lower()
    arch = normalize_arch(platform.machine())
    if system == "windows":
        return "windows", "amd64"
    if system == "darwin":
        return "darwin", arch
    return "linux", arch


def local_tosutil_cache_dir() -> Path:
    override = (os.getenv("LOCAL_TOSUTIL_DIR") or os.getenv("TOSUTIL_CACHE_DIR") or "").strip()
    if override:
        return Path(override).expanduser()
    return Path.home() / ".cache" / "open_workflowgym" / "tosutil"


def cached_tosutil_path(platform_key: tuple[str, str] | None = None) -> Path:
    system, arch = platform_key or local_platform_key()
    cache_dir = local_tosutil_cache_dir() / f"{system}-{arch}"
    if system == "windows":
        return cache_dir / "tosutil.exe"
    return cache_dir / "tosutil"


def tosutil_download_url(platform_key: tuple[str, str] | None = None) -> str:
    key = platform_key or local_platform_key()
    url = TOSUTIL_DOWNLOAD_URLS.get(key)
    if not url:
        system, arch = key
        raise RuntimeError("当前平台暂不支持自动下载 tosutil: %s/%s" % (system, arch))
    override_env = "TOSUTIL_DOWNLOAD_URL"
    if key[0] == "linux":
        override_env = "LINUX_TOSUTIL_DOWNLOAD_URL"
    elif key[0] == "windows":
        override_env = "WINDOWS_TOSUTIL_DOWNLOAD_URL"
    elif key[0] == "darwin":
        override_env = "DARWIN_TOSUTIL_DOWNLOAD_URL"
    return (os.getenv(override_env) or url).strip()


def _binary_is_usable(path: Path) -> bool:
    if not path.is_file() or path.stat().st_size <= 0:
        return False
    if platform.system().lower() != "windows" and not os.access(path, os.X_OK):
        return False
    try:
        subprocess.run(
            [str(path), "version"],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=30,
        )
        return True
    except Exception:
        return False


def _make_executable(path: Path) -> None:
    if platform.system().lower() == "windows":
        return
    mode = path.stat().st_mode
    path.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def download_tosutil(platform_key: tuple[str, str] | None = None) -> Path:
    key = platform_key or local_platform_key()
    target = cached_tosutil_path(key)
    target.parent.mkdir(parents=True, exist_ok=True)
    download_url = tosutil_download_url(key)
    temp_path = target.with_suffix(target.suffix + ".download")
    if temp_path.exists():
        temp_path.unlink()
    with urllib.request.urlopen(download_url, timeout=120) as response:
        temp_path.write_bytes(response.read())
    if platform.system().lower() != "windows":
        _make_executable(temp_path)
    temp_path.replace(target)
    if not _binary_is_usable(target):
        raise RuntimeError("tosutil 下载完成但无法执行: %s" % target)
    return target


def ensure_tosutil_configured(binary: str) -> None:
    global _configured_binary
    if _configured_binary == binary:
        return
    tos_ak = (os.getenv("TOS_AK") or os.getenv("AK") or "").strip()
    tos_sk = (os.getenv("TOS_SK") or os.getenv("SK") or "").strip()
    if not tos_ak or not tos_sk:
        return
    tos_region = (
        os.getenv("TOS_REGION")
        or os.getenv("VOLCENGINE_REGION")
        or os.getenv("SOURCE_REGION")
        or "cn-guangzhou"
    ).strip()
    tos_endpoint = (os.getenv("TOS_ENDPOINT") or "tos-%s.volces.com" % tos_region).strip()
    subprocess.run(
        [binary, "config", "-i", tos_ak, "-k", tos_sk, "-e", tos_endpoint, "-re", tos_region],
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        timeout=60,
    )
    _configured_binary = binary


def resolve_tosutil_binary(*, auto_download: bool = True) -> str:
    override = (os.getenv("TOSUTIL_BINARY") or "").strip()
    if override:
        path = Path(override).expanduser()
        if not path.is_file():
            raise FileNotFoundError("TOSUTIL_BINARY 指向的文件不存在: %s" % path)
        ensure_tosutil_configured(str(path))
        return str(path)

    path_in_path = shutil.which("tosutil")
    if path_in_path:
        ensure_tosutil_configured(path_in_path)
        return path_in_path

    cached = cached_tosutil_path()
    if _binary_is_usable(cached):
        ensure_tosutil_configured(str(cached))
        return str(cached)

    if not auto_download:
        raise FileNotFoundError("未找到可用 tosutil，本地缓存目录: %s" % cached.parent)

    downloaded = download_tosutil()
    ensure_tosutil_configured(str(downloaded))
    return str(downloaded)


def run_tosutil_cp(url: str, target_path: str) -> None:
    binary = resolve_tosutil_binary()
    subprocess.check_call([binary, "cp", url, target_path])


def run_tosutil_ls(url: str, *extra_args: str) -> str:
    binary = resolve_tosutil_binary()
    completed = subprocess.run(
        [binary, "ls", url, *extra_args],
        check=True,
        capture_output=True,
        text=True,
        timeout=300,
    )
    return completed.stdout or ""


def parse_tosutil_next_marker(stdout: str) -> str | None:
    for raw_line in stdout.splitlines():
        line = raw_line.strip()
        if line.lower().startswith("next marker is:"):
            marker = line.split(":", 1)[1].strip()
            return marker or None
    return None


# =============================================================================
# --- Hugging Face upload ---
# =============================================================================

DEFAULT_MIN_HF_HUB_VERSION = "0.25.0"
DEFAULT_UPLOAD_CONCURRENCY = 1
MAX_UPLOAD_CONCURRENCY = 10

def normalize_upload_workers(num_workers: int | None) -> int:
    if num_workers is None:
        env_value = (os.getenv("HF_UPLOAD_NUM_WORKERS") or os.getenv("IMAGE_UPLOAD_CONCURRENCY") or "").strip()
        if env_value:
            num_workers = int(env_value)
        else:
            num_workers = DEFAULT_UPLOAD_CONCURRENCY
    return max(1, min(int(num_workers), MAX_UPLOAD_CONCURRENCY))


def resolve_hf_token() -> str:
    for name in HF_ENV_NAMES:
        value = (os.getenv(name) or "").strip()
        if value:
            os.environ.setdefault("HF_TOKEN", value)
            return value
    return ""


def parse_patterns(values: list[str] | None) -> list[str] | None:
    if not values:
        return None
    patterns: list[str] = []
    for item in values:
        patterns.extend(part.strip() for part in item.split(",") if part.strip())
    return patterns or None


def iter_local_files(folder_path: Path, *, allow_patterns: list[str] | None, ignore_patterns: list[str] | None) -> list[Path]:
    from huggingface_hub.utils import filter_repo_objects

    files = [path for path in folder_path.rglob("*") if path.is_file()]
    relative_paths = [str(path.relative_to(folder_path).as_posix()) for path in files]
    filtered = filter_repo_objects(
        relative_paths,
        allow_patterns=allow_patterns,
        ignore_patterns=ignore_patterns,
    )
    allowed = set(filtered)
    return [path for path in files if path.relative_to(folder_path).as_posix() in allowed]


def summarize_folder(
    folder_path: Path,
    *,
    allow_patterns: list[str] | None,
    ignore_patterns: list[str] | None,
) -> dict[str, object]:
    files = iter_local_files(folder_path, allow_patterns=allow_patterns, ignore_patterns=ignore_patterns)
    total_bytes = sum(path.stat().st_size for path in files)
    return {
        "file_count": len(files),
        "total_bytes": total_bytes,
        "total_gib": round(total_bytes / (1024 ** 3), 3),
        "sample_files": [str(path.relative_to(folder_path)) for path in files[:10]],
    }


def ensure_hf_hub_version(min_version: str = DEFAULT_MIN_HF_HUB_VERSION) -> str:
    try:
        from huggingface_hub import __version__ as hf_version
    except ImportError as exc:
        raise SystemExit(
            "缺少 huggingface_hub，请先安装: pip install 'huggingface_hub>=%s'" % min_version
        ) from exc
    try:
        from packaging.version import Version

        if Version(hf_version) < Version(min_version):
            raise SystemExit(
                "huggingface_hub 版本过低: %s，upload_large_folder 需要 >= %s"
                % (hf_version, min_version)
            )
    except ImportError:
        pass
    return hf_version


def upload_large_folder_to_hub(
    *,
    repo_id: str,
    folder_path: Path,
    repo_type: str,
    revision: str | None,
    private: bool | None,
    allow_patterns: list[str] | None,
    ignore_patterns: list[str] | None,
    num_workers: int | None,
    use_cli: bool,
) -> str:
    token = resolve_hf_token()
    if not token:
        raise SystemExit("缺少 HF_TOKEN（或 HUGGINGFACE_HUB_TOKEN），无法上传到 Hugging Face")

    resolved_workers = normalize_upload_workers(num_workers)
    print("HF 上传并发数: %s" % resolved_workers)

    if use_cli:
        command = [
            "huggingface-cli",
            "upload-large-folder",
            repo_id,
            str(folder_path),
            "--repo-type",
            repo_type,
        ]
        if revision:
            command.extend(["--revision", revision])
        command.extend(["--num-workers", str(resolved_workers)])
        patterns = parse_cli_patterns(allow_patterns, "--allow-pattern")
        command.extend(patterns)
        patterns = parse_cli_patterns(ignore_patterns, "--ignore-pattern")
        command.extend(patterns)
        env = os.environ.copy()
        env.setdefault("HF_TOKEN", token)
        completed = subprocess.run(command, check=False, env=env)
        if completed.returncode != 0:
            raise SystemExit("huggingface-cli upload-large-folder 失败，exit_code=%s" % completed.returncode)
        return "cli://%s" % repo_id

    from huggingface_hub import HfApi

    api = HfApi(token=token)
    create_private = True if private is None else bool(private)
    api.create_repo(
        repo_id=repo_id,
        repo_type=repo_type,
        private=create_private,
        exist_ok=True,
    )
    upload_kwargs = {
        "repo_id": repo_id,
        "folder_path": str(folder_path),
        "repo_type": repo_type,
    }
    if revision:
        upload_kwargs["revision"] = revision
    if private is not None:
        upload_kwargs["private"] = private
    if allow_patterns:
        upload_kwargs["allow_patterns"] = allow_patterns
    if ignore_patterns:
        upload_kwargs["ignore_patterns"] = ignore_patterns
    upload_kwargs["num_workers"] = resolved_workers

    if hasattr(api, "upload_large_folder"):
        api.upload_large_folder(**upload_kwargs)
        return "https://huggingface.co/%s" % repo_id

    print("当前 huggingface_hub 无 upload_large_folder，回退到 upload_folder（支持断点续传）")
    upload_kwargs.pop("num_workers", None)
    api.upload_folder(**upload_kwargs)
    return "https://huggingface.co/%s" % repo_id



def parse_cli_patterns(patterns: list[str] | None, flag: str) -> list[str]:
    if not patterns:
        return []
    args: list[str] = []
    for pattern in patterns:
        args.extend([flag, pattern])
    return args

# =============================================================================
# --- Feishu (optional for --from-csv) ---
# =============================================================================

def parse_feishu_sheet_url(url: str) -> dict[str, str]:
    parsed = urllib.parse.urlparse(url)
    query = urllib.parse.parse_qs(parsed.query)
    token = parsed.path.rstrip("/").split("/")[-1] if parsed.path else ""
    return {
        "token": token,
        "sheet_id": (query.get("sheet") or [""])[0],
        "is_wiki": "/wiki/" in parsed.path,
    }

def feishu_credentials_configured() -> bool:
    return bool(os.getenv("APP_ID", "").strip() and os.getenv("APP_SECRET", "").strip())

FEISHU_OPEN_BASE_URL = os.getenv("FEISHU_OPEN_BASE_URL", "https://feishu-open.example.local/open-apis").rstrip("/")

class FeishuHTTPError(ValueError):
    def __init__(self, status_code: int, body: str):
        super().__init__("飞书 HTTP 调用失败 %s: %s" % (status_code, body))
        self.status_code = status_code
        self.body = body
        try:
            self.response = json.loads(body)
        except ValueError:
            self.response = {}


class FeishuClient:
    """Small Feishu boundary.

    Real API calls can reuse patterns from batch_image_copy_to_feishu.py. This
    scaffold keeps side effects isolated and dry-run friendly.
    """

    def __init__(
        self,
        app_id: str = "",
        app_secret: str = "",
        dry_run: bool = True,
        base_url: str = FEISHU_OPEN_BASE_URL,
        folder_token: str = "",
    ):
        self.app_id = app_id or os.getenv("APP_ID", "")
        self.app_secret = app_secret or os.getenv("APP_SECRET", "")
        self.dry_run = dry_run
        self.base_url = base_url.rstrip("/")
        self.folder_token = folder_token or os.getenv("FEISHU_FOLDER_TOKEN", "")
        self.app_access_token = ""
        if not self.dry_run:
            if not self.app_id or not self.app_secret:
                raise ValueError("缺少 APP_ID 或 APP_SECRET，无法访问飞书")
            self.app_access_token = self.get_app_access_token()

    def get_app_access_token(self) -> str:
        response = self.request_json(
            "POST",
            "/auth/v3/app_access_token/internal",
            {"app_id": self.app_id, "app_secret": self.app_secret},
            auth=False,
        )
        data = response.get("data") or {}
        token = (
            response.get("app_access_token")
            or response.get("tenant_access_token")
            or data.get("app_access_token")
            or data.get("tenant_access_token")
        )
        if not token:
            raise ValueError("获取飞书 app_access_token 失败: %s" % response)
        return token

    def refresh_app_access_token(self) -> None:
        self.app_access_token = self.get_app_access_token()

    def is_auth_error_response(self, response: dict[str, Any]) -> bool:
        return response.get("code") == 99991663

    def is_auth_error(self, exc: Exception) -> bool:
        if isinstance(exc, FeishuHTTPError):
            return self.is_auth_error_response(exc.response)
        return False

    def request_json(self, method: str, path: str, payload: dict[str, Any] | None = None, auth: bool = True) -> dict[str, Any]:
        if self.dry_run:
            return {"code": 0, "data": {}}
        try:
            return self._request_json_once(method, path, payload, auth)
        except Exception as exc:
            if auth and self.is_auth_error(exc):
                self.refresh_app_access_token()
                return self._request_json_once(method, path, payload, auth)
            raise

    def _request_json_once(self, method: str, path: str, payload: dict[str, Any] | None = None, auth: bool = True) -> dict[str, Any]:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8") if payload is not None else None
        headers = {"Content-Type": "application/json; charset=utf-8"}
        if auth:
            headers["Authorization"] = "Bearer %s" % self.app_access_token
        request = urllib.request.Request(
            self.base_url + path,
            data=data,
            headers=headers,
            method=method,
        )
        response = self.open_request(request)
        code = response.get("code", 0)
        if code not in (0, None):
            raise ValueError("飞书接口调用失败 %s %s: %s" % (method, path, response))
        return response

    def open_request(self, request: urllib.request.Request) -> dict[str, Any]:
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                body = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise FeishuHTTPError(exc.code, body)
        if not body:
            return {}
        try:
            return json.loads(body)
        except ValueError:
            raise ValueError("飞书接口返回非 JSON 内容: %s" % body)

    def resolve_wiki_spreadsheet_token(self, wiki_token: str) -> str:
        response = self.request_json("GET", "/wiki/v2/spaces/get_node?token=%s" % urllib.parse.quote(wiki_token, safe=""))
        data = response.get("data") or {}
        node = data.get("node") or data
        obj_token = node.get("obj_token") or node.get("objToken") or node.get("token")
        if not obj_token:
            raise ValueError("解析 wiki 表格 token 失败: %s" % response)
        return obj_token

    def read_values(self, spreadsheet_token: str, cell_range: str) -> list[list[Any]]:
        if self.dry_run:
            return []
        encoded_range = urllib.parse.quote(cell_range, safe="")
        response = self.request_json(
            "GET",
            "/sheets/v2/spreadsheets/%s/values/%s" % (spreadsheet_token, encoded_range),
        )
        data = response.get("data") or {}
        value_range = data.get("valueRange") or data.get("value_range") or {}
        return value_range.get("values") or data.get("values") or response.get("values") or []

def column_to_number(column: str) -> int:
    number = 0
    for char in column:
        number = number * 26 + ord(char) - ord("A") + 1
    return number

def flatten_cell_text(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (int, float, bool)):
        return str(value).strip()
    if isinstance(value, list):
        parts: list[str] = []
        for item in value:
            text = flatten_cell_text(item)
            if text:
                parts.append(text)
        return "".join(parts).strip()
    if isinstance(value, dict):
        return str(value.get("text") or value.get("link") or "").strip()
    return str(value).strip()

def cell_value(row: list[Any], column_index: int) -> str:
    if column_index < 0 or column_index >= len(row):
        return ""
    return flatten_cell_text(row[column_index])

def resolve_spreadsheet_token(client: FeishuClient, wiki_url: str) -> str:
    info = parse_feishu_sheet_url(wiki_url)
    if info.get("is_wiki"):
        return client.resolve_wiki_spreadsheet_token(info["token"])
    return info["token"]

def read_sheet_rows_with_retry(
    client: FeishuClient,
    spreadsheet_token: str,
    sheet_id: str,
    *,
    end_column: str = "AH",
    row_chunk_size: int = 200,
    max_rows: int = 5000,
    max_attempts: int = 3,
) -> list[list[Any]]:
    all_rows: list[list[Any]] = []
    start_row = 1
    while start_row <= max_rows:
        end_row = min(start_row + row_chunk_size - 1, max_rows)
        cell_range = "%s!A%d:%s%d" % (sheet_id, start_row, end_column, end_row)
        chunk: list[list[Any]] = []
        for attempt in range(1, max_attempts + 1):
            try:
                chunk = client.read_values(spreadsheet_token, cell_range)
                break
            except Exception as exc:
                if attempt >= max_attempts:
                    raise
                print("读取 %s 失败 (%s/%s): %s" % (cell_range, attempt, max_attempts, exc), file=sys.stderr)
        if not chunk:
            break
        all_rows.extend(chunk)
        if len(chunk) < row_chunk_size:
            break
        start_row += row_chunk_size
    return all_rows

# =============================================================================
# --- publish pipeline ---
# =============================================================================

DEFAULT_LOCAL_DIR = "image_file"
DEFAULT_REPO_TYPE = "dataset"
DEFAULT_BATCH_SIZE = 1
DEFAULT_MANIFEST_PATH = "output/publish_manifest.json"
DEFAULT_CSV_PATH = "output/publish_guangzhou_images_2phase.csv"
DEFAULT_FEISHU_URL = os.getenv("FEISHU_WIKI_URL", "https://example.feishu.local/wiki/PLACEHOLDER?sheet=SHEET_ID")
DEFAULT_FEISHU_SHEET_ID = "PtDat4"
DEFAULT_IMAGE_HEADER = "image"
STATUS_PENDING = "pending"
STATUS_EXPORTED = "exported"
STATUS_DOWNLOADED = "downloaded"
STATUS_UPLOADED = "uploaded"
STATUS_FAILED = "failed"
STATUS_SKIPPED_WINDOWS = "skipped_windows"
STATUS_SKIPPED_DISK = "skipped_disk"
STATUS_SKIPPED_HF_FULL = "skipped_hf_full"
STATUS_UNMATCHED = "unmatched"

CSV_HEADERS = [
    "原始镜像",
    "镜像名称",
    "上传tos镜像结果",
    "对应的tos镜像id",
    "是否下载到本地",
    "镜像的大小",
    "本地是否重建名字",
    "是否已经上传huggingface",
    "huggingface上对应的镜像名和目录",
]

DEFAULT_HF_REPO_SOFT_LIMIT_GIB = 900.0
DEFAULT_HF_MAX_AUTO_REPOS = 20
DEFAULT_DISK_SIZE_FACTOR = 1.05
DEFAULT_DISK_FREE_MARGIN_BYTES = 2 * (1024 ** 3)
_TOS_LS_CACHE: dict[str, str] = {}
_TOS_OBJECT_SIZE_CACHE: dict[str, int] = {}
_TOS_CACHE_LOCK = threading.Lock()
_TRASH_LOCK = threading.Lock()
_HF_UPLOAD_LOCK = threading.Lock()
HF_STORAGE_ERROR_MARKERS = (
    "storage limit",
    "storagequota",
    "quota",
    "not enough space",
    "insufficient storage",
    "repository limit",
    "disk quota",
    "403 forbidden",
)


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def is_windows_image(image: dict[str, Any]) -> bool:
    if image_record_platform(image) == "windows":
        return True
    label = image_os_type_label(image).lower()
    name = image_display_name(image).lower()
    return "windows" in label or "windows" in name


def find_image_column_index(header_row: list[Any], *, image_header: str = DEFAULT_IMAGE_HEADER) -> int:
    wanted = (image_header or DEFAULT_IMAGE_HEADER).strip().lower()
    for index, cell in enumerate(header_row):
        if flatten_cell_text(cell).lower() == wanted:
            return index
    raise ValueError("飞书表头未找到列: %s" % image_header)


def read_feishu_unique_image_ids(
    *,
    feishu_url: str,
    sheet_id: str = "",
    image_header: str = DEFAULT_IMAGE_HEADER,
    image_column: str = "",
) -> tuple[list[str], dict[str, Any]]:
    if not feishu_credentials_configured():
        raise SystemExit("缺少 APP_ID 或 APP_SECRET，无法读取飞书 image 列")
    client = FeishuClient(dry_run=False)
    info = parse_feishu_sheet_url(feishu_url)
    resolved_sheet_id = (sheet_id or info.get("sheet_id") or DEFAULT_FEISHU_SHEET_ID).strip()
    spreadsheet_token = resolve_spreadsheet_token(client, feishu_url)
    rows = read_sheet_rows_with_retry(
        client,
        spreadsheet_token,
        resolved_sheet_id,
        end_column="AZ",
        row_chunk_size=200,
        max_rows=5000,
    )
    if not rows:
        raise SystemExit("飞书 sheet 为空: %s" % resolved_sheet_id)
    if image_column.strip():
        column_index = column_to_number(image_column.strip()) - 1
    else:
        column_index = find_image_column_index(rows[0], image_header=image_header)

    unique_ids: list[str] = []
    seen: set[str] = set()
    duplicate_count = 0
    empty_count = 0
    for row in rows[1:]:
        image_id = cell_value(row, column_index)
        if not image_id:
            empty_count += 1
            continue
        if image_id in seen:
            duplicate_count += 1
            continue
        seen.add(image_id)
        unique_ids.append(image_id)
    stats = {
        "spreadsheet_token": spreadsheet_token,
        "sheet_id": resolved_sheet_id,
        "column_index": column_index,
        "source_rows": len(rows),
        "unique_image_ids": len(unique_ids),
        "duplicate_count": duplicate_count,
        "empty_count": empty_count,
    }
    return unique_ids, stats


def match_guangzhou_non_windows_images(
    feishu_image_ids: list[str],
    region_images: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[str], list[dict[str, Any]]]:
    """返回 (可发布镜像, 未匹配 ID, Windows 匹配镜像)。"""
    by_id = {
        image_record_field(image, "ImageId", "image_id"): image
        for image in region_images
        if image_record_field(image, "ImageId", "image_id")
    }
    matched_non_windows: list[dict[str, Any]] = []
    unmatched: list[str] = []
    matched_windows: list[dict[str, Any]] = []
    for image_id in feishu_image_ids:
        image = by_id.get(image_id)
        if image is None:
            unmatched.append(image_id)
            continue
        if is_windows_image(image):
            matched_windows.append(image)
            continue
        matched_non_windows.append(image)
    return matched_non_windows, unmatched, matched_windows


def hf_relative_path(image_name: str, image_id: str) -> str:
    subdir = safe_local_path_name(image_name, image_id)
    filename = local_export_filename(image_name, image_id)
    return "%s/%s" % (subdir, filename)


def format_size_text(num_bytes: int | float | None) -> str:
    if num_bytes is None:
        return ""
    try:
        value = float(num_bytes)
    except (TypeError, ValueError):
        return ""
    if value <= 0:
        return "0"
    return "%.3f GiB" % (value / (1024 ** 3))


def empty_csv_row(image_id: str, image_name: str = "") -> dict[str, str]:
    return {
        "原始镜像": image_id,
        "镜像名称": image_name,
        "上传tos镜像结果": "",
        "对应的tos镜像id": "",
        "是否下载到本地": "否",
        "镜像的大小": "",
        "本地是否重建名字": "否",
        "是否已经上传huggingface": "否",
        "huggingface上对应的镜像名和目录": "",
    }


def load_csv_rows(path: Path) -> dict[str, dict[str, str]]:
    if not path.is_file():
        return {}
    rows: dict[str, dict[str, str]] = {}
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            image_id = str(row.get("原始镜像") or "").strip()
            if not image_id:
                continue
            normalized = empty_csv_row(image_id)
            for key in CSV_HEADERS:
                if key in row and row[key] is not None:
                    normalized[key] = str(row[key])
            rows[image_id] = normalized
    return rows


def read_image_ids_from_csv(path: Path) -> list[str]:
    """按 CSV 行顺序读取「原始镜像」列，去重后作为候选 ID 来源。"""
    if not path.is_file():
        raise SystemExit("CSV 不存在，无法 --from-csv: %s" % path)
    ordered_ids: list[str] = []
    seen: set[str] = set()
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or "原始镜像" not in reader.fieldnames:
            raise SystemExit("CSV 缺少「原始镜像」列: %s" % path)
        for row in reader:
            image_id = str(row.get("原始镜像") or "").strip()
            if not image_id or image_id in seen:
                continue
            seen.add(image_id)
            ordered_ids.append(image_id)
    if not ordered_ids:
        raise SystemExit("CSV 中没有可用的原始镜像 ID: %s" % path)
    return ordered_ids


def save_csv_rows(path: Path, rows: dict[str, dict[str, str]], ordered_ids: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    ids = ordered_ids or list(rows.keys())
    seen = set(ids)
    for image_id in rows:
        if image_id not in seen:
            ids.append(image_id)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_HEADERS)
        writer.writeheader()
        for image_id in ids:
            row = rows.get(image_id) or empty_csv_row(image_id)
            writer.writerow({key: row.get(key, "") for key in CSV_HEADERS})


def upsert_csv_row(rows: dict[str, dict[str, str]], image_id: str, **fields: Any) -> None:
    row = rows.get(image_id) or empty_csv_row(image_id)
    for key, value in fields.items():
        if key in CSV_HEADERS and value is not None:
            row[key] = str(value)
    rows[image_id] = row


def apply_manifest_record_to_csv_row(
    csv_rows: dict[str, dict[str, str]],
    image_id: str,
    record: dict[str, Any],
    *,
    local_root: Path,
) -> None:
    """按 image_id 更新内存中对应 CSV 行（不落盘）。"""
    image_name = str(record.get("image_name") or "")
    status = str(record.get("status") or STATUS_PENDING)
    tos_uri = str(record.get("tos_object_uri") or "")
    local_file = str(record.get("local_file") or "")
    hf_path = str(record.get("hf_path") or "")
    size_text = str(record.get("size_text") or "")
    if not hf_path and image_name:
        hf_path = hf_relative_path(image_name, image_id)
    if not size_text and local_file:
        local_path = Path(local_file)
        if local_path.is_file():
            size_text = format_size_text(local_path.stat().st_size)

    tos_result = ""
    downloaded = "否"
    renamed = "否"
    uploaded = "否"
    if status == STATUS_UPLOADED:
        tos_result = "成功"
        downloaded = "是"
        renamed = "是"
        uploaded = "是"
    elif status == STATUS_DOWNLOADED:
        tos_result = "成功"
        downloaded = "是"
        renamed = "是"
    elif status == STATUS_EXPORTED:
        tos_result = "成功"
    elif status == STATUS_SKIPPED_DISK:
        tos_result = "成功" if tos_uri else ""
        downloaded = "否(磁盘不足)"
    elif status == STATUS_SKIPPED_HF_FULL:
        tos_result = "成功" if tos_uri else ""
        downloaded = "是" if local_file else "否(HF仓满停下载)"
    elif status == STATUS_FAILED:
        tos_result = "失败"
    elif status == STATUS_SKIPPED_WINDOWS:
        tos_result = "跳过(Windows)"
    elif status == STATUS_UNMATCHED:
        tos_result = "失败(未匹配广州镜像)"
    elif status == STATUS_PENDING:
        tos_result = ""

    upsert_csv_row(
        csv_rows,
        image_id,
        原始镜像=image_id,
        镜像名称=image_name,
        上传tos镜像结果=tos_result,
        对应的tos镜像id=tos_uri,
        是否下载到本地=downloaded,
        镜像的大小=size_text,
        本地是否重建名字=renamed,
        是否已经上传huggingface=uploaded,
        huggingface上对应的镜像名和目录=hf_path if uploaded == "是" or downloaded.startswith("是") else hf_path,
    )


def sync_csv_from_manifest(
    *,
    csv_rows: dict[str, dict[str, str]],
    csv_path: Path,
    ordered_ids: list[str],
    manifest: dict[str, Any],
    local_root: Path,
    image_ids: list[str] | None = None,
) -> None:
    """按 image_id 更新 CSV 条目后整表落盘。

    CSV 格式无法可靠原地改一行，落盘仍是覆盖写；但内存侧只重算指定 image_id
    （默认全部），避免每次无量扫 manifest。
    """
    images = manifest.get("images") or {}
    if image_ids is None:
        targets = list(images.keys())
    else:
        targets = list(dict.fromkeys(image_ids))
    for image_id in targets:
        record = images.get(image_id)
        if not isinstance(record, dict):
            continue
        apply_manifest_record_to_csv_row(
            csv_rows,
            image_id,
            record,
            local_root=local_root,
        )
    save_csv_rows(csv_path, csv_rows, ordered_ids)


def _parse_tosutil_size_token(token: str) -> int | None:
    cleaned = token.replace(",", "").strip()
    if not cleaned:
        return None
    if cleaned.isdigit():
        return int(cleaned)
    match = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)\s*([KMGTPE]?i?B)", cleaned, flags=re.IGNORECASE)
    if not match:
        return None
    value = float(match.group(1))
    unit = match.group(2).upper()
    # tosutil human-readable labels GB/MB/KB use 1024-based magnitudes (verified vs -bf=raw).
    factor = {
        "B": 1,
        "KB": 1024,
        "MB": 1024 ** 2,
        "GB": 1024 ** 3,
        "TB": 1024 ** 4,
        "PB": 1024 ** 5,
        "EB": 1024 ** 6,
        "KIB": 1024,
        "MIB": 1024 ** 2,
        "GIB": 1024 ** 3,
        "TIB": 1024 ** 4,
        "PIB": 1024 ** 5,
        "EIB": 1024 ** 6,
    }.get(unit)
    if factor is None:
        return None
    return int(value * factor)


def _extract_size_from_tosutil_tokens(tokens: list[str]) -> int | None:
    index = 0
    while index < len(tokens):
        token = tokens[index]
        size = _parse_tosutil_size_token(token)
        if size is not None:
            return size
        cleaned = token.replace(",", "")
        if (
            re.fullmatch(r"[0-9]+(?:\.[0-9]+)?", cleaned)
            and index + 1 < len(tokens)
            and re.fullmatch(r"[KMGTPE]?i?B", tokens[index + 1], flags=re.IGNORECASE)
        ):
            size = _parse_tosutil_size_token(cleaned + tokens[index + 1])
            if size is not None:
                return size
            index += 1
        index += 1
    return None


def parse_tosutil_ls_entries(stdout: str, bucket: str) -> list[tuple[str, int | None]]:
    """解析 tosutil ls 表格（含 key 换行、Size 在下一行、`-bf=raw`）。"""
    normalized_bucket = normalize_tos_bucket(bucket)
    bucket_prefix = "tos://%s/" % normalized_bucket
    skip_exact = {
        "object list:",
        "listing objects .",
        "listing objects.",
    }
    skip_prefixes = (
        "start at",
        "listing objects",
        "listing object",
        "total size",
        "file number",
        "object number",
        "bucket number",
        "next marker",
    )
    entries: list[tuple[str, int | None]] = []
    pending_uri: str | None = None

    def flush_pending() -> None:
        nonlocal pending_uri
        if pending_uri:
            entries.append((pending_uri, None))
            pending_uri = None

    for raw_line in stdout.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        lower = line.lower()
        if lower in skip_exact or any(lower.startswith(prefix) for prefix in skip_prefixes):
            continue
        if lower.startswith("key") and "lastmodified" in lower.replace(" ", ""):
            continue
        if line.startswith("tos://"):
            flush_pending()
            parts = line.split()
            uri = parts[0].rstrip("/")
            if not uri.startswith(bucket_prefix) or uri == bucket_prefix.rstrip("/"):
                continue
            # 过滤表头误识别：tos://bucket/key / Object 等
            key = uri[len(bucket_prefix) :]
            if not key or key.lower() in {"key", "object", "list"}:
                continue
            size = _extract_size_from_tosutil_tokens(parts[1:])
            if size is not None:
                entries.append((uri, size))
                pending_uri = None
            else:
                pending_uri = uri
            continue
        if pending_uri is not None:
            size = _extract_size_from_tosutil_tokens(line.split())
            if size is not None:
                entries.append((pending_uri, size))
                pending_uri = None
            continue
        # 相对 key 单行（精简/旧格式）
        parts = line.split()
        token = parts[0].lstrip("/")
        if "/" in token or token.endswith(".qcow2") or token.endswith(".txt"):
            if token.lower() in {"key", "object"}:
                continue
            uri = "tos://%s/%s" % (normalized_bucket, token)
            size = _extract_size_from_tosutil_tokens(parts[1:])
            entries.append((uri, size))
    flush_pending()
    return entries


def parse_tosutil_ls_object_uris(stdout: str, bucket: str, prefix: str) -> list[str]:
    del prefix  # 兼容旧签名；过滤在 match_tos_uris_for_image 中完成
    return list(dict.fromkeys(uri for uri, _size in parse_tosutil_ls_entries(stdout, bucket)))


def parse_tosutil_ls_object_sizes(stdout: str, bucket: str) -> dict[str, int]:
    """尽量从 tosutil ls 输出解析对象大小；解析失败的对象不出现在结果中。"""
    sizes: dict[str, int] = {}
    for uri, size in parse_tosutil_ls_entries(stdout, bucket):
        if size is not None and size > 0:
            sizes[uri] = size
    return sizes


def list_bucket_ls_stdout(bucket: str, *, force_refresh: bool = False) -> str:
    normalized_bucket = normalize_tos_bucket(bucket)
    with _TOS_CACHE_LOCK:
        if not force_refresh and normalized_bucket in _TOS_LS_CACHE:
            return _TOS_LS_CACHE[normalized_bucket]
    chunks: list[str] = []
    marker = ""
    # 分页 + raw 字节，避免默认 limit/多行 human size 解析失败
    for _ in range(200):
        args = ["-bf=raw", "-limit=1000"]
        if marker:
            args.append("-marker=%s" % marker)
        chunk = run_tosutil_ls("tos://%s/" % normalized_bucket, *args)
        chunks.append(chunk)
        next_marker = parse_tosutil_next_marker(chunk)
        if not next_marker or next_marker == marker:
            break
        marker = next_marker
    joined = "\n".join(chunks)
    with _TOS_CACHE_LOCK:
        _TOS_LS_CACHE[normalized_bucket] = joined
    return joined


def clear_tos_ls_cache(bucket: str | None = None) -> None:
    with _TOS_CACHE_LOCK:
        if bucket is None:
            _TOS_LS_CACHE.clear()
            _TOS_OBJECT_SIZE_CACHE.clear()
            return
        _TOS_LS_CACHE.pop(normalize_tos_bucket(bucket), None)
        prefix = "tos://%s/" % normalize_tos_bucket(bucket)
        for key in list(_TOS_OBJECT_SIZE_CACHE):
            if key.startswith(prefix):
                _TOS_OBJECT_SIZE_CACHE.pop(key, None)


def match_tos_uris_for_image(
    *,
    image_id: str,
    image_name: str,
    bucket: str,
    stdout: str,
) -> list[str]:
    tos_prefix = build_export_tos_prefix(image_name, image_id)
    candidates = parse_tosutil_ls_object_uris(stdout, bucket, tos_prefix)
    image_id_lower = image_id.lower()
    tos_prefix_lower = tos_prefix.lower()
    original_image_id = extract_original_image_id(image_name, image_id)
    original_prefix_lower = strip_image_id_prefix(original_image_id).lower()
    predicted = predict_export_object_uri(bucket, tos_prefix, image_id).rstrip("/").lower()
    matched = [
        uri
        for uri in candidates
        if tos_prefix_lower in uri.lower()
        or image_id_lower in uri.lower()
        or (
            original_prefix_lower
            and uri.lower().split("/")[-1].startswith("%s_" % original_prefix_lower)
        )
    ]

    def sort_key(uri: str) -> tuple[int, int, int]:
        lower = uri.lower().rstrip("/")
        is_predicted = 0 if lower == predicted else 1
        is_system = 0 if lower.endswith("_system.qcow2") or lower.endswith(DEFAULT_EXPORT_OBJECT_SUFFIX) else 1
        return (is_predicted, is_system, len(uri))

    return sorted(matched, key=sort_key)


def find_existing_tos_object(
    *,
    image_id: str,
    image_name: str,
    bucket: str,
    force_refresh: bool = False,
) -> str | None:
    stdout = list_bucket_ls_stdout(bucket, force_refresh=force_refresh)
    matched = match_tos_uris_for_image(
        image_id=image_id,
        image_name=image_name,
        bucket=bucket,
        stdout=stdout,
    )
    return matched[0] if matched else None


def lookup_tos_object_size(sizes: dict[str, int], tos_uri: str) -> int | None:
    """从 ls 解析结果中匹配对象大小（精确 URI / 去尾斜杠 / 唯一 basename）。"""
    target = (tos_uri or "").rstrip("/")
    if not target:
        return None
    if target in sizes:
        return int(sizes[target])
    for uri, size in sizes.items():
        if uri.rstrip("/") == target:
            return int(size)
    name = target.split("/")[-1]
    if not name:
        return None
    matches = [
        int(size)
        for uri, size in sizes.items()
        if uri.rstrip("/").endswith("/" + name) or uri.rstrip("/").endswith(name)
    ]
    if len(matches) == 1:
        return matches[0]
    return None


def stat_tos_object_bytes(tos_uri: str) -> int | None:
    """对单个对象执行 tosutil ls -bf=raw，读取真实大小。"""
    target = (tos_uri or "").strip().rstrip("/")
    if not target.startswith("tos://"):
        return None
    cached = _TOS_OBJECT_SIZE_CACHE.get(target)
    if cached is not None:
        return cached
    try:
        stdout = run_tosutil_ls(target, "-bf=raw", "-limit=10")
    except (RuntimeError, subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired) as exc:
        print("读取 TOS 对象大小失败: %s error=%s" % (target, exc))
        return None
    # tos://bucket/key...
    parts = target[len("tos://") :].split("/", 1)
    bucket = parts[0] if parts else ""
    if not bucket:
        return None
    sizes = parse_tosutil_ls_object_sizes(stdout, bucket)
    size = lookup_tos_object_size(sizes, target)
    if size is None:
        # 有些 tosutil 版本对单对象 ls 只输出一行，且可能只有相对 key
        for uri, value in sizes.items():
            if target.endswith(uri.split("/")[-1]):
                size = int(value)
                break
    if size is not None and size > 0:
        with _TOS_CACHE_LOCK:
            _TOS_OBJECT_SIZE_CACHE[target] = size
    return size


def estimate_tos_object_bytes(
    *,
    tos_uri: str,
    bucket: str,
    image: dict[str, Any] | None = None,
    allow_image_fallback: bool = False,
) -> int | None:
    """返回 TOS 对象真实字节数。

    磁盘预检默认禁止回退到 ECS DescribeImages.Size（常见 50/100/1024 GiB 虚盘规格），
    避免误判本地磁盘不足。
    """
    stdout = list_bucket_ls_stdout(bucket)
    sizes = parse_tosutil_ls_object_sizes(stdout, bucket)
    size = lookup_tos_object_size(sizes, tos_uri)
    if size is not None:
        with _TOS_CACHE_LOCK:
            _TOS_OBJECT_SIZE_CACHE[tos_uri.rstrip("/")] = size
        return size

    size = stat_tos_object_bytes(tos_uri)
    if size is not None:
        return size

    if allow_image_fallback and image is not None:
        return estimate_image_bytes(image)
    return None


def inventory_tos_ready_images(
    candidates: list[dict[str, Any]],
    *,
    bucket: str,
    manifest: dict[str, Any],
    manifest_path: Path,
    csv_rows: dict[str, dict[str, str]] | None = None,
    csv_path: Path | None = None,
    ordered_ids: list[str] | None = None,
    local_root: Path | None = None,
) -> dict[str, dict[str, Any]]:
    """启动时扫描 TOS：识别已就绪目标镜像（优先 *_system.qcow2）并写入真实大小。"""
    stdout = list_bucket_ls_stdout(bucket, force_refresh=True)
    sizes = parse_tosutil_ls_object_sizes(stdout, bucket)
    with _TOS_CACHE_LOCK:
        for uri, size in sizes.items():
            _TOS_OBJECT_SIZE_CACHE[uri.rstrip("/")] = size

    ready: dict[str, dict[str, Any]] = {}
    updated_ids: list[str] = []
    for image in candidates:
        image_id = image_record_field(image, "ImageId", "image_id")
        image_name = image_display_name(image)
        matched = match_tos_uris_for_image(
            image_id=image_id,
            image_name=image_name,
            bucket=bucket,
            stdout=stdout,
        )
        if not matched:
            continue
        tos_uri = matched[0]
        size_bytes = lookup_tos_object_size(sizes, tos_uri) or stat_tos_object_bytes(tos_uri)
        ready[image_id] = {
            "tos_object_uri": tos_uri,
            "size_bytes": size_bytes,
            "image_name": image_name,
        }
        record = manifest.get("images", {}).get(image_id)
        if not isinstance(record, dict):
            continue
        status = str(record.get("status") or STATUS_PENDING)
        if status in (STATUS_UPLOADED, STATUS_DOWNLOADED, STATUS_SKIPPED_WINDOWS, STATUS_UNMATCHED):
            # 仍补齐 URI/大小，但不改终态
            patch: dict[str, Any] = {"tos_object_uri": tos_uri}
            if size_bytes:
                patch["size_text"] = format_size_text(size_bytes)
            update_image_record(manifest, image_id, **patch)
            updated_ids.append(image_id)
            continue
        patch = {
            "status": STATUS_EXPORTED,
            "tos_object_uri": tos_uri,
            "error": "",
        }
        if size_bytes:
            patch["size_text"] = format_size_text(size_bytes)
        else:
            patch["error"] = "TOS 已存在但未能解析对象大小"
        update_image_record(manifest, image_id, **patch)
        updated_ids.append(image_id)

    save_manifest(manifest_path, manifest)
    if csv_rows is not None and csv_path is not None and local_root is not None:
        sync_csv_from_manifest(
            csv_rows=csv_rows,
            csv_path=csv_path,
            ordered_ids=ordered_ids or list(csv_rows.keys()),
            manifest=manifest,
            local_root=local_root,
            image_ids=updated_ids or None,
        )
    with_size = sum(1 for item in ready.values() if item.get("size_bytes"))
    print(
        "TOS 清单: 候选=%s 已就绪=%s（含真实大小=%s）"
        % (len(candidates), len(ready), with_size)
    )
    return ready


def list_hf_repo_system_qcow2_paths(api: Any, *, repo_id: str, repo_type: str) -> set[str]:
    """列出仓库内 *_system.qcow2；仓库不存在或无权访问时返回空集。"""
    try:
        files = api.list_repo_files(repo_id=repo_id, repo_type=repo_type)
    except Exception as exc:
        print("读取 HF 仓库文件列表失败（跳过）: %s error=%s" % (repo_id, exc))
        return set()
    return {str(path) for path in (files or []) if str(path).endswith("_system.qcow2")}


def build_hf_uploaded_path_index(
    api: Any,
    *,
    base_repo_id: str,
    repo_type: str,
    max_repos: int,
) -> dict[str, tuple[int, str, str]]:
    """按镜像目录名索引 HF 上已有 qcow2。

    返回: folder_name -> (repo_index, repo_id, path_in_repo)
    同一目录出现在多个仓时，优先保留序号更小的仓（基仓优先于 -2/-3）。
    """
    index: dict[str, tuple[int, str, str]] = {}
    base = (base_repo_id or "").strip()
    if not base:
        return index
    for repo_index in range(1, max(1, int(max_repos)) + 1):
        repo_id = incremental_repo_id(base, repo_index)
        for path in list_hf_repo_system_qcow2_paths(api, repo_id=repo_id, repo_type=repo_type):
            folder = path.split("/", 1)[0]
            if not folder:
                continue
            existing = index.get(folder)
            if existing is None or repo_index < existing[0]:
                index[folder] = (repo_index, repo_id, path)
    return index


def reconcile_uploaded_from_hf_repos(
    candidates: list[dict[str, Any]],
    *,
    base_repo_id: str,
    repo_type: str,
    max_repos: int,
    manifest: dict[str, Any],
    manifest_path: Path,
    csv_rows: dict[str, dict[str, str]] | None = None,
    csv_path: Path | None = None,
    ordered_ids: list[str] | None = None,
    local_root: Path | None = None,
    api: Any | None = None,
) -> dict[str, str]:
    """启动时对照 HF 仓实际文件，把已存在的镜像标为 uploaded 并回写 CSV。

    成功判定以仓内真实 path 为准；若基仓与 -2/-3 都有，路径优先写成基仓。
    """
    base = (base_repo_id or "").strip()
    if not base:
        print("跳过 HF 对账: 未配置 --repo-id / HF_REPO_ID")
        return {}

    if api is None:
        token = resolve_hf_token()
        if not token:
            print("跳过 HF 对账: 缺少 HF_TOKEN")
            return {}
        from huggingface_hub import HfApi

        api = HfApi(token=token)

    path_index = build_hf_uploaded_path_index(
        api,
        base_repo_id=base,
        repo_type=repo_type,
        max_repos=max_repos,
    )
    if not path_index:
        print("HF 对账: 未在 %s(/-2…) 扫到 *_system.qcow2" % base)
        return {}

    updated: dict[str, str] = {}
    updated_ids: list[str] = []
    for image in candidates:
        image_id = image_record_field(image, "ImageId", "image_id")
        image_name = image_display_name(image)
        record = manifest.get("images", {}).get(image_id)
        if not isinstance(record, dict):
            continue
        status = str(record.get("status") or STATUS_PENDING)
        if status in (STATUS_SKIPPED_WINDOWS, STATUS_UNMATCHED):
            continue

        folder = safe_local_path_name(image_name, image_id)
        hit = path_index.get(folder)
        if hit is None:
            # 兼容目录名与 image_name 不完全一致时，用期望相对路径的目录段再试
            expected = hf_relative_path(image_name, image_id)
            expected_folder = expected.split("/", 1)[0]
            hit = path_index.get(expected_folder)
        if hit is None:
            continue

        _repo_index, repo_id, path_in_repo = hit
        hf_path = "%s:%s" % (repo_id, path_in_repo)
        old_hf = str(record.get("hf_path") or "")
        if status == STATUS_UPLOADED and old_hf == hf_path and str(record.get("hf_repo_id") or "") == repo_id:
            continue

        update_image_record(
            manifest,
            image_id,
            status=STATUS_UPLOADED,
            hf_path=hf_path,
            hf_repo_id=repo_id,
            error="",
        )
        updated[image_id] = hf_path
        updated_ids.append(image_id)

    if updated_ids:
        manifest["hf_reconciled_at"] = utc_now_iso()
        save_manifest(manifest_path, manifest)
        if csv_rows is not None and csv_path is not None and local_root is not None:
            sync_csv_from_manifest(
                csv_rows=csv_rows,
                csv_path=csv_path,
                ordered_ids=ordered_ids or list(csv_rows.keys()),
                manifest=manifest,
                local_root=local_root,
                image_ids=updated_ids,
            )

    print(
        "HF 对账: 扫描仓=%s(/-2…) 命中目录=%s 回写 uploaded=%s"
        % (base, len(path_index), len(updated))
    )
    return updated


def sort_images_tos_ready_first(
    images: list[dict[str, Any]],
    manifest: dict[str, Any],
) -> list[dict[str, Any]]:
    """下载队列：TOS 已就绪且有真实大小的优先，体积小的优先。"""

    def sort_key(image: dict[str, Any]) -> tuple[int, int, str]:
        image_id = image_record_field(image, "ImageId", "image_id")
        record = manifest.get("images", {}).get(image_id) or {}
        uri = str(record.get("tos_object_uri") or "")
        size_text = str(record.get("size_text") or "")
        size_bytes = _TOS_OBJECT_SIZE_CACHE.get(uri.rstrip("/")) if uri else None
        if size_bytes is None and size_text:
            # format_size_text 是展示用；优先 cache
            size_bytes = None
        ready_rank = 0 if uri else 1
        size_rank = int(size_bytes) if size_bytes else 1 << 62
        return (ready_rank, size_rank, image_id)

    return sorted(images, key=sort_key)


def estimate_image_bytes(image: dict[str, Any]) -> int | None:
    for key in ("Size", "size", "SizeGiB", "size_gib", "ImageSize"):
        raw = image.get(key)
        if raw is None or raw == "":
            continue
        try:
            value = float(raw)
        except (TypeError, ValueError):
            continue
        if value <= 0:
            continue
        # Volcengine DescribeImages 的 Size 通常是 GiB
        if value < 4096:
            return int(value * (1024 ** 3))
        return int(value)
    return None


def local_disk_free_bytes(path: Path) -> int:
    target = path if path.exists() else path.parent
    if not target.exists():
        target.mkdir(parents=True, exist_ok=True)
    return int(shutil.disk_usage(str(target)).free)


def has_enough_local_disk(*, path: Path, required_bytes: int | None) -> tuple[bool, int]:
    free_bytes = local_disk_free_bytes(path)
    if required_bytes is None or required_bytes <= 0:
        return True, free_bytes
    needed = int(required_bytes * DEFAULT_DISK_SIZE_FACTOR) + DEFAULT_DISK_FREE_MARGIN_BYTES
    return free_bytes >= needed, free_bytes


def resolve_exported_object_uri(
    *,
    image_id: str,
    image_name: str,
    bucket: str,
    export_result: dict[str, Any] | None = None,
) -> str:
    if export_result and export_result.get("tos_object_uri"):
        return str(export_result["tos_object_uri"])
    existing = find_existing_tos_object(image_id=image_id, image_name=image_name, bucket=bucket)
    if existing:
        return existing
    tos_prefix = build_export_tos_prefix(image_name, image_id)
    return predict_export_object_uri(bucket, tos_prefix, image_id)


def is_hf_storage_error(exc: BaseException) -> bool:
    text = str(exc).lower()
    return any(marker in text for marker in HF_STORAGE_ERROR_MARKERS)


def incremental_repo_id(base_repo_id: str, index: int) -> str:
    if index <= 1:
        return base_repo_id
    return "%s-%s" % (base_repo_id, index)


class HfRepoRotator:
    """按 HF_REPO_ID / HF_REPO_ID-2 / HF_REPO_ID-3 ... 自动建仓并轮换。"""

    def __init__(
        self,
        *,
        base_repo_id: str,
        repo_type: str,
        private: bool | None,
        soft_limit_gib: float = DEFAULT_HF_REPO_SOFT_LIMIT_GIB,
        max_repos: int = DEFAULT_HF_MAX_AUTO_REPOS,
        start_index: int = 1,
    ) -> None:
        self.base_repo_id = (base_repo_id or "").strip()
        self.repo_type = repo_type
        self.private = True if private is None else bool(private)
        self.soft_limit_bytes = int(float(soft_limit_gib) * (1024 ** 3))
        self.max_repos = max(1, int(max_repos))
        self.current_index = max(1, int(start_index))
        self.exhausted = False
        self._api: Any | None = None

    @property
    def current_repo_id(self) -> str:
        return incremental_repo_id(self.base_repo_id, self.current_index)

    def _get_api(self) -> Any:
        if self._api is None:
            from huggingface_hub import HfApi

            token = resolve_hf_token()
            if not token:
                raise SystemExit("缺少 HF_TOKEN（或 HUGGINGFACE_HUB_TOKEN），无法上传到 Hugging Face")
            self._api = HfApi(token=token)
        return self._api

    def ensure_current_repo(self) -> str:
        repo_id = self.current_repo_id
        self._get_api().create_repo(
            repo_id=repo_id,
            repo_type=self.repo_type,
            private=self.private,
            exist_ok=True,
        )
        return repo_id

    def repo_used_bytes(self, repo_id: str) -> int | None:
        try:
            info = self._get_api().repo_info(repo_id=repo_id, repo_type=self.repo_type)
        except Exception as exc:
            print("读取 HF 仓库用量失败: %s error=%s" % (repo_id, exc))
            return None
        used = getattr(info, "used_storage", None)
        if used is None:
            return None
        try:
            return int(used)
        except (TypeError, ValueError):
            return None

    def can_fit(self, needed_bytes: int) -> bool:
        if needed_bytes <= 0:
            return True
        used = self.repo_used_bytes(self.current_repo_id)
        if used is None:
            # 读不到用量时先尝试当前仓，上传失败再轮换
            return True
        return (used + needed_bytes) <= self.soft_limit_bytes

    def rotate(self) -> bool:
        if self.current_index >= self.max_repos:
            self.exhausted = True
            print(
                "HF 自动建仓已达上限 (%s)，停止本地下载与 HF 上传；TOS 导出仍可继续"
                % self.max_repos
            )
            return False
        self.current_index += 1
        repo_id = self.ensure_current_repo()
        print("切换到下一个 HF 仓库: %s" % repo_id)
        return True

    def prepare_for_upload(self, needed_bytes: int) -> str | None:
        if self.exhausted or not self.base_repo_id:
            self.exhausted = True
            return None
        while not self.exhausted:
            repo_id = self.ensure_current_repo()
            if self.can_fit(needed_bytes):
                return repo_id
            print(
                "HF 仓库空间不足预检未通过: %s need=%s soft_limit=%s"
                % (repo_id, format_size_text(needed_bytes), format_size_text(self.soft_limit_bytes))
            )
            if not self.rotate():
                return None
        return None

    def mark_exhausted(self, reason: str = "") -> None:
        self.exhausted = True
        if reason:
            print("HF 上传已停止: %s" % reason)


def download_exported_image(
    *,
    tos_uri: str,
    local_dir: Path,
    image_name: str,
    image_id: str,
) -> Path:
    local_dir.mkdir(parents=True, exist_ok=True)
    temp_path = local_dir / (".download-%s.tmp" % image_id)
    if temp_path.exists():
        temp_path.unlink()
    run_tosutil_cp(tos_uri, str(temp_path))
    if not temp_path.is_file() or temp_path.stat().st_size <= 0:
        raise RuntimeError("TOS 下载失败或文件为空: %s" % tos_uri)
    target_path = local_dir / local_export_filename(image_name, image_id)
    if target_path.exists():
        target_path.unlink()
    temp_path.replace(target_path)
    return target_path


def image_local_subdir(local_root: Path, image_name: str, image_id: str) -> Path:
    return local_root / safe_local_path_name(image_name, image_id)


def image_allow_pattern(local_root: Path, image_name: str, image_id: str) -> str:
    relative = image_local_subdir(local_root, image_name, image_id).relative_to(local_root).as_posix()
    return "%s/**" % relative


def chunk_images(images: list[dict[str, Any]], batch_size: int) -> list[list[dict[str, Any]]]:
    if batch_size <= 0:
        return [images]
    return [images[index : index + batch_size] for index in range(0, len(images), batch_size)]


def load_manifest(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def save_manifest(path: Path, manifest: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    manifest["updated_at"] = utc_now_iso()
    path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def init_manifest(
    *,
    path: Path,
    repo_id: str,
    repo_type: str,
    candidates: list[dict[str, Any]],
    batch_size: int,
) -> dict[str, Any]:
    existing = load_manifest(path)
    images_state = existing.get("images") if isinstance(existing.get("images"), dict) else {}
    images: dict[str, Any] = {}
    for image in candidates:
        image_id = image_record_field(image, "ImageId", "image_id")
        image_name = image_display_name(image)
        prior = images_state.get(image_id) if isinstance(images_state.get(image_id), dict) else {}
        images[image_id] = {
            "image_id": image_id,
            "image_name": image_name,
            "original_image_id": extract_original_image_id(image_name, image_id),
            "status": prior.get("status", STATUS_PENDING),
            "batch_index": prior.get("batch_index"),
            "tos_object_uri": prior.get("tos_object_uri", ""),
            "local_file": prior.get("local_file", ""),
            "size_text": prior.get("size_text", ""),
            "hf_path": prior.get("hf_path") or hf_relative_path(image_name, image_id),
            "error": prior.get("error", ""),
            "updated_at": prior.get("updated_at", ""),
        }
    manifest = {
        "started_at": existing.get("started_at") or utc_now_iso(),
        "updated_at": utc_now_iso(),
        "repo_id": repo_id,
        "repo_type": repo_type,
        "batch_size": batch_size,
        "total_candidates": len(candidates),
        "images": images,
        "batches": existing.get("batches") if isinstance(existing.get("batches"), list) else [],
    }
    save_manifest(path, manifest)
    return manifest


def manifest_counts(manifest: dict[str, Any]) -> dict[str, int]:
    images = manifest.get("images") or {}
    counts = {
        STATUS_PENDING: 0,
        STATUS_EXPORTED: 0,
        STATUS_DOWNLOADED: 0,
        STATUS_UPLOADED: 0,
        STATUS_FAILED: 0,
    }
    for record in images.values():
        status = record.get("status", STATUS_PENDING)
        counts[status] = counts.get(status, 0) + 1
    return counts


def print_progress(manifest: dict[str, Any], *, prefix: str = "") -> None:
    counts = manifest_counts(manifest)
    total = manifest.get("total_candidates", 0)
    print(
        "%s进度: total=%s pending=%s exported=%s downloaded=%s uploaded=%s "
        "skipped_disk=%s skipped_hf_full=%s failed=%s"
        % (
            prefix,
            total,
            counts.get(STATUS_PENDING, 0),
            counts.get(STATUS_EXPORTED, 0),
            counts.get(STATUS_DOWNLOADED, 0),
            counts.get(STATUS_UPLOADED, 0),
            counts.get(STATUS_SKIPPED_DISK, 0),
            counts.get(STATUS_SKIPPED_HF_FULL, 0),
            counts.get(STATUS_FAILED, 0),
        )
    )


def update_image_record(manifest: dict[str, Any], image_id: str, **fields: Any) -> None:
    record = manifest["images"][image_id]
    record.update(fields)
    record["updated_at"] = utc_now_iso()


def select_pending_images(
    candidates: list[dict[str, Any]],
    manifest: dict[str, Any],
    *,
    resume: bool,
) -> list[dict[str, Any]]:
    if not resume:
        return candidates
    pending: list[dict[str, Any]] = []
    for image in candidates:
        image_id = image_record_field(image, "ImageId", "image_id")
        status = manifest["images"][image_id]["status"]
        if status != STATUS_UPLOADED:
            pending.append(image)
    return pending


def _persist_manifest_csv(
    *,
    state_lock: threading.Lock | None,
    manifest: dict[str, Any],
    manifest_path: Path,
    image_id: str,
    fields: dict[str, Any],
    csv_rows: dict[str, dict[str, str]] | None = None,
    csv_path: Path | None = None,
    ordered_ids: list[str] | None = None,
    local_root: Path | None = None,
) -> None:
    def _do() -> None:
        update_image_record(manifest, image_id, **fields)
        save_manifest(manifest_path, manifest)
        if csv_rows is not None and csv_path is not None and local_root is not None:
            sync_csv_from_manifest(
                csv_rows=csv_rows,
                csv_path=csv_path,
                ordered_ids=ordered_ids or list(csv_rows.keys()),
                manifest=manifest,
                local_root=local_root,
                image_ids=[image_id],
            )

    if state_lock is None:
        _do()
    else:
        with state_lock:
            _do()


def process_single_image_download(
    *,
    image: dict[str, Any],
    local_root: Path,
    bucket: str,
    export_result: dict[str, Any] | None,
    manifest: dict[str, Any],
    manifest_path: Path,
    csv_rows: dict[str, dict[str, str]] | None = None,
    csv_path: Path | None = None,
    ordered_ids: list[str] | None = None,
    state_lock: threading.Lock | None = None,
) -> dict[str, Any] | None:
    image_id = image_record_field(image, "ImageId", "image_id")
    image_name = image_display_name(image)
    tos_object_uri = resolve_exported_object_uri(
        image_id=image_id,
        image_name=image_name,
        bucket=bucket,
        export_result=export_result,
    )
    required_bytes = estimate_tos_object_bytes(
        tos_uri=tos_object_uri,
        bucket=bucket,
        image=image,
        allow_image_fallback=False,
    )
    local_image_dir = image_local_subdir(local_root, image_name, image_id)
    if required_bytes is None:
        _persist_manifest_csv(
            state_lock=state_lock,
            manifest=manifest,
            manifest_path=manifest_path,
            image_id=image_id,
            fields={
                "status": STATUS_FAILED,
                "tos_object_uri": tos_object_uri,
                "error": "无法读取 TOS 对象真实大小，拒绝盲下: %s" % tos_object_uri,
            },
            csv_rows=csv_rows,
            csv_path=csv_path,
            ordered_ids=ordered_ids,
            local_root=local_root,
        )
        print(
            "无法读取 TOS 真实大小，跳过下载: %s uri=%s"
            % (image_name, tos_object_uri)
        )
        return None
    enough, free_bytes = has_enough_local_disk(path=local_image_dir, required_bytes=required_bytes)
    if not enough:
        _persist_manifest_csv(
            state_lock=state_lock,
            manifest=manifest,
            manifest_path=manifest_path,
            image_id=image_id,
            fields={
                "status": STATUS_SKIPPED_DISK,
                "tos_object_uri": tos_object_uri,
                "size_text": format_size_text(required_bytes),
                "error": "磁盘不足: need≈%s free=%s (tos真实大小)"
                % (format_size_text(required_bytes), format_size_text(free_bytes)),
            },
            csv_rows=csv_rows,
            csv_path=csv_path,
            ordered_ids=ordered_ids,
            local_root=local_root,
        )
        print(
            "磁盘不足，跳过下载: %s need≈%s free=%s (基于 TOS 真实大小)"
            % (image_name, format_size_text(required_bytes), format_size_text(free_bytes))
        )
        return None

    local_file = download_exported_image(
        tos_uri=tos_object_uri,
        local_dir=local_image_dir,
        image_name=image_name,
        image_id=image_id,
    )
    size_text = format_size_text(local_file.stat().st_size)
    hf_path = hf_relative_path(image_name, image_id)
    summary = summarize_folder(local_image_dir, allow_patterns=None, ignore_patterns=None)
    _persist_manifest_csv(
        state_lock=state_lock,
        manifest=manifest,
        manifest_path=manifest_path,
        image_id=image_id,
        fields={
            "status": STATUS_DOWNLOADED,
            "tos_object_uri": tos_object_uri,
            "local_file": str(local_file),
            "size_text": size_text,
            "hf_path": hf_path,
            "error": "",
        },
        csv_rows=csv_rows,
        csv_path=csv_path,
        ordered_ids=ordered_ids,
        local_root=local_root,
    )
    print(
        "已下载并重建名字: %s -> %s files=%s size=%s"
        % (image_name, local_file, summary["file_count"], size_text)
    )
    return {
        "image_id": image_id,
        "image_name": image_name,
        "tos_object_uri": tos_object_uri,
        "local_file": str(local_file),
        "hf_path": hf_path,
        "allow_pattern": image_allow_pattern(local_root, image_name, image_id),
        "size_bytes": local_file.stat().st_size,
    }


def consume_tos_ready_job(
    *,
    job: dict[str, Any],
    args: argparse.Namespace,
    local_root: Path,
    manifest: dict[str, Any],
    manifest_path: Path,
    csv_rows: dict[str, dict[str, str]] | None,
    csv_path: Path | None,
    ordered_ids: list[str] | None,
    hf_rotator: HfRepoRotator | None,
    state_lock: threading.Lock,
) -> None:
    """消费者：下载 -> 上传 HF -> 清理本地。"""
    image = job["image"]
    image_id = image_record_field(image, "ImageId", "image_id")
    tos_object_uri = str(job.get("tos_object_uri") or "")
    export_result = {
        "image_id": image_id,
        "image_name": image_display_name(image),
        "tos_object_uri": tos_object_uri,
    }

    if (not args.skip_upload) and hf_rotator is not None:
        with state_lock:
            exhausted = hf_rotator.exhausted
        if exhausted:
            _persist_manifest_csv(
                state_lock=state_lock,
                manifest=manifest,
                manifest_path=manifest_path,
                image_id=image_id,
                fields={
                    "status": STATUS_SKIPPED_HF_FULL,
                    "tos_object_uri": tos_object_uri,
                    "error": "HF 仓库空间已满，停止本地下载与上传",
                },
                csv_rows=csv_rows,
                csv_path=csv_path,
                ordered_ids=ordered_ids,
                local_root=local_root,
            )
            return

    if args.skip_download:
        return

    try:
        record = process_single_image_download(
            image=image,
            local_root=local_root,
            bucket=args.tos_bucket,
            export_result=export_result,
            manifest=manifest,
            manifest_path=manifest_path,
            csv_rows=csv_rows,
            csv_path=csv_path,
            ordered_ids=ordered_ids,
            state_lock=state_lock,
        )
    except (RuntimeError, subprocess.CalledProcessError) as exc:
        _persist_manifest_csv(
            state_lock=state_lock,
            manifest=manifest,
            manifest_path=manifest_path,
            image_id=image_id,
            fields={"status": STATUS_FAILED, "error": "download: %s" % exc},
            csv_rows=csv_rows,
            csv_path=csv_path,
            ordered_ids=ordered_ids,
            local_root=local_root,
        )
        print("下载失败: %s error=%s" % (image_display_name(image), exc))
        return

    if record is None or args.skip_upload:
        return

    # 单文件 HF 上传固定 1 worker，避免多消费管道再叠多层 LFS 线程
    hf_upload_workers = 1
    if hf_rotator is None:
        repo_id = args.repo_id
    else:
        with state_lock:
            if hf_rotator.exhausted:
                repo_id = None
            else:
                size_bytes = int(record.get("size_bytes") or 0)
                repo_id = hf_rotator.prepare_for_upload(size_bytes)
                if hf_rotator.exhausted and repo_id is None:
                    pass
        if repo_id is None:
            _persist_manifest_csv(
                state_lock=state_lock,
                manifest=manifest,
                manifest_path=manifest_path,
                image_id=record["image_id"],
                fields={
                    "status": STATUS_SKIPPED_HF_FULL,
                    "error": "HF 仓库空间已满，停止上传",
                },
                csv_rows=csv_rows,
                csv_path=csv_path,
                ordered_ids=ordered_ids,
                local_root=local_root,
            )
            return

    print(
        "上传 HF: %s -> %s size=%s workers=%s"
        % (
            record["image_name"],
            repo_id,
            format_size_text(record.get("size_bytes")),
            hf_upload_workers,
        )
    )
    upload_ok = False
    last_error: BaseException | None = None
    for attempt in range(1, 4):
        try:
            # 多消费管道串行化 HF 上传，避免同一 local_root 并发 upload_large_folder 冲突
            with _HF_UPLOAD_LOCK:
                repo_url = upload_large_folder_to_hub(
                    repo_id=repo_id,
                    folder_path=local_root,
                    repo_type=args.repo_type,
                    revision=args.revision,
                    private=args.private,
                    allow_patterns=[record["allow_pattern"]],
                    ignore_patterns=["**/.download-*.tmp", "**/*.tmp"],
                    num_workers=hf_upload_workers,
                    use_cli=False,
                )
            relative = record.get("hf_path") or hf_relative_path(record["image_name"], record["image_id"])
            hf_path = "%s:%s" % (repo_id, relative)
            _persist_manifest_csv(
                state_lock=state_lock,
                manifest=manifest,
                manifest_path=manifest_path,
                image_id=record["image_id"],
                fields={
                    "status": STATUS_UPLOADED,
                    "hf_path": hf_path,
                    "hf_repo_id": repo_id,
                    "error": "",
                },
                csv_rows=csv_rows,
                csv_path=csv_path,
                ordered_ids=ordered_ids,
                local_root=local_root,
            )
            record["hf_path"] = hf_path
            record["repo_url"] = repo_url
            upload_ok = True
            print("上传完成: %s -> %s" % (record["image_name"], hf_path))
            break
        except (SystemExit, RuntimeError, OSError) as exc:
            last_error = exc
            if hf_rotator is not None and is_hf_storage_error(exc):
                print("HF 空间不足，尝试切换仓库: %s error=%s" % (repo_id, exc))
                with state_lock:
                    rotated = hf_rotator.rotate()
                    if rotated:
                        repo_id = hf_rotator.current_repo_id
                if not rotated:
                    break
                continue
            if attempt >= 3:
                break
            print("上传失败，重试 %s/3: %s error=%s" % (attempt, record["image_name"], exc))
            time.sleep(5)

    if not upload_ok:
        if hf_rotator is not None and last_error is not None and is_hf_storage_error(last_error):
            with state_lock:
                hf_rotator.mark_exhausted(str(last_error))
            _persist_manifest_csv(
                state_lock=state_lock,
                manifest=manifest,
                manifest_path=manifest_path,
                image_id=record["image_id"],
                fields={
                    "status": STATUS_SKIPPED_HF_FULL,
                    "error": "upload storage: %s" % last_error,
                },
                csv_rows=csv_rows,
                csv_path=csv_path,
                ordered_ids=ordered_ids,
                local_root=local_root,
            )
        else:
            _persist_manifest_csv(
                state_lock=state_lock,
                manifest=manifest,
                manifest_path=manifest_path,
                image_id=record["image_id"],
                fields={"status": STATUS_FAILED, "error": "upload: %s" % last_error},
                csv_rows=csv_rows,
                csv_path=csv_path,
                ordered_ids=ordered_ids,
                local_root=local_root,
            )
            if isinstance(last_error, SystemExit) and (
                hf_rotator is None or not is_hf_storage_error(last_error)
            ):
                if not args.continue_on_error:
                    raise last_error
        return

    if args.cleanup_after_upload:
        cleanup_local_image_files([record], local_root=local_root)


def produce_tos_ready_job(
    *,
    image: dict[str, Any],
    args: argparse.Namespace,
    ready_queue: Queue,
    manifest: dict[str, Any],
    manifest_path: Path,
    csv_rows: dict[str, dict[str, str]] | None,
    csv_path: Path | None,
    ordered_ids: list[str] | None,
    local_root: Path,
    state_lock: threading.Lock,
    stop_event: threading.Event,
) -> None:
    """生产者：TOS 已存在或 ExportImage 成功后入队。"""
    if stop_event.is_set():
        return
    image_id = image_record_field(image, "ImageId", "image_id")
    image_name = image_display_name(image)

    # 优先用 inventory/manifest 已写入的 URI，减少并发 tosutil ls
    with state_lock:
        prior_uri = str((manifest.get("images") or {}).get(image_id, {}).get("tos_object_uri") or "")

    existing_uri = prior_uri
    if not existing_uri:
        if not args.skip_export:
            existing_uri = find_existing_tos_object(
                image_id=image_id,
                image_name=image_name,
                bucket=args.tos_bucket,
            ) or ""
        else:
            existing_uri = find_existing_tos_object(
                image_id=image_id,
                image_name=image_name,
                bucket=args.tos_bucket,
            ) or ""
            if not existing_uri:
                tos_prefix = build_export_tos_prefix(image_name, image_id)
                existing_uri = predict_export_object_uri(args.tos_bucket, tos_prefix, image_id)

    tos_uri = existing_uri
    if existing_uri and (prior_uri or not args.skip_export):
        size_bytes = _TOS_OBJECT_SIZE_CACHE.get(existing_uri.rstrip("/")) or stat_tos_object_bytes(existing_uri)
        _persist_manifest_csv(
            state_lock=state_lock,
            manifest=manifest,
            manifest_path=manifest_path,
            image_id=image_id,
            fields={
                "status": STATUS_EXPORTED,
                "tos_object_uri": existing_uri,
                "size_text": format_size_text(size_bytes) if size_bytes else "",
                "error": "",
            },
            csv_rows=csv_rows,
            csv_path=csv_path,
            ordered_ids=ordered_ids,
            local_root=local_root,
        )
        print("TOS 已存在，跳过导出: %s -> %s" % (image_name, existing_uri))
    elif not args.skip_export:
        try:
            api = create_api_instance(SOURCE_REGION)
            result = export_image_to_tos(
                api,
                image,
                tos_bucket=args.tos_bucket,
                poll_interval_seconds=args.poll_interval_seconds,
                timeout_seconds=args.timeout_seconds,
            )
            # 不整桶清缓存（并发生产者会互相踩）；只按对象 stat 真实大小
            tos_uri = str(result.get("tos_object_uri") or "")
            size_bytes = stat_tos_object_bytes(tos_uri) if tos_uri else None
            _persist_manifest_csv(
                state_lock=state_lock,
                manifest=manifest,
                manifest_path=manifest_path,
                image_id=image_id,
                fields={
                    "status": STATUS_EXPORTED,
                    "tos_object_uri": tos_uri,
                    "size_text": format_size_text(size_bytes) if size_bytes else "",
                    "error": "",
                },
                csv_rows=csv_rows,
                csv_path=csv_path,
                ordered_ids=ordered_ids,
                local_root=local_root,
            )
            print("导出完成: %s -> %s" % (image_name, tos_uri))
        except Exception as exc:
            _persist_manifest_csv(
                state_lock=state_lock,
                manifest=manifest,
                manifest_path=manifest_path,
                image_id=image_id,
                fields={"status": STATUS_FAILED, "error": str(exc)},
                csv_rows=csv_rows,
                csv_path=csv_path,
                ordered_ids=ordered_ids,
                local_root=local_root,
            )
            print("导出失败: %s error=%s" % (image_name, exc))
            if not args.continue_on_error:
                stop_event.set()
                raise
            return
    else:
        # skip_export: 使用已解析 URI
        size_bytes = _TOS_OBJECT_SIZE_CACHE.get(tos_uri.rstrip("/")) if tos_uri else None
        if size_bytes is None and tos_uri:
            size_bytes = stat_tos_object_bytes(tos_uri)
        _persist_manifest_csv(
            state_lock=state_lock,
            manifest=manifest,
            manifest_path=manifest_path,
            image_id=image_id,
            fields={
                "status": STATUS_EXPORTED,
                "tos_object_uri": tos_uri,
                "size_text": format_size_text(size_bytes) if size_bytes else "",
                "error": "",
            },
            csv_rows=csv_rows,
            csv_path=csv_path,
            ordered_ids=ordered_ids,
            local_root=local_root,
        )

    if stop_event.is_set() or args.skip_download:
        return
    if not tos_uri:
        return
    size_bytes = _TOS_OBJECT_SIZE_CACHE.get(tos_uri.rstrip("/"))
    ready_queue.put(
        {
            "image": image,
            "tos_object_uri": tos_uri,
            "size_bytes": size_bytes,
        }
    )


def run_producer_consumer_pipeline(
    *,
    work_images: list[dict[str, Any]],
    args: argparse.Namespace,
    local_root: Path,
    manifest: dict[str, Any],
    manifest_path: Path,
    csv_rows: dict[str, dict[str, str]] | None = None,
    csv_path: Path | None = None,
    ordered_ids: list[str] | None = None,
    hf_rotator: HfRepoRotator | None = None,
) -> None:
    """生产者(导出/识别 TOS) 与消费者(下载/上传/清理) 并行推进。"""
    if not work_images:
        print("无待处理镜像")
        return

    consumer_workers = normalize_upload_workers(args.num_workers)
    export_workers = max(1, min(int(args.export_concurrency), len(work_images)))
    state_lock = threading.Lock()
    stop_event = threading.Event()
    ready_queue: Queue = Queue()
    consumer_errors: list[BaseException] = []

    print("=" * 80)
    print(
        "生产者-消费者模式: 待处理=%s 导出并发=%s 消费管道=%s"
        % (len(work_images), export_workers, consumer_workers)
    )
    if args.batch_size and args.batch_size != DEFAULT_BATCH_SIZE:
        print("提示: --batch-size 已忽略（流水线不再按批串行）")

    def _consumer_loop() -> None:
        while True:
            job = ready_queue.get()
            try:
                if job is None:
                    return
                # stop_event 时仍处理已取出的任务，避免丢队；新任务由生产者侧停投
                consume_tos_ready_job(
                    job=job,
                    args=args,
                    local_root=local_root,
                    manifest=manifest,
                    manifest_path=manifest_path,
                    csv_rows=csv_rows,
                    csv_path=csv_path,
                    ordered_ids=ordered_ids,
                    hf_rotator=hf_rotator,
                    state_lock=state_lock,
                )
            except BaseException as exc:
                consumer_errors.append(exc)
                print("消费者异常: %s" % exc)
                if not args.continue_on_error:
                    stop_event.set()
                    raise
            finally:
                ready_queue.task_done()

    consumer_executor = ThreadPoolExecutor(max_workers=consumer_workers)
    consumer_futures = [consumer_executor.submit(_consumer_loop) for _ in range(consumer_workers)]

    try:
        with ThreadPoolExecutor(max_workers=export_workers) as producer_executor:
            producer_futures = [
                producer_executor.submit(
                    produce_tos_ready_job,
                    image=image,
                    args=args,
                    ready_queue=ready_queue,
                    manifest=manifest,
                    manifest_path=manifest_path,
                    csv_rows=csv_rows,
                    csv_path=csv_path,
                    ordered_ids=ordered_ids,
                    local_root=local_root,
                    state_lock=state_lock,
                    stop_event=stop_event,
                )
                for image in work_images
            ]
            for future in as_completed(producer_futures):
                try:
                    future.result()
                except Exception as exc:
                    print("生产者异常: %s" % exc)
                    if not args.continue_on_error:
                        stop_event.set()
                        for pending in producer_futures:
                            pending.cancel()
                        break
    finally:
        for _ in range(consumer_workers):
            ready_queue.put(None)

    for future in as_completed(consumer_futures):
        try:
            future.result()
        except Exception as exc:
            if not args.continue_on_error:
                consumer_executor.shutdown(wait=False, cancel_futures=True)
                raise
            print("消费管道结束异常: %s" % exc)
    consumer_executor.shutdown(wait=True)

    with state_lock:
        if hf_rotator is not None:
            manifest["hf_repo_id"] = hf_rotator.current_repo_id
            manifest["hf_repo_index"] = hf_rotator.current_index
            manifest["hf_exhausted"] = hf_rotator.exhausted
        save_manifest(manifest_path, manifest)
        if csv_rows is not None and csv_path is not None:
            sync_csv_from_manifest(
                csv_rows=csv_rows,
                csv_path=csv_path,
                ordered_ids=ordered_ids or list(csv_rows.keys()),
                manifest=manifest,
                local_root=local_root,
            )
    print_progress(manifest, prefix="流水线结束，")
    if consumer_errors and not args.continue_on_error:
        raise consumer_errors[0]


def empty_local_trash() -> None:
    """清空本机回收站，尽量立刻释放被占用的磁盘空间。"""
    if not _TRASH_LOCK.acquire(blocking=False):
        return
    try:
        _empty_local_trash_unlocked()
    finally:
        _TRASH_LOCK.release()


def _empty_local_trash_unlocked() -> None:
    system = platform.system().lower()
    try:
        if system == "darwin":
            # Finder 回收站（含 APFS 延迟释放场景）
            completed = subprocess.run(
                ["osascript", "-e", 'tell application "Finder" to empty the trash'],
                check=False,
                capture_output=True,
                text=True,
                timeout=120,
            )
            if completed.returncode == 0:
                print("已清空 macOS 回收站")
                return
            # Finder 不可用时直接清 ~/.Trash
            trash_dir = Path.home() / ".Trash"
            if trash_dir.is_dir():
                for child in list(trash_dir.iterdir()):
                    if child.is_dir() and not child.is_symlink():
                        shutil.rmtree(child, ignore_errors=True)
                    else:
                        try:
                            child.unlink()
                        except OSError:
                            pass
                print("已清空 ~/.Trash")
            else:
                err = (completed.stderr or completed.stdout or "").strip()
                print("清空回收站失败: %s" % (err or ("exit=%s" % completed.returncode)))
            return
        if system == "linux":
            trash_dir = Path.home() / ".local" / "share" / "Trash"
            removed = False
            for sub in ("files", "info"):
                target = trash_dir / sub
                if not target.is_dir():
                    continue
                for child in list(target.iterdir()):
                    if child.is_dir() and not child.is_symlink():
                        shutil.rmtree(child, ignore_errors=True)
                    else:
                        try:
                            child.unlink()
                        except OSError:
                            pass
                    removed = True
            if removed:
                print("已清空 Linux 回收站: %s" % trash_dir)
            return
        print("当前系统不支持自动清空回收站: %s" % system)
    except (OSError, subprocess.TimeoutExpired, subprocess.SubprocessError) as exc:
        print("清空回收站失败: %s" % exc)


def cleanup_local_image_files(
    downloaded_records: list[dict[str, Any]],
    *,
    local_root: Path,
) -> None:
    """上传 HF 成功后删除本批镜像文件及空目录，并清空回收站以释放磁盘。"""
    cleaned_any = False
    for record in downloaded_records:
        local_file = Path(record["local_file"])
        if local_file.is_file():
            size_gib = round(local_file.stat().st_size / (1024 ** 3), 3)
            local_file.unlink()
            cleaned_any = True
            print("已清理本地文件: %s (释放 %.3f GiB)" % (local_file, size_gib))
        image_id = record.get("image_id", "")
        if image_id:
            temp_path = local_file.parent / (".download-%s.tmp" % image_id)
            if temp_path.is_file():
                temp_path.unlink()
                cleaned_any = True
                print("已清理临时文件: %s" % temp_path)
        parent = local_file.parent
        if parent.is_dir() and parent != local_root and not any(parent.iterdir()):
            parent.rmdir()
            cleaned_any = True
            print("已清理空目录: %s" % parent)
    if cleaned_any:
        empty_local_trash()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="从飞书 image 列（或 --from-csv）匹配广州非 Windows 镜像并发布到 TOS/HF"
    )
    parser.add_argument("--repo-id", default=os.getenv("HF_REPO_ID", "").strip(), help="HF 仓库 ID 基名，满仓后自动建 -2/-3...")
    parser.add_argument(
        "--repo-type",
        default=os.getenv("HF_REPO_TYPE", DEFAULT_REPO_TYPE),
        choices=("model", "dataset", "space"),
        help="HF 仓库类型，镜像默认 dataset",
    )
    parser.add_argument(
        "--hf-soft-limit-gib",
        type=float,
        default=float(os.getenv("HF_REPO_SOFT_LIMIT_GIB", str(DEFAULT_HF_REPO_SOFT_LIMIT_GIB))),
        help="单个 HF 仓库软上限 GiB，默认 900；接近后自动 create_repo 递增",
    )
    parser.add_argument(
        "--hf-max-auto-repos",
        type=int,
        default=int(os.getenv("HF_MAX_AUTO_REPOS", str(DEFAULT_HF_MAX_AUTO_REPOS))),
        help="自动递增建仓上限，默认 20",
    )
    parser.add_argument(
        "--local-dir",
        default=os.getenv("IMAGE_EXPORT_LOCAL_DIR", DEFAULT_LOCAL_DIR),
        help="本地下载目录，默认 image_file",
    )
    parser.add_argument(
        "--csv-path",
        default=os.getenv("IMAGE_PUBLISH_CSV", DEFAULT_CSV_PATH),
        help="本地进度 CSV，默认 output/publish_guangzhou_images.csv",
    )
    parser.add_argument(
        "--from-csv",
        action="store_true",
        help="不读飞书，直接用 --csv-path 中的「原始镜像」列作为候选 ID（并重新匹配广州非 Windows）",
    )
    parser.add_argument(
        "--feishu-url",
        default=os.getenv("IMAGE_PUBLISH_FEISHU_URL", DEFAULT_FEISHU_URL),
        help="飞书 wiki/sheet URL，默认含 sheet=PtDat4",
    )
    parser.add_argument(
        "--feishu-sheet-id",
        default=os.getenv("IMAGE_PUBLISH_FEISHU_SHEET_ID", DEFAULT_FEISHU_SHEET_ID),
        help="飞书 sheet id，默认 PtDat4",
    )
    parser.add_argument(
        "--image-header",
        default=os.getenv("IMAGE_PUBLISH_IMAGE_HEADER", DEFAULT_IMAGE_HEADER),
        help="飞书表头中的 image 列名，默认 image",
    )
    parser.add_argument(
        "--image-column",
        default=os.getenv("IMAGE_PUBLISH_IMAGE_COLUMN", ""),
        help="可选，直接指定 image 列字母（如 AG）；优先于 --image-header",
    )
    parser.add_argument(
        "--list-all-guangzhou",
        action="store_true",
        help="不读飞书，直接处理 cn-guangzhou 私有镜像列表（旧行为）",
    )
    parser.add_argument("--dry-run", action="store_true", help="仅列出候选与计划路径，不执行")
    parser.add_argument("--all", action="store_true", help="处理全部候选镜像")
    parser.add_argument("--limit", type=int, default=1, help="处理镜像数量，默认 1；配合 --all 时忽略")
    parser.add_argument(
        "--batch-size",
        type=int,
        default=int(os.getenv("IMAGE_PUBLISH_BATCH_SIZE", str(DEFAULT_BATCH_SIZE))),
        help="兼容旧参数，生产者-消费者模式下已忽略",
    )
    parser.add_argument("--image-id", default="", help="只处理指定镜像 ID")
    parser.add_argument("--list-limit", type=int, default=DEFAULT_LIST_LIMIT)
    parser.add_argument("--exclude-bj-suffix", action="store_true", help="排除镜像名以 _bj 结尾的候选")
    parser.add_argument(
        "--ubuntu-only",
        action="store_true",
        help="仅在 --list-all-guangzhou 时生效：只保留 Ubuntu/Linux",
    )
    parser.add_argument(
        "--exclude-gui",
        action="store_true",
        help="仅在 --list-all-guangzhou 时生效：排除镜像名含 gui",
    )
    parser.add_argument("--skip-export", action="store_true", help="跳过 ExportImage，直接从 TOS 下载")
    parser.add_argument("--skip-download", action="store_true", help="跳过 tosutil 下载")
    parser.add_argument("--skip-upload", action="store_true", help="跳过 Hugging Face 上传")
    parser.add_argument("--resume", action="store_true", help="跳过 manifest 中已 uploaded 的镜像")
    parser.add_argument(
        "--continue-on-error",
        action="store_true",
        help="单个镜像失败后继续处理其余镜像（失败记入 manifest）",
    )
    parser.add_argument(
        "--manifest",
        default=os.getenv("IMAGE_PUBLISH_MANIFEST", DEFAULT_MANIFEST_PATH),
        help="进度 manifest 路径，默认 output/publish_manifest.json",
    )
    parser.add_argument(
        "--keep-local",
        action="store_true",
        help="上传后保留本地 qcow2（默认上传成功后会删除以节省磁盘）",
    )
    parser.add_argument(
        "--tos-bucket",
        default=os.getenv("TOS_UPLOAD_BUCKET", DEFAULT_TOS_BUCKET),
        help="TOS 桶，默认 open-workflowgym-sample",
    )
    parser.add_argument("--poll-interval-seconds", type=int, default=int(os.getenv("TASK_POLL_INTERVAL_SECONDS", "30")))
    parser.add_argument(
        "--timeout-seconds",
        type=int,
        default=int(os.getenv("TASK_TIMEOUT_SECONDS", str(DEFAULT_EXPORT_TIMEOUT_SECONDS))),
        help="等待单个镜像导出完成超时，默认 1200 秒（约 20 分钟）",
    )
    parser.add_argument(
        "--export-concurrency",
        type=int,
        default=int(os.getenv("IMAGE_EXPORT_CONCURRENCY", str(DEFAULT_EXPORT_CONCURRENCY))),
        help="生产者：ExportImage 最大并发数，默认 10",
    )
    parser.add_argument(
        "--num-workers",
        type=int,
        default=None,
        help="消费者：同时进行的「下载→上传HF→删本地」管道数，默认 %s，最大 %s（磁盘紧张时请保持 1）"
        % (DEFAULT_UPLOAD_CONCURRENCY, MAX_UPLOAD_CONCURRENCY),
    )
    parser.add_argument("--revision", default=os.getenv("HF_REVISION", "").strip() or None)
    parser.add_argument("--private", dest="private", action="store_true", default=None)
    parser.add_argument("--public", dest="private", action="store_false")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    load_shell_env()
    if not os.getenv("AK") or not os.getenv("SK"):
        raise SystemExit("缺少 AK/SK，请先 export 或写入 ~/.zshrc")
    if not args.skip_upload and not args.repo_id:
        raise SystemExit("上传 Hugging Face 需要 --repo-id（或设置 HF_REPO_ID）")

    local_root = Path(args.local_dir).expanduser().resolve()
    manifest_path = Path(args.manifest).expanduser().resolve()
    csv_path = Path(args.csv_path).expanduser().resolve()
    if args.from_csv and args.list_all_guangzhou:
        raise SystemExit("--from-csv 与 --list-all-guangzhou 不能同时使用")

    api = create_api_instance(SOURCE_REGION)
    region_images = list_region_images(api, limit=args.list_limit)

    csv_rows = load_csv_rows(csv_path)
    ordered_ids: list[str] = []
    unmatched_ids: list[str] = []
    windows_images: list[dict[str, Any]] = []

    if args.list_all_guangzhou:
        candidates = select_export_candidates(
            region_images,
            exclude_bj_suffix=args.exclude_bj_suffix,
            ubuntu_only=args.ubuntu_only,
            exclude_gui=args.exclude_gui,
        )
        ordered_ids = [image_record_field(image, "ImageId", "image_id") for image in candidates]
        print("模式: 全量 cn-guangzhou 列表（--list-all-guangzhou）")
    elif args.from_csv:
        csv_ids = read_image_ids_from_csv(csv_path)
        candidates, unmatched_ids, windows_images = match_guangzhou_non_windows_images(
            csv_ids,
            region_images,
        )
        if args.exclude_bj_suffix:
            candidates = [
                image
                for image in candidates
                if not str(image_display_name(image)).lower().endswith(("_bj", "_bjopen"))
            ]
        ordered_ids = list(csv_ids)
        print("模式: 本地 CSV「原始镜像」列（--from-csv，不读飞书）")
        print("CSV: %s unique=%s" % (csv_path, len(csv_ids)))
        print("未匹配广州镜像: %s" % len(unmatched_ids))
        print("匹配但 Windows 已跳过: %s" % len(windows_images))
    else:
        feishu_ids, feishu_stats = read_feishu_unique_image_ids(
            feishu_url=args.feishu_url,
            sheet_id=args.feishu_sheet_id,
            image_header=args.image_header,
            image_column=args.image_column,
        )
        candidates, unmatched_ids, windows_images = match_guangzhou_non_windows_images(
            feishu_ids,
            region_images,
        )
        if args.exclude_bj_suffix:
            candidates = [
                image
                for image in candidates
                if not str(image_display_name(image)).lower().endswith(("_bj", "_bjopen"))
            ]
        ordered_ids = list(feishu_ids)
        print("模式: 飞书 image 列去重后匹配 cn-guangzhou 非 Windows")
        print(
            "飞书: sheet=%s rows=%s unique=%s duplicates=%s empty=%s"
            % (
                feishu_stats["sheet_id"],
                feishu_stats["source_rows"],
                feishu_stats["unique_image_ids"],
                feishu_stats["duplicate_count"],
                feishu_stats["empty_count"],
            )
        )
        print("未匹配广州镜像: %s" % len(unmatched_ids))
        print("匹配但 Windows 已跳过: %s" % len(windows_images))

    if args.image_id:
        candidates = [
            image
            for image in candidates
            if image_record_field(image, "ImageId", "image_id") == args.image_id
        ]
        if not candidates:
            raise SystemExit("未找到符合条件的镜像: %s" % args.image_id)

    print("源地域: %s" % SOURCE_REGION)
    print("TOS 桶: %s" % normalize_tos_bucket(args.tos_bucket))
    print("本地下载目录: %s" % local_root)
    print("manifest: %s" % manifest_path)
    print("CSV: %s" % csv_path)
    if not args.skip_upload:
        print(
            "HF 仓库基名: %s (%s) soft_limit=%sGiB max_auto_repos=%s"
            % (args.repo_id, args.repo_type, args.hf_soft_limit_gib, args.hf_max_auto_repos)
        )
    print("广州私有镜像总数: %s" % len(region_images))
    print("待发布候选(非 Windows 匹配): %s" % len(candidates))
    preview_limit = 5 if len(candidates) > 5 else len(candidates)
    for index, image in enumerate(candidates[:preview_limit], start=1):
        image_id = image_record_field(image, "ImageId", "image_id")
        image_name = image_display_name(image)
        tos_prefix = build_export_tos_prefix(image_name, image_id)
        print(
            "%s. %s id=%s os=%s tos=%s local=%s hf=%s"
            % (
                index,
                image_name,
                image_id,
                image_os_type_label(image),
                predict_export_object_uri(args.tos_bucket, tos_prefix, image_id),
                image_local_subdir(local_root, image_name, image_id) / local_export_filename(image_name, image_id),
                hf_relative_path(image_name, image_id),
            )
        )
    if len(candidates) > preview_limit:
        print("... 其余 %s 个镜像省略显示" % (len(candidates) - preview_limit))

    for image_id in ordered_ids:
        upsert_csv_row(csv_rows, image_id, 原始镜像=image_id)
    for image_id in unmatched_ids:
        upsert_csv_row(
            csv_rows,
            image_id,
            原始镜像=image_id,
            上传tos镜像结果="失败(未匹配广州镜像)",
        )
    for image in windows_images:
        image_id = image_record_field(image, "ImageId", "image_id")
        image_name = image_display_name(image)
        upsert_csv_row(
            csv_rows,
            image_id,
            原始镜像=image_id,
            镜像名称=image_name,
            上传tos镜像结果="跳过(Windows)",
            huggingface上对应的镜像名和目录=hf_relative_path(image_name, image_id),
        )
    for image in candidates:
        image_id = image_record_field(image, "ImageId", "image_id")
        image_name = image_display_name(image)
        upsert_csv_row(
            csv_rows,
            image_id,
            原始镜像=image_id,
            镜像名称=image_name,
            huggingface上对应的镜像名和目录=hf_relative_path(image_name, image_id),
        )
    save_csv_rows(csv_path, csv_rows, ordered_ids)

    if args.dry_run or not candidates:
        print("已写入 CSV 预览: %s" % csv_path)
        return 0

    if not args.skip_upload:
        ensure_hf_hub_version()

    args.cleanup_after_upload = not args.keep_local

    selected = candidates if args.all else candidates[: max(args.limit, 0)]
    manifest = init_manifest(
        path=manifest_path,
        repo_id=args.repo_id,
        repo_type=args.repo_type,
        candidates=candidates,
        batch_size=args.batch_size,
    )
    hf_rotator: HfRepoRotator | None = None
    if not args.skip_upload:
        start_index = int(manifest.get("hf_repo_index") or 1)
        hf_rotator = HfRepoRotator(
            base_repo_id=args.repo_id,
            repo_type=args.repo_type,
            private=args.private,
            soft_limit_gib=args.hf_soft_limit_gib,
            max_repos=args.hf_max_auto_repos,
            start_index=start_index,
        )
        if manifest.get("hf_exhausted"):
            hf_rotator.exhausted = True
        manifest["hf_repo_id"] = hf_rotator.current_repo_id
        manifest["hf_repo_index"] = hf_rotator.current_index
        manifest["hf_exhausted"] = hf_rotator.exhausted
    for image_id in unmatched_ids:
        manifest["images"][image_id] = {
            "image_id": image_id,
            "image_name": "",
            "original_image_id": image_id,
            "status": STATUS_UNMATCHED,
            "tos_object_uri": "",
            "local_file": "",
            "size_text": "",
            "hf_path": "",
            "error": "未匹配广州镜像",
            "updated_at": utc_now_iso(),
        }
    for image in windows_images:
        image_id = image_record_field(image, "ImageId", "image_id")
        image_name = image_display_name(image)
        manifest["images"][image_id] = {
            "image_id": image_id,
            "image_name": image_name,
            "original_image_id": extract_original_image_id(image_name, image_id),
            "status": STATUS_SKIPPED_WINDOWS,
            "tos_object_uri": "",
            "local_file": "",
            "size_text": "",
            "hf_path": hf_relative_path(image_name, image_id),
            "error": "Windows 镜像已跳过",
            "updated_at": utc_now_iso(),
        }
    save_manifest(manifest_path, manifest)
    sync_csv_from_manifest(
        csv_rows=csv_rows,
        csv_path=csv_path,
        ordered_ids=ordered_ids,
        manifest=manifest,
        local_root=local_root,
    )

    print("扫描 TOS 桶，识别已就绪目标镜像...")
    inventory_tos_ready_images(
        candidates,
        bucket=args.tos_bucket,
        manifest=manifest,
        manifest_path=manifest_path,
        csv_rows=csv_rows,
        csv_path=csv_path,
        ordered_ids=ordered_ids,
        local_root=local_root,
    )

    if not args.skip_upload and args.repo_id:
        print("对照 HF 仓实际文件，回写已上传成功状态...")
        reconcile_uploaded_from_hf_repos(
            candidates,
            base_repo_id=args.repo_id,
            repo_type=args.repo_type,
            max_repos=args.hf_max_auto_repos,
            manifest=manifest,
            manifest_path=manifest_path,
            csv_rows=csv_rows,
            csv_path=csv_path,
            ordered_ids=ordered_ids,
            local_root=local_root,
        )

    work_images = select_pending_images(selected, manifest, resume=args.resume or args.all)
    work_images = sort_images_tos_ready_first(work_images, manifest)
    manifest["batch_total"] = 0
    save_manifest(manifest_path, manifest)

    print("计划处理镜像数: %s" % len(work_images))
    print(
        "流水线: 导出并发=%s 消费管道=%s"
        % (args.export_concurrency, normalize_upload_workers(args.num_workers))
    )
    if hf_rotator is not None:
        print("当前 HF 仓库: %s (index=%s)" % (hf_rotator.current_repo_id, hf_rotator.current_index))
    print_progress(manifest, prefix="初始 ")

    try:
        run_producer_consumer_pipeline(
            work_images=work_images,
            args=args,
            local_root=local_root,
            manifest=manifest,
            manifest_path=manifest_path,
            csv_rows=csv_rows,
            csv_path=csv_path,
            ordered_ids=ordered_ids,
            hf_rotator=hf_rotator,
        )
    except (ApiException, TimeoutError, RuntimeError, subprocess.CalledProcessError, SystemExit) as exc:
        print("流水线失败: %s" % exc)
        save_manifest(manifest_path, manifest)
        sync_csv_from_manifest(
            csv_rows=csv_rows,
            csv_path=csv_path,
            ordered_ids=ordered_ids,
            manifest=manifest,
            local_root=local_root,
        )
        if not args.continue_on_error:
            return 1

    counts = manifest_counts(manifest)
    print("=" * 80)
    print("全部处理结束")
    print_progress(manifest, prefix="最终 ")
    print("CSV: %s" % csv_path)
    if hf_rotator is not None:
        print(
            "HF 仓库状态: current=%s index=%s exhausted=%s"
            % (hf_rotator.current_repo_id, hf_rotator.current_index, hf_rotator.exhausted)
        )
    uploaded = counts.get(STATUS_UPLOADED, 0)
    if uploaded < len(selected):
        print(
            "警告: 仍有未完成镜像 uploaded=%s/%s skipped_disk=%s skipped_hf_full=%s failed=%s"
            % (
                uploaded,
                len(selected),
                counts.get(STATUS_SKIPPED_DISK, 0),
                counts.get(STATUS_SKIPPED_HF_FULL, 0),
                counts.get(STATUS_FAILED, 0),
            )
        )
        return 1
    print("全部 %s 个镜像已上传完成" % len(selected))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
