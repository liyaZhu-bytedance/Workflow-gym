#!/usr/bin/env python3
"""按 AG 列 image 去重飞书表格，保留表头并写入目标 sheet。"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.feishu_client import FeishuClient, column_to_number
from open_workflowgym.local_spreadsheet import feishu_credentials_configured
from open_workflowgym.source_reader import parse_feishu_sheet_url
from open_workflowgym.tools.match_feishu_image_ids import (
    WriteSheetResult,
    cell_value,
    load_bashrc_env,
    resolve_spreadsheet_token,
    trim_trailing_empty_rows,
    write_output_sheet,
)

DEFAULT_SOURCE_WIKI_URL = os.getenv("FEISHU_SOURCE_WIKI_URL", "https://example.feishu.local/wiki/PLACEHOLDER")
DEFAULT_SOURCE_SHEET_ID = "lLohZH"
DEFAULT_OUTPUT_WIKI_URL = os.getenv("FEISHU_OUTPUT_WIKI_URL", "https://example.feishu.local/wiki/PLACEHOLDER")
DEFAULT_OUTPUT_SHEET_ID = "UVXySR"
DEFAULT_IMAGE_COLUMN = "AG"


def resolve_sheet_url(client: FeishuClient, sheet_url: str) -> tuple[str, str]:
    info = parse_feishu_sheet_url(sheet_url)
    token = resolve_spreadsheet_token(client, sheet_url) if info.get("is_wiki") else info["token"]
    sheet_id = info["sheet_id"] or client.query_first_sheet_id(token)
    if not token or not sheet_id:
        raise ValueError("无法从飞书表格 URL 解析 token 或 sheet_id: %s" % sheet_url)
    return token, sheet_id


def dedupe_rows_by_image_column(
    rows: list[list[Any]],
    *,
    image_column_index: int,
) -> tuple[list[list[Any]], int, int]:
    rows = trim_trailing_empty_rows(rows)
    if not rows:
        return [], 0, 0

    output_rows: list[list[Any]] = [rows[0]]
    seen_images: set[str] = set()
    duplicate_count = 0
    skipped_empty_count = 0

    for row in rows[1:]:
        image_value = cell_value(row, image_column_index)
        if not image_value:
            skipped_empty_count += 1
            continue
        if image_value in seen_images:
            duplicate_count += 1
            continue
        seen_images.add(image_value)
        output_rows.append(row)

    return output_rows, duplicate_count, skipped_empty_count


def read_sheet_rows_with_retry(
    client: FeishuClient,
    spreadsheet_token: str,
    sheet_id: str,
    *,
    end_column: str = "AH",
    row_chunk_size: int = 200,
    max_rows: int = 5000,
    max_attempts: int = 3,
) -> list[list[Any]]:
    all_rows: list[list[Any]] = []
    start_row = 1
    while start_row <= max_rows:
        end_row = min(start_row + row_chunk_size - 1, max_rows)
        cell_range = "%s!A%d:%s%d" % (sheet_id, start_row, end_column, end_row)
        chunk: list[list[Any]] = []
        for attempt in range(1, max_attempts + 1):
            try:
                chunk = client.read_values(spreadsheet_token, cell_range)
                break
            except Exception as exc:
                if attempt >= max_attempts:
                    raise
                print("读取 %s 失败 (%s/%s): %s" % (cell_range, attempt, max_attempts, exc), file=sys.stderr)
        if not chunk:
            break
        all_rows.extend(chunk)
        if len(chunk) < row_chunk_size:
            break
        start_row += row_chunk_size
    return all_rows


def run_dedupe(
    client: FeishuClient,
    *,
    source_wiki_url: str = DEFAULT_SOURCE_WIKI_URL,
    source_sheet_id: str = DEFAULT_SOURCE_SHEET_ID,
    output_wiki_url: str = DEFAULT_OUTPUT_WIKI_URL,
    output_sheet_id: str = DEFAULT_OUTPUT_SHEET_ID,
    image_column: str = DEFAULT_IMAGE_COLUMN,
    dry_run: bool = False,
) -> dict[str, Any]:
    source_url = "%s?sheet=%s" % (source_wiki_url.split("?")[0], source_sheet_id)
    source_token, resolved_source_sheet_id = resolve_sheet_url(client, source_url)
    output_token = resolve_spreadsheet_token(client, output_wiki_url)
    image_column_index = column_to_number(image_column) - 1

    source_rows = read_sheet_rows_with_retry(client, source_token, resolved_source_sheet_id)
    output_rows, duplicate_count, skipped_empty_count = dedupe_rows_by_image_column(
        source_rows,
        image_column_index=image_column_index,
    )

    if not dry_run:
        write_result = write_output_sheet(client, output_token, output_sheet_id, output_rows)
    else:
        write_result = WriteSheetResult()

    return {
        "source_sheet_id": resolved_source_sheet_id,
        "output_sheet_id": output_sheet_id,
        "image_column": image_column,
        "source_rows": len(source_rows),
        "output_rows": len(output_rows),
        "duplicate_rows_removed": duplicate_count,
        "empty_image_rows_skipped": skipped_empty_count,
        "attachment_count": write_result.attachment_count,
        "attachment_red_count": write_result.attachment_red_count,
        "failed_cell_count": write_result.failed_cell_count,
        "failed_row_count": write_result.failed_row_count,
        "output_preview": output_rows[:5],
    }


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="按 AG 列 image 去重飞书表格并写入目标 sheet")
    parser.add_argument("--source-wiki-url", default=DEFAULT_SOURCE_WIKI_URL)
    parser.add_argument("--source-sheet-id", default=DEFAULT_SOURCE_SHEET_ID)
    parser.add_argument("--output-wiki-url", default=DEFAULT_OUTPUT_WIKI_URL)
    parser.add_argument("--output-sheet-id", default=DEFAULT_OUTPUT_SHEET_ID)
    parser.add_argument("--image-column", default=DEFAULT_IMAGE_COLUMN, help="用于去重的 image 列，默认 AG")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--bashrc", default="")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    load_bashrc_env(bashrc_path=args.bashrc)
    if not feishu_credentials_configured():
        print("缺少 APP_ID 或 APP_SECRET，请确认已写入 ~/.bashrc 或当前环境变量", file=sys.stderr)
        return 1

    client = FeishuClient(dry_run=False)
    result = run_dedupe(
        client,
        source_wiki_url=args.source_wiki_url,
        source_sheet_id=args.source_sheet_id,
        output_wiki_url=args.output_wiki_url,
        output_sheet_id=args.output_sheet_id,
        image_column=args.image_column,
        dry_run=args.dry_run,
    )

    print("按 %s 列去重完成" % result["image_column"])
    print("  source sheet: %s (%s 行)" % (result["source_sheet_id"], result["source_rows"]))
    print("  output sheet: %s (%s 行，含表头)" % (result["output_sheet_id"], result["output_rows"]))
    print("  去除重复 image 行: %s" % result["duplicate_rows_removed"])
    print("  跳过空 image 行: %s" % result["empty_image_rows_skipped"])
    print("  附件单元格: %s" % result["attachment_count"])
    print("  附件标红单元格: %s" % result["attachment_red_count"])
    print("  写入失败单元格: %s" % result["failed_cell_count"])
    print("  写入失败整行: %s" % result["failed_row_count"])
    if args.dry_run:
        print("预览前 5 行:")
        for row in result["output_preview"]:
            print("  %s" % row[:40])
    else:
        print(
            "已写入: %s?sheet=%s"
            % (args.output_wiki_url.split("?")[0], result["output_sheet_id"])
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
