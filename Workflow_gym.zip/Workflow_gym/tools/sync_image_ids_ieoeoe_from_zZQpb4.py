#!/usr/bin/env python3
"""比对 iEoEoE 与 zZQpb4 镜像名，按 zZQpb4 为准更新 iEoEoE 的镜像 id 并标绿。"""
from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.feishu_client import FeishuClient, column_to_number
from open_workflowgym.local_spreadsheet import feishu_credentials_configured
from open_workflowgym.tools.match_feishu_image_ids import (
    cell_address,
    cell_value,
    flatten_cell_text,
    is_preview_windows2022_name,
    load_bashrc_env,
    read_sheet_rows_chunked,
    resolve_spreadsheet_token,
    write_single_cell_value,
)

DEFAULT_WIKI_URL = os.getenv("FEISHU_WIKI_URL", "https://example.feishu.local/wiki/PLACEHOLDER")
DEFAULT_SOURCE_SHEET_ID = "zZQpb4"
DEFAULT_TARGET_SHEET_ID = "iEoEoE"
SOURCE_IMAGE_NAME_COLUMN = column_to_number("B") - 1
SOURCE_IMAGE_ID_COLUMN = column_to_number("C") - 1
TARGET_IMAGE_NAME_COLUMN = column_to_number("D") - 1
TARGET_IMAGE_ID_COLUMN = column_to_number("E") - 1
UPDATED_BACK_COLOR = "#d9f7be"
BJ_SUFFIX = "_bj"


@dataclass
class ImageIdLookups:
    linux: dict[str, str]
    windows: dict[str, str]


def is_windows_image_name(image_name: str) -> bool:
    return is_preview_windows2022_name(image_name)


def strip_bj_suffix(name: object) -> str:
    text = flatten_cell_text(name)
    if text.endswith(BJ_SUFFIX):
        return text[: -len(BJ_SUFFIX)]
    return text


def resolve_match_key(image_name: str) -> tuple[str, str]:
    text = flatten_cell_text(image_name)
    if not text:
        return "", ""
    if is_windows_image_name(text):
        return "windows", strip_bj_suffix(text)
    return "linux", text


def build_image_id_lookups(rows: list[list[Any]]) -> ImageIdLookups:
    linux_lookup: dict[str, str] = {}
    windows_lookup: dict[str, str] = {}
    for row_index, row in enumerate(rows):
        if row_index == 0:
            continue
        image_name = cell_value(row, SOURCE_IMAGE_NAME_COLUMN)
        image_id = cell_value(row, SOURCE_IMAGE_ID_COLUMN)
        if not image_name or not image_id:
            continue
        match_type, match_key = resolve_match_key(image_name)
        if not match_key:
            continue
        if match_type == "windows":
            windows_lookup[match_key] = image_id
        else:
            linux_lookup[match_key] = image_id
    return ImageIdLookups(linux=linux_lookup, windows=windows_lookup)


def resolve_expected_image_id(image_name: str, lookups: ImageIdLookups) -> str:
    match_type, match_key = resolve_match_key(image_name)
    if not match_key:
        return ""
    if match_type == "windows":
        return lookups.windows.get(match_key, "")
    return lookups.linux.get(match_key, "")


def sheet_cell_range(sheet_id: str, row_index: int, column_index: int) -> str:
    address = cell_address(row_index, column_index)
    return "%s!%s:%s" % (sheet_id, address, address)


def find_updates(
    target_rows: list[list[Any]],
    lookups: ImageIdLookups,
) -> list[dict[str, Any]]:
    updates: list[dict[str, Any]] = []
    for row_index, row in enumerate(target_rows):
        if row_index == 0:
            continue
        image_name = cell_value(row, TARGET_IMAGE_NAME_COLUMN)
        if not image_name:
            continue
        match_type, match_key = resolve_match_key(image_name)
        expected_image_id = resolve_expected_image_id(image_name, lookups)
        if not expected_image_id:
            continue
        current_image_id = cell_value(row, TARGET_IMAGE_ID_COLUMN)
        if current_image_id == expected_image_id:
            continue
        updates.append(
            {
                "row_index": row_index,
                "image_name": image_name,
                "match_type": match_type,
                "match_key": match_key,
                "current_image_id": current_image_id,
                "expected_image_id": expected_image_id,
            }
        )
    return updates


def apply_updates(
    client: FeishuClient,
    spreadsheet_token: str,
    sheet_id: str,
    updates: list[dict[str, Any]],
    *,
    dry_run: bool = False,
) -> dict[str, Any]:
    updated_ranges: list[str] = []
    failed_updates: list[dict[str, Any]] = []

    for item in updates:
        row_index = int(item["row_index"])
        expected_image_id = str(item["expected_image_id"])
        cell_range = sheet_cell_range(sheet_id, row_index, TARGET_IMAGE_ID_COLUMN)
        if dry_run:
            updated_ranges.append(cell_range)
            continue
        try:
            write_single_cell_value(
                client,
                spreadsheet_token,
                sheet_id,
                row_index,
                TARGET_IMAGE_ID_COLUMN,
                expected_image_id,
            )
            client.set_cells_background(
                spreadsheet_token,
                [cell_range],
                back_color=UPDATED_BACK_COLOR,
            )
            updated_ranges.append(cell_range)
        except Exception as exc:
            failed_updates.append({**item, "error": str(exc)})

    return {
        "updated_count": len(updated_ranges),
        "failed_count": len(failed_updates),
        "updated_ranges": updated_ranges,
        "failed_updates": failed_updates,
    }


def run_sync(
    client: FeishuClient,
    *,
    wiki_url: str = DEFAULT_WIKI_URL,
    source_sheet_id: str = DEFAULT_SOURCE_SHEET_ID,
    target_sheet_id: str = DEFAULT_TARGET_SHEET_ID,
    dry_run: bool = False,
) -> dict[str, Any]:
    spreadsheet_token = resolve_spreadsheet_token(client, wiki_url)
    source_rows = read_sheet_rows_chunked(client, spreadsheet_token, source_sheet_id)
    target_rows = read_sheet_rows_chunked(client, spreadsheet_token, target_sheet_id)
    lookups = build_image_id_lookups(source_rows)
    updates = find_updates(target_rows, lookups)
    apply_result = apply_updates(
        client,
        spreadsheet_token,
        target_sheet_id,
        updates,
        dry_run=dry_run,
    )

    matched_count = 0
    linux_matched_count = 0
    windows_matched_count = 0
    consistent_count = 0
    for row_index, row in enumerate(target_rows):
        if row_index == 0:
            continue
        image_name = cell_value(row, TARGET_IMAGE_NAME_COLUMN)
        match_type, _match_key = resolve_match_key(image_name)
        expected_image_id = resolve_expected_image_id(image_name, lookups)
        if not expected_image_id:
            continue
        matched_count += 1
        if match_type == "windows":
            windows_matched_count += 1
        else:
            linux_matched_count += 1
        if cell_value(row, TARGET_IMAGE_ID_COLUMN) == expected_image_id:
            consistent_count += 1

    return {
        "spreadsheet_token": spreadsheet_token,
        "source_sheet_id": source_sheet_id,
        "target_sheet_id": target_sheet_id,
        "source_rows": len(source_rows),
        "target_rows": len(target_rows),
        "linux_lookup_count": len(lookups.linux),
        "windows_lookup_count": len(lookups.windows),
        "matched_count": matched_count,
        "linux_matched_count": linux_matched_count,
        "windows_matched_count": windows_matched_count,
        "consistent_count": consistent_count,
        "need_update_count": len(updates),
        "preview_updates": updates[:10],
        **apply_result,
    }


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Linux: iEoEoE.D 与 zZQpb4.B 完全相同；"
            "Windows: 去掉 _bj 后缀后相同；"
            "若 iEoEoE.E 与 zZQpb4.C 不一致则以 zZQpb4 为准更新并标绿"
        )
    )
    parser.add_argument("--wiki-url", default=DEFAULT_WIKI_URL)
    parser.add_argument("--source-sheet-id", default=DEFAULT_SOURCE_SHEET_ID, help="标准来源 sheet，默认 zZQpb4")
    parser.add_argument("--target-sheet-id", default=DEFAULT_TARGET_SHEET_ID, help="待更新 sheet，默认 iEoEoE")
    parser.add_argument("--dry-run", action="store_true", help="只比对，不写入飞书")
    parser.add_argument("--bashrc", default="")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    load_bashrc_env(bashrc_path=args.bashrc)
    if not feishu_credentials_configured():
        print("缺少 APP_ID 或 APP_SECRET，请确认已写入 ~/.bashrc 或当前环境变量", file=sys.stderr)
        return 1

    client = FeishuClient(dry_run=False)
    result = run_sync(
        client,
        wiki_url=args.wiki_url,
        source_sheet_id=args.source_sheet_id,
        target_sheet_id=args.target_sheet_id,
        dry_run=args.dry_run,
    )

    print("镜像 id 比对同步完成")
    print("  source sheet: %s (%s 行)" % (result["source_sheet_id"], result["source_rows"]))
    print("  target sheet: %s (%s 行)" % (result["target_sheet_id"], result["target_rows"]))
    print("  Linux 来源映射: %s" % result["linux_lookup_count"])
    print("  Windows 来源映射: %s" % result["windows_lookup_count"])
    print(
        "  D/B 匹配行数: %s (Linux=%s, Windows=%s)"
        % (result["matched_count"], result["linux_matched_count"], result["windows_matched_count"])
    )
    print("  已一致行数: %s" % result["consistent_count"])
    print("  需更新行数: %s" % result["need_update_count"])
    if args.dry_run:
        print("预览前 10 条待更新:")
        for item in result["preview_updates"]:
            print(
                "  row=%s [%s] key=%s name=%s current=%s -> expected=%s"
                % (
                    item["row_index"] + 1,
                    item.get("match_type", ""),
                    item.get("match_key", ""),
                    item["image_name"],
                    item["current_image_id"] or "(空)",
                    item["expected_image_id"],
                )
            )
    else:
        print("  已更新: %s" % result["updated_count"])
        print("  更新失败: %s" % result["failed_count"])
        if result["failed_updates"]:
            for item in result["failed_updates"][:5]:
                print("  失败 row=%s error=%s" % (item["row_index"] + 1, item["error"]))
        print(
            "已写入: %s?sheet=%s"
            % (args.wiki_url.split("?")[0], result["target_sheet_id"])
        )
    return 0 if result["failed_count"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
