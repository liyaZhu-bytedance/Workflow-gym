#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.feishu_client import FeishuClient, column_to_number
from open_workflowgym.local_spreadsheet import feishu_credentials_configured
from open_workflowgym.source_reader import parse_feishu_sheet_url
from open_workflowgym.tools.match_feishu_image_ids import (
    NOT_FOUND_LABEL,
    WriteSheetResult,
    cell_value,
    load_bashrc_env,
    read_sheet_rows,
    read_sheet_rows_chunked,
    resolve_spreadsheet_token,
    trim_trailing_empty_rows,
    write_output_sheet,
)

DEFAULT_VE8A1Q_WIKI_URL = os.getenv("FEISHU_VE8A1Q_WIKI_URL", "https://example.feishu.local/wiki/PLACEHOLDER")
DEFAULT_VE8A1Q_SHEET_ID = "Ve8a1Q"
DEFAULT_TASK_WIKI_URL = os.getenv("FEISHU_TASK_WIKI_URL", "https://example.feishu.local/wiki/PLACEHOLDER")
DEFAULT_TASK_SHEET_ID = "TM2HZs"
DEFAULT_OUTPUT_WIKI_URL = DEFAULT_VE8A1Q_WIKI_URL
DEFAULT_OUTPUT_SHEET_ID = "4IX4RL"
DEFAULT_IEOEOE_SHEET_ID = "iEoEoE"
VE8A1Q_IMAGE_ID_COLUMN = 2
VE8A1Q_MATCHED_IMAGE_ID_COLUMN = 4
VE8A1Q_OS_TYPE_COLUMN = 9
IEOEOE_IMAGE_ID_COLUMN = 2
IEOEOE_MATCHED_IMAGE_ID_COLUMN = 4
TASK_MATCH_COLUMN = "AF"
TASK_MATCH_COLUMN_INDEX = column_to_number(TASK_MATCH_COLUMN) - 1
DEFAULT_INSERT_HEADER = "镜像id"
DEFAULT_SECOND_INSERT_HEADER = "匹配镜像id"
NOT_FOUND_MATCHED_IMAGE_ID_LABEL = "没有找到镜像id"


def parse_image_ids(value: object) -> list[str]:
    text = str(value or "").strip()
    if not text or text == NOT_FOUND_LABEL:
        return []
    parts = re.split(r"[,，]", text)
    return [part.strip() for part in parts if part.strip()]


def unique_preserve_order(values: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        result.append(value)
    return result


def insert_columns_after(row: list[Any], column_index: int, values: list[Any]) -> list[Any]:
    padded = list(row)
    insert_at = column_index + 1
    for offset, value in enumerate(values):
        padded.insert(insert_at + offset, value)
    return padded


def is_windows_os_type(os_type: object) -> bool:
    return "win" in str(os_type or "").strip().lower()


def resolve_ve8a1q_output_image_ids(
    row: list[Any],
    *,
    matched_image_id_column: int = VE8A1Q_MATCHED_IMAGE_ID_COLUMN,
) -> list[str]:
    # AG 列统一取 Ve8a1Q.E（镜像id），不再优先 H 列。
    matched_image_id = cell_value(row, matched_image_id_column)
    return parse_image_ids(matched_image_id)


def build_ve8a1q_lookup(
    ve8a1q_rows: list[list[Any]],
    *,
    image_id_column: int = VE8A1Q_IMAGE_ID_COLUMN,
    matched_image_id_column: int = VE8A1Q_MATCHED_IMAGE_ID_COLUMN,
) -> dict[str, list[str]]:
    lookup: dict[str, list[str]] = {}
    for row_index, row in enumerate(ve8a1q_rows):
        if row_index == 0:
            continue
        image_ids = parse_image_ids(cell_value(row, image_id_column))
        output_image_ids = resolve_ve8a1q_output_image_ids(
            row,
            matched_image_id_column=matched_image_id_column,
        )
        if not image_ids:
            continue
        for image_id in image_ids:
            existing = lookup.setdefault(image_id, [])
            for output_image_id in output_image_ids:
                if output_image_id not in existing:
                    existing.append(output_image_id)
    return lookup


def build_ve8a1q_row_lookup(
    ve8a1q_rows: list[list[Any]],
    *,
    image_id_column: int = VE8A1Q_IMAGE_ID_COLUMN,
) -> dict[str, list[list[Any]]]:
    lookup: dict[str, list[list[Any]]] = {}
    for row_index, row in enumerate(ve8a1q_rows):
        if row_index == 0:
            continue
        for image_id in parse_image_ids(cell_value(row, image_id_column)):
            lookup.setdefault(image_id, []).append(row)
    return lookup


def build_ieoeoe_lookup(
    ieoeoe_rows: list[list[Any]],
    *,
    image_id_column: int = IEOEOE_IMAGE_ID_COLUMN,
    matched_image_id_column: int = IEOEOE_MATCHED_IMAGE_ID_COLUMN,
) -> dict[str, list[str]]:
    lookup: dict[str, list[str]] = {}
    for row_index, row in enumerate(ieoeoe_rows):
        if row_index == 0:
            continue
        image_ids = parse_image_ids(cell_value(row, image_id_column))
        matched_value = cell_value(row, matched_image_id_column)
        if not image_ids or not matched_value or matched_value == NOT_FOUND_LABEL:
            continue
        matched_image_ids = parse_image_ids(matched_value)
        if not matched_image_ids:
            continue
        for image_id in image_ids:
            existing = lookup.setdefault(image_id, [])
            for matched_image_id in matched_image_ids:
                if matched_image_id not in existing:
                    existing.append(matched_image_id)
    return lookup


def resolve_secondary_output_image_ids(
    task_image_ids: list[str],
    ve8a1q_row_lookup: dict[str, list[list[Any]]],
    ieoeoe_lookup: dict[str, list[str]],
    *,
    matched_image_id_column: int = VE8A1Q_MATCHED_IMAGE_ID_COLUMN,
    os_type_column: int = VE8A1Q_OS_TYPE_COLUMN,
) -> list[str]:
    matched_values: list[str] = []
    for task_image_id in task_image_ids:
        for row in ve8a1q_row_lookup.get(task_image_id, []):
            if is_windows_os_type(cell_value(row, os_type_column)):
                matched_values.extend(parse_image_ids(cell_value(row, matched_image_id_column)))
            else:
                matched_values.extend(ieoeoe_lookup.get(task_image_id, []))
    return unique_preserve_order(matched_values)


def format_matched_image_ids(image_ids: list[str]) -> str:
    if not image_ids:
        return ""
    return ",".join(image_ids)


def build_output_rows(
    task_rows: list[list[Any]],
    ve8a1q_rows: list[list[Any]],
    ieoeoe_rows: list[list[Any]],
    *,
    task_match_column_index: int = TASK_MATCH_COLUMN_INDEX,
    insert_header: str = DEFAULT_INSERT_HEADER,
    second_insert_header: str = DEFAULT_SECOND_INSERT_HEADER,
) -> tuple[list[list[Any]], int, int, int, int]:
    task_rows = trim_trailing_empty_rows(task_rows)
    ve8a1q_rows = trim_trailing_empty_rows(ve8a1q_rows)
    ieoeoe_rows = trim_trailing_empty_rows(ieoeoe_rows)
    if not task_rows:
        return [], 0, 0, 0, 0

    lookup = build_ve8a1q_lookup(ve8a1q_rows)
    ve8a1q_row_lookup = build_ve8a1q_row_lookup(ve8a1q_rows)
    ieoeoe_lookup = build_ieoeoe_lookup(ieoeoe_rows)
    output_rows: list[list[Any]] = []
    not_found_count = 0
    e_not_found_count = 0
    second_not_found_count = 0
    second_e_not_found_count = 0

    for row_index, row in enumerate(task_rows):
        if row_index == 0:
            output_rows.append(
                insert_columns_after(
                    row,
                    task_match_column_index,
                    [insert_header, second_insert_header],
                )
            )
            continue

        task_image_ids = parse_image_ids(cell_value(row, task_match_column_index))
        matched_values: list[str] = []
        c_matched = False
        for task_image_id in task_image_ids:
            if task_image_id not in lookup:
                continue
            c_matched = True
            matched_values.extend(lookup.get(task_image_id, []))
        matched_values = unique_preserve_order(matched_values)
        if matched_values:
            primary_insert_value = format_matched_image_ids(matched_values)
        elif c_matched:
            primary_insert_value = NOT_FOUND_LABEL
            e_not_found_count += 1
        elif task_image_ids:
            primary_insert_value = NOT_FOUND_MATCHED_IMAGE_ID_LABEL
            not_found_count += 1
        else:
            primary_insert_value = ""

        secondary_matched_values = resolve_secondary_output_image_ids(
            task_image_ids,
            ve8a1q_row_lookup,
            ieoeoe_lookup,
        )
        if secondary_matched_values:
            secondary_insert_value = format_matched_image_ids(secondary_matched_values)
        elif c_matched:
            secondary_insert_value = NOT_FOUND_LABEL
            second_e_not_found_count += 1
        elif task_image_ids:
            secondary_insert_value = NOT_FOUND_MATCHED_IMAGE_ID_LABEL
            second_not_found_count += 1
        else:
            secondary_insert_value = ""

        output_rows.append(
            insert_columns_after(
                row,
                task_match_column_index,
                [primary_insert_value, secondary_insert_value],
            )
        )

    return (
        output_rows,
        not_found_count,
        e_not_found_count,
        second_not_found_count,
        second_e_not_found_count,
    )


def resolve_sheet_url(client: FeishuClient, sheet_url: str) -> tuple[str, str]:
    info = parse_feishu_sheet_url(sheet_url)
    token = resolve_spreadsheet_token(client, sheet_url) if info.get("is_wiki") else info["token"]
    sheet_id = info["sheet_id"] or client.query_first_sheet_id(token)
    if not token or not sheet_id:
        raise ValueError("无法从飞书表格 URL 解析 token 或 sheet_id: %s" % sheet_url)
    return token, sheet_id


def run_merge(
    client: FeishuClient,
    *,
    ve8a1q_wiki_url: str = DEFAULT_VE8A1Q_WIKI_URL,
    ve8a1q_sheet_id: str = DEFAULT_VE8A1Q_SHEET_ID,
    task_wiki_url: str = DEFAULT_TASK_WIKI_URL,
    task_sheet_id: str = DEFAULT_TASK_SHEET_ID,
    output_wiki_url: str = DEFAULT_OUTPUT_WIKI_URL,
    output_sheet_id: str = DEFAULT_OUTPUT_SHEET_ID,
    insert_header: str = DEFAULT_INSERT_HEADER,
    dry_run: bool = False,
) -> dict[str, Any]:
    ve8a1q_token, resolved_ve8a1q_sheet_id = resolve_sheet_url(
        client,
        "%s?sheet=%s" % (ve8a1q_wiki_url.split("?")[0], ve8a1q_sheet_id),
    )
    task_token, resolved_task_sheet_id = resolve_sheet_url(
        client,
        "%s?sheet=%s" % (task_wiki_url.split("?")[0], task_sheet_id),
    )
    output_token = resolve_spreadsheet_token(client, output_wiki_url)

    ve8a1q_rows = read_sheet_rows(client, ve8a1q_token, resolved_ve8a1q_sheet_id, "A1:ZZ2000")
    ieoeoe_rows = read_sheet_rows(
        client,
        ve8a1q_token,
        DEFAULT_IEOEOE_SHEET_ID,
        "A1:ZZ2000",
    )
    task_rows = read_sheet_rows_chunked(client, task_token, resolved_task_sheet_id)
    (
        output_rows,
        not_found_count,
        e_not_found_count,
        second_not_found_count,
        second_e_not_found_count,
    ) = build_output_rows(
        task_rows,
        ve8a1q_rows,
        ieoeoe_rows,
        insert_header=insert_header,
    )

    data_row_count = max(0, len(output_rows) - 1)
    matched_count = data_row_count - not_found_count - e_not_found_count
    second_matched_count = data_row_count - second_not_found_count - second_e_not_found_count
    if not dry_run:
        write_result = write_output_sheet(client, output_token, output_sheet_id, output_rows)
    else:
        write_result = WriteSheetResult()

    return {
        "ve8a1q_sheet_id": resolved_ve8a1q_sheet_id,
        "task_sheet_id": resolved_task_sheet_id,
        "output_sheet_id": output_sheet_id,
        "ve8a1q_rows": len(ve8a1q_rows),
        "ieoeoe_rows": len(ieoeoe_rows),
        "task_rows": len(task_rows),
        "output_rows": len(output_rows),
        "matched_output_rows": matched_count,
        "not_found_output_rows": not_found_count,
        "e_not_found_output_rows": e_not_found_count,
        "second_matched_output_rows": second_matched_count,
        "second_not_found_output_rows": second_not_found_count,
        "second_e_not_found_output_rows": second_e_not_found_count,
        "attachment_count": write_result.attachment_count,
        "attachment_red_count": write_result.attachment_red_count,
        "failed_cell_count": write_result.failed_cell_count,
        "failed_row_count": write_result.failed_row_count,
        "output_preview": output_rows[:5],
    }


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "按 image_id 匹配 Ve8a1Q.C 与 TM2HZs.AF，"
            "AG 列写入 Ve8a1Q.E，"
            "AH 列 Windows 写入 Ve8a1Q.E、其他系统写入 iEoEoE.E"
        )
    )
    parser.add_argument("--ve8a1q-wiki-url", default=DEFAULT_VE8A1Q_WIKI_URL)
    parser.add_argument("--ve8a1q-sheet-id", default=DEFAULT_VE8A1Q_SHEET_ID)
    parser.add_argument("--task-wiki-url", default=DEFAULT_TASK_WIKI_URL)
    parser.add_argument("--task-sheet-id", default=DEFAULT_TASK_SHEET_ID)
    parser.add_argument("--output-wiki-url", default=DEFAULT_OUTPUT_WIKI_URL)
    parser.add_argument("--output-sheet-id", default=DEFAULT_OUTPUT_SHEET_ID)
    parser.add_argument("--insert-header", default=DEFAULT_INSERT_HEADER)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--bashrc", default="")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    load_bashrc_env(bashrc_path=args.bashrc)
    if not feishu_credentials_configured():
        print("缺少 APP_ID 或 APP_SECRET，请确认已写入 ~/.bashrc 或当前环境变量", file=sys.stderr)
        return 1

    client = FeishuClient(dry_run=False)
    result = run_merge(
        client,
        ve8a1q_wiki_url=args.ve8a1q_wiki_url,
        ve8a1q_sheet_id=args.ve8a1q_sheet_id,
        task_wiki_url=args.task_wiki_url,
        task_sheet_id=args.task_sheet_id,
        output_wiki_url=args.output_wiki_url,
        output_sheet_id=args.output_sheet_id,
        insert_header=args.insert_header,
        dry_run=args.dry_run,
    )

    print("任务表合并完成")
    print("  ve8a1q sheet: %s (%s 行)" % (result["ve8a1q_sheet_id"], result["ve8a1q_rows"]))
    print("  task sheet: %s (%s 行)" % (result["task_sheet_id"], result["task_rows"]))
    print("  output sheet: %s (%s 行)" % (result["output_sheet_id"], result["output_rows"]))
    print("  iEoEoE rows: %s" % result["ieoeoe_rows"])
    print("  AG 匹配输出行: %s" % result["matched_output_rows"])
    print("  AG C列无匹配: %s" % result["not_found_output_rows"])
    print("  AG E/H列未找到: %s" % result["e_not_found_output_rows"])
    print("  AH 匹配输出行: %s" % result["second_matched_output_rows"])
    print("  AH C列无匹配: %s" % result["second_not_found_output_rows"])
    print("  AH E列未找到: %s" % result["second_e_not_found_output_rows"])
    print("  附件单元格: %s" % result["attachment_count"])
    print("  附件标红单元格: %s" % result["attachment_red_count"])
    print("  写入失败单元格: %s" % result["failed_cell_count"])
    print("  写入失败整行: %s" % result["failed_row_count"])
    if args.dry_run:
        print("预览前 5 行:")
        for row in result["output_preview"]:
            print("  %s" % row[:35])
    else:
        print(
            "已写入: %s?sheet=%s"
            % (args.output_wiki_url.split("?")[0], result["output_sheet_id"])
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
