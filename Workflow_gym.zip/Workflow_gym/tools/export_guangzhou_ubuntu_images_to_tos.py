#!/usr/bin/env python3
"""将广州区域 Ubuntu 自定义镜像导出到 TOS 固定目录。

筛选规则:
  - 源地域: cn-guangzhou
  - 操作系统: Ubuntu/Linux
  - 镜像名不包含 gui 后缀（不区分大小写）
  - 导出对象: tos://open-workflowgym-sample/{原始镜像ID去image-}_{广州镜像ID}_system.qcow2
  - tos_prefix 使用原始镜像 ID（去掉 image- 前缀），便于通过原始 ID 反查 TOS 对象
  - 下载到本地后文件名恢复为原始镜像名

示例:
  export AK=... SK=...
  python tools/export_guangzhou_ubuntu_images_to_tos.py --dry-run
  python tools/export_guangzhou_ubuntu_images_to_tos.py --limit 1
  python tools/export_guangzhou_ubuntu_images_to_tos.py --image-id image-xxx

  # 完整发布链路（导出 -> TOS 下载 -> Hugging Face）
  python tools/publish_guangzhou_images_to_huggingface.py \\
    --repo-id your-org/workflowgym-images --limit 1
"""
from __future__ import annotations

import argparse
import os
import re
import shlex
import subprocess
import sys
import time
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

import volcenginesdkcore
import volcenginesdkecs
from volcenginesdkcore.rest import ApiException

from open_workflowgym.envs.volcengine_env import (
    get_result_payload,
    image_os_type_label,
    image_record_field,
    image_record_platform,
    to_plain_dict,
)

SOURCE_REGION = "cn-guangzhou"
DEFAULT_LIST_LIMIT = 5000
DEFAULT_PAGE_SIZE = 100
DEFAULT_IMAGE_VISIBILITY = "private"
DEFAULT_TOS_BUCKET = "open-workflowgym-sample"
DEFAULT_EXPORT_OBJECT_SUFFIX = "_system.qcow2"
ORIGINAL_IMAGE_ID_PATTERN = re.compile(r"^image-[a-z0-9]+")
DEFAULT_EXPORT_CONCURRENCY = 10
DEFAULT_EXPORT_TIMEOUT_SECONDS = 1200
BASHRC_ENV_NAMES = ("AK", "SK")


def load_shell_env(names: tuple[str, ...] = BASHRC_ENV_NAMES) -> None:
    missing = [name for name in names if not os.getenv(name, "").strip()]
    if not missing:
        return
    for config_name in (".zshrc", ".bashrc", ".profile"):
        config_path = Path.home() / config_name
        if not config_path.is_file():
            continue
        config_quoted = shlex.quote(str(config_path))
        shell = "zsh" if config_name == ".zshrc" else "bash"
        for name in list(missing):
            try:
                completed = subprocess.run(
                    [
                        shell,
                        "-lc",
                        "set -a; source %s >/dev/null 2>&1; set +a; printf '%%s' \"${%s:-}\""
                        % (config_quoted, name),
                    ],
                    capture_output=True,
                    text=True,
                    timeout=15,
                    check=False,
                )
            except (OSError, subprocess.TimeoutExpired):
                continue
            value = (completed.stdout or "").strip()
            if value:
                os.environ[name] = value
                missing.remove(name)


def create_api_instance(region: str) -> volcenginesdkecs.ECSApi:
    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = region
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkecs.ECSApi()


def image_display_name(image: dict[str, Any]) -> str:
    return image_record_field(image, "ImageName", "image_name") or image_record_field(image, "ImageId", "image_id")


def is_ubuntu_image(image: dict[str, Any]) -> bool:
    if image_record_platform(image) == "ubuntu":
        return True
    label = image_os_type_label(image).lower()
    return "ubuntu" in label or "linux" in label


def has_gui_suffix(image: dict[str, Any]) -> bool:
    return "gui" in image_display_name(image).lower()


def normalize_tos_bucket(bucket: str) -> str:
    value = bucket.strip()
    if value.lower().startswith("tos://"):
        value = value[6:]
    return value.strip("/")


def strip_image_id_prefix(image_id: str) -> str:
    value = (image_id or "").strip()
    if value.lower().startswith("image-"):
        return value[6:]
    return value


def extract_original_image_id(image_name: str, image_id: str) -> str:
    """从镜像名提取原始 image-xxx；若名称不含则回退到当前广州 ImageId。"""
    name = (image_name or "").strip()
    match = ORIGINAL_IMAGE_ID_PATTERN.match(name)
    if match:
        return match.group(0)
    return (image_id or "").strip()


def build_export_tos_prefix(image_name: str, image_id: str) -> str:
    """ExportImage 的 tos_prefix 使用原始镜像 ID（去掉 image- 前缀）。"""
    original_image_id = extract_original_image_id(image_name, image_id)
    return strip_image_id_prefix(original_image_id)


def predict_export_object_key(tos_prefix: str, image_id: str) -> str:
    if not image_id:
        raise ValueError("predict_export_object_key 需要 image_id")
    prefix = (tos_prefix or "").strip("/")
    if not prefix:
        raise ValueError("predict_export_object_key 需要 tos_prefix")
    return "%s_%s%s" % (prefix, image_id, DEFAULT_EXPORT_OBJECT_SUFFIX)


def predict_export_object_uri(bucket: str, tos_prefix: str, image_id: str) -> str:
    return "tos://%s/%s" % (
        normalize_tos_bucket(bucket),
        predict_export_object_key(tos_prefix, image_id),
    )


def local_export_filename(image_name: str, image_id: str) -> str:
    """下载到本地后使用的原始镜像文件名。"""
    original_name = (image_name or image_id).strip() or image_id
    if original_name.endswith(".qcow2"):
        return original_name
    return "%s%s" % (original_name, DEFAULT_EXPORT_OBJECT_SUFFIX)


def safe_local_path_name(image_name: str, image_id: str) -> str:
    original_name = (image_name or image_id).strip() or image_id
    cleaned = re.sub(r"[^\w.\-]+", "_", original_name)
    return cleaned or image_id


def tos_export_uri(bucket: str, prefix: str) -> str:
    normalized_bucket = normalize_tos_bucket(bucket)
    normalized_prefix = prefix.strip("/")
    if normalized_prefix:
        return "tos://%s/%s/" % (normalized_bucket, normalized_prefix)
    return "tos://%s/" % normalized_bucket


def list_region_images(
    api_instance: volcenginesdkecs.ECSApi,
    *,
    limit: int = DEFAULT_LIST_LIMIT,
    page_size: int = DEFAULT_PAGE_SIZE,
    visibility: str = DEFAULT_IMAGE_VISIBILITY,
) -> list[dict[str, Any]]:
    images: list[dict[str, Any]] = []
    next_token = ""
    while len(images) < limit:
        request_kwargs: dict[str, Any] = {
            "max_results": min(page_size, limit - len(images)),
            "visibility": visibility,
        }
        if next_token:
            request_kwargs["next_token"] = next_token
        response = api_instance.describe_images(volcenginesdkecs.DescribeImagesRequest(**request_kwargs))
        result = get_result_payload(to_plain_dict(response))
        page_images = result.get("Images") or result.get("images") or []
        images.extend(page_images)
        next_token = result.get("NextToken") or result.get("next_token") or ""
        if not next_token or not page_images:
            break
    return images[:limit]


def has_bj_name_suffix(image: dict[str, Any]) -> bool:
    name = image_display_name(image).lower()
    return name.endswith("_bj") or name.endswith("_bjopen")


def select_export_candidates(
    images: list[dict[str, Any]],
    *,
    exclude_bj_suffix: bool = False,
    ubuntu_only: bool = True,
    exclude_gui: bool = True,
) -> list[dict[str, Any]]:
    """筛选导出候选。

    publish 全量上传时用 ubuntu_only=False / exclude_gui=False，
    以覆盖 cn-guangzhou 全部私有镜像。
    """
    candidates = []
    for image in images:
        if ubuntu_only and not is_ubuntu_image(image):
            continue
        if exclude_gui and has_gui_suffix(image):
            continue
        if exclude_bj_suffix and has_bj_name_suffix(image):
            continue
        candidates.append(image)
    return sorted(
        candidates,
        key=lambda item: (
            1 if has_bj_name_suffix(item) else 0,
            image_display_name(item).lower(),
        ),
    )


def describe_image_tasks(api_instance: volcenginesdkecs.ECSApi, image_id: str) -> list[dict[str, Any]]:
    response = api_instance.describe_tasks(
        volcenginesdkecs.DescribeTasksRequest(resource_ids=[image_id])
    )
    result = get_result_payload(to_plain_dict(response))
    return result.get("Tasks") or result.get("tasks") or []


def task_record_id(task: dict[str, Any]) -> str:
    return task.get("Id") or task.get("id") or ""


def wait_image_task(
    api_instance: volcenginesdkecs.ECSApi,
    image_id: str,
    *,
    task_label: str,
    poll_interval_seconds: int,
    timeout_seconds: int,
    task_id: str = "",
) -> list[dict[str, Any]]:
    deadline = time.time() + timeout_seconds
    last_tasks: list[dict[str, Any]] = []
    expected_task_id = (task_id or "").strip()
    while time.time() < deadline:
        tasks = describe_image_tasks(api_instance, image_id)
        if tasks:
            last_tasks = tasks
            tracked_tasks = tasks
            if expected_task_id:
                tracked_tasks = [
                    task for task in tasks if task_record_id(task) == expected_task_id
                ]
                if not tracked_tasks:
                    time.sleep(poll_interval_seconds)
                    continue
            for task in tracked_tasks:
                status = task.get("Status") or task.get("status")
                process = task.get("Process")
                if process is None:
                    process = task.get("process")
                print(
                    "%s任务进展: id=%s status=%s process=%s resource=%s"
                    % (
                        task_label,
                        task_record_id(task),
                        status,
                        process,
                        task.get("ResourceId") or task.get("resource_id"),
                    )
                )
                if status in ("Failed", "FAILED", "Error", "ERROR"):
                    raise RuntimeError("%s任务失败: %s" % (task_label, task))
                if status in (
                    "Success",
                    "SUCCESS",
                    "Succeeded",
                    "SUCCEEDED",
                    "Finished",
                    "FINISHED",
                ) or process == 100:
                    return tasks
        time.sleep(poll_interval_seconds)
    raise TimeoutError("等待%s任务完成超时，最后任务信息: %s" % (task_label, last_tasks))


def export_image_to_tos(
    api_instance: volcenginesdkecs.ECSApi,
    image: dict[str, Any],
    *,
    tos_bucket: str,
    poll_interval_seconds: int,
    timeout_seconds: int,
) -> dict[str, Any]:
    image_id = image_record_field(image, "ImageId", "image_id")
    image_name = image_display_name(image)
    original_image_id = extract_original_image_id(image_name, image_id)
    normalized_bucket = normalize_tos_bucket(tos_bucket)
    normalized_prefix = build_export_tos_prefix(image_name, image_id)
    request = volcenginesdkecs.ExportImageRequest(
        image_id=image_id,
        tos_bucket=normalized_bucket,
        tos_prefix=normalized_prefix,
    )
    response = api_instance.export_image(request)
    result = get_result_payload(to_plain_dict(response))
    export_uri = predict_export_object_uri(normalized_bucket, normalized_prefix, image_id)
    print("已提交导出任务: %s" % image_name)
    print("广州 ImageId: %s" % image_id)
    print("原始 ImageId: %s" % original_image_id)
    print("TOS 前缀: %s" % normalized_prefix)
    print("预计 TOS 对象: %s" % export_uri)
    if result:
        print("ExportImage 响应: %s" % result)
    export_task_id = result.get("task_id") or result.get("TaskId") or ""
    tasks = wait_image_task(
        api_instance,
        image_id,
        task_label="导出",
        poll_interval_seconds=poll_interval_seconds,
        timeout_seconds=timeout_seconds,
        task_id=export_task_id,
    )
    return {
        "image_id": image_id,
        "image_name": image_name,
        "original_image_id": original_image_id,
        "tos_bucket": normalized_bucket,
        "tos_prefix": normalized_prefix,
        "tos_uri": export_uri,
        "tos_object_uri": export_uri,
        "local_filename": local_export_filename(image_name, image_id),
        "export_tasks": tasks,
        "export_response": result,
    }


def export_images_concurrently(
    images: list[dict[str, Any]],
    *,
    tos_bucket: str,
    poll_interval_seconds: int,
    timeout_seconds: int,
    max_concurrency: int = DEFAULT_EXPORT_CONCURRENCY,
    raise_on_error: bool = True,
) -> tuple[list[dict[str, Any]], list[tuple[str, str, Exception]]]:
    if not images:
        return [], []
    worker_count = max(1, min(max_concurrency, DEFAULT_EXPORT_CONCURRENCY, len(images)))
    print("导出并发数: %s" % worker_count)
    results: list[dict[str, Any]] = []
    errors: list[tuple[str, str, Exception]] = []

    def _export_one(image: dict[str, Any]) -> dict[str, Any]:
        api = create_api_instance(SOURCE_REGION)
        return export_image_to_tos(
            api,
            image,
            tos_bucket=tos_bucket,
            poll_interval_seconds=poll_interval_seconds,
            timeout_seconds=timeout_seconds,
        )

    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        futures = {executor.submit(_export_one, image): image for image in images}
        for future in as_completed(futures):
            image = futures[future]
            image_name = image_display_name(image)
            image_id = image_record_field(image, "ImageId", "image_id")
            try:
                result = future.result()
                results.append(result)
                print("导出完成: %s -> %s" % (result["image_name"], result["tos_object_uri"]))
            except Exception as exc:
                errors.append((image_id, image_name, exc))
                print("导出失败: %s error=%s" % (image_name, exc))

    if errors and raise_on_error:
        detail = "; ".join("%s: %s" % (name, error) for _, name, error in errors)
        raise RuntimeError("部分镜像导出失败: %s" % detail)
    return sorted(results, key=lambda item: item["image_name"].lower()), errors


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="导出广州 Ubuntu 镜像到 TOS")
    parser.add_argument("--dry-run", action="store_true", help="仅列出候选镜像，不执行导出")
    parser.add_argument("--limit", type=int, default=1, help="实际导出的镜像数量，默认先导出 1 个")
    parser.add_argument("--image-id", default="", help="只导出指定镜像 ID")
    parser.add_argument("--list-limit", type=int, default=DEFAULT_LIST_LIMIT)
    parser.add_argument("--exclude-bj-suffix", action="store_true", help="排除镜像名以 _bj 结尾的候选")
    parser.add_argument(
        "--tos-bucket",
        default=os.getenv("TOS_UPLOAD_BUCKET", DEFAULT_TOS_BUCKET),
        help="导出目标 TOS 桶，默认 open-workflowgym-sample",
    )
    parser.add_argument("--poll-interval-seconds", type=int, default=int(os.getenv("TASK_POLL_INTERVAL_SECONDS", "30")))
    parser.add_argument(
        "--timeout-seconds",
        type=int,
        default=int(os.getenv("TASK_TIMEOUT_SECONDS", str(DEFAULT_EXPORT_TIMEOUT_SECONDS))),
        help="等待单个镜像导出完成超时，默认 1200 秒（约 20 分钟）",
    )
    parser.add_argument(
        "--export-concurrency",
        type=int,
        default=int(os.getenv("IMAGE_EXPORT_CONCURRENCY", str(DEFAULT_EXPORT_CONCURRENCY))),
        help="导出最大并发数，默认 10",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    load_shell_env()
    if not os.getenv("AK") or not os.getenv("SK"):
        raise SystemExit("缺少 AK/SK，请先 export 或写入 ~/.zshrc")

    api = create_api_instance(SOURCE_REGION)
    images = list_region_images(api, limit=args.list_limit)
    candidates = select_export_candidates(images, exclude_bj_suffix=args.exclude_bj_suffix)
    if args.image_id:
        candidates = [
            image
            for image in candidates
            if image_record_field(image, "ImageId", "image_id") == args.image_id
        ]
        if not candidates:
            raise SystemExit("未找到符合条件的镜像: %s" % args.image_id)

    print("源地域: %s" % SOURCE_REGION)
    print("TOS 桶: %s" % normalize_tos_bucket(args.tos_bucket))
    print(
        "TOS 命名: {原始镜像ID去image-}_{广州镜像ID}%s（tos_prefix=原始镜像ID去image-）"
        % DEFAULT_EXPORT_OBJECT_SUFFIX
    )
    print("候选镜像数: %s" % len(candidates))
    for index, image in enumerate(candidates, start=1):
        image_id = image_record_field(image, "ImageId", "image_id")
        image_name = image_display_name(image)
        original_image_id = extract_original_image_id(image_name, image_id)
        tos_prefix = build_export_tos_prefix(image_name, image_id)
        print(
            "%s. %s gz_id=%s orig_id=%s os=%s tos=%s local=%s"
            % (
                index,
                image_name,
                image_id,
                original_image_id,
                image_os_type_label(image),
                predict_export_object_uri(args.tos_bucket, tos_prefix, image_id),
                local_export_filename(image_name, image_id),
            )
        )

    if args.dry_run or not candidates:
        return 0

    selected = candidates[: max(args.limit, 0)]
    try:
        results, errors = export_images_concurrently(
            selected,
            tos_bucket=args.tos_bucket,
            poll_interval_seconds=args.poll_interval_seconds,
            timeout_seconds=args.timeout_seconds,
            max_concurrency=args.export_concurrency,
        )
    except RuntimeError as exc:
        print(exc)
        return 1
    if errors:
        print("部分镜像导出失败: %s" % len(errors))
        return 1
    print("成功导出 %s 个镜像到 TOS" % len(results))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
