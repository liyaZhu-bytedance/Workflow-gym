#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import shlex
import subprocess
import sys
import tempfile
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.feishu_client import FeishuClient, number_to_column, offset_cell
from open_workflowgym.local_spreadsheet import feishu_credentials_configured
from open_workflowgym.source_reader import parse_feishu_sheet_url

DEFAULT_WIKI_URL = os.getenv("FEISHU_WIKI_URL", "https://example.feishu.local/wiki/PLACEHOLDER")
DEFAULT_SOURCE_SHEET_ID = "KedpIH"
DEFAULT_LOOKUP_SHEET_ID = "14c62e"
DEFAULT_OUTPUT_SHEET_ID = "iEoEoE"
DEFAULT_MATCHED_IMAGE_ID_HEADER = "镜像id"
LOOKUP_IMAGE_NAME_COLUMN = 1
LOOKUP_IMAGE_ID_COLUMN = 6
NOT_FOUND_LABEL = "未找到"
PREVIEW_WINDOWS2022_PREFIX = "preview-windows2022"
PREVIEW_WINDOWS2022_KEY_SEGMENTS = 4
DEFAULT_KEY_SEGMENTS = 3
BASHRC_ENV_NAMES = ("APP_ID", "APP_SECRET")


def load_shell_env(names: tuple[str, ...] = BASHRC_ENV_NAMES, shell_config_paths: list[str] | None = None) -> None:
    missing = [name for name in names if not os.getenv(name, "").strip()]
    if not missing:
        return
    candidates = shell_config_paths or [
        os.path.expanduser("~/.bashrc"),
        os.path.expanduser("~/.zshrc"),
        os.path.expanduser("~/.profile"),
    ]
    for config_path in candidates:
        config = Path(config_path)
        if not config.is_file():
            continue
        config_quoted = shlex.quote(str(config))
        shell = "zsh" if config.name.endswith("zshrc") else "bash"
        for name in list(missing):
            try:
                completed = subprocess.run(
                    [
                        shell,
                        "-lc",
                        "set -a; source %s >/dev/null 2>&1; set +a; printf '%%s' \"${%s:-}\""
                        % (config_quoted, name),
                    ],
                    capture_output=True,
                    text=True,
                    timeout=15,
                    check=False,
                )
            except (OSError, subprocess.TimeoutExpired):
                continue
            value = (completed.stdout or "").strip()
            if value:
                os.environ[name] = value
                missing.remove(name)
        if not missing:
            return


def load_bashrc_env(names: tuple[str, ...] = BASHRC_ENV_NAMES, bashrc_path: str = "") -> None:
    if bashrc_path:
        load_shell_env(names, [bashrc_path])
        return
    load_shell_env(names)


def flatten_cell_text(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (int, float, bool)):
        return str(value).strip()
    if isinstance(value, list):
        parts: list[str] = []
        for item in value:
            text = flatten_cell_text(item)
            if text:
                parts.append(text)
        return "".join(parts).strip()
    if isinstance(value, dict):
        return str(value.get("text") or value.get("link") or "").strip()
    return str(value).strip()


def is_preview_windows2022_name(name: object) -> bool:
    text = flatten_cell_text(name)
    if not text:
        return False
    parts = text.split("-")
    return len(parts) >= 2 and parts[0].lower() == "preview" and parts[1].lower() == "windows2022"


STRIP_IMAGE_SUFFIXES = (".qcow2_bj", "_bj_gui", ".qcow2", ".pcow2")


def strip_image_name_suffix(text: str) -> str:
    stripped = text
    while True:
        lowered = stripped.lower()
        for suffix in STRIP_IMAGE_SUFFIXES:
            if lowered.endswith(suffix.lower()):
                stripped = stripped[: -len(suffix)]
                break
        else:
            return stripped


def normalize_image_key(name: object) -> str:
    text = strip_image_name_suffix(flatten_cell_text(name))
    if not text:
        return ""
    parts = text.split("-")
    segment_count = (
        PREVIEW_WINDOWS2022_KEY_SEGMENTS
        if is_preview_windows2022_name(text)
        else DEFAULT_KEY_SEGMENTS
    )
    if len(parts) < segment_count:
        return text
    return "-".join(parts[:segment_count])


LOOKUP_SKIP_SUFFIXES = (".qcow2", ".pcow2")
SOURCE_SKIP_SUFFIXES = (".pcow2",)


def should_skip_image_name(name: object) -> bool:
    text = flatten_cell_text(name).lower()
    return any(text.endswith(suffix) for suffix in SOURCE_SKIP_SUFFIXES)


def should_skip_lookup_image(name: object) -> bool:
    text = flatten_cell_text(name).lower()
    return any(text.endswith(suffix) for suffix in LOOKUP_SKIP_SUFFIXES)


def cell_value(row: list[Any], column_index: int) -> str:
    if column_index < 0 or column_index >= len(row):
        return ""
    return flatten_cell_text(row[column_index])


def build_image_id_lookup(
    lookup_rows: list[list[Any]],
    *,
    image_name_column: int = LOOKUP_IMAGE_NAME_COLUMN,
    image_id_column: int = LOOKUP_IMAGE_ID_COLUMN,
) -> dict[str, list[str]]:
    lookup: dict[str, list[str]] = defaultdict(list)
    for row_index, row in enumerate(lookup_rows):
        if row_index == 0:
            continue
        image_name = cell_value(row, image_name_column)
        image_id = cell_value(row, image_id_column)
        if not image_name or not image_id:
            continue
        if should_skip_lookup_image(image_name):
            continue
        key = normalize_image_key(image_name)
        if not key:
            continue
        if image_id not in lookup[key]:
            lookup[key].append(image_id)
    return dict(lookup)


def format_matched_image_ids(image_ids: list[str]) -> str:
    if not image_ids:
        return NOT_FOUND_LABEL
    return ",".join(image_ids)


def insert_column_after(rows: list[list[Any]], column_index: int, values: list[str]) -> list[list[Any]]:
    output_rows: list[list[Any]] = []
    for row_index, row in enumerate(rows):
        padded = list(row)
        insert_value = values[row_index] if row_index < len(values) else ""
        padded.insert(column_index + 1, insert_value)
        output_rows.append(padded)
    return output_rows


def row_has_content(row: list[Any]) -> bool:
    return any(str(cell or "").strip() for cell in row)


def trim_trailing_empty_rows(rows: list[list[Any]]) -> list[list[Any]]:
    trimmed = list(rows)
    while trimmed and not row_has_content(trimmed[-1]):
        trimmed.pop()
    return trimmed


def build_output_rows(source_rows: list[list[Any]], lookup_rows: list[list[Any]], *, matched_header: str) -> list[list[Any]]:
    source_rows = trim_trailing_empty_rows(source_rows)
    lookup_rows = trim_trailing_empty_rows(lookup_rows)
    if not source_rows:
        return []
    lookup = build_image_id_lookup(lookup_rows)
    source_name_column = 3
    filtered_source_rows: list[list[Any]] = [source_rows[0]]
    matched_values: list[str] = [matched_header]
    for row in source_rows[1:]:
        source_name = cell_value(row, source_name_column)
        if should_skip_image_name(source_name):
            continue
        key = normalize_image_key(source_name)
        filtered_source_rows.append(row)
        matched_values.append(format_matched_image_ids(lookup.get(key, [])))
    return insert_column_after(filtered_source_rows, source_name_column, matched_values)


def resolve_spreadsheet_token(client: FeishuClient, wiki_url: str) -> str:
    info = parse_feishu_sheet_url(wiki_url)
    if info.get("is_wiki"):
        return client.resolve_wiki_spreadsheet_token(info["token"])
    return info["token"]


def read_sheet_rows(client: FeishuClient, spreadsheet_token: str, sheet_id: str, column_range: str = "A1:ZZ2000") -> list[list[Any]]:
    cell_range = "%s!%s" % (sheet_id, column_range)
    return client.read_values(spreadsheet_token, cell_range)


def read_sheet_rows_chunked(
    client: FeishuClient,
    spreadsheet_token: str,
    sheet_id: str,
    *,
    end_column: str = "ZZ",
    row_chunk_size: int = 500,
    max_rows: int = 5000,
) -> list[list[Any]]:
    all_rows: list[list[Any]] = []
    start_row = 1
    while start_row <= max_rows:
        end_row = min(start_row + row_chunk_size - 1, max_rows)
        cell_range = "%s!A%d:%s%d" % (sheet_id, start_row, end_column, end_row)
        chunk = client.read_values(spreadsheet_token, cell_range)
        if not chunk:
            break
        all_rows.extend(chunk)
        if len(chunk) < row_chunk_size:
            break
        start_row += row_chunk_size
    return all_rows


def trim_trailing_empty_columns(rows: list[list[Any]]) -> list[list[Any]]:
    if not rows:
        return rows
    max_width = max(len(row) for row in rows)
    padded = [list(row) + [""] * (max_width - len(row)) for row in rows]
    last_used = -1
    for column_index in range(max_width):
        if any(str(cell or "").strip() for cell in (row[column_index] for row in padded)):
            last_used = column_index
    if last_used < 0:
        return padded
    return [row[: last_used + 1] for row in padded]


MAX_SHEET_CELL_BYTES = 49000
ATTACHMENT_PLACEHOLDER = "见附件"
WRITE_FAILED_TEXT = "[写入失败]"
FAILURE_BACK_COLOR = "#ffccc7"


@dataclass
class WriteSheetResult:
    attachment_count: int = 0
    attachment_red_count: int = 0
    failed_cell_count: int = 0
    failed_row_count: int = 0
    marked_red_ranges: list[str] = field(default_factory=list)


def cell_to_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, dict):
        cell_type = str(value.get("type") or "").strip()
        if cell_type == "embed-image":
            return str(value.get("link") or value.get("text") or "")
        if cell_type == "file":
            file_info = value.get("file") or {}
            return str(file_info.get("file_token") or "")
        return ""
    if isinstance(value, list):
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (str, int, float)):
        return value if isinstance(value, str) else str(value)
    return str(value)


def cell_text_size(value: str) -> int:
    return len(value.encode("utf-8"))


def cell_address(row_index: int, column_index: int) -> str:
    return "%s%s" % (number_to_column(column_index + 1), row_index + 1)


def sheet_cell_range(sheet_id: str, row_index: int, column_index: int) -> str:
    address = cell_address(row_index, column_index)
    return "%s!%s:%s" % (sheet_id, address, address)


def prepare_write_cell(value: Any) -> Any:
    text = cell_to_text(value)
    if cell_text_size(text) > MAX_SHEET_CELL_BYTES:
        return ATTACHMENT_PLACEHOLDER
    return text


@dataclass
class PreparedWritePlan:
    rows: list[list[Any]]
    attachments: list[tuple[int, int, str]]


def prepare_write_plan(rows: list[list[Any]]) -> PreparedWritePlan:
    rows = trim_trailing_empty_columns(rows)
    prepared_rows: list[list[Any]] = []
    attachments: list[tuple[int, int, str]] = []
    for row_index, row in enumerate(rows):
        prepared_row: list[Any] = []
        for column_index, cell in enumerate(row):
            text = cell_to_text(cell)
            if cell_text_size(text) > MAX_SHEET_CELL_BYTES:
                attachments.append((row_index, column_index, text))
                prepared_row.append(ATTACHMENT_PLACEHOLDER)
            else:
                prepared_row.append(text)
        prepared_rows.append(prepared_row)
    return PreparedWritePlan(rows=prepared_rows, attachments=attachments)


def write_values_chunk(
    client: FeishuClient,
    spreadsheet_token: str,
    sheet_id: str,
    start_row: int,
    chunk_rows: list[list[Any]],
) -> None:
    if not chunk_rows:
        return None
    start_cell = "A%s" % start_row
    end_cell = offset_cell(start_cell, len(chunk_rows), len(chunk_rows[0]))
    payload = {
        "valueRanges": [
            {
                "range": "%s!%s:%s" % (sheet_id, start_cell, end_cell),
                "values": chunk_rows,
            }
        ]
    }
    client.request_json(
        "POST",
        "/sheets/v2/spreadsheets/%s/values_batch_update" % spreadsheet_token,
        payload,
    )
    return None


def upload_text_attachment(
    client: FeishuClient,
    spreadsheet_token: str,
    *,
    row_index: int,
    column_index: int,
    content: str,
) -> str:
    file_name = "cell_%s_%s.txt" % (row_index + 1, number_to_column(column_index + 1))
    temp_path = ""
    try:
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", suffix=".txt", delete=False) as handle:
            handle.write(content)
            temp_path = handle.name
        return client.upload_attachment(spreadsheet_token, temp_path, file_name)
    finally:
        if temp_path:
            try:
                os.unlink(temp_path)
            except OSError:
                pass


def mark_cells_red(
    client: FeishuClient,
    spreadsheet_token: str,
    sheet_id: str,
    cell_positions: list[tuple[int, int]],
    result: WriteSheetResult,
    *,
    count_as_failure: bool = True,
) -> None:
    if not cell_positions:
        return None
    ranges = [sheet_cell_range(sheet_id, row_index, column_index) for row_index, column_index in cell_positions]
    client.set_cells_background(spreadsheet_token, ranges, back_color=FAILURE_BACK_COLOR)
    result.marked_red_ranges.extend(ranges)
    if count_as_failure:
        result.failed_cell_count += len(cell_positions)
    else:
        result.attachment_red_count += len(cell_positions)
    return None


def write_single_cell_value(
    client: FeishuClient,
    spreadsheet_token: str,
    sheet_id: str,
    row_index: int,
    column_index: int,
    value: Any,
) -> None:
    address = cell_address(row_index, column_index)
    payload = {
        "valueRanges": [
            {
                "range": "%s!%s:%s" % (sheet_id, address, address),
                "values": [[value]],
            }
        ]
    }
    client.request_json(
        "POST",
        "/sheets/v2/spreadsheets/%s/values_batch_update" % spreadsheet_token,
        payload,
    )
    return None


def write_attachment_cells(
    client: FeishuClient,
    spreadsheet_token: str,
    sheet_id: str,
    attachments: list[tuple[int, int, str]],
    result: WriteSheetResult,
) -> None:
    failed_positions: list[tuple[int, int]] = []
    attachment_positions: list[tuple[int, int]] = []
    for row_index, column_index, content in attachments:
        try:
            file_token = upload_text_attachment(
                client,
                spreadsheet_token,
                row_index=row_index,
                column_index=column_index,
                content=content,
            )
            client.write_file_cell(
                spreadsheet_token,
                sheet_id,
                cell_address(row_index, column_index),
                file_token,
            )
            result.attachment_count += 1
            attachment_positions.append((row_index, column_index))
        except Exception:
            failed_positions.append((row_index, column_index))
            try:
                write_single_cell_value(
                    client,
                    spreadsheet_token,
                    sheet_id,
                    row_index,
                    column_index,
                    WRITE_FAILED_TEXT,
                )
            except Exception:
                pass
    mark_cells_red(client, spreadsheet_token, sheet_id, attachment_positions, result, count_as_failure=False)
    mark_cells_red(client, spreadsheet_token, sheet_id, failed_positions, result, count_as_failure=True)
    return None


def write_sheet_rows(
    client: FeishuClient,
    spreadsheet_token: str,
    sheet_id: str,
    rows: list[list[Any]],
    *,
    chunk_size: int = 5,
) -> WriteSheetResult:
    plan = prepare_write_plan(rows)
    result = WriteSheetResult()
    if not plan.rows:
        raise ValueError("输出表格为空，拒绝写入")

    failed_rows: list[int] = []
    prepared_rows = plan.rows
    for start_index in range(0, len(prepared_rows), chunk_size):
        chunk = prepared_rows[start_index : start_index + chunk_size]
        start_row = start_index + 1
        try:
            write_values_chunk(client, spreadsheet_token, sheet_id, start_row, chunk)
            continue
        except Exception:
            for offset, row in enumerate(chunk):
                row_number = start_row + offset
                try:
                    write_values_chunk(client, spreadsheet_token, sheet_id, row_number, [row])
                except Exception:
                    failed_rows.append(row_number)
                    result.failed_row_count += 1

    if failed_rows:
        end_column = number_to_column(len(prepared_rows[0]))
        failed_ranges = ["%s!A%s:%s%s" % (sheet_id, row_number, end_column, row_number) for row_number in failed_rows]
        client.set_cells_background(spreadsheet_token, failed_ranges, back_color=FAILURE_BACK_COLOR)
        result.marked_red_ranges.extend(failed_ranges)

    write_attachment_cells(client, spreadsheet_token, sheet_id, plan.attachments, result)
    return result


def write_output_sheet(
    client: FeishuClient,
    spreadsheet_token: str,
    sheet_id: str,
    rows: list[list[Any]],
) -> WriteSheetResult:
    return write_sheet_rows(client, spreadsheet_token, sheet_id, rows)


def run_match(
    client: FeishuClient,
    *,
    wiki_url: str = DEFAULT_WIKI_URL,
    source_sheet_id: str = DEFAULT_SOURCE_SHEET_ID,
    lookup_sheet_id: str = DEFAULT_LOOKUP_SHEET_ID,
    output_sheet_id: str = DEFAULT_OUTPUT_SHEET_ID,
    matched_header: str = DEFAULT_MATCHED_IMAGE_ID_HEADER,
    dry_run: bool = False,
) -> dict[str, Any]:
    spreadsheet_token = resolve_spreadsheet_token(client, wiki_url)
    source_rows = read_sheet_rows(client, spreadsheet_token, source_sheet_id)
    lookup_rows = read_sheet_rows(client, spreadsheet_token, lookup_sheet_id, "A1:G2000")
    output_rows = build_output_rows(source_rows, lookup_rows, matched_header=matched_header)

    matched_count = 0
    missing_count = 0
    multi_count = 0
    for row_index, row in enumerate(output_rows):
        if row_index == 0:
            continue
        value = cell_value(row, 4)
        if value == NOT_FOUND_LABEL:
            missing_count += 1
        elif "," in value:
            multi_count += 1
            matched_count += 1
        elif value:
            matched_count += 1

    if not dry_run:
        write_result = write_output_sheet(client, spreadsheet_token, output_sheet_id, output_rows)
    else:
        write_result = WriteSheetResult()

    return {
        "spreadsheet_token": spreadsheet_token,
        "source_sheet_id": source_sheet_id,
        "lookup_sheet_id": lookup_sheet_id,
        "output_sheet_id": output_sheet_id,
        "source_rows": len(source_rows),
        "output_rows": len(output_rows),
        "matched_count": matched_count,
        "missing_count": missing_count,
        "multi_count": multi_count,
        "attachment_count": write_result.attachment_count,
        "attachment_red_count": write_result.attachment_red_count,
        "failed_cell_count": write_result.failed_cell_count,
        "failed_row_count": write_result.failed_row_count,
        "output_preview": output_rows[:5],
    }


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="按镜像名前缀匹配飞书表格中的 image_id，并写入输出 sheet 的 E 列")
    parser.add_argument("--wiki-url", default=DEFAULT_WIKI_URL, help="飞书 wiki 表格 URL（不含 sheet 参数也可）")
    parser.add_argument("--source-sheet-id", default=DEFAULT_SOURCE_SHEET_ID, help="源数据 sheet id，读取 D 列镜像名")
    parser.add_argument("--lookup-sheet-id", default=DEFAULT_LOOKUP_SHEET_ID, help="查找 sheet id，读取 B 列镜像名和 G 列 image_id")
    parser.add_argument("--output-sheet-id", default=DEFAULT_OUTPUT_SHEET_ID, help="输出 sheet id，写入带 E 列的结果")
    parser.add_argument("--matched-header", default=DEFAULT_MATCHED_IMAGE_ID_HEADER, help="新增 E 列表头")
    parser.add_argument("--dry-run", action="store_true", help="只计算匹配结果，不写入飞书")
    parser.add_argument("--bashrc", default="", help="可选，指定 bashrc 路径，默认 ~/.bashrc")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    load_bashrc_env(bashrc_path=args.bashrc)
    if not feishu_credentials_configured():
        print("缺少 APP_ID 或 APP_SECRET，请确认已写入 ~/.bashrc 或当前环境变量", file=sys.stderr)
        return 1

    client = FeishuClient(dry_run=False)
    result = run_match(
        client,
        wiki_url=args.wiki_url,
        source_sheet_id=args.source_sheet_id,
        lookup_sheet_id=args.lookup_sheet_id,
        output_sheet_id=args.output_sheet_id,
        matched_header=args.matched_header,
        dry_run=args.dry_run,
    )

    print("镜像匹配完成")
    print("  spreadsheet_token: %s" % result["spreadsheet_token"])
    print("  source sheet: %s (%s 行)" % (result["source_sheet_id"], result["source_rows"]))
    print("  lookup sheet: %s" % result["lookup_sheet_id"])
    print("  output sheet: %s (%s 行)" % (result["output_sheet_id"], result["output_rows"]))
    print("  匹配成功: %s" % result["matched_count"])
    print("  未找到: %s" % result["missing_count"])
    print("  多个匹配: %s" % result["multi_count"])
    if args.dry_run:
        print("预览前 5 行:")
        for row in result["output_preview"]:
            print("  %s" % row)
    else:
        print(
            "已写入: %s?sheet=%s"
            % (args.wiki_url.split("?")[0], result["output_sheet_id"])
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
