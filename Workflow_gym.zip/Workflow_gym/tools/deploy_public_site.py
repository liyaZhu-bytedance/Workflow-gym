#!/usr/bin/env python3
"""一键部署公网IP服务站点

使用火山引擎SDK实现：
1. 创建ECS实例（默认广州）
2. 配置安全组（开放所有流量）
3. 配置ACL（开放所有流量）
4. 申请并绑定公网IP
5. 配置互联网防火墙策略
6. 安装Python 3.12
7. 启动HTTP服务 (python3 -m http.server 80)
8. 本地curl测试验证

用法:
    export AK=xxx SK=xxx
    # INSTANCE_PASSWORD / KEY_PAIR_NAME 也可写在 ~/.zshrc 中，脚本会自动读取
    python tools/deploy_public_site.py
    python tools/deploy_public_site.py --instance-name my-test-site
    python tools/deploy_public_site.py --region cn-guangzhou

说明:
    脚本会先配置安全组/ACL，再创建实例并绑定 EIP，最后通过云助手安装 Python 并启动 HTTP 服务。
    互联网防火墙默认可通过 AssetList 自动探测；若失败则回退 DescribeControlPolicy。单防火墙账号通常无需手动设置 ID。
"""
from __future__ import annotations

import argparse
import json
import os
import shlex
import subprocess
import sys
import time
import warnings
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

import volcenginesdkcore
from volcenginesdkcore.rest import ApiException

BASHRC_ENV_NAMES = ("AK", "SK", "INSTANCE_PASSWORD", "KEY_PAIR_NAME")

DEFAULT_REGION = "cn-guangzhou"
DEFAULT_IMAGE_ID = "image-yeqmmcfxblfa2vxfbnyz"
DEFAULT_INSTANCE_NAME = "public_site_demo"
DEFAULT_INSTANCE_TYPE_ID = "ecs.g3i.large"
DEFAULT_SECURITY_GROUP_ID = "sg-2jxvygwafv9xc7zrx9wf0sqkg"
DEFAULT_SUBNET_ID = "subnet-2zwe59aqcfhmo6ql1m3wkdq42"
DEFAULT_VOLUME_SIZE = 40
DEFAULT_PROJECT_NAME = "default"
DEFAULT_HTTP_PORT = 80


def load_shell_env(names: tuple[str, ...] = BASHRC_ENV_NAMES) -> None:
    missing = [name for name in names if not os.getenv(name, "").strip()]
    if not missing:
        return
    for config_path in (
        os.path.expanduser("~/.bashrc"),
        os.path.expanduser("~/.zshrc"),
        os.path.expanduser("~/.profile"),
    ):
        config = Path(config_path)
        if not config.is_file():
            continue
        config_quoted = shlex.quote(str(config))
        shell = "zsh" if config.name.endswith("zshrc") else "bash"
        for name in list(missing):
            try:
                completed = subprocess.run(
                    [
                        shell,
                        "-lc",
                        "set -a; source %s >/dev/null 2>&1; set +a; printf '%%s' \"${%s:-}\""
                        % (config_quoted, name),
                    ],
                    capture_output=True,
                    text=True,
                    timeout=15,
                    check=False,
                )
            except (OSError, subprocess.TimeoutExpired):
                continue
            value = (completed.stdout or "").strip()
            if value:
                os.environ[name] = value
                missing.remove(name)
        if not missing:
            return


def to_plain_dict(response: Any) -> Any:
    if isinstance(response, dict):
        return response
    if hasattr(response, "to_dict"):
        return response.to_dict()
    return response


def get_result_payload(response_data: Any) -> Any:
    if isinstance(response_data, dict):
        return response_data.get("Result", response_data)
    return response_data


def first_value(data: Any, *keys: str) -> Any:
    if not isinstance(data, dict):
        return None
    for key in keys:
        value = data.get(key)
        if value:
            return value
    return None


def api_exception_message(exc: ApiException) -> str:
    body = ""
    try:
        if exc.body:
            body_data = json.loads(exc.body) if isinstance(exc.body, str) else exc.body
            body = " body=%s" % json.dumps(body_data, ensure_ascii=False)
    except Exception:
        body = " body=%s" % exc.body
    return "status=%s reason=%s%s" % (getattr(exc, "status", ""), getattr(exc, "reason", ""), body)


def log_step(step: str, message: str = "") -> None:
    prefix = "[%s]" % step
    if message:
        print("%s %s" % (prefix, message), flush=True)
    else:
        print(prefix, flush=True)


def build_instance_console_url(
    region: str,
    instance_id: str,
    project_name: str = DEFAULT_PROJECT_NAME,
) -> str:
    query = urlencode({"tab": "info", "projectName": project_name or DEFAULT_PROJECT_NAME})
    return (
        "https://console.volcengine.com/ecs/region:ecs+%s/instance/detail/%s?%s"
        % (region, instance_id, query)
    )


def create_ecs_api(region: str):
    import volcenginesdkecs

    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = region
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkecs.ECSApi()


def create_vpc_api(region: str):
    import volcenginesdkvpc

    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = region
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkvpc.VPCApi()


def create_fwcenter_api(region: str):
    import volcenginesdkfwcenter

    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = region
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkfwcenter.FWCENTERApi()


def is_duplicate_security_rule_error(message: str) -> bool:
    markers = (
        "already exists",
        "RuleAlreadyExists",
        "InvalidParameter.Duplicate",
        "InvalidSecurityRule.Conflict",
    )
    return any(marker in message for marker in markers)


def extract_operation_detail_errors(result: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    operation_details = result.get("OperationDetails") or result.get("operation_details") or []
    for detail in operation_details:
        if not isinstance(detail, dict):
            continue
        error = detail.get("Error") or detail.get("error") or {}
        if not isinstance(error, dict):
            continue
        code = str(error.get("Code") or error.get("code") or "").strip()
        message = str(error.get("Message") or error.get("message") or "").strip()
        if code or message:
            errors.append("%s: %s" % (code, message) if code else message)
    return errors


def build_allocate_instances_request(
    volcenginesdkecs: Any,
    *,
    instance_name: str,
    instance_type_id: str,
    image_id: str,
    security_group_id: str,
    subnet_id: str,
    volume_size: int,
    project_name: str,
    client_token: str,
    password: str = "",
    key_pair_name: str = "",
    keep_image_credential: bool | None = None,
) -> Any:
    network_interface = volcenginesdkecs.NetworkInterfaceForAllocateInstancesInput(
        subnet_id=[subnet_id],
        security_group_ids=[security_group_id],
    )
    volume = volcenginesdkecs.VolumeForAllocateInstancesInput(
        volume_type="ESSD_PL0",
        size=volume_size,
    )
    request_kwargs: dict[str, Any] = {
        "instance_name": instance_name,
        "instance_type_id": instance_type_id,
        "image_id": image_id,
        "description": "Public site demo instance",
        "network_interfaces": [network_interface],
        "volumes": [volume],
        "instance_charge_type": "PostPaid",
        "project_name": project_name,
        "count": 1,
        "install_run_command_agent": True,
        "client_token": client_token,
    }
    if password:
        request_kwargs["password"] = password
        request_kwargs["keep_image_credential"] = False
    elif key_pair_name:
        request_kwargs["key_pair_name"] = key_pair_name
        request_kwargs["keep_image_credential"] = False
    else:
        if keep_image_credential is None:
            keep_image_credential = os.getenv("KEEP_IMAGE_CREDENTIAL", "1").lower() not in (
                "0",
                "false",
                "no",
                "off",
            )
        request_kwargs["keep_image_credential"] = keep_image_credential
    return volcenginesdkecs.AllocateInstancesRequest(**request_kwargs)


def create_instance(
    region: str,
    image_id: str,
    instance_name: str,
    instance_type_id: str,
    security_group_id: str,
    subnet_id: str,
    volume_size: int,
    project_name: str,
    password: str = "",
    key_pair_name: str = "",
    keep_image_credential: bool | None = None,
) -> dict[str, Any]:
    import volcenginesdkecs
    import uuid

    log_step("1/8", "创建ECS实例...")
    api = create_ecs_api(region)

    request = build_allocate_instances_request(
        volcenginesdkecs,
        instance_name=instance_name,
        instance_type_id=instance_type_id,
        image_id=image_id,
        security_group_id=security_group_id,
        subnet_id=subnet_id,
        volume_size=volume_size,
        project_name=project_name,
        client_token=str(uuid.uuid4()),
        password=password,
        key_pair_name=key_pair_name,
        keep_image_credential=keep_image_credential,
    )

    try:
        response = api.allocate_instances(request)
        response_data = to_plain_dict(response)
        result = get_result_payload(response_data)
        instance_ids = extract_instance_ids_from_operation_details(result)

        if not instance_ids:
            detail_errors = extract_operation_detail_errors(result)
            if detail_errors:
                hint = ""
                if any("PasswordAndKeyPair" in item for item in detail_errors):
                    hint = (
                        " 请设置 INSTANCE_PASSWORD / --password，或 KEY_PAIR_NAME / --key-pair-name，"
                        "或保持 keep_image_credential=true（默认）以复用镜像登录凭据。"
                    )
                raise RuntimeError("创建ECS实例失败: %s%s" % ("; ".join(detail_errors), hint))
            raise ValueError("AllocateInstances 未返回 InstanceIds: %s" % response_data)

        instance_id = instance_ids[0]
        print("  实例ID: %s" % instance_id)

        log_step("1/8", "等待实例启动...")
        wait_for_instance_status(api, instance_id, "RUNNING")
        print("  实例已启动: %s" % instance_id)

        instance_info = describe_instance(api, instance_id)
        network_ips = extract_instance_network_ips(instance_info)
        private_ip = network_ips[0] if network_ips else ""

        return {
            "instance_id": instance_id,
            "private_ip": private_ip,
            "network_ips": network_ips,
            "instance_info": instance_info,
        }
    except ApiException as exc:
        raise RuntimeError("创建ECS实例失败: %s" % api_exception_message(exc)) from exc


def extract_instance_ids_from_operation_details(result: dict[str, Any]) -> list[str]:
    operation_details = result.get("OperationDetails") or result.get("operation_details") or []
    instance_ids: list[str] = []
    for detail in operation_details:
        if not isinstance(detail, dict):
            continue
        for instance_id in detail.get("InstanceIds") or detail.get("instance_ids") or []:
            value = str(instance_id or "").strip()
            if value:
                instance_ids.append(value)
    return instance_ids


def describe_instance(api: Any, instance_id: str) -> dict[str, Any]:
    import volcenginesdkecs

    request = volcenginesdkecs.DescribeInstancesRequest(instance_ids=[instance_id])
    response = api.describe_instances(request)
    response_data = to_plain_dict(response)
    result = get_result_payload(response_data)
    instances = first_value(result, "Instances", "instances") or []
    if not instances:
        raise ValueError("DescribeInstances 未找到实例: %s" % instance_id)
    return instances[0]


def instance_status(instance: dict[str, Any]) -> str:
    return str(instance.get("Status") or instance.get("status") or "").strip()


def wait_for_instance_status(
    api: Any,
    instance_id: str,
    target_status: str,
    timeout_seconds: int = 600,
    poll_seconds: int = 10,
) -> dict[str, Any]:
    deadline = time.time() + timeout_seconds
    last_instance = None
    while time.time() <= deadline:
        try:
            instance = describe_instance(api, instance_id)
            last_instance = instance
            status = instance_status(instance)
            if status == target_status:
                return instance
            print("  当前状态: %s (等待 %s)" % (status, target_status))
        except ApiException:
            pass
        time.sleep(poll_seconds)
    raise TimeoutError(
        "等待实例状态超时: instance_id=%s target=%s last_status=%s"
        % (instance_id, target_status, instance_status(last_instance) if last_instance else "unknown")
    )


def configure_security_group(
    region: str,
    security_group_id: str,
) -> dict[str, Any]:
    import volcenginesdkvpc

    log_step("2/8", "配置安全组（开放所有入站流量）...")
    api = create_vpc_api(region)

    rules_added = []
    rules = [
        {"protocol": "all", "port_start": -1, "port_end": -1, "desc": "all protocols"},
        {"protocol": "tcp", "port_start": 1, "port_end": 65535, "desc": "all TCP ports"},
        {"protocol": "udp", "port_start": 1, "port_end": 65535, "desc": "all UDP ports"},
        {"protocol": "icmp", "port_start": -1, "port_end": -1, "desc": "ICMP"},
    ]

    for rule in rules:
        try:
            request = volcenginesdkvpc.AuthorizeSecurityGroupIngressRequest(
                security_group_id=security_group_id,
                protocol=rule["protocol"],
                port_start=rule["port_start"],
                port_end=rule["port_end"],
                cidr_ip="127.0.0.1/32",
                policy="accept",
                priority=1,
                description="Allow %s for demo site" % rule["desc"],
            )
            response = api.authorize_security_group_ingress(request)
            rules_added.append({"protocol": rule["protocol"], "response": to_plain_dict(response)})
            print("  已添加 %s 入站规则" % rule["protocol"].upper())
        except ApiException as exc:
            msg = api_exception_message(exc)
            if is_duplicate_security_rule_error(msg):
                print("  %s 入站规则已存在或已被更宽规则覆盖，跳过" % rule["protocol"].upper())
            else:
                print("  警告: 添加 %s 入站规则失败: %s" % (rule["protocol"].upper(), msg))

    return {"security_group_id": security_group_id, "rules_added": rules_added}


def configure_acl(
    region: str,
    subnet_id: str,
) -> dict[str, Any]:
    import volcenginesdkvpc

    log_step("3/8", "配置ACL（开放所有流量）...")
    api = create_vpc_api(region)

    try:
        subnet_request = volcenginesdkvpc.DescribeSubnetsRequest(subnet_ids=[subnet_id])
        subnet_response = api.describe_subnets(subnet_request)
        subnet_data = to_plain_dict(subnet_response)
        subnet_result = get_result_payload(subnet_data)
        subnets = first_value(subnet_result, "Subnets", "subnets") or []
        if not subnets:
            print("  警告: 未找到子网信息，跳过ACL配置")
            return {"status": "skipped", "reason": "subnet_not_found"}

        acl_id = first_value(subnets[0], "NetworkAclId", "network_acl_id") or ""
        if not acl_id:
            print("  警告: 子网未关联ACL，跳过ACL配置")
            return {"status": "skipped", "reason": "no_acl_associated"}

        print("  ACL ID: %s" % acl_id)

        acl_attr_request = volcenginesdkvpc.DescribeNetworkAclAttributesRequest(network_acl_id=acl_id)
        acl_attr_response = api.describe_network_acl_attributes(acl_attr_request)
        acl_attr_data = to_plain_dict(acl_attr_response)
        acl_attr_result = get_result_payload(acl_attr_data)
        acl_attr = first_value(acl_attr_result, "NetworkAcl", "network_acl") or acl_attr_result

        ingress_entries = first_value(acl_attr, "IngressAclEntries", "ingress_acl_entries") or []
        egress_entries = first_value(acl_attr, "EgressAclEntries", "egress_acl_entries") or []

        has_allow_all_ingress = any(
            str(entry.get("Policy", entry.get("policy", ""))).lower() == "accept"
            and str(entry.get("SourceCidrIp", entry.get("source_cidr_ip", ""))) == "0.0.0.0/0"
            and str(entry.get("Protocol", entry.get("protocol", ""))).lower() == "all"
            for entry in ingress_entries
        )
        has_allow_all_egress = any(
            str(entry.get("Policy", entry.get("policy", ""))).lower() == "accept"
            and str(entry.get("DestinationCidrIp", entry.get("destination_cidr_ip", ""))) == "0.0.0.0/0"
            and str(entry.get("Protocol", entry.get("protocol", ""))).lower() == "all"
            for entry in egress_entries
        )

        if has_allow_all_ingress and has_allow_all_egress:
            print("  入站和出站全通 ACL 规则已存在，跳过")
            return {"acl_id": acl_id, "status": "already_configured"}

        if has_allow_all_ingress:
            print("  入站全通 ACL 规则已存在")
        if has_allow_all_egress:
            print("  出站全通 ACL 规则已存在")

        new_ingress_entries = []
        for entry in ingress_entries:
            entry_id = first_value(entry, "NetworkAclEntryId", "network_acl_entry_id") or ""
            if entry_id:
                new_ingress_entries.append(
                    volcenginesdkvpc.IngressAclEntryForUpdateNetworkAclEntriesInput(
                        network_acl_entry_id=entry_id,
                        policy=first_value(entry, "Policy", "policy") or "",
                        protocol=first_value(entry, "Protocol", "protocol") or "",
                        source_cidr_ip=first_value(entry, "SourceCidrIp", "source_cidr_ip") or "",
                        port=first_value(entry, "Port", "port") or "-1/-1",
                        description=first_value(entry, "Description", "description") or "",
                    )
                )

        if not has_allow_all_ingress:
            new_ingress_entries.append(
                volcenginesdkvpc.IngressAclEntryForUpdateNetworkAclEntriesInput(
                    network_acl_entry_name="allow-all-ingress",
                    policy="accept",
                    protocol="all",
                    source_cidr_ip="0.0.0.0/0",
                    port="-1/-1",
                    description="Allow all inbound traffic for demo site",
                )
            )
            print("  将添加入站全通ACL规则")

        new_egress_entries = []
        for entry in egress_entries:
            entry_id = first_value(entry, "NetworkAclEntryId", "network_acl_entry_id") or ""
            if entry_id:
                new_egress_entries.append(
                    volcenginesdkvpc.EgressAclEntryForUpdateNetworkAclEntriesInput(
                        network_acl_entry_id=entry_id,
                        policy=first_value(entry, "Policy", "policy") or "",
                        protocol=first_value(entry, "Protocol", "protocol") or "",
                        destination_cidr_ip=first_value(entry, "DestinationCidrIp", "destination_cidr_ip") or "",
                        port=first_value(entry, "Port", "port") or "-1/-1",
                        description=first_value(entry, "Description", "description") or "",
                    )
                )

        if not has_allow_all_egress:
            new_egress_entries.append(
                volcenginesdkvpc.EgressAclEntryForUpdateNetworkAclEntriesInput(
                    network_acl_entry_name="allow-all-egress",
                    policy="accept",
                    protocol="all",
                    destination_cidr_ip="0.0.0.0/0",
                    port="-1/-1",
                    description="Allow all outbound traffic for demo site",
                )
            )
            print("  将添加出站全通ACL规则")

        update_request = volcenginesdkvpc.UpdateNetworkAclEntriesRequest(
            network_acl_id=acl_id,
            update_ingress_acl_entries=not has_allow_all_ingress,
            ingress_acl_entries=new_ingress_entries if not has_allow_all_ingress else None,
            update_egress_acl_entries=not has_allow_all_egress,
            egress_acl_entries=new_egress_entries if not has_allow_all_egress else None,
        )
        update_response = api.update_network_acl_entries(update_request)
        print("  ACL规则更新成功")

        return {"acl_id": acl_id, "status": "configured", "response": to_plain_dict(update_response)}
    except ApiException as exc:
        print("  警告: ACL配置失败: %s" % api_exception_message(exc))
        return {"status": "failed", "error": api_exception_message(exc)}


def allocate_and_bind_eip(
    region: str,
    instance_id: str,
    project_name: str = "default",
) -> dict[str, Any]:
    import volcenginesdkvpc

    log_step("4/8", "申请并绑定公网IP...")
    api = create_vpc_api(region)

    try:
        allocate_request = volcenginesdkvpc.AllocateEipAddressRequest(
            billing_type=2,
            project_name=project_name,
        )
        allocate_response = api.allocate_eip_address(allocate_request)
        allocate_data = to_plain_dict(allocate_response)
        allocate_result = get_result_payload(allocate_data)
        allocation_id = first_value(allocate_result, "AllocationId", "allocation_id")
        if not allocation_id:
            raise ValueError("AllocateEipAddress 响应中没有 AllocationId: %s" % allocate_data)

        print("  公网IP分配ID: %s" % allocation_id)

        print("  等待公网IP可用...")
        eip_address = wait_for_eip_available(api, allocation_id, project_name)
        print("  公网IP: %s" % eip_address)

        print("  绑定公网IP到实例...")
        associate_request = volcenginesdkvpc.AssociateEipAddressRequest(
            allocation_id=allocation_id,
            instance_id=instance_id,
            instance_type="EcsInstance",
        )
        api.associate_eip_address(associate_request)

        print("  等待公网IP绑定完成...")
        bound_ip = wait_for_eip_bound(api, allocation_id, instance_id, project_name)
        print("  公网IP绑定成功: %s" % bound_ip)

        return {
            "allocation_id": allocation_id,
            "eip_address": bound_ip,
            "instance_id": instance_id,
        }
    except ApiException as exc:
        msg = api_exception_message(exc)
        if "QuotaExceeded.Eip" in msg:
            print("  警告: EIP配额已满，尝试查找现有可用EIP...")
            try:
                describe_request = volcenginesdkvpc.DescribeEipAddressesRequest(
                    page_size=100,
                    project_name=project_name,
                )
                describe_response = api.describe_eip_addresses(describe_request)
                describe_data = to_plain_dict(describe_response)
                describe_result = get_result_payload(describe_data)
                eip_addresses = first_value(describe_result, "EipAddresses", "eip_addresses") or []
                available_eip = None
                for item in eip_addresses:
                    status = str(first_value(item, "Status", "status") or "").lower()
                    attached_id = str(first_value(item, "InstanceId", "instance_id") or "").strip()
                    alloc_id = str(first_value(item, "AllocationId", "allocation_id") or "").strip()
                    eip_addr = str(first_value(item, "EipAddress", "eip_address") or "").strip()
                    if status == "available" and alloc_id and eip_addr and not attached_id:
                        available_eip = {
                            "allocation_id": alloc_id,
                            "eip_address": eip_addr,
                        }
                        break
                if available_eip:
                    allocation_id = available_eip["allocation_id"]
                    eip_address = available_eip["eip_address"]
                    print("  找到可用EIP: %s (ID: %s)" % (eip_address, allocation_id))
                    print("  绑定公网IP到实例...")
                    associate_request = volcenginesdkvpc.AssociateEipAddressRequest(
                        allocation_id=allocation_id,
                        instance_id=instance_id,
                        instance_type="EcsInstance",
                    )
                    api.associate_eip_address(associate_request)
                    print("  等待公网IP绑定完成...")
                    bound_ip = wait_for_eip_bound(api, allocation_id, instance_id, project_name)
                    print("  公网IP绑定成功: %s" % bound_ip)
                    return {
                        "allocation_id": allocation_id,
                        "eip_address": bound_ip,
                        "instance_id": instance_id,
                    }
                else:
                    raise RuntimeError("EIP配额已满，且没有找到可用的现有EIP") from exc
            except ApiException as exc2:
                raise RuntimeError("公网IP操作失败: %s" % api_exception_message(exc2)) from exc2
        else:
            raise RuntimeError("公网IP操作失败: %s" % msg) from exc


def wait_for_eip_available(api: Any, allocation_id: str, project_name: str = "default") -> str:
    import volcenginesdkvpc

    timeout_seconds = 120
    poll_seconds = 3
    deadline = time.time() + timeout_seconds
    while time.time() <= deadline:
        try:
            request = volcenginesdkvpc.DescribeEipAddressesRequest(
                allocation_ids=[allocation_id],
                project_name=project_name,
            )
            response = api.describe_eip_addresses(request)
            response_data = to_plain_dict(response)
            result = get_result_payload(response_data)
            eip_addresses = first_value(result, "EipAddresses", "eip_addresses") or []
            for item in eip_addresses:
                item_allocation_id = first_value(item, "AllocationId", "allocation_id") or ""
                if item_allocation_id != allocation_id:
                    continue
                status = str(first_value(item, "Status", "status") or "").lower()
                eip_addr = first_value(item, "EipAddress", "eip_address") or ""
                if status == "available" and eip_addr:
                    return str(eip_addr)
        except ApiException:
            pass
        time.sleep(poll_seconds)
    raise TimeoutError("等待公网IP可用超时: allocation_id=%s" % allocation_id)


def wait_for_eip_bound(api: Any, allocation_id: str, instance_id: str, project_name: str = "default") -> str:
    import volcenginesdkvpc

    timeout_seconds = 60
    poll_seconds = 2
    deadline = time.time() + timeout_seconds
    while time.time() <= deadline:
        try:
            request = volcenginesdkvpc.DescribeEipAddressesRequest(
                allocation_ids=[allocation_id],
                project_name=project_name,
            )
            response = api.describe_eip_addresses(request)
            response_data = to_plain_dict(response)
            result = get_result_payload(response_data)
            eip_addresses = first_value(result, "EipAddresses", "eip_addresses") or []
            for item in eip_addresses:
                item_allocation_id = first_value(item, "AllocationId", "allocation_id") or ""
                if item_allocation_id != allocation_id:
                    continue
                attached_instance_id = first_value(item, "InstanceId", "instance_id") or ""
                eip_addr = first_value(item, "EipAddress", "eip_address") or ""
                if attached_instance_id == instance_id and eip_addr:
                    return str(eip_addr)
        except ApiException:
            pass
        time.sleep(poll_seconds)
    raise TimeoutError(
        "等待公网IP绑定超时: allocation_id=%s instance_id=%s" % (allocation_id, instance_id)
    )


def is_transient_fwcenter_error(message: str) -> bool:
    markers = (
        "InternalServiceError",
        "ServiceUnavailable",
        "Throttling",
        "RequestLimitExceeded",
        "InternalError",
    )
    return any(marker in message for marker in markers)


def call_with_retries(
    label: str,
    fn: Any,
    max_attempts: int = 3,
    retry_seconds: float = 2.0,
) -> Any:
    last_exc: ApiException | None = None
    for attempt in range(1, max_attempts + 1):
        try:
            return fn()
        except ApiException as exc:
            last_exc = exc
            msg = api_exception_message(exc)
            if attempt >= max_attempts or not is_transient_fwcenter_error(msg):
                raise
            print("  警告: %s 临时失败 (第 %d/%d 次): %s" % (label, attempt, max_attempts, msg))
            time.sleep(retry_seconds)
    if last_exc is not None:
        raise last_exc
    raise RuntimeError("%s 调用失败" % label)


def extract_control_policies(response_data: Any) -> list[dict[str, Any]]:
    payload = get_result_payload(to_plain_dict(response_data))
    if not isinstance(payload, dict):
        return []
    policies = first_value(payload, "Data", "data", "Rules", "rules") or []
    return [item for item in policies if isinstance(item, dict)]


def find_nested_string_value(data: Any, *keys: str) -> str:
    normalized_keys = {key.lower() for key in keys}
    if isinstance(data, dict):
        for key, value in data.items():
            if str(key).lower() in normalized_keys and value:
                return str(value)
            nested = find_nested_string_value(value, *keys)
            if nested:
                return nested
    elif isinstance(data, list):
        for item in data:
            nested = find_nested_string_value(item, *keys)
            if nested:
                return nested
    return ""


def build_describe_control_policy_request(
    volcenginesdkfwcenter: Any,
    direction: str,
    internet_firewall_id: str = "",
    rule_id: str = "",
    page_size: int = 100,
    page_number: int = 1,
) -> Any:
    request_kwargs: dict[str, Any] = {
        "direction": direction,
    }
    if rule_id:
        request_kwargs["rule_id"] = rule_id
    else:
        request_kwargs["page_size"] = page_size
        request_kwargs["page_number"] = page_number
    if internet_firewall_id:
        request_kwargs["internet_firewall_id"] = internet_firewall_id
    return volcenginesdkfwcenter.DescribeControlPolicyRequest(**request_kwargs)


def describe_control_policy_by_rule_id(
    api: Any,
    direction: str,
    rule_id: str,
    internet_firewall_id: str = "",
) -> dict[str, Any] | None:
    import volcenginesdkfwcenter

    def fetch_rule() -> dict[str, Any] | None:
        request = build_describe_control_policy_request(
            volcenginesdkfwcenter,
            direction=direction,
            internet_firewall_id=internet_firewall_id,
            rule_id=rule_id,
        )
        response = api.describe_control_policy(request)
        policies = extract_control_policies(response)
        for rule in policies:
            matched_rule_id = str(first_value(rule, "RuleId", "rule_id") or "")
            if matched_rule_id == rule_id:
                return rule
        return policies[0] if policies else None

    return call_with_retries("DescribeControlPolicy(rule_id=%s)" % rule_id, fetch_rule)


def extract_rule_id_from_policy_response(response_data: Any) -> str:
    payload = to_plain_dict(response_data)
    if isinstance(payload, dict):
        direct = first_value(payload, "RuleId", "rule_id")
        if direct:
            return str(direct)
    nested = get_result_payload(payload)
    if isinstance(nested, dict):
        value = first_value(nested, "RuleId", "rule_id")
        if value:
            return str(value)
    return find_nested_string_value(payload, "RuleId", "rule_id")


def is_control_policy_effective(rule: dict[str, Any] | None) -> bool:
    return is_control_policy_deployed(rule)


def is_control_policy_deployed(rule: dict[str, Any] | None) -> bool:
    """策略开关已开且云侧已下发完成。"""
    if not rule:
        return False
    switch_on = first_value(rule, "Status", "status")
    if switch_on is not True:
        return False
    if first_value(rule, "IsEffected", "is_effected") is True:
        return True
    effect_status = first_value(rule, "EffectStatus", "effect_status")
    return effect_status in (3, "3")


def format_control_policy_deploy_status(rule: dict[str, Any] | None) -> str:
    if not rule:
        return "rule_not_found"
    return "status=%s is_effected=%s effect_status=%s action=%s" % (
        first_value(rule, "Status", "status"),
        first_value(rule, "IsEffected", "is_effected"),
        first_value(rule, "EffectStatus", "effect_status"),
        first_value(rule, "Action", "action"),
    )


def wait_for_control_policy_deployed(
    api: Any,
    direction: str,
    rule_id: str,
    internet_firewall_id: str = "",
    timeout_seconds: int | None = None,
    poll_seconds: int = 5,
) -> dict[str, Any] | None:
    if not rule_id:
        return None
    if timeout_seconds is None:
        timeout_seconds = int(os.getenv("FIREWALL_POLICY_DEPLOY_TIMEOUT_SECONDS", "300"))
    deadline = time.time() + timeout_seconds
    last_rule = None
    print("  策略开关已开启，等待云侧下发 %s 方向规则 (rule_id=%s)..." % (direction, rule_id))
    time.sleep(min(poll_seconds, 3))
    while time.time() <= deadline:
        try:
            last_rule = describe_control_policy_by_rule_id(
                api,
                direction=direction,
                rule_id=rule_id,
                internet_firewall_id=internet_firewall_id,
            )
            if is_control_policy_deployed(last_rule):
                print("  ✓ %s 方向策略云侧下发完成 (%s)" % (direction, format_control_policy_deploy_status(last_rule)))
                return last_rule
            print(
                "  云侧下发中: direction=%s rule_id=%s %s"
                % (direction, rule_id, format_control_policy_deploy_status(last_rule))
            )
        except ApiException as exc:
            print("  警告: 查询云侧下发进度失败: %s" % api_exception_message(exc))
        time.sleep(poll_seconds)
    print(
        "  警告: 等待 %s 方向策略云侧下发超时 (%ds): rule_id=%s last=%s"
        % (direction, timeout_seconds, rule_id, format_control_policy_deploy_status(last_rule))
    )
    return last_rule


def wait_for_control_policy_effective(
    api: Any,
    direction: str,
    rule_id: str,
    internet_firewall_id: str = "",
    timeout_seconds: int = 180,
    poll_seconds: int = 5,
) -> dict[str, Any] | None:
    return wait_for_control_policy_deployed(
        api,
        direction=direction,
        rule_id=rule_id,
        internet_firewall_id=internet_firewall_id,
        timeout_seconds=timeout_seconds,
        poll_seconds=poll_seconds,
    )


def describe_control_policies(
    api: Any,
    direction: str,
    internet_firewall_id: str = "",
    page_size: int = 100,
    max_pages: int = 20,
) -> list[dict[str, Any]]:
    import volcenginesdkfwcenter

    def fetch_policies() -> list[dict[str, Any]]:
        policies: list[dict[str, Any]] = []
        for page_number in range(1, max_pages + 1):
            request = build_describe_control_policy_request(
                volcenginesdkfwcenter,
                direction=direction,
                internet_firewall_id=internet_firewall_id,
                page_size=page_size,
                page_number=page_number,
            )
            response = api.describe_control_policy(request)
            page_policies = extract_control_policies(response)
            policies.extend(page_policies)
            payload = get_result_payload(to_plain_dict(response))
            total_count = int(first_value(payload, "TotalCount", "total_count") or 0)
            if len(policies) >= total_count or len(page_policies) < page_size:
                break
        return policies

    return call_with_retries("DescribeControlPolicy(%s)" % direction, fetch_policies)


def extract_firewall_assets(response_data: Any) -> list[dict[str, Any]]:
    payload = get_result_payload(to_plain_dict(response_data))
    if not isinstance(payload, dict):
        return []
    assets = first_value(payload, "Data", "data") or []
    return [item for item in assets if isinstance(item, dict)]


def build_asset_list_request(
    volcenginesdkfwcenter: Any,
    region: str = "",
    internet_firewall_id: str = "",
    current_page: int = 1,
    page_size: int = 100,
) -> Any:
    request_kwargs: dict[str, Any] = {
        "current_page": current_page,
        "page_size": page_size,
    }
    if internet_firewall_id:
        request_kwargs["internet_firewall_id"] = internet_firewall_id
    if region:
        request_kwargs["region_code"] = [region]
    return volcenginesdkfwcenter.AssetListRequest(**request_kwargs)


def describe_firewall_assets(
    api: Any,
    region: str = "",
    internet_firewall_id: str = "",
    page_size: int = 100,
    max_pages: int = 20,
) -> list[dict[str, Any]]:
    import volcenginesdkfwcenter

    def fetch_assets(filter_region: str) -> list[dict[str, Any]]:
        assets: list[dict[str, Any]] = []
        for current_page in range(1, max_pages + 1):
            request = build_asset_list_request(
                volcenginesdkfwcenter,
                region=filter_region,
                internet_firewall_id=internet_firewall_id,
                current_page=current_page,
                page_size=page_size,
            )
            response = api.asset_list(request)
            page_assets = extract_firewall_assets(response)
            assets.extend(page_assets)
            payload = get_result_payload(to_plain_dict(response))
            total_count = int(first_value(payload, "TotalCount", "total_count") or 0)
            if len(assets) >= total_count or len(page_assets) < page_size:
                break
        if filter_region:
            assets = [
                item
                for item in assets
                if str(first_value(item, "Region", "region") or "") == filter_region
            ]
        return assets

    try:
        return call_with_retries("AssetList", lambda: fetch_assets(region))
    except ApiException as exc:
        if not region:
            raise
        print("  警告: 带 region 的 AssetList 失败，尝试不带 region 过滤: %s" % api_exception_message(exc))
        return call_with_retries("AssetList", lambda: fetch_assets(""))


def probe_internet_firewall_via_asset_list(api: Any, region: str) -> dict[str, Any]:
    import volcenginesdkfwcenter

    try:
        request = build_asset_list_request(
            volcenginesdkfwcenter,
            region=region,
            current_page=1,
            page_size=10,
        )
        response = api.asset_list(request)
        response_data = to_plain_dict(response)
        discovered_id = find_nested_string_value(response_data, "InternetFirewallId", "internet_firewall_id")
        assets = extract_firewall_assets(response)
        payload = get_result_payload(response_data)
        total_count = int(first_value(payload, "TotalCount", "total_count") or 0)
        region_assets = [
            item
            for item in assets
            if str(first_value(item, "Region", "region") or "") == region
        ]
        return {
            "available": True,
            "internet_firewall_id": discovered_id,
            "source": "asset_list",
            "region": region,
            "asset_count": total_count,
            "region_asset_count": len(region_assets),
            "sample_assets": assets[:3],
        }
    except ApiException as exc:
        return {
            "available": False,
            "internet_firewall_id": "",
            "source": "asset_list",
            "region": region,
            "error": api_exception_message(exc),
        }


def probe_internet_firewall_via_control_policy(api: Any, region: str) -> dict[str, Any]:
    import volcenginesdkfwcenter

    try:
        request = build_describe_control_policy_request(
            volcenginesdkfwcenter,
            direction="in",
            page_size=1,
            page_number=1,
        )
        response = api.describe_control_policy(request)
        response_data = to_plain_dict(response)
        discovered_id = find_nested_string_value(response_data, "InternetFirewallId", "internet_firewall_id")
        policies = extract_control_policies(response)
        total_count = int(first_value(get_result_payload(response_data), "TotalCount", "total_count") or 0)
        return {
            "available": True,
            "internet_firewall_id": discovered_id,
            "source": "describe_control_policy",
            "region": region,
            "policy_count": total_count,
            "sample_policy_count": len(policies),
        }
    except ApiException as exc:
        return {
            "available": False,
            "internet_firewall_id": "",
            "source": "describe_control_policy",
            "region": region,
            "error": api_exception_message(exc),
        }


def find_firewall_asset_for_ip(assets: list[dict[str, Any]], eip_address: str) -> dict[str, Any] | None:
    for asset in assets:
        ip = str(first_value(asset, "Ip", "ip") or "")
        if ip == eip_address:
            return asset
    return None


def find_firewall_asset_for_instance(
    assets: list[dict[str, Any]],
    instance_id: str,
) -> dict[str, Any] | None:
    for asset in assets:
        asset_instance = str(
            first_value(
                asset,
                "InstanceId",
                "instance_id",
                "ResourceId",
                "resource_id",
                "AssetId",
                "asset_id",
            )
            or ""
        )
        if asset_instance == instance_id:
            return asset
    return None


def find_firewall_asset(
    assets: list[dict[str, Any]],
    eip_address: str = "",
    instance_id: str = "",
) -> dict[str, Any] | None:
    if eip_address:
        matched = find_firewall_asset_for_ip(assets, eip_address)
        if matched:
            return matched
    if instance_id:
        return find_firewall_asset_for_instance(assets, instance_id)
    return None


def extract_instance_network_ips(instance_info: dict[str, Any]) -> list[str]:
    ips: list[str] = []
    network_interfaces = first_value(instance_info, "NetworkInterfaces", "network_interfaces") or []
    for nic in network_interfaces:
        primary_ip = str(first_value(nic, "PrimaryIpAddress", "primary_ip_address") or "").strip()
        if primary_ip:
            ips.append(primary_ip)
        private_ip_addresses = first_value(nic, "PrivateIpAddresses", "private_ip_addresses") or []
        for addr in private_ip_addresses:
            if isinstance(addr, dict):
                ip = str(first_value(addr, "PrivateIpAddress", "private_ip_address") or "").strip()
            else:
                ip = str(addr).strip()
            if ip:
                ips.append(ip)
    deduped: list[str] = []
    seen: set[str] = set()
    for ip in ips:
        if ip not in seen:
            seen.add(ip)
            deduped.append(ip)
    return deduped


def prefer_volcengine_firewall_ip(network_ips: list[str]) -> str:
    for ip in network_ips:
        if ip.startswith("101.96."):
            return ip
    for ip in network_ips:
        if not ip.startswith("192.168."):
            return ip
    return network_ips[0] if network_ips else ""


def wait_for_firewall_asset(
    api: Any,
    eip_address: str,
    region: str,
    internet_firewall_id: str = "",
    instance_id: str = "",
    timeout_seconds: int = 60,
    poll_seconds: int = 5,
) -> dict[str, Any] | None:
    deadline = time.time() + timeout_seconds
    consecutive_errors = 0
    while time.time() <= deadline:
        try:
            assets = describe_firewall_assets(
                api,
                region=region,
                internet_firewall_id=internet_firewall_id,
                page_size=100,
                max_pages=2,
            )
            consecutive_errors = 0
        except ApiException as exc:
            consecutive_errors += 1
            print("  警告: 查询防火墙资产列表失败: %s" % api_exception_message(exc))
            if consecutive_errors >= 3:
                print("  提示: AssetList 连续失败，跳过 EIP 资产等待，继续配置控制策略")
                return None
            time.sleep(poll_seconds)
            continue

        matched = find_firewall_asset(assets, eip_address=eip_address, instance_id=instance_id)
        if matched:
            return matched
        wait_label = eip_address or instance_id or "资产"
        print("  等待 %s 出现在互联网防火墙资产列表..." % wait_label)
        time.sleep(poll_seconds)
    return None


def resolve_internet_firewall_id(api: Any, region: str) -> dict[str, Any]:
    configured_id = os.getenv("INTERNET_FIREWALL_ID", "").strip()
    if configured_id:
        return {
            "available": True,
            "internet_firewall_id": configured_id,
            "source": "env",
            "region": region,
        }

    asset_probe = probe_internet_firewall_via_asset_list(api, region)
    if asset_probe.get("available"):
        return asset_probe

    policy_probe = probe_internet_firewall_via_control_policy(api, region)
    if policy_probe.get("available"):
        return policy_probe

    errors = []
    if asset_probe.get("error"):
        errors.append("AssetList: %s" % asset_probe["error"])
    if policy_probe.get("error"):
        errors.append("DescribeControlPolicy: %s" % policy_probe["error"])
    return {
        "available": False,
        "internet_firewall_id": "",
        "source": "asset_list+describe_control_policy",
        "region": region,
        "error": "; ".join(errors) if errors else "未检测到互联网防火墙",
        "probes": {
            "asset_list": asset_probe,
            "describe_control_policy": policy_probe,
        },
    }


def control_policy_matches_eip(rule: dict[str, Any], direction: str, eip_address: str) -> bool:
    rule_dir = str(first_value(rule, "Direction", "direction") or "")
    if rule_dir and rule_dir != direction:
        return False
    if direction == "in":
        target = str(first_value(rule, "Destination", "destination") or "")
    else:
        target = str(first_value(rule, "Source", "source") or "")
    return eip_address in target


def find_control_policy_rule_for_eip(
    policies: list[dict[str, Any]],
    direction: str,
    eip_address: str,
) -> dict[str, Any] | None:
    for rule in policies:
        if control_policy_matches_eip(rule, direction, eip_address):
            return rule
    return None


def normalize_firewall_ip(ip_address: str) -> str:
    value = str(ip_address or "").strip()
    if "/" in value:
        value = value.split("/", 1)[0]
    return value


def build_control_policy_endpoints(direction: str, target_ip: str) -> dict[str, str]:
    ip = normalize_firewall_ip(target_ip)
    if direction == "in":
        return {
            "source": "0.0.0.0/0",
            "source_type": "net",
            "destination": ip,
            "destination_type": "net",
        }
    return {
        "source": ip,
        "source_type": "net",
        "destination": "0.0.0.0/0",
        "destination_type": "net",
    }


def build_add_control_policy_request(
    volcenginesdkfwcenter: Any,
    direction: str,
    target_ip: str,
    internet_firewall_id: str = "",
    prio: int = 1,
) -> Any:
    endpoints = build_control_policy_endpoints(direction, target_ip)
    request_kwargs: dict[str, Any] = {
        "action": "accept",
        "destination": endpoints["destination"],
        "destination_type": endpoints["destination_type"],
        "direction": direction,
        "prio": prio,
        "proto": "ANY",
        "source": endpoints["source"],
        "source_type": endpoints["source_type"],
    }
    if internet_firewall_id:
        request_kwargs["internet_firewall_id"] = internet_firewall_id
    return volcenginesdkfwcenter.AddControlPolicyRequest(**request_kwargs)


def build_modify_control_policy_request(
    volcenginesdkfwcenter: Any,
    rule_id: str,
    direction: str,
    target_ip: str,
    internet_firewall_id: str = "",
) -> Any:
    endpoints = build_control_policy_endpoints(direction, target_ip)
    request_kwargs: dict[str, Any] = {
        "rule_id": rule_id,
        "action": "accept",
        "destination": endpoints["destination"],
        "destination_type": endpoints["destination_type"],
        "direction": direction,
        "proto": "ANY",
        "source": endpoints["source"],
        "source_type": endpoints["source_type"],
    }
    if internet_firewall_id:
        request_kwargs["internet_firewall_id"] = internet_firewall_id
    return volcenginesdkfwcenter.ModifyControlPolicyRequest(**request_kwargs)


def enable_control_policy_switch(
    api: Any,
    volcenginesdkfwcenter: Any,
    direction: str,
    rule_id: str,
    internet_firewall_id: str = "",
    status: bool = True,
) -> dict[str, Any]:
    if not rule_id:
        raise ValueError("启用防火墙策略开关需要 rule_id")

    request_kwargs: dict[str, Any] = {
        "direction": direction,
        "rule_ids": [rule_id],
        "status": status,
    }
    if internet_firewall_id:
        request_kwargs["internet_firewall_id"] = internet_firewall_id

    def update_switch() -> Any:
        request = volcenginesdkfwcenter.UpdateControlPolicySwitchRequest(**request_kwargs)
        return api.update_control_policy_switch(request)

    response = call_with_retries(
        "UpdateControlPolicySwitch(%s)" % direction,
        update_switch,
    )
    return to_plain_dict(response)


def upsert_control_policy_for_direction(
    api: Any,
    volcenginesdkfwcenter: Any,
    direction: str,
    target_ip: str,
    internet_firewall_id: str = "",
) -> dict[str, Any]:
    normalized_ip = normalize_firewall_ip(target_ip)
    existing_rule = find_control_policy_rule_for_eip(
        describe_control_policies(api, direction, internet_firewall_id=internet_firewall_id),
        direction,
        normalized_ip,
    )
    if existing_rule:
        rule_id = str(first_value(existing_rule, "RuleId", "rule_id") or "")
        if not rule_id:
            raise ValueError("已存在匹配策略但未返回 RuleId: %s" % existing_rule)
        response = api.modify_control_policy(
            build_modify_control_policy_request(
                volcenginesdkfwcenter,
                rule_id,
                direction,
                normalized_ip,
                internet_firewall_id=internet_firewall_id,
            )
        )
        action = "modify"
    else:
        try:
            response = api.add_control_policy(
                build_add_control_policy_request(
                    volcenginesdkfwcenter,
                    direction,
                    normalized_ip,
                    internet_firewall_id=internet_firewall_id,
                )
            )
            action = "add"
            rule_id = extract_rule_id_from_policy_response(response)
        except ApiException as exc:
            msg = api_exception_message(exc)
            if "already exists" not in msg and "Duplicate" not in msg and "RuleAlreadyExist" not in msg:
                raise
            existing_rule = find_control_policy_rule_for_eip(
                describe_control_policies(api, direction, internet_firewall_id=internet_firewall_id),
                direction,
                normalized_ip,
            )
            if not existing_rule:
                raise RuntimeError("策略已存在但 DescribeControlPolicy 未找到匹配规则: %s" % msg) from exc
            rule_id = str(first_value(existing_rule, "RuleId", "rule_id") or "")
            response = api.modify_control_policy(
                build_modify_control_policy_request(
                    volcenginesdkfwcenter,
                    rule_id,
                    direction,
                    normalized_ip,
                    internet_firewall_id=internet_firewall_id,
                )
            )
            action = "modify"

    if not rule_id:
        rule_id = extract_rule_id_from_policy_response(response)

    switch_response = enable_control_policy_switch(
        api,
        volcenginesdkfwcenter,
        direction=direction,
        rule_id=rule_id,
        internet_firewall_id=internet_firewall_id,
        status=True,
    )
    print("  已开启 %s 方向策略开关: rule_id=%s" % (direction, rule_id))

    deployed_rule = wait_for_control_policy_deployed(
        api,
        direction=direction,
        rule_id=rule_id,
        internet_firewall_id=internet_firewall_id,
    )
    return {
        "direction": direction,
        "action": action,
        "rule_id": rule_id,
        "target_ip": normalized_ip,
        "response": to_plain_dict(response),
        "switch_response": switch_response,
        "switch_enabled": True,
        "deployed": is_control_policy_deployed(deployed_rule),
        "effective": is_control_policy_deployed(deployed_rule),
        "deployed_rule": deployed_rule,
        "effective_rule": deployed_rule,
    }


def resolve_firewall_policy_target_ip(
    eip_address: str,
    private_ip: str = "",
    network_ips: list[str] | None = None,
    firewall_asset: dict[str, Any] | None = None,
) -> tuple[str, str]:
    configured = os.getenv("FIREWALL_POLICY_TARGET_IP", "").strip()
    if configured:
        return normalize_firewall_ip(configured), "env"

    if firewall_asset:
        asset_ip = str(first_value(firewall_asset, "Ip", "ip") or "").strip()
        if asset_ip:
            return normalize_firewall_ip(asset_ip), "asset_list"

    # 互联网防火墙策略应对准公网 EIP（广州账号常见 101.96.x），而非 192.168.x 私网地址
    if eip_address:
        return normalize_firewall_ip(eip_address), "eip"

    ips = list(network_ips or [])
    if private_ip and private_ip not in ips:
        ips.insert(0, private_ip)
    preferred = prefer_volcengine_firewall_ip(ips)
    if preferred:
        return normalize_firewall_ip(preferred), "instance_network"

    return normalize_firewall_ip(eip_address), "fallback"


def configure_firewall_policy(
    region: str,
    eip_address: str,
    private_ip: str = "",
    instance_id: str = "",
    network_ips: list[str] | None = None,
) -> dict[str, Any]:
    import volcenginesdkfwcenter

    log_step("5/8", "配置互联网防火墙策略...")
    api = create_fwcenter_api(region)

    firewall_info = resolve_internet_firewall_id(api, region)
    if not firewall_info.get("available"):
        print("  警告: 未检测到可用的互联网防火墙，跳过策略配置")
        if firewall_info.get("error"):
            print("  探测失败: %s" % firewall_info["error"])
        print("  提示: 若账号启用了互联网防火墙但探测失败，可手动设置 INTERNET_FIREWALL_ID")
        return {"status": "skipped", "reason": "firewall_unavailable", "probe": firewall_info}

    firewall_id = str(firewall_info.get("internet_firewall_id") or "")
    if firewall_id:
        print("  防火墙ID: %s (来源: %s)" % (firewall_id, firewall_info.get("source", "")))
    elif firewall_info.get("source") == "asset_list":
        print(
            "  已通过 AssetList 探测到互联网防火墙 (区域 %s 资产数: %s, 总资产数: %s)"
            % (
                region,
                firewall_info.get("region_asset_count", "unknown"),
                firewall_info.get("asset_count", "unknown"),
            )
        )
        print("  当前账号使用默认互联网防火墙实例，无需手动设置 INTERNET_FIREWALL_ID")
    else:
        print(
            "  已通过 DescribeControlPolicy 探测到互联网防火墙 (现有策略数: %s)"
            % firewall_info.get("policy_count", "unknown")
        )
        print("  当前账号使用默认互联网防火墙实例，无需手动设置 INTERNET_FIREWALL_ID")

    try:
        firewall_asset = wait_for_firewall_asset(
            api,
            eip_address,
            region,
            internet_firewall_id=firewall_id,
            instance_id=instance_id,
        )
    except ApiException as exc:
        print("  警告: 等待防火墙资产失败，跳过: %s" % api_exception_message(exc))
        firewall_asset = None

    if firewall_asset:
        asset_ip = str(first_value(firewall_asset, "Ip", "ip") or "")
        print(
            "  资产已在防火墙列表中 (ip=%s, name=%s, enable=%s)"
            % (
                asset_ip or eip_address,
                first_value(firewall_asset, "Name", "name") or "",
                first_value(firewall_asset, "Enable", "enable"),
            )
        )
    else:
        print("  提示: 实例/EIP 暂未出现在 AssetList 中，仍将尝试直接配置控制策略")

    policy_target_ip, policy_target_source = resolve_firewall_policy_target_ip(
        eip_address,
        private_ip=private_ip,
        network_ips=network_ips,
        firewall_asset=firewall_asset,
    )
    print(
        "  防火墙策略目标 IP: %s (来源: %s, in 方向 destination / out 方向 source)"
        % (policy_target_ip, policy_target_source)
    )
    if private_ip and private_ip != policy_target_ip:
        print("  说明: 实例 PrimaryIpAddress=%s，防火墙策略不对 192.168.x 私网地址生效" % private_ip)

    rules_configured = []
    for direction in ("in", "out"):
        try:
            result = upsert_control_policy_for_direction(
                api,
                volcenginesdkfwcenter,
                direction,
                policy_target_ip,
                internet_firewall_id=firewall_id,
            )
            rules_configured.append(result)
            action_label = "修改" if result.get("action") == "modify" else "添加"
            effective_label = "云侧已下发" if result.get("deployed") else "云侧下发未完成"
            print(
                "  已%s %s 方向全通策略 (rule_id=%s, %s)"
                % (action_label, direction, result.get("rule_id", ""), effective_label)
            )
        except ApiException as exc:
            print("  警告: 配置 %s 方向策略失败: %s" % (direction, api_exception_message(exc)))
        except Exception as exc:
            print("  警告: 配置 %s 方向策略失败: %s" % (direction, exc))

    ping_result = ping_public_ip(eip_address)
    if ping_result.get("success"):
        print("  ✓ ping %s 成功" % eip_address)
    else:
        print("  提示: ping %s 未通（可能禁 ICMP），将继续 curl HTTP 测试" % eip_address)

    return {
        "status": "configured" if rules_configured else "failed",
        "firewall_id": firewall_id or None,
        "probe": firewall_info,
        "firewall_asset": firewall_asset,
        "policy_target_ip": policy_target_ip,
        "policy_target_source": policy_target_source,
        "ping": ping_result,
        "rules": rules_configured,
    }


def describe_cloud_assistant_status(api: Any, instance_id: str) -> dict[str, Any] | None:
    import volcenginesdkecs

    request = volcenginesdkecs.DescribeCloudAssistantStatusRequest(
        instance_ids=[instance_id],
    )
    response = api.describe_cloud_assistant_status(request)
    data = to_plain_dict(response)
    result = get_result_payload(data)
    instances = result.get("Instances") or result.get("instances") or []
    for item in instances:
        item_id = item.get("InstanceId") or item.get("instance_id")
        if item_id == instance_id:
            return item
    return None


def cloud_assistant_status_value(status: dict[str, Any] | None) -> str:
    if not status:
        return ""
    return str(status.get("Status") or status.get("status") or "")


def is_cloud_assistant_ready(status: dict[str, Any] | None) -> bool:
    return cloud_assistant_status_value(status).lower() in {
        "online",
        "running",
        "available",
        "normal",
    }


def wait_for_cloud_assistant_ready(
    api: Any,
    instance_id: str,
    timeout_seconds: int = 300,
    poll_seconds: int = 10,
) -> dict[str, Any]:
    deadline = time.time() + timeout_seconds
    last_status = None
    while time.time() <= deadline:
        status = describe_cloud_assistant_status(api, instance_id)
        last_status = status
        status_value = cloud_assistant_status_value(status)
        if is_cloud_assistant_ready(status):
            if status_value.lower() != "online":
                print("  云助手状态: %s (视为可用，继续 RunCommand)" % status_value)
            else:
                print("  云助手状态: Online")
            return status or {}
        print("  云助手状态: %s (等待 Online/Running)" % (status_value or "unknown"))
        time.sleep(poll_seconds)
    raise TimeoutError(
        "等待云助手就绪超时: instance_id=%s last_status=%s"
        % (instance_id, cloud_assistant_status_value(last_status) or "unknown")
    )


def install_python_and_start_server(
    region: str,
    instance_id: str,
    port: int = 80,
) -> dict[str, Any]:
    import volcenginesdkecs

    log_step("6/8", "安装 Python 3.12 并启动 HTTP 服务...")
    api = create_ecs_api(region)

    print("  等待云助手就绪...")
    wait_for_cloud_assistant_ready(api, instance_id)
    print("  云助手已就绪")

    install_script = """#!/bin/bash
set -e

echo "=== 检查Python版本 ==="
if command -v python3.12 &>/dev/null; then
    echo "Python 3.12 已安装"
    python3.12 --version
elif command -v python3 &>/dev/null; then
    PY3_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
    echo "当前 Python3 版本: $PY3_VERSION"
    if [[ "$PY3_VERSION" == 3.12* ]] || [[ "$PY3_VERSION" =~ ^3\\.(1[2-9]|[2-9][0-9]) ]]; then
        echo "Python 版本满足要求 (>=3.12)"
        if ! command -v python3.12 &>/dev/null; then
            ln -sf $(which python3) /usr/local/bin/python3.12
        fi
    else
        echo "正在安装 Python 3.12..."
        if command -v apt-get &>/dev/null; then
            export DEBIAN_FRONTEND=noninteractive
            apt-get update -qq
            apt-get install -y -qq software-properties-common
            add-apt-repository -y ppa:deadsnakes/ppa || true
            apt-get update -qq
            apt-get install -y -qq python3.12 python3.12-venv || {
                echo "PPA安装失败，尝试使用系统包管理器..."
                apt-get install -y -qq python3 python3-pip
                ln -sf $(which python3) /usr/local/bin/python3.12
            }
        elif command -v yum &>/dev/null; then
            yum install -y python3 python3-pip || true
            ln -sf $(which python3) /usr/local/bin/python3.12
        else
            echo "无法确定包管理器，使用现有 python3"
            ln -sf $(which python3) /usr/local/bin/python3.12
        fi
    fi
else
    echo "未找到 Python3，尝试安装..."
    if command -v apt-get &>/dev/null; then
        export DEBIAN_FRONTEND=noninteractive
        apt-get update -qq
        apt-get install -y -qq python3 python3-pip
    elif command -v yum &>/dev/null; then
        yum install -y python3 python3-pip
    fi
    ln -sf $(which python3) /usr/local/bin/python3.12
fi

echo "=== 创建网页内容 ==="
mkdir -p /var/www/demo
cat > /var/www/demo/index.html << 'HTMLEOF'
<!DOCTYPE html>
<html>
<head>
    <title>Public Site Demo</title>
    <meta charset="utf-8">
</head>
<body>
    <h1>Hello from Volcengine ECS!</h1>
    <p>This is a demo public site deployed automatically.</p>
    <p>Instance: %s</p>
</body>
</html>
HTMLEOF

echo "=== 启动 HTTP 服务器 ==="
cd /var/www/demo
nohup python3.12 -m http.server %d > /var/log/http_server.log 2>&1 &
HTTP_PID=$!
echo "HTTP server PID: $HTTP_PID"

sleep 2
if kill -0 $HTTP_PID 2>/dev/null; then
    echo "HTTP server 启动成功，监听端口 %d"
else
    echo "HTTP server 启动失败，尝试用 python3..."
    nohup python3 -m http.server %d > /var/log/http_server.log 2>&1 &
    sleep 2
fi

echo "=== 验证服务 ==="
sleep 1
curl -s -o /dev/null -w "%%{http_code}" http://127.0.0.1:%d || echo "验证失败"

echo "=== 完成 ==="
""" % (instance_id, port, port, port, port)

    try:
        run_command_request = volcenginesdkecs.RunCommandRequest(
            instance_ids=[instance_id],
            type="Shell",
            command_content=install_script,
            invocation_name="deploy-public-site-install",
            timeout=600,
            content_encoding="PlainText",
            working_dir="/root",
        )
        response = api.run_command(run_command_request)
        response_data = to_plain_dict(response)
        result = get_result_payload(response_data)
        invocation_id = first_value(result, "InvocationId", "invocation_id")
        if not invocation_id:
            raise ValueError("RunCommand 响应中没有 InvocationId: %s" % response_data)

        print("  命令已提交，等待执行完成...")
        command_result = wait_for_command_result(api, instance_id, invocation_id)
        print_run_command_output(command_result.get("output", ""))
        print("  Python安装和服务启动完成 (status=%s exit_code=%s)" % (
            command_result.get("status", ""),
            command_result.get("exit_code"),
        ))

        return {
            "invocation_id": invocation_id,
            "status": command_result.get("status", ""),
            "exit_code": command_result.get("exit_code"),
            "output": command_result.get("output", ""),
        }
    except ApiException as exc:
        raise RuntimeError("RunCommand失败: %s" % api_exception_message(exc)) from exc


def run_command_result_status(invocation_result: dict[str, Any]) -> str:
    return str(
        first_value(
            invocation_result,
            "InvocationResultStatus",
            "invocation_result_status",
        )
        or ""
    )


def run_command_exit_code(invocation_result: dict[str, Any]) -> int | None:
    raw = first_value(invocation_result, "ExitCode", "exit_code")
    if raw is None or raw == "":
        return None
    try:
        return int(raw)
    except (TypeError, ValueError):
        return None


def is_run_command_success(status: str, exit_code: int | None) -> bool:
    if status != "Success":
        return False
    return exit_code in (None, 0)


def find_invocation_result_for_instance(
    invocation_results: list[dict[str, Any]],
    instance_id: str,
) -> dict[str, Any] | None:
    for item in invocation_results:
        item_id = str(first_value(item, "InstanceId", "instance_id") or "")
        if item_id == instance_id:
            return item
    return invocation_results[0] if invocation_results else None


def decode_run_command_output(output_raw: str) -> str:
    import base64

    if not output_raw:
        return ""
    try:
        return base64.b64decode(output_raw).decode("utf-8", errors="replace")
    except Exception:
        return output_raw


def format_run_command_output_preview(output: str, max_chars: int = 2000) -> str:
    text = (output or "").strip()
    if not text:
        return "(无输出)"
    if len(text) <= max_chars:
        return text
    return "... (省略前 %d 字符)\n%s" % (len(text) - max_chars, text[-max_chars:])


def print_run_command_output(output: str) -> None:
    preview = format_run_command_output_preview(output)
    print("  命令执行输出:")
    for line in preview.splitlines():
        print("    %s" % line)


def wait_for_command_result(
    api: Any,
    instance_id: str,
    invocation_id: str,
    timeout_seconds: int = 600,
    poll_seconds: int = 5,
) -> dict[str, Any]:
    import volcenginesdkecs

    deadline = time.time() + timeout_seconds
    last_output = ""
    while time.time() <= deadline:
        try:
            request = volcenginesdkecs.DescribeInvocationResultsRequest(
                invocation_id=invocation_id,
                instance_id=instance_id,
                page_number=1,
                page_size=10,
            )
            response = api.describe_invocation_results(request)
            response_data = to_plain_dict(response)
            result = get_result_payload(response_data)
            invocation_results = first_value(result, "InvocationResults", "invocation_results") or []
            invocation_result = find_invocation_result_for_instance(invocation_results, instance_id)
            if invocation_result:
                status = run_command_result_status(invocation_result)
                output_raw = str(first_value(invocation_result, "Output", "output") or "")
                exit_code = run_command_exit_code(invocation_result)
                output = decode_run_command_output(output_raw)
                last_output = output

                if status == "Success":
                    if exit_code not in (None, 0):
                        print(
                            "  警告: 命令状态 Success 但 exit_code=%s，仍将返回执行输出"
                            % exit_code
                        )
                    return {
                        "status": status,
                        "exit_code": exit_code,
                        "output": output,
                    }
                if status in ("Failed", "Timeout", "Error"):
                    error_msg = str(first_value(invocation_result, "ErrorInfo", "error_info") or "")
                    raise RuntimeError(
                        "命令执行失败: status=%s exit_code=%s error=%s output=%s"
                        % (status, exit_code, error_msg, output[-500:])
                    )
                print("  命令执行中: %s" % (status or "unknown"))
        except ApiException:
            pass
        time.sleep(poll_seconds)
    raise TimeoutError(
        "等待命令执行超时: invocation_id=%s last_output=%s" % (invocation_id, last_output[-500:])
    )


def ping_public_ip(
    eip_address: str,
    count: int = 3,
) -> dict[str, Any]:
    try:
        completed = subprocess.run(
            ["ping", "-c", str(count), eip_address],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        success = completed.returncode == 0
        return {
            "success": success,
            "returncode": completed.returncode,
            "stdout": (completed.stdout or "")[-300:],
            "stderr": (completed.stderr or "")[-300:],
        }
    except Exception as exc:
        return {"success": False, "error": str(exc)}


def test_public_site(
    eip_address: str,
    port: int = 80,
) -> dict[str, Any]:
    log_step("8/8", "本地 curl 测试公网访问...")

    max_attempts = 10
    wait_between = 5

    for attempt in range(1, max_attempts + 1):
        try:
            print("  第 %d/%d 次尝试: curl -v http://%s:%d" % (attempt, max_attempts, eip_address, port))
            completed = subprocess.run(
                ["curl", "-v", "--connect-timeout", "10", "--max-time", "15", "http://%s:%d" % (eip_address, port)],
                capture_output=True,
                text=True,
                timeout=20,
                check=False,
            )
            if completed.returncode == 0 and completed.stdout:
                print("  ✓ 公网访问成功!")
                print("  响应内容 (前200字符): %s" % completed.stdout[:200])
                return {
                    "success": True,
                    "url": "http://%s:%d" % (eip_address, port),
                    "status_code": "200",
                    "output": completed.stdout,
                    "stderr": completed.stderr,
                }
            else:
                print("  访问失败: returncode=%d" % completed.returncode)
                if completed.stderr:
                    print("  stderr: %s" % completed.stderr[-200:])
        except Exception as exc:
            print("  curl异常: %s" % exc)

        if attempt < max_attempts:
            print("  等待 %d 秒后重试..." % wait_between)
            time.sleep(wait_between)
            wait_between = min(wait_between * 1.5, 15)

    print("  ✗ 公网访问测试失败")
    return {"success": False, "url": "http://%s:%d" % (eip_address, port)}


def deploy_public_site(
    region: str = DEFAULT_REGION,
    image_id: str = DEFAULT_IMAGE_ID,
    instance_name: str = DEFAULT_INSTANCE_NAME,
    instance_type_id: str = DEFAULT_INSTANCE_TYPE_ID,
    security_group_id: str = DEFAULT_SECURITY_GROUP_ID,
    subnet_id: str = DEFAULT_SUBNET_ID,
    volume_size: int = DEFAULT_VOLUME_SIZE,
    project_name: str = DEFAULT_PROJECT_NAME,
    http_port: int = DEFAULT_HTTP_PORT,
    password: str = "",
    key_pair_name: str = "",
    keep_image_credential: bool | None = None,
) -> dict[str, Any]:
    load_shell_env()

    if not password:
        password = os.getenv("INSTANCE_PASSWORD", "").strip()
    if not key_pair_name:
        key_pair_name = os.getenv("KEY_PAIR_NAME", "").strip()

    if not os.getenv("AK") or not os.getenv("SK"):
        raise ValueError("请设置 AK 和 SK 环境变量（或在 ~/.zshrc 中配置）")

    print("=" * 60)
    print("一键部署公网IP服务站点")
    print("=" * 60)
    print("区域: %s" % region)
    print("实例名: %s" % instance_name)
    print("实例类型: %s" % instance_type_id)
    print("镜像: %s" % image_id)
    print("HTTP端口: %d" % http_port)
    print("=" * 60)

    result: dict[str, Any] = {
        "region": region,
        "instance_name": instance_name,
    }

    # 先配置网络策略，再创建实例，避免实例就绪后仍被 SG/ACL 拦截
    sg_result = configure_security_group(region, security_group_id)
    result["security_group"] = sg_result

    acl_result = configure_acl(region, subnet_id)
    result["acl"] = acl_result

    instance_result = create_instance(
        region=region,
        image_id=image_id,
        instance_name=instance_name,
        instance_type_id=instance_type_id,
        security_group_id=security_group_id,
        subnet_id=subnet_id,
        volume_size=volume_size,
        project_name=project_name,
        password=password,
        key_pair_name=key_pair_name,
        keep_image_credential=keep_image_credential,
    )
    result["instance"] = instance_result
    instance_id = instance_result["instance_id"]
    instance_console_url = build_instance_console_url(region, instance_id, project_name)
    instance_result["console_url"] = instance_console_url
    result["instance_console_url"] = instance_console_url

    eip_result = allocate_and_bind_eip(region, instance_id, project_name)
    result["eip"] = eip_result
    eip_address = eip_result["eip_address"]

    fw_result = configure_firewall_policy(
        region,
        eip_address,
        private_ip=str(instance_result.get("private_ip") or ""),
        instance_id=instance_id,
        network_ips=list(instance_result.get("network_ips") or []),
    )
    result["firewall"] = fw_result

    server_result = install_python_and_start_server(region, instance_id, http_port)
    result["server"] = server_result

    log_step("7/8", "HTTP 服务已在实例 %s 端口 %d 启动" % (instance_id, http_port))

    test_result = test_public_site(eip_address, http_port)
    result["test"] = test_result

    log_step("完成", "部署流程结束")
    print("=" * 60)
    print("部署结果汇总:")
    print("  实例ID: %s" % instance_id)
    print("  控制台链接: %s" % instance_console_url)
    print("  私网IP: %s" % instance_result.get("private_ip", ""))
    print("  公网IP: %s" % eip_address)
    print("  访问地址: http://%s:%d" % (eip_address, http_port))
    print("  测试结果: %s" % ("成功 ✓" if test_result.get("success") else "失败 ✗"))
    print("=" * 60)

    return result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="一键部署公网IP服务站点")
    parser.add_argument("--region", default=os.getenv("VOLCENGINE_REGION", DEFAULT_REGION))
    parser.add_argument("--image-id", default=os.getenv("DEFAULT_IMAGE_ID", DEFAULT_IMAGE_ID))
    parser.add_argument("--instance-name", default=DEFAULT_INSTANCE_NAME)
    parser.add_argument("--instance-type", default=DEFAULT_INSTANCE_TYPE_ID)
    parser.add_argument("--security-group-id", default=DEFAULT_SECURITY_GROUP_ID)
    parser.add_argument("--subnet-id", default=DEFAULT_SUBNET_ID)
    parser.add_argument("--volume-size", type=int, default=DEFAULT_VOLUME_SIZE)
    parser.add_argument("--project-name", default=DEFAULT_PROJECT_NAME)
    parser.add_argument("--http-port", type=int, default=DEFAULT_HTTP_PORT)
    parser.add_argument("--password", default=os.getenv("INSTANCE_PASSWORD", ""), help="实例登录密码")
    parser.add_argument("--key-pair-name", default=os.getenv("KEY_PAIR_NAME", ""), help="SSH 密钥对名称")
    parser.add_argument(
        "--keep-image-credential",
        dest="keep_image_credential",
        action="store_true",
        default=None,
        help="复用镜像内置登录凭据（默认开启，除非设置了 password/key-pair）",
    )
    parser.add_argument(
        "--no-keep-image-credential",
        dest="keep_image_credential",
        action="store_false",
        help="不复用镜像登录凭据",
    )
    parser.add_argument("--output-json", default="", help="将结果保存为JSON文件")
    return parser


def main(argv: list[str] | None = None) -> int:
    load_shell_env()
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        result = deploy_public_site(
            region=args.region,
            image_id=args.image_id,
            instance_name=args.instance_name,
            instance_type_id=args.instance_type,
            security_group_id=args.security_group_id,
            subnet_id=args.subnet_id,
            volume_size=args.volume_size,
            project_name=args.project_name,
            http_port=args.http_port,
            password=args.password,
            key_pair_name=args.key_pair_name,
            keep_image_credential=args.keep_image_credential,
        )
        if args.output_json:
            output_path = Path(args.output_json)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(result, f, ensure_ascii=False, indent=2, default=str)
            print("结果已保存到: %s" % output_path)
        return 0 if result.get("test", {}).get("success", False) else 1
    except KeyboardInterrupt:
        print("\n用户中断")
        return 130
    except Exception as exc:
        print("部署失败: %s" % exc)
        return 1


if __name__ == "__main__":
    sys.exit(main())
