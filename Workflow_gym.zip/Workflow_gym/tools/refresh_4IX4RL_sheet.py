#!/usr/bin/env python3
"""重新跑 4IX4RL 合并流水线，对比历史 AG/AH 列并按最新值更新标绿。"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.feishu_client import FeishuClient, column_to_number
from open_workflowgym.local_spreadsheet import feishu_credentials_configured
from open_workflowgym.tools.match_feishu_image_ids import (
    WriteSheetResult,
    cell_address,
    cell_value,
    load_bashrc_env,
    read_sheet_rows_chunked,
    resolve_spreadsheet_token,
    write_output_sheet,
    write_single_cell_value,
)
from open_workflowgym.tools.merge_task_sheet_from_ve8a1q import (
    DEFAULT_OUTPUT_SHEET_ID,
    DEFAULT_OUTPUT_WIKI_URL,
    DEFAULT_TASK_SHEET_ID,
    DEFAULT_TASK_WIKI_URL,
    DEFAULT_VE8A1Q_SHEET_ID,
    DEFAULT_VE8A1Q_WIKI_URL,
    build_output_rows,
    read_sheet_rows,
    resolve_sheet_url,
)

AG_COLUMN_INDEX = column_to_number("AG") - 1
AH_COLUMN_INDEX = column_to_number("AH") - 1
UPDATED_BACK_COLOR = "#d9f7be"


def sheet_cell_range(sheet_id: str, row_index: int, column_index: int) -> str:
    address = cell_address(row_index, column_index)
    return "%s!%s:%s" % (sheet_id, address, address)


def extract_ag_ah_values(rows: list[list[Any]]) -> list[tuple[str, str]]:
    values: list[tuple[str, str]] = []
    for row_index, row in enumerate(rows):
        if row_index == 0:
            values.append(("", ""))
            continue
        values.append(
            (
                cell_value(row, AG_COLUMN_INDEX),
                cell_value(row, AH_COLUMN_INDEX),
            )
        )
    return values


def find_ag_ah_updates(
    historical_rows: list[list[Any]],
    new_rows: list[list[Any]],
) -> list[dict[str, Any]]:
    updates: list[dict[str, Any]] = []
    max_rows = max(len(historical_rows), len(new_rows))
    for row_index in range(max_rows):
        if row_index == 0:
            continue
        historical_ag = ""
        historical_ah = ""
        if row_index < len(historical_rows):
            historical_ag = cell_value(historical_rows[row_index], AG_COLUMN_INDEX)
            historical_ah = cell_value(historical_rows[row_index], AH_COLUMN_INDEX)
        if row_index >= len(new_rows):
            continue
        new_ag = cell_value(new_rows[row_index], AG_COLUMN_INDEX)
        new_ah = cell_value(new_rows[row_index], AH_COLUMN_INDEX)
        if historical_ag != new_ag:
            updates.append(
                {
                    "row_index": row_index,
                    "column_index": AG_COLUMN_INDEX,
                    "column_name": "AG",
                    "historical_value": historical_ag,
                    "new_value": new_ag,
                }
            )
        if historical_ah != new_ah:
            updates.append(
                {
                    "row_index": row_index,
                    "column_index": AH_COLUMN_INDEX,
                    "column_name": "AH",
                    "historical_value": historical_ah,
                    "new_value": new_ah,
                }
            )
    return updates


def apply_ag_ah_updates(
    client: FeishuClient,
    spreadsheet_token: str,
    sheet_id: str,
    updates: list[dict[str, Any]],
) -> dict[str, Any]:
    updated_ranges: list[str] = []
    failed_updates: list[dict[str, Any]] = []
    for item in updates:
        row_index = int(item["row_index"])
        column_index = int(item["column_index"])
        new_value = item["new_value"]
        cell_range = sheet_cell_range(sheet_id, row_index, column_index)
        try:
            write_single_cell_value(
                client,
                spreadsheet_token,
                sheet_id,
                row_index,
                column_index,
                new_value,
            )
            client.set_cells_background(
                spreadsheet_token,
                [cell_range],
                back_color=UPDATED_BACK_COLOR,
            )
            updated_ranges.append(cell_range)
        except Exception as exc:
            failed_updates.append({**item, "error": str(exc)})
    return {
        "updated_count": len(updated_ranges),
        "failed_count": len(failed_updates),
        "updated_ranges": updated_ranges,
        "failed_updates": failed_updates,
    }


def run_refresh(
    client: FeishuClient,
    *,
    ve8a1q_wiki_url: str = DEFAULT_VE8A1Q_WIKI_URL,
    ve8a1q_sheet_id: str = DEFAULT_VE8A1Q_SHEET_ID,
    task_wiki_url: str = DEFAULT_TASK_WIKI_URL,
    task_sheet_id: str = DEFAULT_TASK_SHEET_ID,
    output_wiki_url: str = DEFAULT_OUTPUT_WIKI_URL,
    output_sheet_id: str = DEFAULT_OUTPUT_SHEET_ID,
    dry_run: bool = False,
) -> dict[str, Any]:
    output_token = resolve_spreadsheet_token(client, output_wiki_url)
    historical_rows = read_sheet_rows_chunked(client, output_token, output_sheet_id)

    ve8a1q_token, resolved_ve8a1q_sheet_id = resolve_sheet_url(
        client,
        "%s?sheet=%s" % (ve8a1q_wiki_url.split("?")[0], ve8a1q_sheet_id),
    )
    task_token, resolved_task_sheet_id = resolve_sheet_url(
        client,
        "%s?sheet=%s" % (task_wiki_url.split("?")[0], task_sheet_id),
    )
    ve8a1q_rows = read_sheet_rows(client, ve8a1q_token, resolved_ve8a1q_sheet_id, "A1:ZZ2000")
    ieoeoe_rows = read_sheet_rows(client, ve8a1q_token, "iEoEoE", "A1:ZZ2000")
    task_rows = read_sheet_rows_chunked(client, task_token, resolved_task_sheet_id)
    (
        new_rows,
        not_found_count,
        e_not_found_count,
        second_not_found_count,
        second_e_not_found_count,
    ) = build_output_rows(task_rows, ve8a1q_rows, ieoeoe_rows)

    updates = find_ag_ah_updates(historical_rows, new_rows)
    if dry_run:
        write_result = WriteSheetResult()
        apply_result = {
            "updated_count": len(updates),
            "failed_count": 0,
            "updated_ranges": [],
            "failed_updates": [],
        }
    else:
        write_result = write_output_sheet(client, output_token, output_sheet_id, new_rows)
        if updates:
            apply_result = apply_ag_ah_updates(client, output_token, output_sheet_id, updates)
        else:
            apply_result = {
                "updated_count": 0,
                "failed_count": 0,
                "updated_ranges": [],
                "failed_updates": [],
            }

    data_row_count = max(0, len(new_rows) - 1)
    matched_count = data_row_count - not_found_count - e_not_found_count
    second_matched_count = data_row_count - second_not_found_count - second_e_not_found_count
    return {
        "output_sheet_id": output_sheet_id,
        "historical_rows": len(historical_rows),
        "new_rows": len(new_rows),
        "ve8a1q_rows": len(ve8a1q_rows),
        "ieoeoe_rows": len(ieoeoe_rows),
        "task_rows": len(task_rows),
        "matched_output_rows": matched_count,
        "second_matched_output_rows": second_matched_count,
        "ag_ah_diff_count": len(updates),
        "preview_updates": updates[:15],
        "attachment_count": write_result.attachment_count,
        "failed_cell_count": write_result.failed_cell_count,
        "failed_row_count": write_result.failed_row_count,
        **apply_result,
    }


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="重新生成 4IX4RL，并将与历史不一致的 AG/AH 列按最新值更新后标绿"
    )
    parser.add_argument("--ve8a1q-wiki-url", default=DEFAULT_VE8A1Q_WIKI_URL)
    parser.add_argument("--ve8a1q-sheet-id", default=DEFAULT_VE8A1Q_SHEET_ID)
    parser.add_argument("--task-wiki-url", default=DEFAULT_TASK_WIKI_URL)
    parser.add_argument("--task-sheet-id", default=DEFAULT_TASK_SHEET_ID)
    parser.add_argument("--output-wiki-url", default=DEFAULT_OUTPUT_WIKI_URL)
    parser.add_argument("--output-sheet-id", default=DEFAULT_OUTPUT_SHEET_ID)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--bashrc", default="")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    load_bashrc_env(bashrc_path=args.bashrc)
    if not feishu_credentials_configured():
        print("缺少 APP_ID 或 APP_SECRET，请确认已写入 ~/.bashrc 或当前环境变量", file=sys.stderr)
        return 1

    client = FeishuClient(dry_run=False)
    result = run_refresh(
        client,
        ve8a1q_wiki_url=args.ve8a1q_wiki_url,
        ve8a1q_sheet_id=args.ve8a1q_sheet_id,
        task_wiki_url=args.task_wiki_url,
        task_sheet_id=args.task_sheet_id,
        output_wiki_url=args.output_wiki_url,
        output_sheet_id=args.output_sheet_id,
        dry_run=args.dry_run,
    )

    print("4IX4RL 流水线刷新完成")
    print("  output sheet: %s" % result["output_sheet_id"])
    print("  历史行数: %s" % result["historical_rows"])
    print("  新生成行数: %s" % result["new_rows"])
    print("  task rows: %s" % result["task_rows"])
    print("  ve8a1q rows: %s" % result["ve8a1q_rows"])
    print("  iEoEoE rows: %s" % result["ieoeoe_rows"])
    print("  AG 匹配输出行: %s" % result["matched_output_rows"])
    print("  AH 匹配输出行: %s" % result["second_matched_output_rows"])
    print("  AG/AH 与历史不一致: %s" % result["ag_ah_diff_count"])
    if args.dry_run:
        print("预览前 15 条 AG/AH 差异:")
        for item in result["preview_updates"]:
            print(
                "  row=%s %s: %s -> %s"
                % (
                    item["row_index"] + 1,
                    item["column_name"],
                    item["historical_value"] or "(空)",
                    item["new_value"] or "(空)",
                )
            )
    else:
        print("  已标绿更新: %s" % result["updated_count"])
        print("  更新失败: %s" % result["failed_count"])
        print("  写入失败单元格: %s" % result["failed_cell_count"])
        print("  写入失败整行: %s" % result["failed_row_count"])
        print(
            "已写入: %s?sheet=%s"
            % (args.output_wiki_url.split("?")[0], result["output_sheet_id"])
        )
    return 0 if result.get("failed_count", 0) == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
