#!/usr/bin/env python3
"""将 deploy_public_site 部署总结发布到飞书 Doc 云文档（docx）。"""
from __future__ import annotations

import os
import re
import shlex
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from feishu_client import FeishuClient  # noqa: E402


def load_shell_env(names: tuple[str, ...]) -> None:
    missing = [name for name in names if not os.getenv(name, "").strip()]
    if not missing:
        return
    for config_path in (
        os.path.expanduser("~/.bashrc"),
        os.path.expanduser("~/.zshrc"),
        os.path.expanduser("~/.profile"),
    ):
        config = Path(config_path)
        if not config.is_file():
            continue
        config_quoted = shlex.quote(str(config))
        shell = "zsh" if config.name.endswith("zshrc") else "bash"
        for name in list(missing):
            try:
                completed = subprocess.run(
                    [
                        shell,
                        "-lc",
                        "set -a; source %s >/dev/null 2>&1; set +a; printf '%%s' \"${%s:-}\""
                        % (config_quoted, name),
                    ],
                    capture_output=True,
                    text=True,
                    timeout=15,
                    check=False,
                )
            except (OSError, subprocess.TimeoutExpired):
                continue
            value = (completed.stdout or "").strip()
            if value:
                os.environ[name] = value
                missing.remove(name)
        if not missing:
            return


def resolve_screenshot_path() -> Path | None:
    workspace_image = ROOT / "docs" / "deploy_public_site_effect.png"
    override = os.getenv("DEPLOY_PUBLIC_SITE_SCREENSHOT", "").strip()
    if override:
        source = Path(override).expanduser()
        if source.is_file():
            workspace_image.parent.mkdir(parents=True, exist_ok=True)
            if not workspace_image.exists() or source.stat().st_mtime > workspace_image.stat().st_mtime:
                import shutil

                shutil.copy2(source, workspace_image)
    if workspace_image.is_file():
        return workspace_image
    return None


def insert_doc_image_with_bytedcli(doc_url: str, image_path: Path) -> bool:
    if not shutil_which("bytedcli"):
        return False
    rel_path = "./%s" % image_path.resolve().relative_to(ROOT.resolve()).as_posix()
    completed = subprocess.run(
        [
            "bytedcli",
            "lark",
            "docs",
            "media-insert",
            "--doc",
            doc_url,
            "--file",
            rel_path,
            "--type",
            "image",
            "--caption",
            "部署效果：浏览器访问公网 EIP",
            "--width",
            "720",
        ],
        capture_output=True,
        text=True,
        timeout=120,
        check=False,
        cwd=str(ROOT),
    )
    if completed.returncode != 0:
        print("警告: bytedcli 插入图片失败: %s" % (completed.stderr or completed.stdout))
        return False
    return True


def shutil_which(name: str) -> str | None:
    from shutil import which

    return which(name)


def extract_feishu_doc_markdown(markdown_text: str, start_heading: str = "## 概述") -> str:
    marker = start_heading.strip()
    index = markdown_text.find(marker)
    if index < 0:
        raise ValueError("未找到飞书 Doc 起始标题: %s" % start_heading)
    return markdown_text[index:].lstrip()


def flatten_feishu_doc_formatting(markdown_text: str) -> str:
    """去掉行内代码和代码块标记，避免飞书 Doc 导入后出现灰色背景。"""
    text = re.sub(r"```[^\n]*\n(.*?)```", lambda match: match.group(1).strip("\n") + "\n", markdown_text, flags=re.DOTALL)
    text = re.sub(r"`([^`\n]+)`", r"\1", text)
    return text


def prepare_feishu_doc_markdown(source_path: Path) -> Path:
    content = source_path.read_text(encoding="utf-8")
    feishu_content = extract_feishu_doc_markdown(content)
    feishu_content = flatten_feishu_doc_formatting(feishu_content)
    output_path = ROOT / "docs" / ".deploy_public_site_feishu_doc.md"
    output_path.write_text(feishu_content, encoding="utf-8")
    return output_path


def main() -> int:
    load_shell_env(("APP_ID", "APP_SECRET", "FEISHU_FOLDER_TOKEN"))
    title = "deploy_public_site 一键部署公网站点总结"
    markdown_path = ROOT / "docs" / "deploy_public_site_summary.md"
    if not markdown_path.is_file():
        raise FileNotFoundError("未找到 Markdown 源文件: %s" % markdown_path)

    feishu_markdown_path = prepare_feishu_doc_markdown(markdown_path)
    print("飞书 Doc 仅导入「概述」及之后的内容（不含环境变量章节，且无代码块灰底）")

    client = FeishuClient(dry_run=False)
    document_id, document_url = client.import_markdown_as_docx(
        str(feishu_markdown_path),
        title=title,
        folder_token=os.getenv("FEISHU_FOLDER_TOKEN", "").strip(),
    )

    admin = os.getenv("FEISHU_SHEET_ADMIN_MEMBER_ID", "admin@example.com")
    try:
        client.grant_docx_admin_permission(document_id, admin)
        print("已授予 Doc 管理员权限: %s" % admin)
    except Exception as exc:
        print("授权失败（文档已创建）: %s" % exc)

    screenshot = resolve_screenshot_path()
    if screenshot:
        if insert_doc_image_with_bytedcli(document_url, screenshot):
            print("已插入部署效果图")
        else:
            print("提示: 未能自动插入效果图，请手动上传到文档末尾")
    else:
        print("警告: 未找到效果图，跳过图片插入")

    print("飞书 Doc 云文档已创建: %s" % document_url)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
