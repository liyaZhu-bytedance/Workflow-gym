#!/usr/bin/env python3
"""将指定 HF dataset 源仓文件合并到 juliazzzvvv/openworkflowgym，并导出文件清单。

默认:
  源仓: juliazzzvvv/openworkflowgym-2, -3, -4
  目标: juliazzzvvv/openworkflowgym
  目标已有相同 path_in_repo 则跳过
  服务端 copy（不落本地），成功后从源仓删除（移动）；可用 --copy-only 只复制不删
  清单 CSV: output/hf_openworkflowgym_files.csv

依赖:
  pip install 'huggingface_hub>=1.17'   # 需跨仓 CommitOperationCopy / copy_files
  建议 Python >=3.10（可用仓库内 .venv311）

环境变量:
  HF_TOKEN / HUGGINGFACE_HUB_TOKEN（也可写在 ~/.zshrc）

示例:
  .venv311/bin/python tools/merge_hf_repos_into_openworkflowgym.py
  .venv311/bin/python tools/merge_hf_repos_into_openworkflowgym.py --dry-run
  .venv311/bin/python tools/merge_hf_repos_into_openworkflowgym.py --copy-only
"""
from __future__ import annotations

import argparse
import csv
import os
import shlex
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


HF_ENV_NAMES = ("HF_TOKEN", "HUGGINGFACE_HUB_TOKEN", "HUGGING_FACE_HUB_TOKEN")
DEFAULT_DEST_REPO = "juliazzzvvv/openworkflowgym"
DEFAULT_SOURCE_REPOS = (
    "juliazzzvvv/openworkflowgym-2",
    "juliazzzvvv/openworkflowgym-3",
    "juliazzzvvv/openworkflowgym-4",
)
DEFAULT_REPO_TYPE = "dataset"
DEFAULT_CSV_PATH = "output/hf_openworkflowgym_files.csv"
CSV_HEADERS = [
    "path_in_repo",
    "size_bytes",
    "size_gib",
    "lfs",
    "blob_id",
    "listed_at",
]


def load_hf_token_from_shell() -> None:
    """若环境变量缺失，尝试从 ~/.zshrc / ~/.bashrc 加载。"""
    if any(os.getenv(name, "").strip() for name in HF_ENV_NAMES):
        return
    for config_name in (".zshrc", ".bashrc", ".profile"):
        config_path = Path.home() / config_name
        if not config_path.is_file():
            continue
        config_quoted = shlex.quote(str(config_path))
        shell = "zsh" if config_name == ".zshrc" else "bash"
        for name in HF_ENV_NAMES:
            if os.getenv(name, "").strip():
                continue
            try:
                completed = subprocess.run(
                    [
                        shell,
                        "-lc",
                        "set -a; source %s >/dev/null 2>&1; set +a; printf '%%s' \"${%s:-}\""
                        % (config_quoted, name),
                    ],
                    capture_output=True,
                    text=True,
                    timeout=15,
                    check=False,
                )
            except (OSError, subprocess.TimeoutExpired):
                continue
            value = (completed.stdout or "").strip()
            if value:
                os.environ[name] = value
                if name != "HF_TOKEN":
                    os.environ.setdefault("HF_TOKEN", value)


def resolve_hf_token() -> str:
    load_hf_token_from_shell()
    for name in HF_ENV_NAMES:
        value = (os.getenv(name) or "").strip()
        if value:
            os.environ.setdefault("HF_TOKEN", value)
            return value
    return ""


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def format_gib(num_bytes: int | None) -> str:
    if num_bytes is None:
        return ""
    return "%.3f" % (float(num_bytes) / (1024 ** 3))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="合并 HF 源仓文件到 openworkflowgym，并导出目标仓文件清单 CSV"
    )
    parser.add_argument("--dest-repo", default=DEFAULT_DEST_REPO, help="目标仓库 ID")
    parser.add_argument(
        "--source-repo",
        action="append",
        dest="source_repos",
        default=None,
        help="源仓库 ID，可重复传入；默认 openworkflowgym-2/-3/-4",
    )
    parser.add_argument("--repo-type", default=DEFAULT_REPO_TYPE, choices=("dataset", "model", "space"))
    parser.add_argument(
        "--csv-path",
        default=DEFAULT_CSV_PATH,
        help="目标仓文件清单 CSV，默认 output/hf_openworkflowgym_files.csv",
    )
    parser.add_argument(
        "--copy-only",
        action="store_true",
        help="只复制到目标仓，不从源仓删除（默认复制成功后删除源文件=移动）",
    )
    parser.add_argument("--dry-run", action="store_true", help="只打印计划，不 copy/删除")
    parser.add_argument(
        "--skip-merge",
        action="store_true",
        help="跳过合并，只列出目标仓文件并写 CSV",
    )
    parser.add_argument(
        "--include-gitattributes",
        action="store_true",
        help="默认跳过 .gitattributes；加此开关才复制",
    )
    return parser


def hf_uri(repo_type: str, repo_id: str, path_in_repo: str = "") -> str:
    """构造 hf:// URI（dataset/space 带前缀）。"""
    if repo_type == "dataset":
        base = "hf://datasets/%s" % repo_id
    elif repo_type == "space":
        base = "hf://spaces/%s" % repo_id
    else:
        base = "hf://%s" % repo_id
    if not path_in_repo:
        return base
    return "%s/%s" % (base, path_in_repo.lstrip("/"))


def require_server_copy_support(api: Any) -> None:
    if not hasattr(api, "copy_files"):
        raise SystemExit(
            "当前 huggingface_hub 不支持跨仓服务端 copy。"
            "请升级: pip install 'huggingface_hub>=1.17'（建议用 .venv311）"
        )


def list_repo_path_set(api: Any, repo_id: str, repo_type: str) -> set[str]:
    try:
        files = api.list_repo_files(repo_id=repo_id, repo_type=repo_type)
    except Exception as exc:
        raise SystemExit("列出仓库失败 %s: %s" % (repo_id, exc)) from exc
    return set(files or [])


def list_repo_file_details(api: Any, repo_id: str, repo_type: str) -> list[dict[str, Any]]:
    """递归列出文件详情（路径、大小、是否 LFS）。"""
    rows: list[dict[str, Any]] = []
    try:
        entries = api.list_repo_tree(repo_id=repo_id, repo_type=repo_type, recursive=True)
    except Exception as exc:
        raise SystemExit("列出仓库树失败 %s: %s" % (repo_id, exc)) from exc

    for entry in entries:
        path = getattr(entry, "path", None)
        if not path:
            continue
        # RepoFolder 没有 blob_id / 通常 type=directory
        if getattr(entry, "type", None) == "directory":
            continue
        if not hasattr(entry, "size"):
            continue
        size = getattr(entry, "size", None)
        lfs = getattr(entry, "lfs", None)
        blob_id = getattr(entry, "blob_id", "") or ""
        rows.append(
            {
                "path_in_repo": str(path),
                "size_bytes": int(size) if size is not None else "",
                "size_gib": format_gib(int(size)) if size is not None else "",
                "lfs": "是" if lfs else "否",
                "blob_id": str(blob_id),
                "listed_at": utc_now_iso(),
            }
        )
    rows.sort(key=lambda item: item["path_in_repo"])
    return rows


def write_files_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_HEADERS)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in CSV_HEADERS})


def repo_exists(api: Any, repo_id: str, repo_type: str) -> bool:
    try:
        api.repo_info(repo_id=repo_id, repo_type=repo_type)
        return True
    except Exception:
        return False


def merge_one_file(
    *,
    api: Any,
    source_repo: str,
    dest_repo: str,
    repo_type: str,
    path_in_repo: str,
    copy_only: bool,
    dry_run: bool,
) -> str:
    """服务端 copy（不落本地）。返回: copied|moved|dry-run-*"""
    if dry_run:
        action = "dry-run-copy" if copy_only else "dry-run-move"
        print("[%s] %s:%s -> %s:%s" % (action, source_repo, path_in_repo, dest_repo, path_in_repo))
        return action

    src_uri = hf_uri(repo_type, source_repo, path_in_repo)
    dst_uri = hf_uri(repo_type, dest_repo, path_in_repo)
    print("服务端 copy: %s -> %s" % (src_uri, dst_uri))
    api.copy_files(src_uri, dst_uri)

    if copy_only:
        print("已复制: %s:%s -> %s" % (source_repo, path_in_repo, dest_repo))
        return "copied"

    print("删除源文件: %s:%s" % (source_repo, path_in_repo))
    try:
        api.delete_file(
            path_in_repo=path_in_repo,
            repo_id=source_repo,
            repo_type=repo_type,
            commit_message="move to %s: remove %s" % (dest_repo, path_in_repo),
        )
    except Exception as exc:
        # copy 已成功；源文件若已不存在（404）仍视为移动完成
        msg = str(exc).lower()
        if "404" in msg or "entry not found" in msg or "does not exist" in msg:
            print("源文件已不存在，视为移动完成: %s:%s (%s)" % (source_repo, path_in_repo, exc))
        else:
            raise
    print("已移动: %s:%s -> %s" % (source_repo, path_in_repo, dest_repo))
    return "moved"


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    token = resolve_hf_token()
    if not token:
        raise SystemExit("缺少 HF_TOKEN（或 HUGGINGFACE_HUB_TOKEN）")

    from huggingface_hub import HfApi

    api = HfApi(token=token)
    require_server_copy_support(api)
    source_repos = args.source_repos or list(DEFAULT_SOURCE_REPOS)
    dest_repo = args.dest_repo.strip()
    repo_type = args.repo_type
    csv_path = Path(args.csv_path).expanduser().resolve()

    if not repo_exists(api, dest_repo, repo_type):
        raise SystemExit("目标仓库不存在或无权访问: %s" % dest_repo)

    print("目标仓: %s (%s)" % (dest_repo, repo_type))
    print("源仓: %s" % ", ".join(source_repos))
    print("模式: 服务端 copy（不落本地）")
    dest_files = list_repo_path_set(api, dest_repo, repo_type)
    print("目标仓现有文件数: %s" % len(dest_files))

    stats = {"skipped": 0, "copied": 0, "moved": 0, "dry_run": 0, "missing_source": 0, "failed": 0}

    if not args.skip_merge:
        for source_repo in source_repos:
            if not repo_exists(api, source_repo, repo_type):
                print("源仓不存在或无权访问，跳过: %s" % source_repo)
                stats["missing_source"] += 1
                continue
            source_files = sorted(list_repo_path_set(api, source_repo, repo_type))
            print("=" * 72)
            print("处理源仓 %s，文件数=%s" % (source_repo, len(source_files)))
            for path_in_repo in source_files:
                if path_in_repo == ".gitattributes" and not args.include_gitattributes:
                    print("跳过(.gitattributes): %s" % path_in_repo)
                    stats["skipped"] += 1
                    continue
                if path_in_repo in dest_files:
                    print("跳过(目标已存在): %s" % path_in_repo)
                    stats["skipped"] += 1
                    continue
                try:
                    action = merge_one_file(
                        api=api,
                        source_repo=source_repo,
                        dest_repo=dest_repo,
                        repo_type=repo_type,
                        path_in_repo=path_in_repo,
                        copy_only=args.copy_only,
                        dry_run=args.dry_run,
                    )
                    if action.startswith("dry-run"):
                        stats["dry_run"] += 1
                    elif action == "copied":
                        stats["copied"] += 1
                        dest_files.add(path_in_repo)
                    elif action == "moved":
                        stats["moved"] += 1
                        dest_files.add(path_in_repo)
                except Exception as exc:
                    stats["failed"] += 1
                    print("失败: %s:%s error=%s" % (source_repo, path_in_repo, exc), file=sys.stderr)

    print("=" * 72)
    print(
        "合并统计: skipped=%s copied=%s moved=%s dry_run=%s missing_source=%s failed=%s"
        % (
            stats["skipped"],
            stats["copied"],
            stats["moved"],
            stats["dry_run"],
            stats["missing_source"],
            stats["failed"],
        )
    )

    print("列出目标仓文件并写入 CSV...")
    detail_rows = list_repo_file_details(api, dest_repo, repo_type)
    # dry-run 时目标仓未变，仍写当前真实列表
    write_files_csv(csv_path, detail_rows)
    print("已写入: %s (files=%s)" % (csv_path, len(detail_rows)))
    for row in detail_rows[:20]:
        print("  - %s (%s GiB)" % (row["path_in_repo"], row["size_gib"] or "?"))
    if len(detail_rows) > 20:
        print("  ... 其余 %s 个省略" % (len(detail_rows) - 20))

    return 1 if stats["failed"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
