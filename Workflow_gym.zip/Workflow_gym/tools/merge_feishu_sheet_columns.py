#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.feishu_client import FeishuClient
from open_workflowgym.local_spreadsheet import feishu_credentials_configured
from open_workflowgym.source_reader import parse_feishu_sheet_url
from open_workflowgym.tools.match_feishu_image_ids import (
    NOT_FOUND_LABEL,
    cell_value,
    load_bashrc_env,
    read_sheet_rows,
    resolve_spreadsheet_token,
    trim_trailing_empty_rows,
    write_output_sheet,
)

DEFAULT_LOOKUP_SHEET_URL = os.getenv("FEISHU_LOOKUP_SHEET_URL", "https://example.feishu.local/sheets/PLACEHOLDER?sheet=SHEET_ID")
DEFAULT_BASE_WIKI_URL = os.getenv("FEISHU_BASE_WIKI_URL", "https://example.feishu.local/wiki/PLACEHOLDER")
DEFAULT_BASE_SHEET_ID = "iEoEoE"
DEFAULT_OUTPUT_SHEET_ID = "Ve8a1Q"
DEFAULT_MATCHED_IMAGE_ID_COLUMN = 4
DEFAULT_INSERT_COLUMNS = (3, 4, 5, 6)
FALLBACK_INSERT_HEADERS = ("列D", "列E", "列F", "列G")


def parse_image_ids(value: object) -> list[str]:
    text = str(value or "").strip()
    if not text or text == NOT_FOUND_LABEL:
        return []
    parts = re.split(r"[,，]", text)
    return [part.strip() for part in parts if part.strip()]


def build_defg_lookup(
    lookup_rows: list[list[Any]],
    *,
    image_id_column: int = 2,
    value_columns: tuple[int, int, int, int] = DEFAULT_INSERT_COLUMNS,
) -> dict[str, list[Any]]:
    lookup: dict[str, list[Any]] = {}
    for row_index, row in enumerate(lookup_rows):
        if row_index == 0:
            continue
        image_id = cell_value(row, image_id_column)
        if not image_id or image_id in lookup:
            continue
        lookup[image_id] = [row[column] if column < len(row) else "" for column in value_columns]
    return lookup


def lookup_insert_headers(
    lookup_rows: list[list[Any]],
    *,
    value_columns: tuple[int, int, int, int] = DEFAULT_INSERT_COLUMNS,
) -> list[str]:
    if not lookup_rows:
        return list(FALLBACK_INSERT_HEADERS)
    header_row = lookup_rows[0]
    headers = [cell_value(header_row, column) for column in value_columns]
    if any(headers):
        return headers
    return list(FALLBACK_INSERT_HEADERS)


def insert_columns_after(
    row: list[Any],
    column_index: int,
    values: list[Any],
) -> list[Any]:
    padded = list(row)
    insert_at = column_index + 1
    for offset, value in enumerate(values):
        padded.insert(insert_at + offset, value)
    return padded


def build_merged_rows(
    base_rows: list[list[Any]],
    lookup_rows: list[list[Any]],
    *,
    matched_image_id_column: int = DEFAULT_MATCHED_IMAGE_ID_COLUMN,
    value_columns: tuple[int, int, int, int] = DEFAULT_INSERT_COLUMNS,
) -> list[list[Any]]:
    base_rows = trim_trailing_empty_rows(base_rows)
    lookup_rows = trim_trailing_empty_rows(lookup_rows)
    if not base_rows:
        return []

    lookup = build_defg_lookup(
        lookup_rows,
        value_columns=value_columns,
    )
    insert_headers = lookup_insert_headers(lookup_rows, value_columns=value_columns)
    empty_values = [""] * len(insert_headers)
    output_rows: list[list[Any]] = []

    for row_index, row in enumerate(base_rows):
        if row_index == 0:
            output_rows.append(insert_columns_after(row, matched_image_id_column, insert_headers))
            continue

        matched_values = empty_values
        for image_id in parse_image_ids(cell_value(row, matched_image_id_column)):
            if image_id in lookup:
                matched_values = lookup[image_id]
                break
        output_rows.append(insert_columns_after(row, matched_image_id_column, matched_values))

    return output_rows


def resolve_sheet_url(client: FeishuClient, sheet_url: str) -> tuple[str, str]:
    info = parse_feishu_sheet_url(sheet_url)
    token = resolve_spreadsheet_token(client, sheet_url) if info.get("is_wiki") else info["token"]
    sheet_id = info["sheet_id"] or client.query_first_sheet_id(token)
    if not token or not sheet_id:
        raise ValueError("无法从飞书表格 URL 解析 token 或 sheet_id: %s" % sheet_url)
    return token, sheet_id


def run_merge(
    client: FeishuClient,
    *,
    lookup_sheet_url: str = DEFAULT_LOOKUP_SHEET_URL,
    base_wiki_url: str = DEFAULT_BASE_WIKI_URL,
    base_sheet_id: str = DEFAULT_BASE_SHEET_ID,
    output_sheet_id: str = DEFAULT_OUTPUT_SHEET_ID,
    dry_run: bool = False,
) -> dict[str, Any]:
    lookup_token, lookup_sheet_id = resolve_sheet_url(client, lookup_sheet_url)
    base_token, resolved_base_sheet_id = resolve_sheet_url(
        client,
        "%s?sheet=%s" % (base_wiki_url.split("?")[0], base_sheet_id),
    )
    if resolved_base_sheet_id != base_sheet_id:
        base_sheet_id = resolved_base_sheet_id

    lookup_rows = read_sheet_rows(client, lookup_token, lookup_sheet_id, "A1:G2000")
    base_rows = read_sheet_rows(client, base_token, base_sheet_id)
    output_rows = build_merged_rows(base_rows, lookup_rows)

    matched_count = 0
    missing_count = 0
    for row_index, row in enumerate(output_rows):
        if row_index == 0:
            continue
        inserted_values = row[DEFAULT_MATCHED_IMAGE_ID_COLUMN + 1 : DEFAULT_MATCHED_IMAGE_ID_COLUMN + 5]
        if any(str(cell or "").strip() for cell in inserted_values):
            matched_count += 1
        else:
            missing_count += 1

    output_token = base_token
    if not dry_run:
        write_output_sheet(client, output_token, output_sheet_id, output_rows)

    return {
        "lookup_spreadsheet_token": lookup_token,
        "lookup_sheet_id": lookup_sheet_id,
        "base_spreadsheet_token": base_token,
        "base_sheet_id": base_sheet_id,
        "output_sheet_id": output_sheet_id,
        "lookup_rows": len(lookup_rows),
        "base_rows": len(base_rows),
        "output_rows": len(output_rows),
        "matched_count": matched_count,
        "missing_count": missing_count,
        "output_preview": output_rows[:5],
    }


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="按 image_id 将 lookup 表 DEFG 列合并到 base 表 E 列之后，并写入输出 sheet"
    )
    parser.add_argument("--lookup-sheet-url", default=DEFAULT_LOOKUP_SHEET_URL, help="lookup 表 URL，读取 C 列和 DEFG 列")
    parser.add_argument("--base-wiki-url", default=DEFAULT_BASE_WIKI_URL, help="base 表所在 wiki URL")
    parser.add_argument("--base-sheet-id", default=DEFAULT_BASE_SHEET_ID, help="base sheet id，读取 E 列 image_id")
    parser.add_argument("--output-sheet-id", default=DEFAULT_OUTPUT_SHEET_ID, help="输出 sheet id")
    parser.add_argument("--dry-run", action="store_true", help="只计算合并结果，不写入飞书")
    parser.add_argument("--bashrc", default="", help="可选，指定 bashrc 路径，默认 ~/.bashrc")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    load_bashrc_env(bashrc_path=args.bashrc)
    if not feishu_credentials_configured():
        print("缺少 APP_ID 或 APP_SECRET，请确认已写入 ~/.bashrc 或当前环境变量", file=sys.stderr)
        return 1

    client = FeishuClient(dry_run=False)
    result = run_merge(
        client,
        lookup_sheet_url=args.lookup_sheet_url,
        base_wiki_url=args.base_wiki_url,
        base_sheet_id=args.base_sheet_id,
        output_sheet_id=args.output_sheet_id,
        dry_run=args.dry_run,
    )

    print("表格合并完成")
    print("  lookup sheet: %s (%s 行)" % (result["lookup_sheet_id"], result["lookup_rows"]))
    print("  base sheet: %s (%s 行)" % (result["base_sheet_id"], result["base_rows"]))
    print("  output sheet: %s (%s 行)" % (result["output_sheet_id"], result["output_rows"]))
    print("  匹配成功: %s" % result["matched_count"])
    print("  未匹配: %s" % result["missing_count"])
    if args.dry_run:
        print("预览前 5 行:")
        for row in result["output_preview"]:
            print("  %s" % row[:12])
    else:
        print(
            "已写入: %s?sheet=%s"
            % (args.base_wiki_url.split("?")[0], result["output_sheet_id"])
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
