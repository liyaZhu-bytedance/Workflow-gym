#!/usr/bin/env python3
"""Batch-create ECS instances via AllocateInstances (multi-zone).

Example:
  export AK=... SK=...
  python tools/allocate_instances.py --count 20 --image-id image-yeqmmcfxblfa2vxfbnyz

  # Ubuntu 实例
  python tools/allocate_instances.py --instance-name open_workflow_gym_ubuntu

  # wait until all instances reach RUNNING
  python tools/allocate_instances.py --count 5 --wait
"""
from __future__ import annotations

import argparse
import json
import os
import shlex
import subprocess
import sys
import time
import uuid
import warnings
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

import volcenginesdkcore
import volcenginesdkecs
from volcenginesdkcore.rest import ApiException

from open_workflowgym.envs.volcengine_env import get_result_payload, to_plain_dict

DEFAULT_REGION = "cn-guangzhou"
DEFAULT_IMAGE_ID = "image-yeqmmcfxblfa2vxfbnyz"
DEFAULT_INSTANCE_NAME = "open_workflow_gym_windows"
DEFAULT_INSTANCE_TYPE_ID = "ecs.g4i.4xlarge"
DEFAULT_SECURITY_GROUP_ID = "sg-2jxvygwafv9xc7zrx9wf0sqkg"
DEFAULT_SUBNET_IDS = (
    "subnet-2zwe59aqcfhmo6ql1m3wkdq42",
    "subnet-1m1zburva2hhc6vtia726dol8",
    "subnet-1phsryth6pgqo5sehpn21io2h",
)
DEFAULT_VOLUME_SIZE = 500
DEFAULT_COUNT = 20
DEFAULT_PROJECT_NAME = "default"
DEFAULT_READY_STATUS = "RUNNING"
DEFAULT_CREATE_TIMEOUT_SECONDS = 900
DEFAULT_POLL_INTERVAL_SECONDS = 30
BASHRC_ENV_NAMES = ("AK", "SK")


def load_shell_env(names: tuple[str, ...] = BASHRC_ENV_NAMES) -> None:
    missing = [name for name in names if not os.getenv(name, "").strip()]
    if not missing:
        return
    for config_path in (
        os.path.expanduser("~/.bashrc"),
        os.path.expanduser("~/.zshrc"),
        os.path.expanduser("~/.profile"),
    ):
        config = Path(config_path)
        if not config.is_file():
            continue
        config_quoted = shlex.quote(str(config))
        shell = "zsh" if config.name.endswith("zshrc") else "bash"
        for name in list(missing):
            try:
                completed = subprocess.run(
                    [
                        shell,
                        "-lc",
                        "set -a; source %s >/dev/null 2>&1; set +a; printf '%%s' \"${%s:-}\""
                        % (config_quoted, name),
                    ],
                    capture_output=True,
                    text=True,
                    timeout=15,
                    check=False,
                )
            except (OSError, subprocess.TimeoutExpired):
                continue
            value = (completed.stdout or "").strip()
            if value:
                os.environ[name] = value
                missing.remove(name)
        if not missing:
            return


def parse_csv_values(raw: str) -> list[str]:
    return [item.strip() for item in (raw or "").split(",") if item.strip()]


def create_api_instance(region: str) -> volcenginesdkecs.ECSApi:
    ak = os.getenv("AK", "").strip()
    sk = os.getenv("SK", "").strip()
    if not ak or not sk:
        raise SystemExit("缺少 AK/SK，请设置环境变量或写入 ~/.bashrc")
    configuration = volcenginesdkcore.Configuration()
    configuration.ak = ak
    configuration.sk = sk
    configuration.region = region
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkecs.ECSApi()


def build_allocate_instances_request(args: argparse.Namespace) -> volcenginesdkecs.AllocateInstancesRequest:
    network_interfaces = [
        volcenginesdkecs.NetworkInterfaceForAllocateInstancesInput(
            security_group_ids=args.security_group_ids,
            subnet_id=args.subnet_ids,
        )
    ]
    volumes = [
        volcenginesdkecs.VolumeForAllocateInstancesInput(
            size=args.volume_size,
        )
    ]
    request_kwargs: dict[str, Any] = {
        "batch_create_in_multi_zone": args.batch_create_in_multi_zone,
        "count": args.count,
        "image_id": args.image_id,
        "instance_name": args.instance_name,
        "instance_type_id": args.instance_type_id,
        "keep_image_credential": args.keep_image_credential,
        "install_run_command_agent": args.install_run_command_agent,
        "network_interfaces": network_interfaces,
        "volumes": volumes,
        "project_name": args.project_name,
        "client_token": str(uuid.uuid4()),
    }
    if args.dry_run:
        request_kwargs["dry_run"] = True
    if args.password:
        request_kwargs["password"] = args.password
        request_kwargs["keep_image_credential"] = False
    if args.zone_id:
        request_kwargs["zone_id"] = args.zone_id
        request_kwargs["batch_create_in_multi_zone"] = False
    if args.unique_suffix:
        request_kwargs["unique_suffix"] = True
    return volcenginesdkecs.AllocateInstancesRequest(**request_kwargs)


def api_exception_message(exc: ApiException) -> str:
    body = getattr(exc, "body", None)
    if not body:
        return str(exc)
    try:
        data = json.loads(body)
    except (TypeError, ValueError):
        return str(body)
    metadata = data.get("ResponseMetadata") or {}
    error = metadata.get("Error") or data.get("Error") or {}
    code = error.get("Code") or ""
    message = error.get("Message") or ""
    if code or message:
        return "%s: %s" % (code, message)
    return json.dumps(data, ensure_ascii=False)


def extract_instance_ids(response: Any) -> list[str]:
    result = get_result_payload(to_plain_dict(response))
    operation_details = result.get("OperationDetails") or result.get("operation_details") or []
    instance_ids: list[str] = []
    for detail in operation_details:
        if not isinstance(detail, dict):
            continue
        for instance_id in detail.get("InstanceIds") or detail.get("instance_ids") or []:
            value = str(instance_id or "").strip()
            if value:
                instance_ids.append(value)
    return instance_ids


def describe_instance(api_instance: volcenginesdkecs.ECSApi, instance_id: str) -> dict[str, Any]:
    response = api_instance.describe_instances(
        volcenginesdkecs.DescribeInstancesRequest(instance_ids=[instance_id])
    )
    result = get_result_payload(to_plain_dict(response))
    instances = result.get("Instances") or result.get("instances") or []
    if not instances:
        raise RuntimeError("DescribeInstances 没有查询到实例: %s" % instance_id)
    return instances[0]


def instance_status(instance: dict[str, Any]) -> str:
    return str(instance.get("Status") or instance.get("status") or "")


def wait_for_instance_status(
    api_instance: volcenginesdkecs.ECSApi,
    instance_id: str,
    *,
    expected_status: str,
    timeout_seconds: int,
    poll_interval_seconds: int,
) -> dict[str, Any]:
    deadline = time.time() + timeout_seconds
    last_status = ""
    while time.time() < deadline:
        instance = describe_instance(api_instance, instance_id)
        last_status = instance_status(instance)
        print("实例 %s 当前状态: %s" % (instance_id, last_status), flush=True)
        if last_status == expected_status:
            return instance
        if last_status in ("ERROR", "FAILED"):
            raise RuntimeError("实例创建失败: %s status=%s" % (instance_id, last_status))
        time.sleep(poll_interval_seconds)
    raise TimeoutError(
        "等待实例状态超时: %s expected=%s last_status=%s" % (instance_id, expected_status, last_status)
    )


def print_operation_details(response: Any) -> None:
    result = get_result_payload(to_plain_dict(response))
    operation_details = result.get("OperationDetails") or result.get("operation_details") or []
    if not operation_details:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    for detail in operation_details:
        zone_id = detail.get("ZoneId") or detail.get("zone_id") or ""
        instance_ids = detail.get("InstanceIds") or detail.get("instance_ids") or []
        preorder_ids = detail.get("PreorderIds") or detail.get("preorder_ids") or []
        error = detail.get("Error") or detail.get("error") or {}
        print(
            "zone=%s instance_ids=%s preorder_ids=%s error=%s"
            % (zone_id, instance_ids, preorder_ids, error or "NA"),
            flush=True,
        )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="通过 AllocateInstances 批量创建多可用区 ECS 实例")
    parser.add_argument("--region", default=os.getenv("VOLCENGINE_REGION", DEFAULT_REGION))
    parser.add_argument("--image-id", default=os.getenv("IMAGE_ID", DEFAULT_IMAGE_ID))
    parser.add_argument("--instance-name", default=os.getenv("INSTANCE_NAME", DEFAULT_INSTANCE_NAME))
    parser.add_argument("--instance-type-id", default=os.getenv("INSTANCE_TYPE_ID", DEFAULT_INSTANCE_TYPE_ID))
    parser.add_argument("--count", type=int, default=int(os.getenv("INSTANCE_COUNT", str(DEFAULT_COUNT))))
    parser.add_argument("--volume-size", type=int, default=int(os.getenv("VOLUME_SIZE", str(DEFAULT_VOLUME_SIZE))))
    parser.add_argument("--project-name", default=os.getenv("PROJECT_NAME", DEFAULT_PROJECT_NAME))
    parser.add_argument(
        "--security-group-ids",
        default=os.getenv("SECURITY_GROUP_ID", DEFAULT_SECURITY_GROUP_ID),
        help="逗号分隔的安全组 ID",
    )
    parser.add_argument(
        "--subnet-ids",
        default=os.getenv("SUBNET_IDS", ",".join(DEFAULT_SUBNET_IDS)),
        help="逗号分隔的子网 ID（多可用区批量创建时传多个）",
    )
    parser.add_argument(
        "--zone-id",
        default=os.getenv("ZONE_ID", ""),
        help="指定单可用区时设置；设置后会关闭 batch_create_in_multi_zone",
    )
    multi_zone_default = os.getenv("BATCH_CREATE_IN_MULTI_ZONE", "1").lower() not in ("0", "false", "no", "off")
    keep_credential_default = os.getenv("KEEP_IMAGE_CREDENTIAL", "1").lower() not in ("0", "false", "no", "off")
    install_agent_default = os.getenv("INSTALL_RUN_COMMAND_AGENT", "1").lower() not in ("0", "false", "no", "off")
    parser.set_defaults(
        batch_create_in_multi_zone=multi_zone_default,
        keep_image_credential=keep_credential_default,
        install_run_command_agent=install_agent_default,
    )
    parser.add_argument("--batch-create-in-multi-zone", dest="batch_create_in_multi_zone", action="store_true")
    parser.add_argument("--no-batch-create-in-multi-zone", dest="batch_create_in_multi_zone", action="store_false")
    parser.add_argument("--keep-image-credential", dest="keep_image_credential", action="store_true")
    parser.add_argument("--no-keep-image-credential", dest="keep_image_credential", action="store_false")
    parser.add_argument("--password", default=os.getenv("INSTANCE_PASSWORD", ""), help="设置后会覆盖 keep_image_credential")
    parser.add_argument("--unique-suffix", action="store_true", help="为实例名追加唯一后缀")
    parser.add_argument("--install-run-command-agent", dest="install_run_command_agent", action="store_true")
    parser.add_argument(
        "--no-install-run-command-agent",
        dest="install_run_command_agent",
        action="store_false",
        help="创建时不安装 Cloud Assistant（默认安装）",
    )
    parser.add_argument("--dry-run", action="store_true", help="仅校验参数，不实际创建")
    parser.add_argument("--wait", action="store_true", help="等待所有实例达到目标状态")
    parser.add_argument("--ready-status", default=os.getenv("INSTANCE_READY_STATUS", DEFAULT_READY_STATUS))
    parser.add_argument(
        "--create-timeout-seconds",
        type=int,
        default=int(os.getenv("INSTANCE_CREATE_TIMEOUT_SECONDS", str(DEFAULT_CREATE_TIMEOUT_SECONDS))),
    )
    parser.add_argument(
        "--poll-interval-seconds",
        type=int,
        default=int(os.getenv("POLL_INTERVAL_SECONDS", str(DEFAULT_POLL_INTERVAL_SECONDS))),
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    load_shell_env()
    parser = build_parser()
    args = parser.parse_args(argv)
    args.security_group_ids = parse_csv_values(args.security_group_ids)
    args.subnet_ids = parse_csv_values(args.subnet_ids)
    if not args.security_group_ids:
        raise SystemExit("至少需要一个 security group id")
    if not args.subnet_ids:
        raise SystemExit("至少需要一个 subnet id")
    if args.count < 1:
        raise SystemExit("--count 必须 >= 1")

    api_instance = create_api_instance(args.region)
    request = build_allocate_instances_request(args)
    print(
        "AllocateInstances: region=%s count=%s image_id=%s instance_name=%s instance_type_id=%s subnets=%s dry_run=%s"
        % (
            args.region,
            args.count,
            args.image_id,
            args.instance_name,
            args.instance_type_id,
            ",".join(args.subnet_ids),
            args.dry_run,
        ),
        flush=True,
    )
    try:
        response = api_instance.allocate_instances(request)
    except ApiException as exc:
        print("AllocateInstances 失败: %s" % api_exception_message(exc), flush=True)
        return 1

    print_operation_details(response)
    instance_ids = extract_instance_ids(response)
    if instance_ids:
        print("WORKFLOWGYM_ALLOCATED_INSTANCE_IDS", instance_ids, flush=True)
    else:
        print("AllocateInstances 未返回 InstanceIds，请检查 OperationDetails", flush=True)

    if args.wait and instance_ids and not args.dry_run:
        for instance_id in instance_ids:
            instance = wait_for_instance_status(
                api_instance,
                instance_id,
                expected_status=args.ready_status,
                timeout_seconds=args.create_timeout_seconds,
                poll_interval_seconds=args.poll_interval_seconds,
            )
            print(
                "实例就绪: id=%s name=%s status=%s zone=%s image=%s"
                % (
                    instance_id,
                    instance.get("InstanceName") or instance.get("instance_name") or "",
                    instance_status(instance),
                    instance.get("ZoneId") or instance.get("zone_id") or "",
                    instance.get("ImageId") or instance.get("image_id") or "",
                ),
                flush=True,
            )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
