#!/usr/bin/env python3
"""按 Ve8a1Q.C 与 PtDat4.Z 一致，将 Ve8a1Q.E 写入 PtDat4.AA 并标绿。"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.feishu_client import FeishuClient, column_to_number
from open_workflowgym.local_spreadsheet import feishu_credentials_configured
from open_workflowgym.tools.match_feishu_image_ids import (
    cell_address,
    cell_value,
    load_bashrc_env,
    read_sheet_rows_chunked,
    resolve_spreadsheet_token,
    write_single_cell_value,
)

DEFAULT_WIKI_URL = os.getenv("FEISHU_WIKI_URL", "https://example.feishu.local/wiki/PLACEHOLDER")
DEFAULT_SOURCE_SHEET_ID = "Ve8a1Q"
DEFAULT_TARGET_SHEET_ID = "PtDat4"
SOURCE_MATCH_COLUMN = column_to_number("C") - 1
SOURCE_VALUE_COLUMN = column_to_number("E") - 1
TARGET_MATCH_COLUMN = column_to_number("Z") - 1
TARGET_VALUE_COLUMN = column_to_number("AA") - 1
UPDATED_BACK_COLOR = "#d9f7be"
IMAGE_ID_SPLIT_PATTERN = re.compile(r"[,，;；]+")


def parse_image_ids(value: object) -> list[str]:
    text = str(value or "").strip()
    if not text:
        return []
    return [part.strip() for part in IMAGE_ID_SPLIT_PATTERN.split(text) if part.strip()]


def sheet_cell_range(sheet_id: str, row_index: int, column_index: int) -> str:
    address = cell_address(row_index, column_index)
    return "%s!%s:%s" % (sheet_id, address, address)


def build_image_id_lookup(rows: list[list[Any]]) -> dict[str, str]:
    lookup: dict[str, str] = {}
    for row_index, row in enumerate(rows):
        if row_index == 0:
            continue
        image_id = cell_value(row, SOURCE_VALUE_COLUMN)
        if not image_id:
            continue
        for match_image_id in parse_image_ids(cell_value(row, SOURCE_MATCH_COLUMN)):
            lookup[match_image_id] = image_id
    return lookup


def find_updates(
    target_rows: list[list[Any]],
    lookup: dict[str, str],
) -> list[dict[str, Any]]:
    updates: list[dict[str, Any]] = []
    for row_index, row in enumerate(target_rows):
        if row_index == 0:
            continue
        match_image_id = cell_value(row, TARGET_MATCH_COLUMN)
        if not match_image_id:
            continue
        expected_image_id = lookup.get(match_image_id, "")
        if not expected_image_id:
            continue
        current_value = cell_value(row, TARGET_VALUE_COLUMN)
        if current_value == expected_image_id:
            continue
        updates.append(
            {
                "row_index": row_index,
                "match_image_id": match_image_id,
                "current_value": current_value,
                "expected_value": expected_image_id,
            }
        )
    return updates


def apply_updates(
    client: FeishuClient,
    spreadsheet_token: str,
    sheet_id: str,
    updates: list[dict[str, Any]],
    *,
    dry_run: bool = False,
) -> dict[str, Any]:
    updated_ranges: list[str] = []
    failed_updates: list[dict[str, Any]] = []

    for item in updates:
        row_index = int(item["row_index"])
        expected_value = str(item["expected_value"])
        cell_range = sheet_cell_range(sheet_id, row_index, TARGET_VALUE_COLUMN)
        if dry_run:
            updated_ranges.append(cell_range)
            continue
        try:
            write_single_cell_value(
                client,
                spreadsheet_token,
                sheet_id,
                row_index,
                TARGET_VALUE_COLUMN,
                expected_value,
            )
            client.set_cells_background(
                spreadsheet_token,
                [cell_range],
                back_color=UPDATED_BACK_COLOR,
            )
            updated_ranges.append(cell_range)
        except Exception as exc:
            failed_updates.append({**item, "error": str(exc)})

    return {
        "updated_count": len(updated_ranges),
        "failed_count": len(failed_updates),
        "updated_ranges": updated_ranges,
        "failed_updates": failed_updates,
    }


def run_sync(
    client: FeishuClient,
    *,
    wiki_url: str = DEFAULT_WIKI_URL,
    source_sheet_id: str = DEFAULT_SOURCE_SHEET_ID,
    target_sheet_id: str = DEFAULT_TARGET_SHEET_ID,
    dry_run: bool = False,
) -> dict[str, Any]:
    spreadsheet_token = resolve_spreadsheet_token(client, wiki_url)
    source_rows = read_sheet_rows_chunked(client, spreadsheet_token, source_sheet_id)
    target_rows = read_sheet_rows_chunked(client, spreadsheet_token, target_sheet_id)
    lookup = build_image_id_lookup(source_rows)
    updates = find_updates(target_rows, lookup)
    apply_result = apply_updates(
        client,
        spreadsheet_token,
        target_sheet_id,
        updates,
        dry_run=dry_run,
    )

    matched_count = 0
    consistent_count = 0
    for row_index, row in enumerate(target_rows):
        if row_index == 0:
            continue
        match_image_id = cell_value(row, TARGET_MATCH_COLUMN)
        if not match_image_id or match_image_id not in lookup:
            continue
        matched_count += 1
        if cell_value(row, TARGET_VALUE_COLUMN) == lookup[match_image_id]:
            consistent_count += 1

    return {
        "spreadsheet_token": spreadsheet_token,
        "source_sheet_id": source_sheet_id,
        "target_sheet_id": target_sheet_id,
        "source_rows": len(source_rows),
        "target_rows": len(target_rows),
        "lookup_count": len(lookup),
        "matched_count": matched_count,
        "consistent_count": consistent_count,
        "need_update_count": len(updates),
        "preview_updates": updates[:10],
        **apply_result,
    }


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="按 Ve8a1Q.C 与 PtDat4.Z 一致，将 Ve8a1Q.E 写入 PtDat4.AA 并标绿"
    )
    parser.add_argument("--wiki-url", default=DEFAULT_WIKI_URL)
    parser.add_argument("--source-sheet-id", default=DEFAULT_SOURCE_SHEET_ID)
    parser.add_argument("--target-sheet-id", default=DEFAULT_TARGET_SHEET_ID)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--bashrc", default="")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    load_bashrc_env(bashrc_path=args.bashrc)
    if not feishu_credentials_configured():
        print("缺少 APP_ID 或 APP_SECRET，请确认已写入 ~/.bashrc 或当前环境变量", file=sys.stderr)
        return 1

    client = FeishuClient(dry_run=False)
    result = run_sync(
        client,
        wiki_url=args.wiki_url,
        source_sheet_id=args.source_sheet_id,
        target_sheet_id=args.target_sheet_id,
        dry_run=args.dry_run,
    )

    print("PtDat4 AA 列同步完成")
    print("  source sheet: %s (%s 行)" % (result["source_sheet_id"], result["source_rows"]))
    print("  target sheet: %s (%s 行)" % (result["target_sheet_id"], result["target_rows"]))
    print("  Ve8a1Q C->E 映射: %s" % result["lookup_count"])
    print("  Z 列匹配行数: %s" % result["matched_count"])
    print("  已一致行数: %s" % result["consistent_count"])
    print("  需更新行数: %s" % result["need_update_count"])
    if args.dry_run:
        print("预览前 10 条待更新:")
        for item in result["preview_updates"]:
            print(
                "  row=%s Z=%s AA: %s -> %s"
                % (
                    item["row_index"] + 1,
                    item["match_image_id"],
                    item["current_value"] or "(空)",
                    item["expected_value"],
                )
            )
    else:
        print("  已更新: %s" % result["updated_count"])
        print("  更新失败: %s" % result["failed_count"])
        if result["failed_updates"]:
            for item in result["failed_updates"][:5]:
                print("  失败 row=%s error=%s" % (item["row_index"] + 1, item["error"]))
        print(
            "已写入: %s?sheet=%s"
            % (args.wiki_url.split("?")[0], result["target_sheet_id"])
        )
    return 0 if result["failed_count"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
