from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from .records import TaskRecord, ValidationResult


ValidationRule = Callable[[TaskRecord], str]


@dataclass(frozen=True)
class FieldRuleConfig:
    name: str
    enabled: bool = True


def validate_task(record: TaskRecord, rules: list[ValidationRule] | None = None) -> ValidationResult:
    active_rules = rules or default_rules()
    failures = [message for rule in active_rules if (message := rule(record))]
    if failures:
        return ValidationResult(
            run_id=record.run_id,
            task_id=record.task_id,
            row_number=record.row_number,
            passed=False,
            status="失败",
            reason="; ".join(failures),
        )
    return ValidationResult(
        run_id=record.run_id,
        task_id=record.task_id,
        row_number=record.row_number,
        passed=True,
        status="通过",
    )


def default_rules() -> list[ValidationRule]:
    return [
        require_task_id,
        require_image_id,
    ]


def require_task_id(record: TaskRecord) -> str:
    return "" if record.task_id else "缺少任务 ID"


def require_image_id(record: TaskRecord) -> str:
    return "" if record.image_id else "缺少镜像 ID"

