from __future__ import annotations

import datetime as _dt
import json
import uuid
from dataclasses import asdict, dataclass, field, is_dataclass
from typing import Any


def now_text() -> str:
    return _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def new_id(prefix: str) -> str:
    return "%s-%s" % (prefix, uuid.uuid4().hex)


def to_jsonable(value: Any) -> Any:
    if is_dataclass(value):
        return {key: to_jsonable(item) for key, item in asdict(value).items()}
    if isinstance(value, dict):
        return {str(key): to_jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [to_jsonable(item) for item in value]
    return value


def json_dumps(value: Any) -> str:
    return json.dumps(to_jsonable(value), ensure_ascii=False, sort_keys=True)


@dataclass(frozen=True)
class RunConfig:
    run_id: str
    source_feishu_url: str = ""
    source_csv_path: str = ""
    report_csv_dir: str = ""
    task_replay_db: str = ""
    target_id: str = ""
    sample_num: int = 1
    step_num: int = 400
    player: str = "gpt"
    judger: str = "gemini3.1"
    max_workers: int = 20
    validate: bool = True
    start_row: int = 2
    source_range: str = ""
    output_root: str = ""
    state_db_path: str = ""
    dry_run: str = ""
    enable_real_feishu: bool = False
    enable_real_cloud: bool = False
    region: str = "cn-beijing"
    demo_image_id: str = "image-demo"
    discover_instance_name_prefix: str = "workflow_gym"
    discover_project_name: str = ""
    discover_instance_limit: int = 30
    discover_probe_max_workers: int = 8
    resume_running_samples: bool = False
    recover_instances: bool = True
    auto_reset_unknown_instances: bool = False
    force_reset_instances: bool = False
    instance_ids: tuple[str, ...] = ()
    tos_output_prefix: str = ""
    prefetch_rows: int = 100
    max_pending_samples: int = 200
    model_call_timeout_seconds: int = 300
    action_timeout_seconds: int = 60
    max_no_action_seconds: int = 1800
    input_download_timeout_seconds: int = 300
    tosutil_timeout_seconds: int = 300
    max_memory_usage_percent: float = 85.0
    min_available_memory_mb: int = 1024
    max_worker_processes: int = 64
    min_free_disk_gb: float = 20.0
    max_run_dir_gb: float = 200.0
    max_sample_dir_mb: float = 2048.0
    screenshot_retention_policy: str = "all"
    screenshot_retention_every_n: int = 5
    verbose_steps: bool = False
    write_step_traj: bool = False
    lease_ttl_seconds: int = 3600
    lease_backend: str = "local"
    remote_action_delivery: str = "wgm-direct"
    wgm_api_base: str = ""
    wgm_token: str = ""
    fail_on_unknown_platform: bool = True
    sample_init_timeout_seconds: int = 3600
    model_lease_heartbeat_min_seconds: int = 600
    sample_future_max_seconds: int = 10800


@dataclass
class TaskRecord:
    run_id: str
    task_id: str
    row_number: int
    fields: dict[str, Any]

    @property
    def image_id(self) -> str:
        return str(self.fields.get("image") or self.fields.get("image_id") or self.fields.get("镜像ID") or "")

    @property
    def input_path(self) -> str:
        return normalize_optional_text(self.fields.get("输入文件路径") or self.fields.get("input_path") or "")

    @property
    def output_path(self) -> str:
        return normalize_optional_text(self.fields.get("输出文件路径") or self.fields.get("output_path") or "")

    @property
    def final_answer_names(self) -> str:
        return normalize_optional_text(self.fields.get("final_answer文件名") or self.fields.get("final_answer_names") or "")

    @property
    def tos_url(self) -> Any:
        return self.fields.get("tos_url") or self.fields.get("TOS_URL") or ""

    @property
    def final_answer_urls(self) -> Any:
        return self.fields.get("final answer 文件") or self.fields.get("final_answer_urls") or ""

    @property
    def metric_type(self) -> str:
        return normalize_optional_text(self.fields.get("metric_type") or self.fields.get("判分类型") or "")


@dataclass
class ValidationResult:
    run_id: str
    task_id: str
    row_number: int
    passed: bool
    status: str
    reason: str = ""


@dataclass
class InstanceLease:
    run_id: str
    lease_id: str
    instance_id: str
    task_id: str
    sample_index: int
    status: str
    acquired_at: str
    expires_at: str = ""
    released_at: str = ""
    reserved_eip_allocation_id: str = ""
    reserved_eip_address: str = ""


@dataclass
class SampleJob:
    run_id: str
    task_id: str
    sample_index: int
    task: TaskRecord
    config: RunConfig
    lease: InstanceLease | None = None


@dataclass
class PromptBundle:
    sp: str = ""
    up: str = ""
    tool_calls: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class StepTrace:
    step_index: int
    screenshot: str
    response: str = ""
    thought: str = ""
    function_call: Any = None
    transformed_function_call: Any = None
    executed_code: list[str] = field(default_factory=list)
    action_summaries: list[dict[str, Any]] = field(default_factory=list)
    error: str = ""
    timestamp: str = field(default_factory=now_text)


@dataclass
class TaskFileResult:
    input_urls: list[str] = field(default_factory=list)
    input_downloads: list[dict[str, Any]] = field(default_factory=list)
    final_answer_files: list[str] = field(default_factory=list)
    output_uploads: list[dict[str, Any]] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


@dataclass
class TrajectoryResult:
    run_id: str
    task_id: str
    sample_index: int
    status: str
    sample_dir: str
    traj_json_path: str
    traj_md_path: str
    id_json_path: str
    sample_status_path: str
    last_step: int = -1
    error: str = ""
    task_files: TaskFileResult = field(default_factory=TaskFileResult)
    task_fields: dict[str, Any] = field(default_factory=dict)


def normalize_optional_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        if not value:
            return ""
        return ",".join(str(item).strip() for item in value if str(item).strip())
    text = str(value).strip()
    return "" if text in ("[]", "null", "None") else text


@dataclass
class ScoreResult:
    run_id: str
    task_id: str
    sample_index: int
    score_json_path: str
    saved_at: str
    check: dict[str, Any]
    vm_screen_pixel_size: dict[str, Any] = field(default_factory=dict)
    task_fields: dict[str, Any] = field(default_factory=dict)


@dataclass
class OutboxEvent:
    run_id: str
    event_id: str
    event_type: str
    payload: dict[str, Any]
    task_id: str = ""
    sample_index: int | None = None
    schema_version: int = 1
    idempotency_key: str = ""
    created_at: str = field(default_factory=now_text)

