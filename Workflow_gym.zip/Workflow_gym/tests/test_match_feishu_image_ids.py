from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.tools.match_feishu_image_ids import (
    NOT_FOUND_LABEL,
    build_image_id_lookup,
    build_output_rows,
    flatten_cell_text,
    format_matched_image_ids,
    normalize_image_key,
    should_skip_lookup_image,
)


class MatchFeishuImageIdsTest(unittest.TestCase):
    def test_normalize_image_key(self):
        name = "preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-ye515ftkhsqc6iktcidr"
        self.assertEqual(normalize_image_key(name), "preview-Ubuntu2204_64-weka")

    def test_normalize_image_key_preview_windows2022(self):
        name = "preview-windows2022-ECS-uY0v-initv1-20251201"
        self.assertEqual(normalize_image_key(name), "preview-windows2022-ECS-uY0v")

    def test_normalize_image_key_stable_windows2022(self):
        name = "stable-windows2022-ECS-fMRu01-initv1-20251201"
        self.assertEqual(normalize_image_key(name), "stable-windows2022-ECS")

    def test_normalize_image_key_preview_windows2022_paint_net(self):
        rich_name = [
            {"text": "preview-windows2022-Paint.NET", "type": "url"},
            {"text": "-initv5.1.11-20260126", "type": "text"},
        ]
        self.assertEqual(
            normalize_image_key(rich_name),
            "preview-windows2022-Paint.NET-initv5.1.11",
        )

    def test_flatten_cell_text(self):
        rich_name = [
            {"text": "preview-windows2022-Paint.NET", "type": "url"},
            {"text": "-initv5.1.11-20260126", "type": "text"},
        ]
        self.assertEqual(
            flatten_cell_text(rich_name),
            "preview-windows2022-Paint.NET-initv5.1.11-20260126",
        )

    def test_normalize_image_key_qcow2_suffix(self):
        self.assertEqual(normalize_image_key("abc-xxx-yyy"), "abc-xxx-yyy")
        self.assertEqual(normalize_image_key("abc-xxx-yyy.qcow2"), "abc-xxx-yyy")

    def test_normalize_image_key_strips_qcow2_bj_and_bj_gui(self):
        self.assertEqual(
            normalize_image_key("preview-Ubuntu2204_64-weka-v3.8.6-move.qcow2_bj"),
            "preview-Ubuntu2204_64-weka",
        )
        self.assertEqual(
            normalize_image_key("ubuntu-bios-init-20251009-haojun_bj_gui"),
            "ubuntu-bios-init",
        )

    def test_build_output_rows_skips_qcow2_lookup_name(self):
        source_rows = [
            ["序号", "名称", "备注", "源镜像名"],
            ["1", "a", "x", "abc-xxx-yyy"],
        ]
        lookup_rows = [
            ["", "镜像名", "", "", "", "", "镜像id"],
            self._lookup_row("abc-xxx-yyy.qcow2", "image-abc"),
        ]
        output_rows = build_output_rows(source_rows, lookup_rows, matched_header="镜像id")
        self.assertEqual(output_rows[1][4], NOT_FOUND_LABEL)

    def test_should_skip_qcow2_lookup(self):
        self.assertTrue(should_skip_lookup_image("demo-image.qcow2"))
        self.assertTrue(should_skip_lookup_image("demo-image.QCOW2"))

    def test_should_skip_pcow2(self):
        self.assertTrue(should_skip_lookup_image("demo-image.pcow2"))
        self.assertFalse(should_skip_lookup_image("preview-Ubuntu2204_64-weka-v3.8.6"))

    def test_should_skip_qcow2_bj(self):
        self.assertFalse(should_skip_lookup_image("demo-image.qcow2_bj"))
        self.assertFalse(should_skip_lookup_image("demo-image.QCOW2_BJ"))
        self.assertFalse(should_skip_lookup_image("preview-windows2022-ECS-uY0v-initv1"))

    def _lookup_row(self, image_name: str, image_id: str) -> list[str]:
        row = [""] * 7
        row[1] = image_name
        row[6] = image_id
        return row

    def test_build_image_id_lookup_preview_windows2022(self):
        lookup_rows = [
            ["", "镜像名", "", "", "", "", "镜像id"],
            self._lookup_row(
                "preview-windows2022-ECS-uY0v-initv1-20251201_i-abc",
                "image-win-preview",
            ),
            self._lookup_row(
                "preview-windows2022-ECS-uY0v-other-20251201_i-def",
                "image-win-preview-2",
            ),
            self._lookup_row(
                "preview-windows2022-ECS-other-initv1-20251201_i-xyz",
                "image-other-ecs",
            ),
        ]
        lookup = build_image_id_lookup(lookup_rows)
        self.assertEqual(
            lookup["preview-windows2022-ECS-uY0v"],
            ["image-win-preview", "image-win-preview-2"],
        )
        self.assertEqual(lookup["preview-windows2022-ECS-other"], ["image-other-ecs"])

    def test_build_output_rows_preview_windows2022(self):
        source_rows = [
            ["序号", "名称", "备注", "源镜像名"],
            ["1", "a", "x", "preview-windows2022-ECS-uY0v-initv1-20251201"],
        ]
        lookup_rows = [
            ["", "镜像名", "", "", "", "", "镜像id"],
            self._lookup_row(
                "preview-windows2022-ECS-uY0v-initv1-20251201_i-abc",
                "image-win-preview",
            ),
        ]
        output_rows = build_output_rows(source_rows, lookup_rows, matched_header="镜像id")
        self.assertEqual(output_rows[1][4], "image-win-preview")

    def test_build_image_id_lookup(self):
        lookup_rows = [
            ["", "镜像名", "", "", "", "", "镜像id"],
            self._lookup_row("preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-abc", "image-abc"),
            self._lookup_row("preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-def", "image-def"),
            self._lookup_row("ignored.pcow2", "image-skip"),
        ]
        lookup = build_image_id_lookup(lookup_rows)
        self.assertEqual(
            lookup["preview-Ubuntu2204_64-weka"],
            ["image-abc", "image-def"],
        )

    def test_format_matched_image_ids(self):
        self.assertEqual(format_matched_image_ids([]), NOT_FOUND_LABEL)
        self.assertEqual(format_matched_image_ids(["image-a"]), "image-a")
        self.assertEqual(format_matched_image_ids(["image-a", "image-b"]), "image-a,image-b")

    def test_build_output_rows_matches_qcow2_bj_after_strip(self):
        source_rows = [
            ["序号", "名称", "备注", "源镜像名"],
            ["1", "a", "x", "preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-abc"],
            ["2", "b", "y", "preview-Ubuntu2204_64-weka-v3.8.6-move.qcow2_bj"],
        ]
        lookup_rows = [
            ["", "镜像名", "", "", "", "", "镜像id"],
            self._lookup_row("preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-abc", "image-abc"),
            self._lookup_row("preview-Ubuntu2204_64-weka-v3.8.6-move.qcow2_bj", "image-bj"),
        ]
        output_rows = build_output_rows(source_rows, lookup_rows, matched_header="镜像id")
        self.assertEqual(len(output_rows), 3)
        self.assertEqual(output_rows[1][4], "image-abc,image-bj")
        self.assertEqual(output_rows[2][4], "image-abc,image-bj")

    def test_build_output_rows_matches_bj_gui_after_strip(self):
        source_rows = [
            ["序号", "名称", "备注", "源镜像名"],
            ["1", "a", "x", "ubuntu-bios-init-20251009-haojun_bj_gui"],
        ]
        lookup_rows = [
            ["", "镜像名", "", "", "", "", "镜像id"],
            self._lookup_row("ubuntu-bios-init-20251009-other", "image-gui"),
        ]
        output_rows = build_output_rows(source_rows, lookup_rows, matched_header="镜像id")
        self.assertEqual(output_rows[1][4], "image-gui")

    def test_build_output_rows_inserts_column_e(self):
        source_rows = [
            ["序号", "名称", "备注", "源镜像名"],
            ["1", "a", "x", "preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-abc"],
            ["2", "b", "y", "preview-Ubuntu2204_64-unknown-v1.0.0"],
        ]
        lookup_rows = [
            ["", "镜像名", "", "", "", "", "镜像id"],
            self._lookup_row("preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-abc", "image-abc"),
            self._lookup_row("preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-def", "image-def"),
        ]
        output_rows = build_output_rows(source_rows, lookup_rows, matched_header="镜像id")
        self.assertEqual(output_rows[0], ["序号", "名称", "备注", "源镜像名", "镜像id"])
        self.assertEqual(output_rows[1][4], "image-abc,image-def")
        self.assertEqual(output_rows[2][4], NOT_FOUND_LABEL)


if __name__ == "__main__":
    unittest.main()
