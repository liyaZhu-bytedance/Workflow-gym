from __future__ import annotations

import base64
import json
import sys
import types
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = Path("/tmp/owg_path_sampler_outputs")
PACKAGE_ROOT.mkdir(parents=True, exist_ok=True)
link = PACKAGE_ROOT / "open_workflowgym"
if link.exists() or link.is_symlink():
    link.unlink()
link.symlink_to(REPO_ROOT)
sys.path.insert(0, str(PACKAGE_ROOT))

if "PIL" not in sys.modules:
    pil_module = types.ModuleType("PIL")
    pil_image_module = types.ModuleType("PIL.Image")
    pil_module.Image = pil_image_module
    sys.modules["PIL"] = pil_module
    sys.modules["PIL.Image"] = pil_image_module

from open_workflowgym.records import InstanceLease, RunConfig, SampleJob, TaskRecord
from open_workflowgym.sampler import (
    Sampler,
    build_output_file_check_command,
    build_sample_tos_prefix,
    command_succeeded,
    format_step_prompt_snapshot,
    output_source_paths,
    parse_output_file_check_marker,
    parse_tos_presign_markers,
)


class SamplerOutputsTest(unittest.TestCase):
    def test_parse_tos_presign_markers_from_run_command_output(self):
        raw_output = (
            "upload ok\n"
            "WORKFLOWGYM_TOS_PRESIGN\tresult.csv\thttps://bucket.tos-cn-beijing.volces.com/result.csv?x=1\n"
        )
        command_result = {
            "results": [
                {
                    "Output": base64.b64encode(raw_output.encode("utf-8")).decode("ascii"),
                }
            ]
        }

        self.assertEqual(
            parse_tos_presign_markers(command_result),
            {"result.csv": "https://bucket.tos-cn-beijing.volces.com/result.csv?x=1"},
        )

    def test_parse_output_file_check_marker(self):
        raw_output = "WORKFLOWGYM_OUTPUT_FILE\tKKX.pdf\texists\t/home/user/Desktop/output/KKX.pdf\t123\n"
        command_result = {
            "results": [
                {
                    "InvocationResultStatus": "Success",
                    "ExitCode": 0,
                    "Output": base64.b64encode(raw_output.encode("utf-8")).decode("ascii"),
                }
            ]
        }

        marker = parse_output_file_check_marker(command_result, "KKX.pdf")

        self.assertTrue(marker["success"])
        self.assertTrue(marker["exists"])
        self.assertEqual(marker["relative_path"], "KKX.pdf")
        self.assertEqual(marker["source_path"], "/home/user/Desktop/output/KKX.pdf")
        self.assertEqual(marker["size"], 123)

    def test_parse_output_file_check_marker_legacy_backtick_t(self):
        raw_output = (
            "WORKFLOWGYM_OUTPUT_FILE`tuser.sql`texists`t"
            "C:\\Users\\Administrator\\Desktop\\output\\user.sql`t879\r\n"
        )
        command_result = {
            "results": [
                {
                    "InvocationResultStatus": "Success",
                    "ExitCode": 0,
                    "decoded_output": raw_output,
                }
            ]
        }
        marker = parse_output_file_check_marker(command_result, "user.sql")
        self.assertTrue(marker["exists"])
        self.assertEqual(marker["size"], 879)
        self.assertIn("user.sql", marker["source_path"])

    def test_collect_outputs_prefers_http_download_when_explicitly_enabled(self):
        import tempfile
        import os
        from unittest import mock

        content = b"CREATE TABLE user(id INT);\n"
        env = FakeHttpEnv(content, source_path=r"C:\Users\Administrator\Desktop\output\user.sql")
        sampler = Sampler(None, env)
        job = sample_job(final_answer_names="user.sql")
        object.__setattr__(job.config, "lease_backend", "redis")
        object.__setattr__(job.config, "remote_action_delivery", "wgm-direct")

        with mock.patch.dict(os.environ, {"WGM_FILE_COLLECT_VIA": "http"}, clear=False):
            with tempfile.TemporaryDirectory() as tmp:
                result = sampler.collect_outputs(job, sample_dir=tmp)
                local = Path(tmp) / "production" / "user.sql"
                self.assertTrue(local.is_file())
                self.assertEqual(local.read_bytes(), content)
                self.assertEqual(result.errors, [])
                self.assertEqual(result.output_uploads[0]["status"], "http_downloaded")
                self.assertTrue(result.output_uploads[0]["output_file_exists"])
                self.assertEqual(env.commands, [])
                self.assertEqual(env.download_calls, 1)

    def test_collect_outputs_redis_defaults_to_tosutil(self):
        env = FakeHttpEnv(b"should-not-use")
        env.results = [
            exists_check_result("KKX.pdf", 10),
            upload_result("KKX.pdf", "https://example.com/KKX.pdf?sig=1"),
        ]
        sampler = Sampler(None, env)
        job = sample_job(final_answer_names="KKX.pdf")
        object.__setattr__(job.config, "lease_backend", "redis")
        object.__setattr__(job.config, "remote_action_delivery", "wgm-direct")

        import os
        from unittest import mock

        with mock.patch.dict(os.environ, {"WGM_FILE_COLLECT_VIA": ""}, clear=False):
            os.environ.pop("WGM_FILE_COLLECT_VIA", None)
            result = sampler.collect_outputs(job, sample_dir="/tmp/unused")
        self.assertEqual(result.output_uploads[0]["status"], "uploaded")
        self.assertNotIn("http_download", result.output_uploads[0])
        self.assertEqual(len(env.commands), 2)
        self.assertEqual(env.download_calls, 0)

    def test_collect_outputs_falls_back_to_tosutil_when_http_fails(self):
        env = FakeHttpEnv(b"", fail=True)
        env.results = [
            exists_check_result("KKX.pdf", 10),
            upload_result("KKX.pdf", "https://example.com/KKX.pdf?sig=1"),
        ]
        sampler = Sampler(None, env)
        job = sample_job(final_answer_names="KKX.pdf")
        object.__setattr__(job.config, "lease_backend", "redis")
        object.__setattr__(job.config, "remote_action_delivery", "wgm-direct")

        import os
        from unittest import mock

        with mock.patch.dict(os.environ, {"WGM_FILE_COLLECT_VIA": "http"}, clear=False):
            result = sampler.collect_outputs(job, sample_dir="/tmp/unused")
        self.assertEqual(result.output_uploads[0]["status"], "uploaded")
        self.assertFalse(result.output_uploads[0]["http_download"]["success"])
        self.assertEqual(len(env.commands), 2)

    def test_command_succeeded_detects_failed_exit(self):
        self.assertFalse(
            command_succeeded(
                {
                    "results": [
                        {
                            "InvocationResultStatus": "Failed",
                            "ExitCode": 1,
                        }
                    ]
                }
            )
        )

    def test_collect_outputs_records_missing_file(self):
        sampler = Sampler(None, FakeEnv([missing_check_result("KKX.pdf")]))
        job = sample_job(final_answer_names="KKX.pdf")

        result = sampler.collect_outputs(job)

        self.assertEqual(result.final_answer_files, ["KKX.pdf"])
        self.assertEqual(len(result.output_uploads), 1)
        self.assertEqual(result.output_uploads[0]["status"], "missing")
        self.assertFalse(result.output_uploads[0]["output_file_exists"])
        self.assertIn("缺少 final answer 文件", result.errors[0])

    def test_collect_outputs_records_upload_result(self):
        sampler = Sampler(
            None,
            FakeEnv(
                [
                    exists_check_result("KKX.pdf", 10),
                    upload_result("KKX.pdf", "https://example.com/KKX.pdf?sig=1"),
                ]
            ),
        )
        job = sample_job(final_answer_names="KKX.pdf")

        result = sampler.collect_outputs(job)

        self.assertEqual(result.errors, [])
        self.assertEqual(len(result.output_uploads), 1)
        upload = result.output_uploads[0]
        self.assertEqual(upload["status"], "uploaded")
        self.assertTrue(upload["output_file_exists"])
        self.assertTrue(upload["file_check"]["success"])
        self.assertTrue(upload["tosutil_cp_result"]["success"])
        self.assertEqual(upload["tos_url"], "https://example.com/KKX.pdf?sig=1")
        self.assertEqual(upload["tos_path"], "tos://open-workflowgym-sample/output-test/1746/sample_1/production/KKX.pdf")

    def test_build_sample_tos_prefix_uses_task_sample_production_path(self):
        job = sample_job(final_answer_names="KKX.pdf")
        object.__setattr__(job.config, "output_root", "output/kimi_native_1746_visual_verify_rerun3")

        self.assertEqual(
            build_sample_tos_prefix(job),
            "tos://open-workflowgym-sample/kimi_native_1746_visual_verify_rerun3/1746/sample_1/production",
        )

    def test_format_step_prompt_snapshot_puts_each_history_step_on_its_own_line(self):
        formatted = format_step_prompt_snapshot(
            {
                "saved_at": "2026-07-14 14:57:05",
                "step_index": 10,
                "history": [
                    {"step_index": 0, "response": "step-0"},
                    {"step_index": 1, "response": "step-1"},
                ],
                "model_input": {"error": "demo"},
            }
        )

        self.assertIn('"history": [', formatted)
        self.assertIn('"step_index": 0', formatted)
        self.assertIn('"step_index": 1', formatted)
        parsed = json.loads(formatted)
        self.assertEqual(len(parsed["history"]), 2)

    def test_output_source_paths_checks_each_comma_separated_output_dir(self):
        output_path = "/home/user/Desktop/output/http_with_jpegs,/home/user/Desktop/output"
        self.assertEqual(
            output_source_paths(output_path, "image_hash.txt"),
            [
                "/home/user/Desktop/output/http_with_jpegs/image_hash.txt",
                "/home/user/Desktop/output/image_hash.txt",
            ],
        )

    def test_build_output_file_check_command_tries_all_output_dirs(self):
        output_path = "/home/user/Desktop/output/http_with_jpegs,/home/user/Desktop/output"
        command = build_output_file_check_command(output_path, "image_hash.txt")

        self.assertIn("/home/user/Desktop/output/http_with_jpegs/image_hash.txt", command)
        self.assertIn("/home/user/Desktop/output/image_hash.txt", command)

    def test_collect_outputs_uses_second_output_dir_for_task_173(self):
        sampler = Sampler(
            None,
            FakeEnv(
                [
                    exists_check_result(
                        "image_hash.txt",
                        42,
                        "/home/user/Desktop/output/image_hash.txt",
                    ),
                    upload_result("image_hash.txt", "https://example.com/image_hash.txt?sig=1"),
                ]
            ),
        )
        job = SampleJob(
            run_id="run-test",
            task_id="173",
            sample_index=1,
            task=TaskRecord(
                run_id="run-test",
                task_id="173",
                row_number=1,
                fields={
                    "输出文件路径": "/home/user/Desktop/output/http_with_jpegs,/home/user/Desktop/output",
                    "final_answer文件名": "image_hash.txt",
                },
            ),
            config=RunConfig(run_id="run-test", output_root="output-test"),
            lease=InstanceLease(
                run_id="run-test",
                lease_id="lease-test",
                instance_id="i-test",
                task_id="173",
                sample_index=1,
                status="busy",
                acquired_at="2026-01-01 00:00:00",
            ),
        )

        result = sampler.collect_outputs(job)

        self.assertEqual(result.errors, [])
        self.assertEqual(result.output_uploads[0]["status"], "uploaded")
        self.assertEqual(
            result.output_uploads[0]["source_path"],
            "/home/user/Desktop/output/image_hash.txt",
        )
        self.assertEqual(
            result.output_uploads[0]["candidate_source_paths"],
            [
                "/home/user/Desktop/output/http_with_jpegs/image_hash.txt",
                "/home/user/Desktop/output/image_hash.txt",
            ],
        )
        self.assertIn("/home/user/Desktop/output/http_with_jpegs/image_hash.txt", sampler.env.commands[0])
        self.assertIn("/home/user/Desktop/output/image_hash.txt", sampler.env.commands[0])


class FakeEnv:
    def __init__(self, results):
        self.results = list(results)
        self.commands = []

    def run_command(self, instance_id, command, timeout):
        self.commands.append(command)
        if not self.results:
            raise AssertionError("unexpected run_command call")
        return self.results.pop(0)


class FakeHttpEnv(FakeEnv):
    def __init__(self, content: bytes, *, source_path: str = "", fail: bool = False):
        super().__init__([])
        self.content = content
        self.source_path = source_path
        self.fail = fail
        self.download_calls = 0

    def download_file(self, instance_id, paths, timeout=120):
        self.download_calls += 1
        if self.fail:
            raise ValueError("http download unavailable")
        path = self.source_path or (list(paths)[0] if paths else "")
        return {
            "ok": True,
            "path": path,
            "name": Path(path.replace("\\", "/")).name,
            "size": len(self.content),
            "content": self.content,
            "via": "wgm_flask_http",
        }


def sample_job(final_answer_names: str) -> SampleJob:
    return SampleJob(
        run_id="run-test",
        task_id="1746",
        sample_index=1,
        task=TaskRecord(
            run_id="run-test",
            task_id="1746",
            row_number=1,
            fields={
                "输出文件路径": "/home/user/Desktop/output",
                "final_answer文件名": final_answer_names,
            },
        ),
        config=RunConfig(run_id="run-test", output_root="output-test"),
        lease=InstanceLease(
            run_id="run-test",
            lease_id="lease-test",
            instance_id="i-test",
            task_id="1746",
            sample_index=1,
            status="busy",
            acquired_at="2026-01-01 00:00:00",
        ),
    )


def exists_check_result(relative_path: str, size: int, source_path: str = "") -> dict:
    resolved_source_path = source_path or "/home/user/Desktop/output/%s" % relative_path
    return command_result(
        "WORKFLOWGYM_OUTPUT_FILE\t%s\texists\t%s\t%s\n" % (relative_path, resolved_source_path, size)
    )


def missing_check_result(relative_path: str) -> dict:
    return command_result("WORKFLOWGYM_OUTPUT_FILE\t%s\tmissing\t/home/user/Desktop/output/%s\t\n" % (relative_path, relative_path))


def upload_result(relative_path: str, url: str) -> dict:
    return command_result("upload ok\nWORKFLOWGYM_TOS_PRESIGN\t%s\t%s\n" % (relative_path, url))


def command_result(raw_output: str) -> dict:
    return {
        "results": [
            {
                "InvocationResultStatus": "Success",
                "ExitCode": 0,
                "Output": base64.b64encode(raw_output.encode("utf-8")).decode("ascii"),
            }
        ]
    }


if __name__ == "__main__":
    unittest.main()
