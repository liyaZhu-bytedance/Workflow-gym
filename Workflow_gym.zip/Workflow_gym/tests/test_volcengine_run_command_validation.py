from __future__ import annotations

import sys
import unittest
from unittest import mock
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.envs.volcengine_env import (
    build_linux_configure_tosutil_command,
    build_linux_download_tosutil_command,
    build_windows_configure_tosutil_command,
    build_windows_autologon_command,
    build_windows_download_python_installer_command,
    build_windows_download_tosutil_command,
    build_windows_file_queue_runner_setup_command,
    build_prepare_windows_pyautogui_command,
    platform_from_os_type,
    resolve_effective_os_type,
    resolve_run_command_type,
    tos_endpoint_for_region,
    tosutil_verify_bucket_uri,
    validate_run_command_payload,
    windows_login_password,
    windows_login_user,
)
from open_workflowgym.task_files import build_windows_prepare_input_command, DownloadPlan


class RunCommandValidationTest(unittest.TestCase):
    def test_windows_rejects_linux_bash_script(self):
        with self.assertRaisesRegex(ValueError, "Windows"):
            resolve_run_command_type("Shell", "#!/bin/bash\necho ok\n", "Windows")

    def test_windows_infers_powershell_type(self):
        command_type = resolve_run_command_type("Shell", "Write-Host 'ok'\n", "Windows Server")

        self.assertEqual(command_type, "PowerShell")

    def test_windows_infers_bat_type(self):
        command_type = resolve_run_command_type("Shell", "echo ok\r\n", "Windows")

        self.assertEqual(command_type, "Bat")

    def test_windows_prepare_input_command_infers_powershell_type(self):
        command = build_windows_prepare_input_command(
            r"C:\Users\Administrator\Desktop\input",
            [DownloadPlan(url="https://example.com/a.txt", filename="a.txt")],
            30,
        )

        self.assertEqual(resolve_run_command_type("Shell", command, "Windows"), "PowerShell")

    def test_platform_from_os_type(self):
        self.assertEqual(platform_from_os_type("Windows Server 2022"), "windows")
        self.assertEqual(platform_from_os_type("Ubuntu 22.04"), "ubuntu")

    def test_linux_rejects_powershell_type(self):
        with self.assertRaisesRegex(ValueError, "Linux/Ubuntu"):
            resolve_run_command_type("PowerShell", "Write-Host 'ok'\n", "Ubuntu 22.04")

    def test_linux_rejects_powershell_script_even_with_shell_type(self):
        with self.assertRaisesRegex(ValueError, "PowerShell"):
            resolve_run_command_type("Shell", "Write-Host 'ok'\n", "Ubuntu 22.04")

    def test_linux_allows_shell(self):
        self.assertEqual(resolve_run_command_type("Shell", "#!/bin/bash\necho ok\n", "Ubuntu"), "Shell")

    def test_instance_supports_windows_runcommand(self):
        from open_workflowgym.envs.volcengine_env import (
            CloudAssistantPlatformMismatchError,
            image_os_type_label,
            image_record_platform,
            instance_compatible_for_image_platform,
            instance_platform_from_name,
            instance_supports_windows_runcommand,
            is_cloud_assistant_platform_mismatch_text,
            platform_to_os_type_label,
        )

        self.assertTrue(instance_supports_windows_runcommand({"InstanceName": "open_workflow_gym_windows"}))
        self.assertFalse(instance_supports_windows_runcommand({"InstanceName": "open_workflow_gym_ubuntu"}))
        self.assertFalse(
            instance_supports_windows_runcommand(
                {"OsType": "Windows Server 2022", "InstanceName": "open_workflow_gym_ubuntu"}
            )
        )
        self.assertEqual(instance_platform_from_name({"InstanceName": "open_workflow_gym_windows"}), "windows")
        self.assertEqual(instance_platform_from_name({"InstanceName": "open_workflow_gym_ubuntu"}), "ubuntu")
        self.assertEqual(platform_to_os_type_label("windows"), "Windows")
        self.assertEqual(
            image_record_platform({"OsType": "Linux", "Platform": "Ubuntu"}),
            "ubuntu",
        )
        self.assertEqual(
            image_os_type_label({"OsType": "Linux", "Platform": "Ubuntu"}),
            "Linux/Ubuntu",
        )
        self.assertTrue(
            instance_compatible_for_image_platform(
                {"InstanceName": "open_workflow_gym_windows"},
                "windows",
            )
        )
        self.assertFalse(
            instance_compatible_for_image_platform(
                {"InstanceName": "open_workflow_gym_ubuntu"},
                "windows",
            )
        )
        self.assertTrue(
            is_cloud_assistant_platform_mismatch_text("unsupported command type PowerShell on linux")
        )

    def test_discover_reusable_instances_filters_by_image_platform(self):
        from open_workflowgym.envs.volcengine_env import VolcengineEnv

        env = VolcengineEnv(dry_run="")
        env.describe_image = lambda image_id: {
            "ImageId": image_id,
            "OsType": "Windows",
            "Platform": "Windows Server 2022",
        }
        env.describe_instances = lambda **kwargs: [
            {"InstanceId": "i-win", "InstanceName": "open_workflow_gym_windows", "Status": "RUNNING"},
            {"InstanceId": "i-ubuntu", "InstanceName": "open_workflow_gym_ubuntu", "Status": "RUNNING"},
        ]
        matched = env.discover_reusable_instances(
            name_prefix="open_workflow_gym",
            platform="windows",
            target_image_id="image-task324",
            limit=10,
        )
        self.assertEqual([item["InstanceId"] for item in matched], ["i-win"])

    def test_initialize_for_sample_rejects_mismatched_image_platform(self):
        from open_workflowgym.envs.volcengine_env import CloudAssistantPlatformMismatchError, VolcengineEnv

        env = VolcengineEnv(dry_run="")
        env.describe_instance = lambda instance_id: {
            "InstanceId": instance_id,
            "InstanceName": "open_workflow_gym_ubuntu",
            "ImageId": "image-old",
            "Status": "RUNNING",
        }
        env.describe_image = lambda image_id: {
            "ImageId": image_id,
            "OsType": "Windows",
            "Platform": "Windows Server 2022",
        }
        with self.assertRaises(CloudAssistantPlatformMismatchError) as ctx:
            env.initialize_for_sample("i-ubuntu", "image-win", "/tmp/sample")
        self.assertEqual(ctx.exception.instance_platform, "ubuntu")
        self.assertEqual(ctx.exception.expected_platform, "windows")
        self.assertTrue(ctx.exception.instance_os_type)
        self.assertTrue(ctx.exception.expected_os_type)

    def test_build_exception_record_includes_platform_context(self):
        from open_workflowgym.envs.volcengine_env import CloudAssistantPlatformMismatchError
        from open_workflowgym.records import RunConfig, SampleJob, TaskRecord
        from open_workflowgym.sampler import build_exception_record

        exc = CloudAssistantPlatformMismatchError(
            "mismatch",
            instance_id="i-yeqg0zdbswuo7buff78w",
            instance_name="open_workflow_gym_windows",
            instance_platform="windows",
            instance_os_type="Windows",
            expected_platform="ubuntu",
            expected_os_type="Linux/Ubuntu",
            image_id="image-yepzwx7t5pkhx14h6iq3",
        )
        job = SampleJob(
            run_id="run-test",
            task_id="42",
            sample_index=3,
            task=TaskRecord(run_id="run-test", task_id="42", row_number=1, fields={"系统类型": "Ubuntu"}),
            config=RunConfig(run_id="run-test", player="kimi", step_num=400),
            lease=None,
        )
        record = build_exception_record(job, "sampling", exc, -1, "", None)
        self.assertEqual(record["instance_os_type"], "Windows")
        self.assertEqual(record["expected_os_type"], "Linux/Ubuntu")
        self.assertEqual(record["instance_platform"], "windows")
        self.assertEqual(record["expected_platform"], "ubuntu")
        self.assertEqual(record["task_expected_platform"], "ubuntu")
        self.assertEqual(record["task_expected_os_type"], "Ubuntu")

    def test_unknown_described_os_uses_windows_platform_hint(self):
        self.assertEqual(resolve_effective_os_type("UNKNOWN", "Windows"), "Windows")

    def test_task_platform_hint_overrides_unknown_described_os(self):
        self.assertEqual(resolve_effective_os_type("", "windows"), "Windows")
        self.assertEqual(resolve_effective_os_type("", "ubuntu"), "Ubuntu")

    def test_windows_autologon_command_sets_registry(self):
        command = build_windows_autologon_command("Administrator", "secret")

        self.assertIn("AutoAdminLogon", command)
        self.assertIn("DefaultUserName", command)
        self.assertIn("DefaultPassword", command)

    def test_windows_file_queue_runner_uses_interactive_onlogon_task(self):
        command = build_windows_file_queue_runner_setup_command("Administrator", "secret")

        self.assertIn("/SC ONLOGON", command)
        self.assertIn("/IT", command)
        self.assertIn("WorkflowGymFileQueueWatchdog", command)
        self.assertIn("schtasks /Delete", command)
        self.assertIn(">nul 2>nul", command)
        self.assertIn("workflowgym_file_queue_action.json", command)
        self.assertIn("workflowgym_file_queue_result.json", command)

    def test_windows_login_user_default(self):
        self.assertEqual(windows_login_user(), "Administrator")

    def test_windows_login_password_defaults_to_empty(self):
        with mock.patch.dict("os.environ", {}, clear=False):
            import os

            os.environ.pop("INSTANCE_PASSWORD", None)
            os.environ.pop("WINDOWS_LOGIN_PASSWORD", None)

            self.assertEqual(windows_login_password(), "")

    def test_windows_prepare_command_uses_tos_python_installer(self):
        command = build_prepare_windows_pyautogui_command()

        self.assertIn("WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_TOS_URI", command)
        self.assertIn("WORKFLOWGYM_WINDOWS_PYTHON_TOSUTIL", command)
        self.assertIn("WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_READY", command)
        self.assertIn("WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_EXISTING", command)
        self.assertIn(r"C:\Users\Administrator\AppData\Local\Temp\workflowgym-python-installer.exe", command)
        self.assertIn("tos://open-workflowgym-win-python/python-3.12.8-amd64_1.exe", command)
        self.assertIn("C:\\Windows\\System32\\tosutil.exe", command)
        self.assertIn("$tosutilPath cp", command)
        self.assertIn("WORKFLOWGYM_WINDOWS_PYTHON_TOSUTIL_MISSING", command)
        self.assertIn("WORKFLOWGYM_WINDOWS_PYTHON_TOS_COPY_FAILED", command)
        self.assertIn("throw ('tosutil not found: ' + $tosutilPath)", command)
        self.assertIn("throw ('Python installer TOS copy failed: ' + $pythonInstallerTosUri)", command)
        self.assertIn("https://pypi.tuna.tsinghua.edu.cn/simple", command)
        self.assertIn("pypi.tuna.tsinghua.edu.cn", command)
        self.assertIn("WORKFLOWGYM_WINDOWS_PIP_INDEX", command)
        self.assertIn("pip install --upgrade pip setuptools wheel -i $pipIndex --trusted-host $pipTrustedHost", command)
        self.assertIn("pip install --upgrade pyautogui pyperclip pillow -i $pipIndex --trusted-host $pipTrustedHost", command)
        self.assertNotIn("'pip<25'", command)
        self.assertNotIn("'setuptools<70'", command)
        self.assertNotIn("--no-build-isolation", command)
        self.assertIn("-Encoding ASCII", command)
        self.assertIn("WORKFLOWGYM_WINDOWS_PYAUTOGUI_PIP_FAILED", command)
        self.assertIn("WORKFLOWGYM_WINDOWS_PYAUTOGUI_SHIM_READY", command)
        self.assertIn("pyautogui.py", command)
        self.assertIn("pyperclip.py", command)
        self.assertIn("def tripleClick", command)
        self.assertNotIn("Invoke-WebRequest", command)
        self.assertNotIn("-TimeoutSec 1200", command)
        self.assertNotIn("https://mirrors.tuna.tsinghua.edu.cn/python/3.12.8/python-3.12.8-amd64.exe", command)
        self.assertNotIn("https://www.python.org/ftp/python/3.12.8/python-3.12.8-amd64.exe", command)

    def test_linux_download_tosutil_uses_wget_and_expected_url(self):
        command = build_linux_download_tosutil_command()

        self.assertIn("#!/bin/bash", command)
        self.assertIn("wget -q", command)
        self.assertIn("https://m645b3e1bb36e-mrap.mrap.accesspoint.tos-global.volces.com/linux/amd64/tosutil", command)
        self.assertIn("/usr/local/bin/tosutil", command)
        self.assertIn("WORKFLOWGYM_LINUX_TOSUTIL_DOWNLOAD_READY", command)

    def test_linux_configure_tosutil_command_sets_credentials_and_verifies_prefix(self):
        command = build_linux_configure_tosutil_command("ak", "sk", "tos-cn-guangzhou.volces.com", "cn-guangzhou")

        self.assertIn("/usr/local/bin/tosutil", command)
        self.assertIn("config -i ak -k sk -e tos-cn-guangzhou.volces.com -re cn-guangzhou", command)
        self.assertIn('"$target" ls "$verify_bucket"', command)
        self.assertIn("tos://open-workflowgym-sample/.workflowgym-healthcheck/", command)
        self.assertIn("WORKFLOWGYM_LINUX_TOSUTIL_CONFIG_DONE", command)

    def test_windows_tosutil_commands_install_and_configure(self):
        download_command = build_windows_download_tosutil_command()
        config_command = build_windows_configure_tosutil_command("ak", "sk", "tos-cn-guangzhou.volces.com", "cn-guangzhou")
        python_installer_command = build_windows_download_python_installer_command()

        self.assertIn("https://m645b3e1bb36e-mrap.mrap.accesspoint.tos-global.volces.com/windows/tosutil", download_command)
        self.assertIn(r"C:\Windows\System32\tosutil.exe", download_command)
        self.assertIn("WORKFLOWGYM_WINDOWS_TOSUTIL_DOWNLOAD_EXISTING", download_command)
        self.assertIn("WORKFLOWGYM_WINDOWS_TOSUTIL_DOWNLOAD_READY", download_command)
        self.assertIn("& $target config -i $tosAk -k $tosSk -e $tosEndpoint -re $tosRegion", config_command)
        self.assertIn("& $target ls $verifyBucket", config_command)
        self.assertIn("tos://open-workflowgym-sample/.workflowgym-healthcheck/", config_command)
        self.assertIn("WORKFLOWGYM_WINDOWS_TOSUTIL_CONFIG_DONE", config_command)
        self.assertIn("tos://open-workflowgym-win-python/python-3.12.8-amd64_1.exe", python_installer_command)
        self.assertIn("Join-Path $env:TEMP 'workflowgym-python-installer.exe'", python_installer_command)
        self.assertIn("& $tosutilPath cp $pythonInstallerTosUri $installer", python_installer_command)
        self.assertIn("WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_DOWNLOAD_START", python_installer_command)
        self.assertIn("WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_READY", python_installer_command)

    def test_tos_endpoint_defaults_from_region(self):
        self.assertEqual(tos_endpoint_for_region("cn-guangzhou"), "tos-cn-guangzhou.volces.com")

    def test_tosutil_verify_bucket_uri_defaults_to_healthcheck_prefix(self):
        with mock.patch.dict("os.environ", {}, clear=True):
            self.assertEqual(
                tosutil_verify_bucket_uri(),
                "tos://open-workflowgym-sample/.workflowgym-healthcheck/",
            )

    def test_tosutil_verify_bucket_uri_prefers_explicit_verify_bucket(self):
        with mock.patch.dict(
            "os.environ",
            {"TOS_VERIFY_BUCKET": "tos://custom-bucket", "TOS_UPLOAD_BUCKET": "tos://open-workflowgym-sample"},
            clear=True,
        ):
            self.assertEqual(
                tosutil_verify_bucket_uri(),
                "tos://custom-bucket/.workflowgym-healthcheck/",
            )

    def test_tosutil_verify_bucket_uri_supports_explicit_list_uri(self):
        with mock.patch.dict(
            "os.environ",
            {"TOS_VERIFY_LIST_URI": "tos://custom-bucket/my-prefix"},
            clear=True,
        ):
            self.assertEqual(tosutil_verify_bucket_uri(), "tos://custom-bucket/my-prefix/")

    def test_linux_shell_requires_bash_shebang(self):
        with self.assertRaisesRegex(ValueError, "#!/bin/bash"):
            validate_run_command_payload("echo ok\n", "Shell")

    def test_run_command_content_size_limit(self):
        command = "#!/bin/bash\n" + ("x" * (16 * 1024))

        with self.assertRaisesRegex(ValueError, "16KB"):
            validate_run_command_payload(command, "Shell")


if __name__ == "__main__":
    unittest.main()
