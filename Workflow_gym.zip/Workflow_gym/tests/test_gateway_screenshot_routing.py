from __future__ import annotations

import base64
import os
import sys
import unittest
from pathlib import Path
from unittest import mock

REPO_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = Path("/tmp/owg_path")
PACKAGE_ROOT.mkdir(parents=True, exist_ok=True)
link = PACKAGE_ROOT / "open_workflowgym"
if link.exists() or link.is_symlink():
    link.unlink()
link.symlink_to(REPO_ROOT)
sys.path.insert(0, str(PACKAGE_ROOT))

from open_workflowgym.envs.gateway_volcengine_env import (
    GatewayVolcengineEnv,
    screenshot_delivery,
    screenshot_via_wgm,
)


TINY_PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
)


def _env_without_screenshot_flags() -> dict[str, str]:
    return {
        key: value
        for key, value in os.environ.items()
        if key not in ("REDIS_SCREENSHOT_VIA_WGM", "WGM_SCREENSHOT_VIA_WGM", "WGM_SCREENSHOT_VIA")
    }


class GatewayScreenshotRoutingTests(unittest.TestCase):
    def test_screenshot_via_wgm_default_true(self):
        with mock.patch.dict("os.environ", _env_without_screenshot_flags(), clear=True):
            self.assertTrue(screenshot_via_wgm())
            self.assertEqual(screenshot_delivery(), "wgm-direct")

    def test_screenshot_via_wgm_env(self):
        with mock.patch.dict("os.environ", {"WGM_SCREENSHOT_VIA": "wgm-direct"}, clear=False):
            self.assertTrue(screenshot_via_wgm())
            self.assertEqual(screenshot_delivery(), "wgm-direct")
        with mock.patch.dict("os.environ", {"WGM_SCREENSHOT_VIA": "wgm"}, clear=False):
            self.assertTrue(screenshot_via_wgm())
        with mock.patch.dict("os.environ", {"WGM_SCREENSHOT_VIA": "pyautogui"}, clear=False):
            self.assertTrue(screenshot_via_wgm())
            self.assertEqual(screenshot_delivery(), "wgm-pyautogui")
        with mock.patch.dict("os.environ", {"WGM_SCREENSHOT_VIA": "local"}, clear=False):
            self.assertFalse(screenshot_via_wgm())
            self.assertEqual(screenshot_delivery(), "local")
        with mock.patch.dict(
            "os.environ",
            {"REDIS_SCREENSHOT_VIA_WGM": "0", "WGM_SCREENSHOT_VIA": ""},
            clear=False,
        ):
            self.assertFalse(screenshot_via_wgm())
        with mock.patch.dict(
            "os.environ",
            {"REDIS_SCREENSHOT_VIA_WGM": "1", "WGM_SCREENSHOT_VIA": ""},
            clear=False,
        ):
            self.assertTrue(screenshot_via_wgm())

    def test_get_console_screenshot_defaults_to_wgm(self):
        env = GatewayVolcengineEnv(wgm_token="tok", dry_run="")
        env.lease_renew_context = mock.Mock(lease_id="lease-1")
        with mock.patch.dict("os.environ", _env_without_screenshot_flags(), clear=True):
            with mock.patch.object(
                env.wgm,
                "screenshot_bytes",
                return_value=TINY_PNG,
            ) as wgm_shot:
                with mock.patch.object(GatewayVolcengineEnv.__bases__[0], "get_console_screenshot") as local:
                    out = env.get_console_screenshot("i-1")
        self.assertEqual(out, TINY_PNG)
        wgm_shot.assert_called_once()
        local.assert_not_called()

    def test_get_console_screenshot_can_use_local(self):
        env = GatewayVolcengineEnv(wgm_token="tok", dry_run="")
        with mock.patch.dict(
            "os.environ",
            {"WGM_SCREENSHOT_VIA": "local", "AK": "ak", "SK": "sk"},
            clear=False,
        ):
            with mock.patch.object(
                GatewayVolcengineEnv.__bases__[0],
                "get_console_screenshot",
                return_value=TINY_PNG,
            ) as local:
                with mock.patch.object(env.wgm, "screenshot_bytes") as wgm_shot:
                    out = env.get_console_screenshot("i-1")
        self.assertEqual(out, TINY_PNG)
        local.assert_called_once_with("i-1")
        wgm_shot.assert_not_called()

    def test_local_screenshot_requires_ak_sk(self):
        env = GatewayVolcengineEnv(wgm_token="tok", dry_run="")
        with mock.patch.dict(
            "os.environ",
            {"WGM_SCREENSHOT_VIA": "local", "AK": "", "SK": ""},
            clear=False,
        ):
            with self.assertRaisesRegex(ValueError, "需要本机设置火山 AK/SK"):
                env.get_console_screenshot("i-1")

    def test_get_console_screenshot_can_use_wgm_pyautogui(self):
        env = GatewayVolcengineEnv(wgm_token="tok", dry_run="")
        image_b64 = base64.b64encode(TINY_PNG).decode("ascii")
        action_result = {
            "ok": True,
            "output": "prefix\nWORKFLOWGYM_SCREENSHOT_B64:%s\nsuffix" % image_b64,
            "results": [{"decoded_output": ""}],
        }
        with mock.patch.dict("os.environ", {"WGM_SCREENSHOT_VIA": "pyautogui"}, clear=False):
            with mock.patch.object(env, "run_action", return_value=action_result) as run_action:
                with mock.patch.object(env.wgm, "screenshot_bytes") as wgm_shot:
                    out = env.get_console_screenshot("i-1")
        self.assertEqual(out, TINY_PNG)
        run_action.assert_called_once()
        wgm_shot.assert_not_called()

    def test_pyautogui_screenshot_does_not_fallback_to_wgm_stream(self):
        env = GatewayVolcengineEnv(wgm_token="tok", dry_run="")
        env.lease_renew_context = mock.Mock(lease_id="lease-1")
        with mock.patch.dict("os.environ", {"WGM_SCREENSHOT_VIA": "pyautogui"}, clear=False):
            with mock.patch.object(
                env,
                "run_action",
                side_effect=ValueError("workflowgym flask action failed via wgm-direct: exit_code=1"),
            ):
                with mock.patch.object(env.wgm, "screenshot_bytes") as wgm_shot:
                    with self.assertRaisesRegex(ValueError, "exit_code=1"):
                        env.get_console_screenshot("i-1")
        wgm_shot.assert_not_called()

    def test_run_action_error_includes_stderr(self):
        env = GatewayVolcengineEnv(wgm_token="tok", dry_run="")
        env.lease_renew_context = mock.Mock(lease_id="lease-1")
        with mock.patch.object(
            env.wgm,
            "run_action",
            return_value={"ok": False, "error": "exit_code=1", "stderr": "ModuleNotFoundError: PIL"},
        ):
            with self.assertRaisesRegex(ValueError, "stderr=ModuleNotFoundError: PIL"):
                env.run_action("", script="print(1)")


if __name__ == "__main__":
    unittest.main()
