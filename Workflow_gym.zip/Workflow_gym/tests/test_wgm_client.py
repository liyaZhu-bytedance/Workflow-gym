from __future__ import annotations

import base64
import sys
import unittest
from pathlib import Path
from unittest import mock

REPO_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = Path("/tmp/owg_path")
PACKAGE_ROOT.mkdir(parents=True, exist_ok=True)
link = PACKAGE_ROOT / "open_workflowgym"
if link.exists() or link.is_symlink():
    link.unlink()
link.symlink_to(REPO_ROOT)
sys.path.insert(0, str(PACKAGE_ROOT))

from open_workflowgym.envs.wgm_client import WgmClient, WgmClientError


class WgmClientTests(unittest.TestCase):
    def test_wait_job_success(self):
        client = WgmClient(api_base="https://example.test", api_token="wgm-test", ttl_seconds=1800)
        with mock.patch.object(
            client,
            "get_job",
            side_effect=[
                {"status": "running", "phase": "replacing"},
                {
                    "status": "succeeded",
                    "result": {
                        "lease_id": "lease-1",
                        "instance_id": "i-1",
                        "expires_at": "2026-07-24 12:00:00",
                    },
                },
            ],
        ):
            result = client.wait_job("job-1", timeout_seconds=10, poll_seconds=0.01)
        self.assertEqual(result["lease_id"], "lease-1")
        self.assertEqual(result["instance_id"], "i-1")

    def test_wait_job_failed(self):
        client = WgmClient(api_base="https://example.test", api_token="wgm-test")
        with mock.patch.object(
            client,
            "get_job",
            return_value={"status": "failed", "error": "boom"},
        ):
            with self.assertRaises(WgmClientError):
                client.wait_job("job-1", timeout_seconds=5, poll_seconds=0.01)

    def test_acquire_and_prepare_wait(self):
        client = WgmClient(api_base="https://example.test", api_token="wgm-test")
        with mock.patch.object(client, "acquire_and_prepare", return_value={"job_id": "job-9"}):
            with mock.patch.object(
                client,
                "wait_job",
                return_value={"lease_id": "lease-9", "instance_id": "i-9", "status": "succeeded"},
            ) as wait:
                out = client.acquire_and_prepare_wait(os_type="ubuntu", image_id="image-1")
        wait.assert_called_once()
        self.assertEqual(out["lease_id"], "lease-9")

    def test_run_action_posts_script(self):
        client = WgmClient(api_base="https://example.test", api_token="wgm-test", timeout_seconds=10)
        with mock.patch.object(client, "_request_json", return_value={"ok": True, "output": "hi"}) as req:
            out = client.run_action("lease-1", script="print(1)", timeout=90, action_id="a1")
        self.assertTrue(out.get("ok"))
        args, kwargs = req.call_args
        self.assertEqual(args[0], "POST")
        self.assertEqual(args[1], "/api/v1/sessions/lease-1/run-action")
        self.assertEqual(kwargs["timeout_seconds"], 120.0)
        body = args[2]
        self.assertEqual(body["script"], "print(1)")
        self.assertEqual(body["id"], "a1")
        self.assertEqual(body["action"], "python")

    def test_ensure_ready_retries_504_then_succeeds(self):
        client = WgmClient(api_base="https://example.test", api_token="wgm-test", timeout_seconds=10)
        with mock.patch.object(
            client,
            "_request_json",
            side_effect=[
                WgmClientError("HTTP Error 504: Gateway Timeout", status=504),
                {"ready": True, "ubuntu_flask_port": 8080},
            ],
        ) as req:
            with mock.patch("open_workflowgym.envs.wgm_client.time.sleep", return_value=None):
                out = client.ensure_ready("lease-1", wait_timeout_seconds=60, poll_seconds=0.01)
        self.assertTrue(out.get("ready"))
        self.assertEqual(req.call_count, 2)
        body = req.call_args_list[0].args[2]
        self.assertFalse(body.get("heal"))

    def test_ensure_ready_allow_heal_flag(self):
        client = WgmClient(api_base="https://example.test", api_token="wgm-test")
        with mock.patch.object(client, "_request_json", return_value={"ready": True}) as req:
            client.ensure_ready("lease-1", allow_heal=True, wait_timeout_seconds=1, poll_seconds=0.01)
        self.assertTrue(req.call_args.args[2].get("heal"))

    def test_screenshot_stream_bytes(self):
        client = WgmClient(api_base="https://example.test", api_token="wgm-test", timeout_seconds=10)
        png = base64.b64decode(
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
        )
        with mock.patch.dict("os.environ", {"WGM_SCREENSHOT_FORMAT": "stream"}, clear=False):
            with mock.patch.object(client, "_request_binary", return_value=png) as req:
                out = client.screenshot_bytes("lease-1")
        self.assertEqual(out, png)
        self.assertIn("/screenshot/stream", req.call_args.args[1])

    def test_screenshot_stream_retries_incomplete_read(self):
        client = WgmClient(api_base="https://example.test", api_token="wgm-test", timeout_seconds=10)
        png = b"\x89PNG\r\n\x1a\n" + b"x"
        with mock.patch.dict(
            "os.environ",
            {
                "WGM_SCREENSHOT_FORMAT": "stream",
                "WGM_SCREENSHOT_MAX_ATTEMPTS": "3",
                "WGM_SCREENSHOT_RETRY_BASE_SECONDS": "0",
                "WGM_SCREENSHOT_FALLBACK_BASE64": "false",
            },
            clear=False,
        ):
            with mock.patch.object(
                client,
                "_screenshot_bytes_once",
                side_effect=[
                    WgmClientError("IncompleteRead: truncated"),
                    png,
                ],
            ) as once:
                with mock.patch("open_workflowgym.envs.wgm_client.time.sleep", return_value=None):
                    out = client.screenshot_bytes("lease-1")
        self.assertEqual(out, png)
        self.assertEqual(once.call_count, 2)

    def test_screenshot_stream_retries_flow_limit(self):
        client = WgmClient(api_base="https://example.test", api_token="wgm-test", timeout_seconds=10)
        png = b"\x89PNG\r\n\x1a\n" + b"x"
        flow_error = WgmClientError(
            "(429)\nReason: Too Many Requests\nFlowLimitExceeded",
            status=429,
        )
        with mock.patch.dict(
            "os.environ",
            {
                "WGM_SCREENSHOT_FORMAT": "stream",
                "WGM_SCREENSHOT_MAX_ATTEMPTS": "3",
                "WGM_SCREENSHOT_RETRY_BASE_SECONDS": "0",
                "WGM_SCREENSHOT_FALLBACK_BASE64": "false",
                "WGM_SCREENSHOT_FLOW_LIMIT_RETRY_SECONDS": "10",
            },
            clear=False,
        ):
            with mock.patch.object(
                client,
                "_screenshot_bytes_once",
                side_effect=[flow_error, png],
            ) as once:
                with mock.patch("open_workflowgym.envs.wgm_client.time.sleep", return_value=None) as sleep:
                    out = client.screenshot_bytes("lease-1")
        self.assertEqual(out, png)
        self.assertEqual(once.call_count, 2)
        sleep.assert_called_once_with(10.0)

    def test_screenshot_base64_legacy_mode(self):
        client = WgmClient(api_base="https://example.test", api_token="wgm-test", timeout_seconds=10)
        with mock.patch.dict("os.environ", {"WGM_SCREENSHOT_FORMAT": "base64"}, clear=False):
            with mock.patch.object(
                client,
                "_screenshot_json",
                return_value={"screenshot_base64": "aGVsbG8="},
            ) as legacy:
                out = client.screenshot_bytes("lease-1")
        legacy.assert_called_once()
        self.assertEqual(out, b"hello")

    def test_screenshot_retries_incomplete_read(self):
        client = WgmClient(api_base="https://example.test", api_token="wgm-test", timeout_seconds=10)
        with mock.patch.dict(
            "os.environ",
            {"WGM_SCREENSHOT_FORMAT": "base64", "WGM_SCREENSHOT_MAX_ATTEMPTS": "3", "WGM_SCREENSHOT_RETRY_BASE_SECONDS": "0"},
            clear=False,
        ):
            with mock.patch.object(
                client,
                "_request_json",
                side_effect=[
                    WgmClientError("IncompleteRead: 74827 bytes read, 290570 more expected"),
                    {"screenshot_base64": "aGVsbG8=", "instance_id": "i-1"},
                ],
            ) as req:
                with mock.patch("open_workflowgym.envs.wgm_client.time.sleep", return_value=None):
                    out = client.screenshot("lease-1")
        self.assertEqual(out["screenshot_base64"], "aGVsbG8=")
        self.assertEqual(req.call_count, 2)
        self.assertGreaterEqual(req.call_args.kwargs.get("timeout_seconds") or 0, 180.0)

    def test_download_file_posts_paths(self):
        client = WgmClient(api_base="https://example.test", api_token="wgm-test", ttl_seconds=1800)
        with mock.patch.object(
            client,
            "_request_json",
            return_value={
                "ok": True,
                "path": r"C:\Users\Administrator\Desktop\output\user.sql",
                "name": "user.sql",
                "size": 4,
                "content_b64": "AAAA",
                "content_encoding": "base64",
            },
        ) as req:
            out = client.download_file("lease-1", paths=[r"C:\Users\Administrator\Desktop\output\user.sql"], timeout=90)
        self.assertTrue(out["ok"])
        self.assertEqual(out["name"], "user.sql")
        self.assertEqual(req.call_args.args[0], "POST")
        self.assertIn("/download-file", req.call_args.args[1])
        self.assertEqual(
            req.call_args.args[2]["paths"],
            [r"C:\Users\Administrator\Desktop\output\user.sql"],
        )


if __name__ == "__main__":
    unittest.main()
