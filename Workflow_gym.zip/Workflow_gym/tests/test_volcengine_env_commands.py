from __future__ import annotations

import os
import sys
import types
import unittest
from unittest import mock
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.envs.volcengine_eip import (
    allocate_and_associate_eip,
    allocate_eip_address,
    associate_eip_address_with_retry,
    disassociate_eip_address,
    find_available_eip_address,
    find_associated_eip_addresses,
    is_eip_status_retryable,
    prepare_eip_allocations,
)
from open_workflowgym.envs.volcengine_env import (
    VolcengineEnv,
    build_set_desktop_resolution_command,
    build_set_windows_desktop_resolution_command,
    build_ubuntu_interactive_flask_runner_setup_command,
    build_windows_fast_init_probe_command,
    build_windows_file_queue_runner_probe_command,
    build_windows_file_queue_runner_setup_command,
    build_windows_interactive_flask_runner_setup_command,
    cloud_assistant_status_value,
    display_session_needs_xorg_reboot,
    DRY_RUN_SCREENSHOT_BYTES,
    flask_runner_bind_host,
    instance_image_id,
    is_console_screenshot_invalid_timestamp_error,
    is_console_screenshot_retryable,
    is_replace_system_volume_complete,
    print_run_command_invocation_results,
    ubuntu_flask_runner_port,
    ubuntu_flask_runner_port_candidates,
)


class FakeAllocateResponse:
    def to_dict(self):
        return {"Result": {"AllocationId": "eip-test"}}


class FakeDescribeEipResponse:
    def to_dict(self):
        return {
            "Result": {
                "EipAddresses": [
                    {"AllocationId": "eip-attached", "Status": "Attached", "InstanceId": "i-other"},
                    {"AllocationId": "eip-available", "Status": "Available", "InstanceId": ""},
                ]
            }
        }


class FakeVpcApi:
    def __init__(self):
        self.request = None
        self.associate_attempts = 0
        self.allocate_attempts = 0
        self.disassociate_attempts = 0

    def allocate_eip_address(self, request):
        self.request = request
        self.allocate_attempts += 1
        return FakeAllocateResponse()

    def describe_eip_addresses(self, request):
        self.request = request
        return FakeDescribeEipResponse()

    def associate_eip_address(self, request):
        self.request = request
        self.associate_attempts += 1
        if self.associate_attempts == 1:
            raise RuntimeError("InvalidEip.InvalidStatus: not in the correct status")
        return {"Result": {"RequestId": "associate-test"}}

    def disassociate_eip_address(self, request):
        self.request = request
        self.disassociate_attempts += 1
        return {"Result": {"RequestId": "req-test"}}


class FakeVpcApiWithAssociatedEip(FakeVpcApi):
    def __init__(self):
        super().__init__()
        self.describe_attempts = 0

    def describe_eip_addresses(self, request):
        self.request = request
        self.describe_attempts += 1
        if self.describe_attempts == 1:
            return types.SimpleNamespace(
                to_dict=lambda: {
                    "Result": {
                        "EipAddresses": [
                            {"AllocationId": "eip-bound", "Status": "Attached", "InstanceId": "i-test"},
                            {"AllocationId": "eip-other", "Status": "Attached", "InstanceId": "i-other"},
                        ]
                    }
                }
            )
        return FakeDescribeEipResponse()


class FakeVpcApiWithMultipleAvailableEips(FakeVpcApi):
    def describe_eip_addresses(self, request):
        self.request = request
        return types.SimpleNamespace(
            to_dict=lambda: {
                "Result": {
                    "EipAddresses": [
                        {"AllocationId": "eip-available-1", "Status": "Available", "InstanceId": "", "EipAddress": "1.1.1.1"},
                        {"AllocationId": "eip-available-2", "Status": "Available", "InstanceId": "", "EipAddress": "1.1.1.2"},
                    ]
                }
            }
        )


class FakeVpcApiWithOneAvailableEip(FakeVpcApi):
    def describe_eip_addresses(self, request):
        self.request = request
        items = [
            {"AllocationId": "eip-available-1", "Status": "Available", "InstanceId": "", "EipAddress": "1.1.1.1"},
        ]
        if self.allocate_attempts:
            items.append({"AllocationId": "eip-test", "Status": "Available", "InstanceId": "", "EipAddress": "1.1.1.3"})
        return types.SimpleNamespace(to_dict=lambda: {"Result": {"EipAddresses": items}})


class FakeEcsApi:
    def __init__(self):
        self.replace_system_volume_request = None
        self.run_command_request = None
        self.invocation_results = [
            {
                "InvocationResultStatus": "Success",
                "ExitCode": 0,
            }
        ]

    def replace_system_volume(self, request):
        self.replace_system_volume_request = request
        return {"Result": {"RequestId": "replace-test"}}

    def describe_cloud_assistant_status(self, request):
        return {"Result": {"Instances": [{"InstanceId": "i-test", "Status": "Online"}]}}

    def describe_instances(self, request):
        return {"Result": {"Instances": [{"InstanceId": "i-test", "OsType": "Windows"}]}}

    def run_command(self, request):
        self.run_command_request = request
        return {"Result": {"InvocationId": "ivk-test"}}

    def describe_invocation_results(self, request):
        return {
            "Result": {
                "InvocationResults": self.invocation_results
            }
        }


class FakeEcsApiWithReplacePolling(FakeEcsApi):
    def __init__(self, target_image_id: str, final_status: str = "STOPPED"):
        super().__init__()
        self.target_image_id = target_image_id
        self.final_status = final_status
        self.describe_calls = 0

    def describe_instances(self, request):
        self.describe_calls += 1
        if self.describe_calls < 3:
            return {
                "Result": {
                    "Instances": [
                        {
                            "InstanceId": "i-test",
                            "ImageId": "image-old",
                            "Status": "REPLACING",
                            "OsType": "Linux",
                        }
                    ]
                }
            }
        return {
            "Result": {
                "Instances": [
                    {
                        "InstanceId": "i-test",
                        "ImageId": self.target_image_id,
                        "Status": self.final_status,
                        "OsType": "Windows",
                    }
                ]
            }
        }


class VolcengineEnvCommandTest(unittest.TestCase):
    def test_build_set_desktop_resolution_command_defaults_to_1080p(self):
        command = build_set_desktop_resolution_command("user", "/home/user", ":0", "/home/user/.Xauthority")

        self.assertIn("target_mode=1920x1080", command)
        self.assertIn("cvt_mode=1920x1080_60.00", command)
        self.assertIn("xrandr --output", command)
        self.assertIn("xdpyinfo", command)
        self.assertIn("desktop resolution set:", command)
        self.assertIn("substr(\\$0, 10)", command)
        self.assertNotIn('sub(/^Modeline /, "");', command)

    def test_build_set_windows_desktop_resolution_command_defaults_to_1080p(self):
        command = build_set_windows_desktop_resolution_command("Administrator", "secret", 1920, 1080)

        self.assertIn("WorkflowGymSetDesktopResolution", command)
        self.assertIn("workflowgym_set_desktop_resolution.ps1", command)
        self.assertIn("WORKFLOWGYM_WINDOWS_RESOLUTION_TASK_STARTED", command)
        self.assertIn("WORKFLOWGYM_WINDOWS_RESOLUTION_TARGET", command)
        self.assertIn("$targetWidth = 1920", command)
        self.assertIn("$targetHeight = 1080", command)
        self.assertIn("ChangeDisplaySettings", command)
        self.assertIn("/IT", command)

    def test_display_session_needs_xorg_reboot_detects_xwayland(self):
        output = "\n".join(
            [
                "Screen 0: minimum 16 x 16, current 1280 x 800, maximum 32767 x 32767",
                "XWAYLAND0 connected 1280x800+0+0 (normal left inverted right x axis y axis) 0mm x 0mm",
                "   1280x800      59.86*+",
            ]
        )
        self.assertTrue(display_session_needs_xorg_reboot(output, "1920x1080"))

    def test_display_session_needs_xorg_reboot_skips_when_target_already_active(self):
        output = "\n".join(
            [
                "XWAYLAND0 connected 1920x1080+0+0",
                "   1920x1080     60.00*+",
            ]
        )
        self.assertFalse(display_session_needs_xorg_reboot(output, "1920x1080"))

    def test_display_session_needs_xorg_reboot_skips_xorg_output(self):
        output = "\n".join(
            [
                "Virtual-1 connected primary 1280x800+0+0",
                "   1920x1080     60.00",
                "   1280x800      59.86*+",
            ]
        )
        self.assertFalse(display_session_needs_xorg_reboot(output, "1920x1080"))

    def test_build_set_desktop_resolution_command_rejects_invalid_size(self):
        with self.assertRaises(ValueError):
            build_set_desktop_resolution_command("user", "/home/user", ":0", "/home/user/.Xauthority", 0, 1080)

    def test_allocate_eip_address_extracts_allocation_id(self):
        sys.modules["volcenginesdkvpc"] = types.SimpleNamespace(
            AllocateEipAddressRequest=lambda **kwargs: kwargs,
        )
        api = FakeVpcApi()

        result = allocate_eip_address(api, billing_type=2, project_name="default")

        self.assertEqual(result["allocation_id"], "eip-test")

    def test_find_available_eip_address_returns_unattached_available_eip(self):
        sys.modules["volcenginesdkvpc"] = types.SimpleNamespace(
            DescribeEipAddressesRequest=lambda **kwargs: kwargs,
        )
        api = FakeVpcApi()

        result = find_available_eip_address(api, project_name="default")

        self.assertIsNotNone(result)
        self.assertEqual(result["allocation_id"], "eip-available")

    def test_find_associated_eip_addresses_returns_eips_for_instance(self):
        sys.modules["volcenginesdkvpc"] = types.SimpleNamespace(
            DescribeEipAddressesRequest=lambda **kwargs: kwargs,
        )
        api = FakeVpcApiWithAssociatedEip()

        result = find_associated_eip_addresses(api, "i-test", project_name="default")

        self.assertEqual([item["allocation_id"] for item in result], ["eip-bound"])

    def test_initialize_for_sample_records_public_ip_requirement_in_dry_run(self):
        env = VolcengineEnv(dry_run="env", region="cn-guangzhou")

        metadata = env.initialize_for_sample("i-test", "image-test", "", requires_public_ip=True)

        self.assertTrue(metadata["requires_public_ip"])
        self.assertTrue(metadata["dry_run"])

    def test_disassociate_eip_address_uses_allocation_id(self):
        sys.modules["volcenginesdkvpc"] = types.SimpleNamespace(
            DisassociateEipAddressRequest=lambda **kwargs: kwargs,
        )
        api = FakeVpcApi()

        result = disassociate_eip_address(api, "eip-test")

        self.assertEqual(api.request["allocation_id"], "eip-test")
        self.assertEqual(result["Result"]["RequestId"], "req-test")

    def test_associate_eip_address_retries_transient_status(self):
        sys.modules["volcenginesdkvpc"] = types.SimpleNamespace(
            AssociateEipAddressRequest=lambda **kwargs: kwargs,
        )
        api = FakeVpcApi()

        result = associate_eip_address_with_retry(api, "eip-test", "i-test")

        self.assertEqual(api.associate_attempts, 2)
        self.assertEqual(result["Result"]["RequestId"], "associate-test")

    def test_invalid_instance_in_use_is_retryable(self):
        self.assertTrue(is_eip_status_retryable(RuntimeError("InvalidInstance.InUse")))

    def test_allocate_and_associate_reuses_available_eip(self):
        sys.modules["volcenginesdkvpc"] = types.SimpleNamespace(
            DescribeEipAddressesRequest=lambda **kwargs: kwargs,
            AssociateEipAddressRequest=lambda **kwargs: kwargs,
        )
        api = FakeVpcApi()
        import open_workflowgym.envs.volcengine_eip as eip_module

        original_create = eip_module.create_vpc_api
        eip_module.create_vpc_api = lambda region: api
        self.addCleanup(lambda: setattr(eip_module, "create_vpc_api", original_create))

        result = allocate_and_associate_eip("i-test", "cn-guangzhou")

        self.assertEqual(result["allocation_id"], "eip-available")
        self.assertTrue(result["reused_existing_eip"])
        self.assertEqual(api.allocate_attempts, 0)
        self.assertEqual(api.associate_attempts, 2)

    def test_allocate_and_associate_disassociates_existing_instance_eip_first(self):
        sys.modules["volcenginesdkvpc"] = types.SimpleNamespace(
            DescribeEipAddressesRequest=lambda **kwargs: kwargs,
            DisassociateEipAddressRequest=lambda **kwargs: kwargs,
            AssociateEipAddressRequest=lambda **kwargs: kwargs,
        )
        api = FakeVpcApiWithAssociatedEip()
        import open_workflowgym.envs.volcengine_eip as eip_module

        original_create = eip_module.create_vpc_api
        eip_module.create_vpc_api = lambda region: api
        self.addCleanup(lambda: setattr(eip_module, "create_vpc_api", original_create))
        import os

        previous_wait = os.environ.get("VOLCENGINE_EIP_PRE_DISASSOCIATE_WAIT_SECONDS")
        os.environ["VOLCENGINE_EIP_PRE_DISASSOCIATE_WAIT_SECONDS"] = "0"
        def restore_wait_env():
            if previous_wait is None:
                os.environ.pop("VOLCENGINE_EIP_PRE_DISASSOCIATE_WAIT_SECONDS", None)
            else:
                os.environ["VOLCENGINE_EIP_PRE_DISASSOCIATE_WAIT_SECONDS"] = previous_wait

        self.addCleanup(restore_wait_env)

        result = allocate_and_associate_eip("i-test", "cn-guangzhou")

        self.assertEqual(api.disassociate_attempts, 1)
        self.assertEqual(result["pre_disassociated_eips"][0]["allocation_id"], "eip-bound")
        self.assertEqual(result["allocation_id"], "eip-available")

    def test_prepare_eip_allocations_reuses_available_eips_before_allocating(self):
        sys.modules["volcenginesdkvpc"] = types.SimpleNamespace(
            DescribeEipAddressesRequest=lambda **kwargs: kwargs,
        )
        api = FakeVpcApiWithMultipleAvailableEips()
        import open_workflowgym.envs.volcengine_eip as eip_module

        original_create = eip_module.create_vpc_api
        eip_module.create_vpc_api = lambda region: api
        self.addCleanup(lambda: setattr(eip_module, "create_vpc_api", original_create))

        result = prepare_eip_allocations("cn-guangzhou", 2)

        self.assertEqual([item["allocation_id"] for item in result], ["eip-available-1", "eip-available-2"])
        self.assertEqual(api.allocate_attempts, 0)

    def test_prepare_eip_allocations_allocates_only_shortage(self):
        sys.modules["volcenginesdkvpc"] = types.SimpleNamespace(
            DescribeEipAddressesRequest=lambda **kwargs: kwargs,
            AllocateEipAddressRequest=lambda **kwargs: kwargs,
        )
        api = FakeVpcApiWithOneAvailableEip()
        import open_workflowgym.envs.volcengine_eip as eip_module

        original_create = eip_module.create_vpc_api
        eip_module.create_vpc_api = lambda region: api
        self.addCleanup(lambda: setattr(eip_module, "create_vpc_api", original_create))

        result = prepare_eip_allocations("cn-guangzhou", 2)

        self.assertEqual([item["allocation_id"] for item in result], ["eip-available-1", "eip-test"])
        self.assertEqual(api.allocate_attempts, 1)

    def test_cleanup_public_ip_binding_skips_without_allocation_id(self):
        env = VolcengineEnv(dry_run="env", region="cn-guangzhou")

        result = env.cleanup_public_ip_binding({}, "")

        self.assertEqual(result["status"], "skipped")
        self.assertEqual(result["reason"], "missing_allocation_id")

    def test_replace_system_volume_uses_password_without_keep_image_credential(self):
        sys.modules["volcenginesdkecs"] = types.SimpleNamespace(
            ReplaceSystemVolumeRequest=lambda **kwargs: kwargs,
        )
        env = VolcengineEnv(region="cn-guangzhou")
        api = FakeEcsApi()
        env._api_instance = api
        import os

        previous_password = os.environ.get("INSTANCE_PASSWORD")
        os.environ["INSTANCE_PASSWORD"] = "test-password"

        def restore_password_env():
            if previous_password is None:
                os.environ.pop("INSTANCE_PASSWORD", None)
            else:
                os.environ["INSTANCE_PASSWORD"] = previous_password

        self.addCleanup(restore_password_env)

        env.replace_system_volume("i-test", "image-test")

        self.assertEqual(api.replace_system_volume_request["password"], "test-password")
        self.assertFalse(api.replace_system_volume_request["keep_image_credential"])

    def test_windows_run_command_requires_windows_password(self):
        sys.modules["volcenginesdkecs"] = types.SimpleNamespace(
            DescribeCloudAssistantStatusRequest=lambda **kwargs: kwargs,
            DescribeInstancesRequest=lambda **kwargs: kwargs,
            RunCommandRequest=lambda **kwargs: kwargs,
            DescribeInvocationResultsRequest=lambda **kwargs: kwargs,
        )
        env = VolcengineEnv(region="cn-guangzhou")
        api = FakeEcsApi()
        env._api_instance = api

        with mock.patch.dict(
            "os.environ",
            {"WINDOWS_LOGIN_USER": "Administrator"},
            clear=False,
        ):
            import os

            os.environ.pop("INSTANCE_PASSWORD", None)
            os.environ.pop("WINDOWS_LOGIN_PASSWORD", None)
            with self.assertRaisesRegex(ValueError, "Windows RunCommand"):
                env.run_command_and_wait("i-test", "Write-Output 'ok'", 30, "PowerShell")

    def test_windows_run_command_sends_configured_windows_password(self):
        sys.modules["volcenginesdkecs"] = types.SimpleNamespace(
            DescribeCloudAssistantStatusRequest=lambda **kwargs: kwargs,
            DescribeInstancesRequest=lambda **kwargs: kwargs,
            RunCommandRequest=lambda **kwargs: kwargs,
            DescribeInvocationResultsRequest=lambda **kwargs: kwargs,
        )
        env = VolcengineEnv(region="cn-guangzhou")
        api = FakeEcsApi()
        env._api_instance = api

        with mock.patch.dict(
            "os.environ",
            {
                "INSTANCE_PASSWORD": "test-password",
                "WINDOWS_LOGIN_USER": "Administrator",
            },
            clear=False,
        ):
            env.run_command_and_wait("i-test", "Write-Output 'ok'", 30, "PowerShell")

        self.assertEqual(api.run_command_request["working_dir"], "C:\\Users\\")
        self.assertNotIn("username", api.run_command_request)
        self.assertEqual(api.run_command_request["windows_password"], "test-password")

    def test_windows_run_command_sends_optional_username(self):
        sys.modules["volcenginesdkecs"] = types.SimpleNamespace(
            DescribeCloudAssistantStatusRequest=lambda **kwargs: kwargs,
            DescribeInstancesRequest=lambda **kwargs: kwargs,
            RunCommandRequest=lambda **kwargs: kwargs,
            DescribeInvocationResultsRequest=lambda **kwargs: kwargs,
        )
        env = VolcengineEnv(region="cn-guangzhou")
        api = FakeEcsApi()
        env._api_instance = api

        with mock.patch.dict(
            "os.environ",
            {
                "INSTANCE_PASSWORD": "test-password",
                "WINDOWS_LOGIN_USER": "Administrator",
            },
            clear=False,
        ):
            env.run_command_and_wait("i-test", "Write-Output 'ok'", 30, "PowerShell", username="Administrator")

        self.assertEqual(api.run_command_request["username"], "Administrator")
        self.assertEqual(api.run_command_request["windows_password"], "test-password")

    def test_run_command_prints_status_and_decoded_output(self):
        sys.modules["volcenginesdkecs"] = types.SimpleNamespace(
            DescribeCloudAssistantStatusRequest=lambda **kwargs: kwargs,
            DescribeInstancesRequest=lambda **kwargs: kwargs,
            RunCommandRequest=lambda **kwargs: kwargs,
            DescribeInvocationResultsRequest=lambda **kwargs: kwargs,
        )
        env = VolcengineEnv(region="cn-guangzhou")
        api = FakeEcsApi()
        api.invocation_results = [
            {
                "InvocationResultStatus": "Success",
                "ExitCode": 0,
                "Output": "b2sK",
            }
        ]
        env._api_instance = api

        with mock.patch.dict(
            "os.environ",
            {
                "INSTANCE_PASSWORD": "test-password",
                "WINDOWS_LOGIN_USER": "Administrator",
            },
            clear=False,
        ), mock.patch("open_workflowgym.envs.volcengine_env.time.sleep"), mock.patch("builtins.print") as mocked_print:
            env.run_command_and_wait("i-test", "Write-Output 'ok'", 30, "PowerShell")

        printed = "\n".join(str(call.args[0]) for call in mocked_print.call_args_list if call.args)
        self.assertIn("WORKFLOWGYM_RUNCOMMAND_SUBMITTED", printed)
        self.assertIn("invocation_id=ivk-test", printed)
        self.assertIn("——cmd exe res———", printed)
        self.assertIn("ok\n", printed)
        self.assertIn("__________________", printed)
        self.assertNotIn("invocation_result_status=Success", printed)

    def test_pending_run_command_result_is_not_printed(self):
        with mock.patch("builtins.print") as mocked_print:
            print_run_command_invocation_results(
                "ivk-test",
                [{"InvocationResultStatus": "Pending", "ExitCode": 0}],
                finished=False,
                failed=False,
            )

        self.assertEqual(mocked_print.call_args_list, [])

    def test_failed_run_command_prints_failure_and_decoded_output(self):
        sys.modules["volcenginesdkecs"] = types.SimpleNamespace(
            DescribeCloudAssistantStatusRequest=lambda **kwargs: kwargs,
            DescribeInstancesRequest=lambda **kwargs: kwargs,
            RunCommandRequest=lambda **kwargs: kwargs,
            DescribeInvocationResultsRequest=lambda **kwargs: kwargs,
        )
        env = VolcengineEnv(region="cn-guangzhou")
        api = FakeEcsApi()
        api.invocation_results = [
            {
                "InvocationResultStatus": "Failed",
                "ExitCode": 1,
                "Output": "ZmFpbGVkCg==",
            }
        ]
        env._api_instance = api

        with mock.patch.dict(
            "os.environ",
            {
                "INSTANCE_PASSWORD": "test-password",
                "WINDOWS_LOGIN_USER": "Administrator",
            },
            clear=False,
        ), mock.patch("open_workflowgym.envs.volcengine_env.time.sleep"), mock.patch("builtins.print") as mocked_print:
            with self.assertRaisesRegex(ValueError, "RunCommand 执行失败"):
                env.run_command_and_wait("i-test", "Write-Output 'failed'", 30, "PowerShell")

        printed = "\n".join(str(call.args[0]) for call in mocked_print.call_args_list if call.args)
        self.assertIn("invocation_result_status=Failed", printed)
        self.assertIn("invocation_id=ivk-test", printed)
        self.assertIn("——cmd exe res———", printed)
        self.assertIn("failed\n", printed)
        self.assertIn("__________________", printed)

    def test_windows_initialization_defaults_to_flask_runner(self):
        env = VolcengineEnv(region="cn-guangzhou")

        with mock.patch.dict(
            "os.environ",
            {
                "INSTANCE_PASSWORD": "test-password",
                "WINDOWS_LOGIN_USER": "Administrator",
                "WINDOWS_AUTO_LOGIN_REBOOT": "0",
                "WORKFLOWGYM_CONFIGURE_TOSUTIL": "0",
                "WORKFLOWGYM_WINDOWS_FAST_INIT": "0",
            },
            clear=False,
        ):
            import os

            os.environ.pop("WINDOWS_CONFIGURE_AUTO_LOGIN", None)
            os.environ.pop("WINDOWS_ACTION_RUNNER", None)
            os.environ.pop("WINDOWS_FILE_QUEUE_RUNNER", None)

            def fake_run_command(instance_id, command, *args, **kwargs):
                if "build_windows_autologon" in command or "AutoAdminLogon" in command:
                    return {"results": [{"decoded_output": "WORKFLOWGYM_WINDOWS_AUTOLOGIN user=Administrator"}]}
                if "WORKFLOWGYM_WINDOWS_PIP_INDEX" in command or "build_prepare" in command:
                    return {"results": [{"decoded_output": "WORKFLOWGYM_WINDOWS_PYAUTOGUI_READY file=x\nWORKFLOWGYM_WINDOWS_PYAUTOGUI_SIZE 1024x768"}]}
                if "workflowgym_validate_pyautogui" in command or "pyautogui dimensions" in command:
                    return {"results": [{"decoded_output": "pyautogui dimensions: 1024x768"}]}
                if "WORKFLOWGYM_PROBE_FLASK_RUNNER_OK" in command:
                    return {"results": [{"decoded_output": "WORKFLOWGYM_PROBE_FLASK_RUNNER_OK"}]}
                if "WorkflowGymInteractiveFlaskRunner" in command:
                    return {"results": [{"decoded_output": "WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_STARTED"}]}
                raise AssertionError("unexpected command in test: %s" % command[:200])

            with mock.patch.object(env, "run_command", side_effect=fake_run_command):
                metadata = env.initialize_windows_for_sample("i-test", "")

        self.assertEqual(metadata.get("windows_action_runner"), "flask")
        self.assertEqual(metadata.get("windows_flask_runner_probe"), "ok")

    def test_windows_initialization_can_configure_flask_runner_without_eip(self):
        env = VolcengineEnv(region="cn-guangzhou")

        with mock.patch.dict(
            "os.environ",
            {
                "INSTANCE_PASSWORD": "test-password",
                "WINDOWS_LOGIN_USER": "Administrator",
                "WINDOWS_AUTO_LOGIN_REBOOT": "0",
                "WORKFLOWGYM_CONFIGURE_TOSUTIL": "0",
                "WORKFLOWGYM_WINDOWS_FAST_INIT": "0",
                "WINDOWS_ACTION_RUNNER": "flask",
            },
            clear=False,
        ):
            import os

            os.environ.pop("WINDOWS_CONFIGURE_AUTO_LOGIN", None)

            def fake_run_command(instance_id, command, *args, **kwargs):
                if "AutoAdminLogon" in command:
                    return {"results": [{"decoded_output": "WORKFLOWGYM_WINDOWS_AUTOLOGIN user=Administrator"}]}
                if "WORKFLOWGYM_WINDOWS_PIP_INDEX" in command:
                    return {"results": [{"decoded_output": "WORKFLOWGYM_WINDOWS_PYAUTOGUI_READY file=x\nWORKFLOWGYM_WINDOWS_PYAUTOGUI_SIZE 1024x768"}]}
                if "workflowgym_validate_pyautogui" in command:
                    return {"results": [{"decoded_output": "pyautogui dimensions: 1024x768"}]}
                if "WORKFLOWGYM_PROBE_FLASK_RUNNER_OK" in command:
                    return {"results": [{"decoded_output": "WORKFLOWGYM_PROBE_FLASK_RUNNER_OK"}]}
                if "WorkflowGymInteractiveFlaskRunner" in command:
                    return {"results": [{"decoded_output": "WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_STARTED"}]}
                raise AssertionError("unexpected command in test: %s" % command[:200])

            with mock.patch.object(env, "run_command", side_effect=fake_run_command):
                metadata = env.initialize_windows_for_sample("i-test", "")

        self.assertEqual(metadata.get("windows_action_runner"), "flask")
        self.assertEqual(metadata.get("windows_flask_runner_probe"), "ok")

    def test_windows_initialization_can_use_legacy_file_queue_runner(self):
        env = VolcengineEnv(region="cn-guangzhou")

        with mock.patch.dict(
            "os.environ",
            {
                "INSTANCE_PASSWORD": "test-password",
                "WINDOWS_LOGIN_USER": "Administrator",
                "WINDOWS_AUTO_LOGIN_REBOOT": "0",
                "WORKFLOWGYM_CONFIGURE_TOSUTIL": "0",
                "WINDOWS_ACTION_RUNNER": "file_queue",
            },
            clear=False,
        ):
            import os

            os.environ.pop("WINDOWS_CONFIGURE_AUTO_LOGIN", None)

            def fake_run_command(instance_id, command, *args, **kwargs):
                if "WORKFLOWGYM_PROBE_AUTOLOGIN_OK" in command and "Set-ItemProperty" not in command:
                    raise ValueError("autologin probe failed")
                if "Set-ItemProperty" in command and "AutoAdminLogon" in command:
                    return {"results": [{"decoded_output": "WORKFLOWGYM_WINDOWS_AUTOLOGIN user=Administrator"}]}
                if "workflowgym_probe_pyautogui" in command:
                    raise ValueError("pyautogui probe failed")
                if "WORKFLOWGYM_WINDOWS_PIP_INDEX" in command:
                    return {"results": [{"decoded_output": "WORKFLOWGYM_WINDOWS_PYAUTOGUI_READY file=x\nWORKFLOWGYM_WINDOWS_PYAUTOGUI_SIZE 1024x768"}]}
                if "workflowgym_validate_pyautogui" in command:
                    return {"results": [{"decoded_output": "pyautogui dimensions: 1024x768"}]}
                if "WORKFLOWGYM_PROBE_FILE_QUEUE_OK" in command and "WorkflowGymFileQueueWatchdog" not in command:
                    raise ValueError("file queue probe failed")
                if "WorkflowGymFileQueueWatchdog" in command:
                    return {"results": [{"decoded_output": "WORKFLOWGYM_FILE_QUEUE_RUNNER_HEARTBEAT"}]}
                raise AssertionError("unexpected command in test: %s" % command[:200])

            with mock.patch.object(env, "run_command", side_effect=fake_run_command):
                metadata = env.initialize_windows_for_sample("i-test", "")

        self.assertEqual(metadata.get("windows_action_runner"), "file_queue")
        self.assertIn("windows_file_queue_runner_result", metadata)

    def test_windows_fast_init_probe_checks_fresh_flask_runner_by_default(self):
        probe = build_windows_fast_init_probe_command()
        self.assertIn("WORKFLOWGYM_PROBE_FLASK_RUNNER_OK", probe)
        self.assertIn("workflowgym_interactive_flask_runner.py", probe)

        runner_probe = build_windows_file_queue_runner_probe_command(20)
        self.assertIn("WORKFLOWGYM_FILE_QUEUE_RUNNER_PROBE_OK", runner_probe)
        self.assertIn("$maxAge = 20", runner_probe)

    def test_windows_file_queue_runner_setup_uses_resilient_v3_runner(self):
        setup = build_windows_file_queue_runner_setup_command("Administrator", "secret")
        self.assertIn("runner_version = 3", setup)
        self.assertIn("def safe_screen_size():", setup)
        self.assertIn("def run_action_script(script_path):", setup)
        self.assertIn("CREATE_NEW_PROCESS_GROUP", setup)
        self.assertIn("LOOP_ERROR", setup)

    def test_windows_fast_init_restarts_flask_runner_when_probe_fails(self):
        env = VolcengineEnv(region="cn-guangzhou")
        runner_probe_calls = 0

        def fake_run_command(instance_id, command, *args, **kwargs):
            nonlocal runner_probe_calls
            if "workflowgym_fast_init_probe.py" in command:
                return {
                    "results": [
                        {
                            "decoded_output": "WORKFLOWGYM_PROBE_FLASK_RUNNER_OK\nWORKFLOWGYM_WINDOWS_FAST_INIT_READY size=1024x768",
                        }
                    ]
                }
            if "schtasks /Create" in command and "WorkflowGymInteractiveFlaskRunner" in command:
                return {"results": [{"decoded_output": "WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_STARTED"}]}
            if (
                "$taskName = 'WorkflowGymInteractiveFlaskRunner'" in command
                and "schtasks /Create" not in command
                and "workflowgym_fast_init_probe.py" not in command
            ):
                runner_probe_calls += 1
                if runner_probe_calls == 1:
                    raise ValueError("flask runner probe failed after retries")
                return {"results": [{"decoded_output": "WORKFLOWGYM_PROBE_FLASK_RUNNER_OK"}]}
            raise AssertionError("unexpected command: %s" % command[:200])

        with mock.patch.dict(
            "os.environ",
            {
                "INSTANCE_PASSWORD": "test-password",
                "WINDOWS_LOGIN_USER": "Administrator",
                "WORKFLOWGYM_WINDOWS_FAST_INIT": "1",
            },
            clear=False,
        ):
            with mock.patch.object(env, "run_command", side_effect=fake_run_command):
                metadata = env.initialize_windows_for_sample("i-test", "")

        self.assertTrue(metadata.get("windows_fast_init"))
        self.assertEqual(metadata.get("windows_flask_runner_probe"), "ok")
        self.assertIn("windows_flask_runner_setup_result", metadata)
        self.assertEqual(runner_probe_calls, 2)

    def test_windows_fast_init_restarts_file_queue_runner_when_probe_fails(self):
        env = VolcengineEnv(region="cn-guangzhou")
        runner_probe_calls = 0

        def fake_run_command(instance_id, command, *args, **kwargs):
            nonlocal runner_probe_calls
            if "workflowgym_fast_init_probe.py" in command:
                return {
                    "results": [
                        {
                            "decoded_output": "WORKFLOWGYM_FILE_QUEUE_RUNNER_PROBE_OK\nWORKFLOWGYM_WINDOWS_FAST_INIT_READY size=1024x768",
                        }
                    ]
                }
            if "WORKFLOWGYM_FILE_QUEUE_RUNNER_PROBE_OK" in command and "workflowgym_fast_init_probe.py" not in command:
                runner_probe_calls += 1
                if runner_probe_calls == 1:
                    raise ValueError("runner heartbeat stale age=999s")
                return {"results": [{"decoded_output": "WORKFLOWGYM_FILE_QUEUE_RUNNER_PROBE_OK"}]}
            if "WorkflowGymFileQueueWatchdog" in command:
                return {"results": [{"decoded_output": "WORKFLOWGYM_FILE_QUEUE_WATCHDOG_READY"}]}
            raise AssertionError("unexpected command: %s" % command[:200])

        with mock.patch.dict(
            "os.environ",
            {
                "INSTANCE_PASSWORD": "test-password",
                "WINDOWS_LOGIN_USER": "Administrator",
                "WORKFLOWGYM_WINDOWS_FAST_INIT": "1",
                "WINDOWS_ACTION_RUNNER": "file_queue",
            },
            clear=False,
        ):
            with mock.patch.object(env, "run_command", side_effect=fake_run_command):
                metadata = env.initialize_windows_for_sample("i-test", "")

        self.assertTrue(metadata.get("windows_fast_init"))
        self.assertEqual(metadata.get("windows_file_queue_runner_probe"), "ok")
        self.assertIn("windows_file_queue_runner_result", metadata)
        self.assertEqual(runner_probe_calls, 2)

    def test_run_command_failure_logs_command_context(self):
        sys.modules["volcenginesdkecs"] = types.SimpleNamespace(
            DescribeCloudAssistantStatusRequest=lambda **kwargs: kwargs,
            DescribeInstancesRequest=lambda **kwargs: kwargs,
            RunCommandRequest=lambda **kwargs: kwargs,
            DescribeInvocationResultsRequest=lambda **kwargs: kwargs,
        )
        env = VolcengineEnv(region="cn-guangzhou")
        api = FakeEcsApi()
        api.invocation_results = [
            {
                "InvocationResultStatus": "Failed",
                "ExitCode": 1,
                "Output": "ZmFpbGVk",
            }
        ]
        env._api_instance = api
        command = "Write-Output 'debug-me'"

        with mock.patch.dict(
            "os.environ",
            {
                "INSTANCE_PASSWORD": "test-password",
                "WINDOWS_LOGIN_USER": "Administrator",
            },
            clear=False,
        ):
            with self.assertRaisesRegex(ValueError, "debug-me") as cm:
                env.run_command_and_wait("i-test", command, 30, "PowerShell")

        error_text = str(cm.exception)
        self.assertIn("RunCommand context:", error_text)
        self.assertIn("type=PowerShell", error_text)
        self.assertIn("working_dir=C:\\Users\\", error_text)
        self.assertIn("windows_password=<set len=13 last4=word>", error_text)
        self.assertIn(command, error_text)
        self.assertNotIn("test-password", error_text)

    def test_instance_image_id_reads_image_id_field(self):
        self.assertEqual(instance_image_id({"ImageId": "image-test"}), "image-test")
        self.assertEqual(instance_image_id({"image_id": "image-lower"}), "image-lower")
        self.assertEqual(instance_image_id({}), "")

    def test_wait_for_replace_system_volume_waits_until_target_image_and_stopped(self):
        sys.modules["volcenginesdkecs"] = types.SimpleNamespace(
            DescribeInstancesRequest=lambda **kwargs: kwargs,
        )
        env = VolcengineEnv(region="cn-guangzhou")
        api = FakeEcsApiWithReplacePolling("image-new")
        env._api_instance = api

        with mock.patch.dict(
            "os.environ",
            {"REPLACE_SYSTEM_VOLUME_POLL_SECONDS": "0"},
            clear=False,
        ):
            instance = env.wait_for_replace_system_volume("i-test", "image-new", timeout_seconds=30)

        self.assertEqual(api.describe_calls, 3)
        self.assertEqual(instance_image_id(instance), "image-new")
        self.assertEqual(instance.get("Status"), "STOPPED")

    def test_wait_for_replace_system_volume_accepts_running_with_target_image(self):
        sys.modules["volcenginesdkecs"] = types.SimpleNamespace(
            DescribeInstancesRequest=lambda **kwargs: kwargs,
        )
        env = VolcengineEnv(region="cn-guangzhou")
        api = FakeEcsApiWithReplacePolling("image-new", final_status="RUNNING")
        env._api_instance = api

        with mock.patch.dict(
            "os.environ",
            {"REPLACE_SYSTEM_VOLUME_POLL_SECONDS": "0"},
            clear=False,
        ):
            instance = env.wait_for_replace_system_volume("i-test", "image-new", timeout_seconds=30)

        self.assertEqual(instance_image_id(instance), "image-new")
        self.assertEqual(instance.get("Status"), "RUNNING")

    def test_is_replace_system_volume_complete(self):
        self.assertTrue(
            is_replace_system_volume_complete({"image_id": "image-new", "status": "RUNNING"}, "image-new")
        )
        self.assertTrue(
            is_replace_system_volume_complete({"ImageId": "image-new", "Status": "STOPPED"}, "image-new")
        )
        self.assertFalse(
            is_replace_system_volume_complete({"image_id": "image-old", "status": "RUNNING"}, "image-new")
        )
        self.assertFalse(
            is_replace_system_volume_complete({"image_id": "image-new", "status": "REPLACING"}, "image-new")
        )

    def test_wait_for_replace_system_volume_timeout_raises(self):
        sys.modules["volcenginesdkecs"] = types.SimpleNamespace(
            DescribeInstancesRequest=lambda **kwargs: kwargs,
        )
        env = VolcengineEnv(region="cn-guangzhou")
        api = FakeEcsApiWithReplacePolling("image-new")
        env._api_instance = api

        with mock.patch.dict(
            "os.environ",
            {"REPLACE_SYSTEM_VOLUME_POLL_SECONDS": "0"},
            clear=False,
        ):
            with self.assertRaisesRegex(TimeoutError, "等待镜像替换完成超时"):
                env.wait_for_replace_system_volume("i-test", "image-new", timeout_seconds=0)

    def test_ensure_cloud_assistant_ready_reboots_on_readyreboot(self):
        sys.modules["volcenginesdkecs"] = types.SimpleNamespace(
            DescribeInstancesRequest=lambda **kwargs: kwargs,
            RebootInstanceRequest=lambda **kwargs: kwargs,
        )
        env = VolcengineEnv(region="cn-guangzhou")
        statuses = [
            {"InstanceId": "i-test", "Status": "ReadyReboot"},
            {"InstanceId": "i-test", "Status": "Online"},
        ]

        def fake_describe(instance_id):
            if statuses:
                return statuses.pop(0)
            return {"InstanceId": "i-test", "Status": "Online"}

        with mock.patch.object(env, "describe_cloud_assistant_status", side_effect=fake_describe), mock.patch.object(
            env, "_reboot_for_cloud_assistant"
        ) as reboot_mock, mock.patch("open_workflowgym.envs.volcengine_env.time.sleep"):
            result = env.ensure_cloud_assistant_ready("i-test")

        reboot_mock.assert_called_once_with("i-test")
        self.assertEqual(cloud_assistant_status_value(result), "Online")

    def test_ensure_cloud_assistant_ready_reboots_when_readyreboot_appears_during_poll(self):
        sys.modules["volcenginesdkecs"] = types.SimpleNamespace(
            DescribeInstancesRequest=lambda **kwargs: kwargs,
            RebootInstanceRequest=lambda **kwargs: kwargs,
        )
        env = VolcengineEnv(region="cn-guangzhou")
        statuses = [
            {"InstanceId": "i-test", "Status": "Installing"},
            {"InstanceId": "i-test", "Status": "ReadyReboot"},
            {"InstanceId": "i-test", "Status": "Online"},
        ]

        def fake_describe(instance_id):
            if statuses:
                return statuses.pop(0)
            return {"InstanceId": "i-test", "Status": "Online"}

        with mock.patch.object(env, "describe_cloud_assistant_status", side_effect=fake_describe), mock.patch.object(
            env, "_reboot_for_cloud_assistant"
        ) as reboot_mock, mock.patch("open_workflowgym.envs.volcengine_env.time.sleep"):
            result = env.ensure_cloud_assistant_ready("i-test")

        reboot_mock.assert_called_once_with("i-test")
        self.assertEqual(cloud_assistant_status_value(result), "Online")

    def test_ensure_cloud_assistant_ready_raises_when_reboot_attempts_exhausted(self):
        sys.modules["volcenginesdkecs"] = types.SimpleNamespace(
            DescribeInstancesRequest=lambda **kwargs: kwargs,
            RebootInstanceRequest=lambda **kwargs: kwargs,
        )
        env = VolcengineEnv(region="cn-guangzhou")

        with mock.patch.dict("os.environ", {"CLOUD_ASSISTANT_MAX_REBOOT_ATTEMPTS": "0"}, clear=False), mock.patch.object(
            env, "describe_cloud_assistant_status", return_value={"InstanceId": "i-test", "Status": "ReadyReboot"}
        ), mock.patch("open_workflowgym.envs.volcengine_env.time.sleep"):
            with self.assertRaisesRegex(RuntimeError, "需要重启实例后才能使用"):
                env.ensure_cloud_assistant_ready("i-test")

    def test_console_screenshot_retryable_includes_invalid_timestamp(self):
        error = ValueError(
            '{"Error":{"Code":"InvalidTimestamp","Message":"The Signature of the request is expired"}}'
        )
        self.assertTrue(is_console_screenshot_invalid_timestamp_error(error))
        self.assertTrue(is_console_screenshot_retryable(error))

    def test_get_console_screenshot_raises_total_timeout_when_call_hangs(self):
        import time as time_module

        env = VolcengineEnv(region="cn-guangzhou")

        class SlowApi:
            def get_console_screenshot(self, request):
                time_module.sleep(2)
                return {"Result": {"Screenshot": "unused"}}

        with mock.patch.dict(
            "os.environ",
            {
                "CONSOLE_SCREENSHOT_TOTAL_TIMEOUT_SECONDS": "1",
                "CONSOLE_SCREENSHOT_CALL_TIMEOUT_SECONDS": "0.2",
                "CONSOLE_SCREENSHOT_MAX_ATTEMPTS": "2",
                "CONSOLE_SCREENSHOT_RETRY_BASE_SECONDS": "0",
            },
            clear=False,
        ), mock.patch.object(env, "api", return_value=SlowApi()):
            with self.assertRaisesRegex(TimeoutError, "GetConsoleScreenshot 总超时"):
                env.get_console_screenshot("i-test")

    def test_get_console_screenshot_retries_invalid_timestamp(self):
        import base64

        env = VolcengineEnv(region="cn-guangzhou")
        calls = {"count": 0}
        screenshot_b64 = base64.b64encode(DRY_RUN_SCREENSHOT_BYTES).decode("ascii")

        class FlakyApi:
            def get_console_screenshot(self, request):
                calls["count"] += 1
                if calls["count"] == 1:
                    raise ValueError(
                        '{"Error":{"Code":"InvalidTimestamp","Message":"The Signature of the request is expired"}}'
                    )
                return {"Result": {"Screenshot": "data:image/png;base64," + screenshot_b64}}

        with mock.patch.dict(
            "os.environ",
            {
                "CONSOLE_SCREENSHOT_TOTAL_TIMEOUT_SECONDS": "10",
                "CONSOLE_SCREENSHOT_CALL_TIMEOUT_SECONDS": "5",
                "CONSOLE_SCREENSHOT_MAX_ATTEMPTS": "3",
                "CONSOLE_SCREENSHOT_RETRY_BASE_SECONDS": "0",
            },
            clear=False,
        ), mock.patch.object(env, "api", return_value=FlakyApi()), mock.patch(
            "open_workflowgym.envs.volcengine_env.time.sleep"
        ):
            screenshot = env.get_console_screenshot("i-test")

        self.assertEqual(screenshot, DRY_RUN_SCREENSHOT_BYTES)
        self.assertEqual(calls["count"], 2)


class UbuntuFlaskRunnerPortTests(unittest.TestCase):
    def test_default_port_candidates_prefer_80_then_8080(self):
        with mock.patch.dict("os.environ", {}, clear=True):
            self.assertEqual(ubuntu_flask_runner_port_candidates(), [80, 8080])
            self.assertEqual(ubuntu_flask_runner_port(), 80)

    def test_explicit_env_port_overrides_candidates(self):
        with mock.patch.dict("os.environ", {"UBUNTU_FLASK_RUNNER_PORT": "19090"}, clear=True):
            self.assertEqual(ubuntu_flask_runner_port_candidates(), [19090])
            self.assertEqual(ubuntu_flask_runner_port(), 19090)


class UbuntuFlaskRunnerSetupCommandTests(unittest.TestCase):
    def test_flask_setup_uses_break_system_packages_fallback(self):
        command = build_ubuntu_interactive_flask_runner_setup_command(
            "user",
            "/home/user",
            ":0",
            "/run/user/1000/gdm/Xauthority",
            "workflowgym-flask-token",
            80,
        )
        self.assertIn("workflowgym_pip_install_flask()", command)
        self.assertIn("workflowgym_pip_install_flask_fallback()", command)
        self.assertIn("--ignore-installed --break-system-packages flask", command)
        self.assertIn("WORKFLOWGYM_FLASK_PIP_INSTALL_OK", command)
        self.assertIn("WORKFLOWGYM_FLASK_PIP_INSTALL_FAILED", command)
        self.assertNotIn("|| true", command.split("workflowgym_pip_install_flask")[1].split("sudo tee")[0])

    def test_local_mode_binds_loopback(self):
        env = {"LEASE_BACKEND": "local"}
        with mock.patch.dict("os.environ", env, clear=False):
            os.environ.pop("WORKFLOWGYM_FLASK_BIND_HOST", None)
            self.assertEqual(flask_runner_bind_host(), "127.0.0.1")
            command = build_ubuntu_interactive_flask_runner_setup_command(
                "user",
                "/home/user",
                ":0",
                "/run/user/1000/gdm/Xauthority",
                "workflowgym-flask-token",
                80,
            )
        self.assertIn('BIND_HOST = "127.0.0.1"', command)
        self.assertNotIn('BIND_HOST = "0.0.0.0"', command)

    def test_redis_mode_binds_loopback(self):
        with mock.patch.dict("os.environ", {"LEASE_BACKEND": "redis"}, clear=False):
            os.environ.pop("WORKFLOWGYM_FLASK_BIND_HOST", None)
            self.assertEqual(flask_runner_bind_host(), "127.0.0.1")
            command = build_ubuntu_interactive_flask_runner_setup_command(
                "user",
                "/home/user",
                ":0",
                "/run/user/1000/gdm/Xauthority",
                "workflowgym-flask-token",
                80,
            )
        self.assertIn('BIND_HOST = "127.0.0.1"', command)
        self.assertNotIn('BIND_HOST = "0.0.0.0"', command)

    def test_bind_host_env_override(self):
        with mock.patch.dict(
            "os.environ",
            {"LEASE_BACKEND": "local", "WORKFLOWGYM_FLASK_BIND_HOST": "0.0.0.0"},
            clear=False,
        ):
            self.assertEqual(flask_runner_bind_host(), "0.0.0.0")

    def test_windows_local_mode_binds_loopback(self):
        with mock.patch.dict("os.environ", {"LEASE_BACKEND": "local"}, clear=False):
            os.environ.pop("WORKFLOWGYM_FLASK_BIND_HOST", None)
            command = build_windows_interactive_flask_runner_setup_command(
                "Administrator",
                "password",
                "workflowgym-flask-token",
                8080,
            )
        self.assertIn('BIND_HOST = "127.0.0.1"', command)
        self.assertIn("app.run(host=BIND_HOST, port=PORT, threaded=False)", command)
        self.assertIn("path_outside_desktop", command)
        self.assertIn("DESKTOP_ROOT = Path(__file__).resolve().parent", command)

    def test_ubuntu_file_endpoint_restricted_to_desktop(self):
        command = build_ubuntu_interactive_flask_runner_setup_command(
            "user",
            "/home/user",
            ":0",
            "/run/user/1000/gdm/Xauthority",
            "workflowgym-flask-token",
            80,
        )
        self.assertIn('Path("/home/user/Desktop")', command)
        self.assertIn("path_outside_desktop", command)
        self.assertIn("def under_desktop(path):", command)


if __name__ == "__main__":
    unittest.main()
