from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.agents.base import SampleContext
from open_workflowgym.records import TaskRecord
from open_workflowgym.sampler import prepare_remote_action_command, should_deliver_windows_action_via_flask


class SamplerActionWrappingTest(unittest.TestCase):
    def test_wraps_raw_pyautogui_for_windows_flask_default(self):
        context = sample_context("windows", {"windows_action_runner": "flask"})
        command, action_script_info = prepare_remote_action_command("import pyautogui\npyautogui.click(1, 2)", context)

        self.assertEqual(action_script_info.get("backend"), "pyautogui")
        self.assertEqual(action_script_info.get("xdotool_code"), "")
        self.assertIn("$ErrorActionPreference = 'Stop'", command)
        self.assertIn("WORKFLOWGYM_FLASK_AGENT_RESULT", command)
        self.assertIn("127.0.0.1", command)
        self.assertNotIn("#!/bin/bash", command)

    def test_wraps_raw_pyautogui_for_windows_file_queue(self):
        context = sample_context("windows", {"windows_action_runner": "file_queue"})
        command, _ = prepare_remote_action_command("import pyautogui\npyautogui.click(1, 2)", context)

        self.assertIn("$ErrorActionPreference = 'Stop'", command)
        self.assertNotIn("#!/bin/bash", command)

    def test_wraps_raw_pyautogui_for_linux_flask_default(self):
        context = sample_context("ubuntu", {"ubuntu_action_runner": "flask"})
        command, action_script_info = prepare_remote_action_command("import pyautogui\npyautogui.click(1, 2)", context)

        self.assertEqual(action_script_info.get("backend"), "pyautogui")
        self.assertEqual(action_script_info.get("xdotool_code"), "")
        self.assertIn("pyautogui.click(1, 2)", action_script_info.get("pyautogui_code"))

        self.assertTrue(command.startswith("#!/bin/bash"))
        self.assertIn("WORKFLOWGYM_FLASK_AGENT_RESULT", command)
        self.assertIn("127.0.0.1", command)
        self.assertNotIn("/tmp/workflowgym_pyautogui.py", command)

    def test_wraps_raw_pyautogui_for_linux_legacy(self):
        context = sample_context("ubuntu", {"ubuntu_action_runner": "legacy"})
        command, _ = prepare_remote_action_command("import pyautogui\npyautogui.click(1, 2)", context)

        self.assertTrue(command.startswith("#!/bin/bash"))
        self.assertIn("/tmp/workflowgym_pyautogui.py", command)

    def test_keeps_already_wrapped_command(self):
        context = sample_context("windows")
        command = "$ErrorActionPreference = 'Stop'\nWrite-Output 'ok'"

        self.assertEqual(prepare_remote_action_command(command, context)[0], command)

    def test_should_not_deliver_windows_actions_via_external_flask(self):
        context = sample_context("windows", {"windows_action_runner": "flask"})
        command, _ = prepare_remote_action_command("import pyautogui\npyautogui.click(1, 2)", context)

        self.assertFalse(should_deliver_windows_action_via_flask(context, command))


def sample_context(platform: str, metadata: dict | None = None) -> SampleContext:
    payload = {"platform": platform}
    if metadata:
        payload.update(metadata)
    return SampleContext(
        run_id="run-test",
        task=TaskRecord(run_id="run-test", task_id="task-test", row_number=1, fields={}),
        sample_index=1,
        sample_dir="/tmp/sample",
        metadata=payload,
    )


if __name__ == "__main__":
    unittest.main()
