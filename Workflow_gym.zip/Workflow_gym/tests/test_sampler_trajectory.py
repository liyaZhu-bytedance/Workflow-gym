from __future__ import annotations

import sys
import types
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.agents.base import SampleContext
from open_workflowgym.agents.kimi26 import KimiNativeAgentAdapter
from open_workflowgym.records import RunConfig, SampleJob, StepTrace, TaskRecord
from open_workflowgym.sampler import (
    SampleRunState,
    Sampler,
    StepActionResult,
    is_recorded_step_trace,
    recorded_step_traces,
    trace_payload,
)


class SamplerTrajectoryFilterTest(unittest.TestCase):
    def test_is_recorded_step_trace_excludes_execution_failures(self):
        self.assertTrue(is_recorded_step_trace(StepTrace(step_index=0, screenshot="step_0.jpg", response="ok")))
        self.assertFalse(
            is_recorded_step_trace(
                StepTrace(
                    step_index=1,
                    screenshot="step_1.jpg",
                    response="bad",
                    error="RunCommand 执行失败: TaskExecutionFailed",
                )
            )
        )

    def test_recorded_step_traces_keeps_only_successful_steps(self):
        traces = [
            StepTrace(step_index=0, screenshot="step_0.jpg", response="ok"),
            StepTrace(step_index=1, screenshot="step_1.jpg", response="bad", error="failed"),
            StepTrace(step_index=2, screenshot="step_2.jpg", response="ok2"),
        ]
        recorded = recorded_step_traces(traces)
        self.assertEqual([trace.step_index for trace in recorded], [0, 2])

    def test_trace_payload_omits_error_field_for_successful_steps(self):
        payload = trace_payload(StepTrace(step_index=0, screenshot="step_0.jpg", response="ok"))
        self.assertNotIn("error", payload)


class KimiNativeHistoryRollbackTest(unittest.TestCase):
    def test_rollback_last_step_history_removes_last_turn(self):
        adapter = KimiNativeAgentAdapter()
        adapter.actions = ["action-1", "action-2"]
        adapter.cots = [{"action": "a1"}, {"action": "a2"}]
        adapter.observations = [{"screenshot": b"1"}, {"screenshot": b"2"}]

        adapter.rollback_last_step_history()

        self.assertEqual(adapter.actions, ["action-1"])
        self.assertEqual(len(adapter.cots), 1)
        self.assertEqual(len(adapter.observations), 1)


class SamplerDiscardFailedStepTest(unittest.TestCase):
    def test_discard_failed_step_removes_trace_and_rolls_back_player_history(self):
        env = types.SimpleNamespace(run_command=mock.Mock(return_value={"results": []}))
        sampler = Sampler(agent_factory=mock.Mock(), env=env)
        job = SampleJob(
            run_id="run-test",
            task_id="330",
            sample_index=1,
            task=TaskRecord(run_id="run-test", task_id="330", row_number=1, fields={}),
            config=RunConfig(run_id="run-test", player="kimi", step_num=1),
            lease=types.SimpleNamespace(instance_id="i-test"),
        )
        context = SampleContext(
            run_id="run-test",
            task=job.task,
            sample_index=1,
            sample_dir="/tmp/sample",
        )
        state = SampleRunState()
        player = KimiNativeAgentAdapter()
        player.actions = ["keep"]
        player.cots = [{"action": "keep"}]
        player.observations = [{"screenshot": b"keep"}]
        failed_trace = StepTrace(step_index=3, screenshot="step_3.jpg", response="bad action")
        state.traces.append(failed_trace)
        context.history.append(failed_trace)
        action_result = StepActionResult(trace=failed_trace)
        action_result.trace.error = "RunCommand 执行失败: SyntaxError"

        with mock.patch("open_workflowgym.sampler.trace_sample"):
            sampler.discard_failed_step_if_needed(job, state, context, player, action_result, 3)

        self.assertEqual(state.traces, [])
        self.assertEqual(context.history, [])
        self.assertEqual(player.actions, [])
        self.assertEqual(player.cots, [])
        self.assertEqual(player.observations, [])


if __name__ == "__main__":
    unittest.main()
