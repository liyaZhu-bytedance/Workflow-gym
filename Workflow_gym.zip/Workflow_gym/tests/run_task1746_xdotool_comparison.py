from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PKG_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(PKG_ROOT))

from open_workflowgym.agents.factory import AgentFactory
from open_workflowgym.envs.volcengine_env import VolcengineEnv
from open_workflowgym.records import InstanceLease, RunConfig, SampleJob, TaskRecord
from open_workflowgym.sampler import Sampler

from tests.test_task1746_ubuntu_http_runner_e2e import (
    STEP_NUM_100,
    TASK_ID,
    ensure_instance_running,
    load_zshrc_env,
    project_output_dir,
    read_env,
    resolve_task1746_record,
)

XDOTOOL_OUTPUT_DIR = "manual_task1746_xdotool_100step"
PYAUTOGUI_OUTPUT_DIR = "manual_task1746_pyautogui_100step"
COMPARISON_REPORT = "task1746_xdotool_vs_pyautogui_100step_comparison.md"


def build_sample_job(
    *,
    instance_id: str,
    output_root: str,
    player: str,
    run_id_suffix: str,
) -> SampleJob:
    run_id = "task1746-xdotool-compare-%s" % run_id_suffix
    task = resolve_task1746_record()
    task = TaskRecord(
        run_id=run_id,
        task_id=task.task_id,
        row_number=task.row_number,
        fields=task.fields,
    )
    return SampleJob(
        run_id=run_id,
        task_id=TASK_ID,
        sample_index=1,
        task=task,
        config=RunConfig(
            run_id=run_id,
            output_root=output_root,
            sample_num=1,
            step_num=STEP_NUM_100,
            player=player,
            judger="gemini3.1",
            enable_real_cloud=True,
            tosutil_timeout_seconds=180,
            write_step_traj=True,
            action_timeout_seconds=120,
        ),
        lease=InstanceLease(
            run_id=run_id,
            lease_id="%s-lease" % run_id,
            instance_id=instance_id,
            task_id=TASK_ID,
            sample_index=1,
            status="busy",
            acquired_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        ),
    )


def run_mode(*, mode: str, instance_id: str, player: str) -> dict:
    if mode == "xdotool":
        os.environ["UBUNTU_PYAUTOGUI_XDOTOOL_BACKEND"] = "1"
        output_dir = XDOTOOL_OUTPUT_DIR
        suffix = "xdotool-100"
    elif mode == "pyautogui":
        os.environ["UBUNTU_PYAUTOGUI_XDOTOOL_BACKEND"] = "0"
        output_dir = PYAUTOGUI_OUTPUT_DIR
        suffix = "pyautogui-100"
    else:
        raise ValueError("unknown mode: %s" % mode)

    os.environ.setdefault("UBUNTU_ACTION_RUNNER", "flask")
    output_root = str(project_output_dir() / output_dir)
    print("WORKFLOWGYM_COMPARE_MODE", mode, flush=True)
    print("WORKFLOWGYM_COMPARE_OUTPUT_ROOT", output_root, flush=True)
    print("WORKFLOWGYM_COMPARE_XDOTOOL_BACKEND", os.getenv("UBUNTU_PYAUTOGUI_XDOTOOL_BACKEND"), flush=True)
    print("WORKFLOWGYM_COMPARE_PLAYER", player, flush=True)

    env = VolcengineEnv(region=read_env("VOLCENGINE_REGION", read_env("SOURCE_REGION", "cn-guangzhou")))
    ensure_instance_running(env, instance_id)
    job = build_sample_job(instance_id=instance_id, output_root=output_root, player=player, run_id_suffix=suffix)
    trajectory = Sampler(AgentFactory(), env).run_sample(job)
    return {
        "mode": mode,
        "output_root": output_root,
        "sample_dir": trajectory.sample_dir,
        "status": trajectory.status,
        "last_step": trajectory.last_step,
        "error": trajectory.error,
        "traj_json_path": trajectory.traj_json_path,
        "traj_md_path": str(Path(trajectory.sample_dir) / "traj.md"),
    }


def read_jsonl(path: Path) -> list[dict]:
    if not path.is_file():
        return []
    events = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            payload = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict):
            events.append(payload)
    return events


def summarize_sample(sample_dir: Path) -> dict:
    summary = {
        "sample_dir": str(sample_dir),
        "exists": sample_dir.is_dir(),
        "screenshot_count": 0,
        "missing_screenshots": [],
        "status": "",
        "last_step": -1,
        "error": "",
        "backend_counts": {},
        "action_errors": 0,
        "skip_count": 0,
        "xdotool_action_steps": 0,
        "pyautogui_action_steps": 0,
        "traj_steps": 0,
        "traj_chars": 0,
    }
    if not sample_dir.is_dir():
        return summary

    status_path = sample_dir / "sample_status.json"
    if status_path.is_file():
        payload = json.loads(status_path.read_text(encoding="utf-8"))
        summary["status"] = str(payload.get("status") or "")
        summary["last_step"] = int(payload.get("last_step") or -1)
        summary["error"] = str(payload.get("error") or "")

    for step_index in range(STEP_NUM_100):
        shot = sample_dir / ("step_%d.jpg" % step_index)
        if shot.is_file():
            summary["screenshot_count"] += 1
        else:
            summary["missing_screenshots"].append(step_index)

    for event in read_jsonl(sample_dir / "sample_log.json"):
        extra = event.get("extra") if isinstance(event.get("extra"), dict) else {}
        backend = str(extra.get("backend") or "")
        if backend:
            summary["backend_counts"][backend] = summary["backend_counts"].get(backend, 0) + 1
            if backend == "xdotool":
                summary["xdotool_action_steps"] += 1
            if backend == "pyautogui":
                summary["pyautogui_action_steps"] += 1
        message = str(event.get("message") or "")
        if "SKIP" in message or str(extra.get("reason") or "").startswith("disallowed"):
            summary["skip_count"] += 1
        if "执行失败" in message or "failed" in message.lower():
            summary["action_errors"] += 1

    traj_md = sample_dir / "traj.md"
    if traj_md.is_file():
        text = traj_md.read_text(encoding="utf-8", errors="replace")
        summary["traj_chars"] = len(text)
        summary["traj_steps"] = text.count("\n## Step ")

    metadata_path = sample_dir / "sample_metadata.json"
    if metadata_path.is_file():
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        env_meta = metadata.get("env") if isinstance(metadata.get("env"), dict) else metadata
        summary["ubuntu_action_runner"] = env_meta.get("ubuntu_action_runner")
        summary["ubuntu_flask_runner_probe"] = env_meta.get("ubuntu_flask_runner_probe")

    return summary


def write_comparison_report(xdotool_summary: dict, pyautogui_summary: dict, report_path: Path) -> None:
    lines = [
        "# Task 1746：xdotool vs pyautogui 100 步对比",
        "",
        "> player: `kimi_native` | steps: 100 | Ubuntu Flask runner",
        "",
        "## 采样目录",
        "",
        "| 模式 | 目录 |",
        "|------|------|",
        "| xdotool | `%s` |" % xdotool_summary.get("sample_dir", ""),
        "| pyautogui | `%s` |" % pyautogui_summary.get("sample_dir", ""),
        "",
        "## 运行指标",
        "",
        "| 指标 | xdotool | pyautogui |",
        "|------|---------|-----------|",
        "| status | %s | %s |" % (xdotool_summary.get("status"), pyautogui_summary.get("status")),
        "| last_step | %s | %s |" % (xdotool_summary.get("last_step"), pyautogui_summary.get("last_step")),
        "| traj steps | %s | %s |" % (xdotool_summary.get("traj_steps"), pyautogui_summary.get("traj_steps")),
        "| screenshots | %s | %s |" % (xdotool_summary.get("screenshot_count"), pyautogui_summary.get("screenshot_count")),
        "| backend xdotool actions | %s | %s |" % (xdotool_summary.get("xdotool_action_steps"), pyautogui_summary.get("xdotool_action_steps")),
        "| backend pyautogui actions | %s | %s |" % (xdotool_summary.get("pyautogui_action_steps"), pyautogui_summary.get("pyautogui_action_steps")),
        "| skip/disallowed | %s | %s |" % (xdotool_summary.get("skip_count"), pyautogui_summary.get("skip_count")),
        "| action errors (log) | %s | %s |" % (xdotool_summary.get("action_errors"), pyautogui_summary.get("action_errors")),
        "",
        "## 截图缺失",
        "",
        "- xdotool missing: %s" % (xdotool_summary.get("missing_screenshots") or "none"),
        "- pyautogui missing: %s" % (pyautogui_summary.get("missing_screenshots") or "none"),
        "",
        "## 人工比对建议",
        "",
        "重点对比以下截图与 `traj.md` 对应 step：",
        "- `step_0.jpg` / `env_ready.jpg`：环境初始化",
        "- `step_6~12.jpg`：文件对话框导航",
        "- 中后期变量重命名与信度分析步骤",
        "- 末段是否生成 `KKX.pdf`",
        "",
        "查看轨迹：",
        "- `%s/traj.md`" % xdotool_summary.get("sample_dir", ""),
        "- `%s/traj.md`" % pyautogui_summary.get("sample_dir", ""),
        "",
    ]
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text("\n".join(lines), encoding="utf-8")
    print("WORKFLOWGYM_COMPARE_REPORT", str(report_path), flush=True)


def compare_existing() -> None:
    xdotool_summary = summarize_sample(project_output_dir() / XDOTOOL_OUTPUT_DIR / TASK_ID / "sample_1")
    pyautogui_summary = summarize_sample(project_output_dir() / PYAUTOGUI_OUTPUT_DIR / TASK_ID / "sample_1")
    report_path = project_output_dir() / COMPARISON_REPORT
    write_comparison_report(xdotool_summary, pyautogui_summary, report_path)
    print(json.dumps({"xdotool": xdotool_summary, "pyautogui": pyautogui_summary}, ensure_ascii=False, indent=2), flush=True)


def main() -> None:
    load_zshrc_env()
    parser = argparse.ArgumentParser(description="Run task 1746 xdotool vs pyautogui comparison")
    parser.add_argument(
        "command",
        choices=("run-both", "run-xdotool", "run-pyautogui", "compare"),
        help="run sampling or compare existing outputs",
    )
    parser.add_argument("--player", default="kimi_native")
    parser.add_argument("--instance-id", default=read_env("WORKFLOWGYM_TEST_INSTANCE_ID", "i-yeqf508xkwnu262ipptn"))
    args = parser.parse_args()

    if not read_env("AK") or not read_env("SK"):
        raise SystemExit("set AK/SK for Volcengine")
    if not (read_env("MOONSHOT_API_KEY") or read_env("KIMI_API_KEY") or read_env("KIMI_NATIVE_API_KEY")):
        raise SystemExit("set MOONSHOT_API_KEY or KIMI_API_KEY")

    if args.command == "compare":
        compare_existing()
        return

    results = []
    if args.command in ("run-both", "run-xdotool"):
        results.append(run_mode(mode="xdotool", instance_id=args.instance_id, player=args.player))
    if args.command in ("run-both", "run-pyautogui"):
        results.append(run_mode(mode="pyautogui", instance_id=args.instance_id, player=args.player))

    for item in results:
        print("WORKFLOWGYM_COMPARE_RESULT", json.dumps(item, ensure_ascii=False), flush=True)
    compare_existing()


if __name__ == "__main__":
    main()
