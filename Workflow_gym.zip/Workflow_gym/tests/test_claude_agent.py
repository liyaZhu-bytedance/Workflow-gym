from __future__ import annotations

import unittest

from mm_agents.anthropic.openrouter_agent import SYSTEM_PROMPT as LEGACY_CLAUDE_SYSTEM_PROMPT
from open_workflowgym.open_workflowgym.open_workflowgym.agents.base import SampleContext
from open_workflowgym.open_workflowgym.open_workflowgym.agents.claude import (
    SYSTEM_PROMPT,
    ClaudeAgentAdapter,
    extract_fallback_action,
)
from open_workflowgym.open_workflowgym.open_workflowgym.agents.factory import AgentFactory
from open_workflowgym.open_workflowgym.open_workflowgym.records import TaskRecord


class ClaudeAgentTest(unittest.TestCase):
    def test_factory_registers_claude(self):
        self.assertIsInstance(AgentFactory().create("claude"), ClaudeAgentAdapter)

    def test_embedded_prompt_matches_legacy_constant(self):
        self.assertEqual(SYSTEM_PROMPT, LEGACY_CLAUDE_SYSTEM_PROMPT)

    def test_action_to_pyautogui_scales_from_api_resolution(self):
        adapter = ClaudeAgentAdapter()
        adapter.screen_size = (1920, 1080)
        adapter.api_screen_size = (1280, 720)
        adapter.resize_factor = (1.5, 1.5)
        code = adapter.action_to_pyautogui({"action": "left_click", "coordinate": [640, 360]})
        self.assertIn("pyautogui.click(960, 540)", code)

    def test_fallback_action_parses_action_json(self):
        action = extract_fallback_action('Thinking...\nAction: {"action": "wait"}')
        self.assertEqual(action, {"action": "wait"})

    def test_terminal_command_requests_stop_without_executed_code(self):
        adapter = ClaudeAgentAdapter()
        adapter._last_actions = [{"command": "DONE", "action_type": "done"}]
        parsed = adapter.parse_response("{}", sample_context())
        self.assertEqual(parsed["function_call"], adapter._last_actions)
        self.assertEqual(adapter.to_pyautogui(parsed["function_call"], sample_context()), [])
        self.assertTrue(adapter.should_stop_after_step(sample_context(), None))

    def test_no_actions_requests_stop_like_wg_main(self):
        adapter = ClaudeAgentAdapter()
        adapter._last_actions = []
        adapter._should_stop_after_step = True
        self.assertTrue(adapter.should_stop_after_step(sample_context(), None))


def sample_context() -> SampleContext:
    return SampleContext(
        run_id="run-test",
        task=TaskRecord(run_id="run-test", task_id="task-test", row_number=1, fields={"task": "demo"}),
        sample_index=1,
        sample_dir="/tmp/sample",
    )


if __name__ == "__main__":
    unittest.main()
