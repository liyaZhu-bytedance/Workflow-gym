from __future__ import print_function

import os
import unittest

import volcenginesdkcore
import volcenginesdkecs

from main import get_result_payload, run_command_and_wait


INSTANCE_ID = os.getenv("INSTANCE_ID", "i-yeprxlt3i8bw80dfwlbv")


def create_api_instance():
    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = "cn-beijing"
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkecs.ECSApi()


class TestInstanceIfconfig(unittest.TestCase):
    def test_run_ifconfig_on_instance(self):
        api_instance = create_api_instance()

        response_data = run_command_and_wait(
            api_instance,
            INSTANCE_ID,
            "#!/bin/bash\nifconfig",
            "test-ifconfig",
            working_dir="/home",
            timeout=60,
        )

        result = get_result_payload(response_data)
        invocation_results = (
            result.get("InvocationResults")
            or result.get("invocation_results")
            or []
        )
        self.assertTrue(invocation_results, "没有获取到 ifconfig 执行结果")

        for item in invocation_results:
            status = (
                item.get("InvocationResultStatus")
                or item.get("invocation_result_status")
            )
            exit_code = item.get("ExitCode")
            if exit_code is None:
                exit_code = item.get("exit_code")

            self.assertEqual(status, "Success")
            self.assertEqual(exit_code, 0)
            print("ifconfig 输出:")
            print(item.get("decoded_output") or "<无输出>")


if __name__ == "__main__":
    unittest.main()
