from __future__ import print_function

import json
import os
import time
import unittest
import uuid
import warnings

warnings.filterwarnings(
    "ignore",
    message="urllib3 v2 only supports OpenSSL.*",
)

import volcenginesdkcore
import volcenginesdkecs
from volcenginesdkcore.rest import ApiException


PROJECT_NAME = os.getenv("PROJECT_NAME", "default")
IMAGE_ID = os.getenv("IMAGE_ID", "image-yepzpl6g3ikhx1vo9jam")
INSTANCE_NAME = os.getenv("INSTANCE_NAME", "open_workflow_gym_ubuntu")
INSTANCE_TYPE_ID = os.getenv("INSTANCE_TYPE_ID", "ecs.g3il.4xlarge")
INSTANCE_TYPE_IDS = tuple(
    item.strip()
    for item in os.getenv("INSTANCE_TYPE_IDS", "ecs.r4il.4xlarge,ecs.r4il.2xlarge,%s" % INSTANCE_TYPE_ID).split(",")
    if item.strip()
)
SECURITY_GROUP_ID = os.getenv("SECURITY_GROUP_ID", "sg-2jxvygwafv9xc7zrx9wf0sqkg")
SUBNET_ID = os.getenv("SUBNET_ID", "subnet-1phsryth6pgqo5sehpn21io2h")
VOLUME_SIZE = int(os.getenv("VOLUME_SIZE", "400"))
ZONE_ID = os.getenv("ZONE_ID", "cn-guangzhou-a")
AVAILABLE_RESOURCE_ZONES = tuple(
    item.strip()
    for item in os.getenv("AVAILABLE_RESOURCE_ZONES", "cn-guangzhou-a,cn-guangzhou-b,cn-guangzhou-c").split(",")
    if item.strip()
)
INSTANCE_PASSWORD = os.getenv("INSTANCE_PASSWORD", "AlwaysDay1-BUPT-01")
INSTANCE_COUNT = int(os.getenv("INSTANCE_COUNT", "39"))
INSTANCE_READY_STATUS = os.getenv("INSTANCE_READY_STATUS", "RUNNING")
INSTANCE_CREATE_TIMEOUT_SECONDS = int(os.getenv("INSTANCE_CREATE_TIMEOUT_SECONDS", "900"))
POLL_INTERVAL_SECONDS = int(os.getenv("POLL_INTERVAL_SECONDS", "30"))


def create_api_instance():
    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = "cn-guangzhou"
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkecs.ECSApi()


def get_result_payload(data):
    return data.get("Result") or data.get("result") or data


def to_plain_dict(value):
    if hasattr(value, "to_dict"):
        return value.to_dict()
    if isinstance(value, dict):
        return value
    return dict(value)


def build_run_instances_request(instance_type_id):
    return volcenginesdkecs.RunInstancesRequest(
        project_name=PROJECT_NAME,
        image_id=IMAGE_ID,
        instance_name=INSTANCE_NAME,
        instance_type_id=instance_type_id,
        network_interfaces=[
            volcenginesdkecs.NetworkInterfaceForRunInstancesInput(
                security_group_ids=[SECURITY_GROUP_ID],
                subnet_id=SUBNET_ID,
            )
        ],
        volumes=[
            volcenginesdkecs.VolumeForRunInstancesInput(
                size=VOLUME_SIZE,
            )
        ],
        zone_id=ZONE_ID,
        keep_image_credential=False,
        password=INSTANCE_PASSWORD,
        client_token=str(uuid.uuid4()),
    )


def describe_instance(api_instance, instance_id):
    response = api_instance.describe_instances(
        volcenginesdkecs.DescribeInstancesRequest(instance_ids=[instance_id])
    )
    response_data = to_plain_dict(response)
    result = get_result_payload(response_data)
    instances = result.get("Instances") or result.get("instances") or []
    if not instances:
        raise AssertionError("DescribeInstances 没有查询到实例: %s" % instance_id)
    return instances[0]


def instance_status(instance):
    return instance.get("Status") or instance.get("status") or ""


def wait_for_instance_status(api_instance, instance_id, expected_status):
    deadline = time.time() + INSTANCE_CREATE_TIMEOUT_SECONDS
    last_status = ""
    while time.time() < deadline:
        instance = describe_instance(api_instance, instance_id)
        last_status = instance_status(instance)
        print("实例 %s 当前状态: %s" % (instance_id, last_status))
        if last_status == expected_status:
            return instance
        if last_status in ("ERROR", "FAILED"):
            raise AssertionError("实例创建失败: %s status=%s" % (instance_id, last_status))
        time.sleep(POLL_INTERVAL_SECONDS)
    raise AssertionError(
        "等待实例状态超时: %s expected=%s last_status=%s"
        % (instance_id, expected_status, last_status)
    )


def print_available_resources(api_instance, instance_type_id):
    print("查询广州各可用区库存: instance_type_id=%s" % instance_type_id)
    for zone_id in AVAILABLE_RESOURCE_ZONES:
        try:
            request = volcenginesdkecs.DescribeAvailableResourceRequest(
                destination_resource="InstanceType",
                instance_type_id=instance_type_id,
                zone_id=zone_id,
            )
            response = api_instance.describe_available_resource(request)
            result = get_result_payload(to_plain_dict(response))
            print_available_resource_result(zone_id, result)
        except ApiException as exc:
            print("库存查询失败: zone_id=%s error=%s" % (zone_id, exc))


def print_available_resource_result(zone_id, result):
    zones = result.get("AvailableZones") or result.get("available_zones") or []
    if not zones:
        print("  - %s: 无库存返回" % zone_id)
        return
    zone = zones[0]
    zone_status = zone.get("Status") or zone.get("status") or ""
    resources = []
    for available_resource in zone.get("AvailableResources") or zone.get("available_resources") or []:
        for supported_resource in available_resource.get("SupportedResources") or available_resource.get("supported_resources") or []:
            resources.append(
                "%s=%s"
                % (
                    supported_resource.get("Value") or supported_resource.get("value"),
                    supported_resource.get("Status") or supported_resource.get("status"),
                )
            )
    print("  - %s: %s %s" % (zone_id, zone_status, ", ".join(resources)))


def api_exception_code(exc):
    body = getattr(exc, "body", None)
    if not body:
        return ""
    try:
        data = json.loads(body)
    except (TypeError, ValueError):
        return str(body)
    metadata = data.get("ResponseMetadata") or {}
    error = metadata.get("Error") or data.get("Error") or {}
    return error.get("Code") or ""


def handle_run_instances_exception(api_instance, exc, instance_type_id):
    error_code = api_exception_code(exc)
    print("RunInstances 调用失败: error_code=%s zone_id=%s instance_type_id=%s" % (error_code, ZONE_ID, instance_type_id))
    if error_code == "Insufficient.InstanceCapacity":
        print_available_resources(api_instance, instance_type_id)
        print("提示: 如果其他可用区 Available，需要同时切换 ZONE_ID 和对应可用区的 SUBNET_ID。")


def is_retryable_capacity_error(exc):
    return api_exception_code(exc) == "Insufficient.InstanceCapacity"


def run_instances_with_ordered_specs(api_instance):
    last_exception = None
    for instance_type_id in INSTANCE_TYPE_IDS:
        try:
            print("尝试创建实例: zone_id=%s instance_type_id=%s" % (ZONE_ID, instance_type_id))
            request = build_run_instances_request(instance_type_id)
            return instance_type_id, api_instance.run_instances(request)
        except ApiException as exc:
            last_exception = exc
            handle_run_instances_exception(api_instance, exc, instance_type_id)
            if not is_retryable_capacity_error(exc):
                raise
            print("规格库存不足，降级尝试下一个规格")
    raise AssertionError("所有候选规格都无法创建实例: %s last_error=%s" % (",".join(INSTANCE_TYPE_IDS), last_exception))


class TestCreateInstance(unittest.TestCase):
    def test_run_instances(self):
        api_instance = create_api_instance()

        for i in range(1, INSTANCE_COUNT + 1):
            try:
                print("创建第 %s 个实例" % i)
                selected_instance_type_id, response = run_instances_with_ordered_specs(api_instance)
            except ApiException as exc:
                self.fail("RunInstances 调用失败: %s" % exc)

            response_data = to_plain_dict(response)
            result = get_result_payload(response_data)
            instance_ids = result.get("InstanceIds") or result.get("instance_ids") or []

            self.assertTrue(instance_ids, "RunInstances 响应中没有返回 InstanceIds")
            print("创建实例成功，instance_type_id=%s InstanceIds:" % selected_instance_type_id)
            print(instance_ids)
            for instance_id in instance_ids:
                wait_for_instance_status(api_instance, instance_id, INSTANCE_READY_STATUS)
                print("实例创建完成: %s status=%s" % (instance_id, INSTANCE_READY_STATUS))


if __name__ == "__main__":
    unittest.main()
