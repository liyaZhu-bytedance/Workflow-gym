"""Live: POST /api/v1/sessions/acquire-and-prepare + poll jobs/{job_id}."""
from __future__ import annotations

import os
import unittest

from tests.wgm_http._common import make_client, require_wgm_token, save_lease


@require_wgm_token
class AcquireAndPrepareHttpTest(unittest.TestCase):
    def test_acquire_and_prepare_wait(self):
        client = make_client()
        image_id = str(os.getenv("WGM_IMAGE_ID") or "").strip()
        os_type = str(os.getenv("WGM_OS_TYPE") or "").strip()
        skip_replace_env = str(os.getenv("WGM_SKIP_REPLACE") or "").strip().lower()
        if skip_replace_env in ("1", "true", "yes"):
            skip_replace = True
        elif skip_replace_env in ("0", "false", "no"):
            skip_replace = False
        else:
            skip_replace = not bool(image_id)

        kwargs = {
            "skip_replace": skip_replace,
            "ttl_seconds": int(os.getenv("WGM_TTL_SECONDS") or "1800"),
            "wait_timeout_seconds": float(os.getenv("WGM_PREPARE_TIMEOUT_SECONDS") or "1200"),
            "poll_seconds": float(os.getenv("WGM_JOB_POLL_SECONDS") or "5"),
        }
        if image_id:
            kwargs["image_id"] = image_id
        if os_type:
            kwargs["os_type"] = os_type

        # wait_job 会打印 phase/step/logs 进度
        result = client.acquire_and_prepare_wait(**kwargs)

        lease_id = str(result.get("lease_id") or "")
        instance_id = str(result.get("instance_id") or "")
        self.assertTrue(lease_id, msg=f"missing lease_id: {result}")
        self.assertTrue(instance_id, msg=f"missing instance_id: {result}")
        self.assertEqual(result.get("status"), "succeeded")

        job_id = str(result.get("job_id") or "")
        save_lease(lease_id, instance_id=instance_id, job_id=job_id, extra={"result": result})
        warnings = result.get("warnings") or []
        print(
            f"\n[wgm_http] acquire ok lease_id={lease_id} instance_id={instance_id} "
            f"phase={result.get('phase')} warnings={len(warnings)}\n"
            f"export WGM_LEASE_ID={lease_id}"
        )


if __name__ == "__main__":
    unittest.main()
