"""Live: POST /api/v1/sessions/{lease_id}/run-command (IO prep / agent action)."""
from __future__ import annotations

import os
import unittest

from tests.wgm_http._common import make_client, require_lease_id, require_wgm_token


@require_wgm_token
class RunCommandHttpTest(unittest.TestCase):
    def test_run_command(self):
        lease_id = require_lease_id()
        client = make_client()
        command = str(os.getenv("WGM_COMMAND") or "echo WGM_OK").strip() or "echo WGM_OK"
        data = client.run_command(lease_id, command, timeout=int(os.getenv("WGM_COMMAND_TIMEOUT") or "120"))
        self.assertIsInstance(data, dict)
        self.assertEqual(str(data.get("lease_id") or "lease-83b2472d381646069b0285c2204c1520"), lease_id)
        self.assertTrue(data.get("instance_id"), msg=f"missing instance_id: {data}")
        print(f"\n[wgm_http] run-command ok data={data}")
        self.assertIn("result", data)
        print(f"\n[wgm_http] run-command ok keys={list(data.keys())}")


if __name__ == "__main__":
    unittest.main()
