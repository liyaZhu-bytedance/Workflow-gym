"""Live: POST /api/v1/sessions/{lease_id}/ensure-ready."""
from __future__ import annotations

import unittest

from tests.wgm_http._common import make_client, require_lease_id, require_wgm_token


@require_wgm_token
class EnsureReadyHttpTest(unittest.TestCase):
    def test_ensure_ready(self):
        lease_id = require_lease_id()
        client = make_client()
        data = client.ensure_ready(lease_id)
        self.assertIsInstance(data, dict)
        self.assertEqual(str(data.get("lease_id") or "lease-83b2472d381646069b0285c2204c1520"), lease_id)
        self.assertTrue(data.get("instance_id"), msg=f"missing instance_id: {data}")
        self.assertIn("ready", data)
        self.assertTrue(data.get("ready"), msg=f"ensure-ready not ready: {data.get('errors') or data}")
        print(
            f"\n[wgm_http] ensure-ready ready={data.get('ready')} "
            f"platform={data.get('platform')} "
            f"ubuntu_flask_port={data.get('ubuntu_flask_port')} "
            f"windows_flask_port={data.get('windows_flask_port')} "
            f"errors={data.get('errors')}"
        )


if __name__ == "__main__":
    unittest.main()
