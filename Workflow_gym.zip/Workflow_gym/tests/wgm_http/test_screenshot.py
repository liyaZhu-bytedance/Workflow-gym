"""Live: WGM screenshot stream (POST .../screenshot/stream)."""
from __future__ import annotations

import re
import unittest
from pathlib import Path

from tests.wgm_http._common import make_client, require_lease_id, require_wgm_token

OUT_DIR = Path(__file__).resolve().parent


@require_wgm_token
class ScreenshotHttpTest(unittest.TestCase):
    def test_screenshot_stream(self):
        lease_id = require_lease_id()
        client = make_client()
        raw = client.screenshot_bytes(lease_id)
        self.assertTrue(raw, msg="empty screenshot body")
        self.assertTrue(
            raw.startswith(b"\x89PNG\r\n\x1a\n") or raw.startswith(b"\xff\xd8\xff"),
            msg="response is not PNG/JPEG",
        )

        safe = re.sub(r"[^A-Za-z0-9._-]+", "_", lease_id)[:64] or "lease"
        out_path = OUT_DIR / f"screenshot_{safe}.png"
        out_path.write_bytes(raw)
        self.assertTrue(out_path.is_file() and out_path.stat().st_size > 0)
        print(f"\n[wgm_http] screenshot stream saved: {out_path} ({out_path.stat().st_size} bytes)")


if __name__ == "__main__":
    unittest.main()
