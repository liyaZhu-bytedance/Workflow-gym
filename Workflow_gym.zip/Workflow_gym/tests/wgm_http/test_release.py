"""Live: POST /api/v1/sessions/{lease_id}/release."""
from __future__ import annotations

import unittest

from tests.wgm_http._common import clear_state, make_client, require_lease_id, require_wgm_token


@require_wgm_token
class ReleaseHttpTest(unittest.TestCase):
    def test_release(self):
        lease_id = require_lease_id()
        client = make_client()
        data = client.release(lease_id)
        self.assertIsInstance(data, dict)
        self.assertEqual(str(data.get("lease_id") or ""), lease_id)
        self.assertTrue(data.get("success") in (True, 1, "true", "True") or data.get("instance_id"))
        clear_state()
        print(f"\n[wgm_http] release ok lease_id={lease_id}")


if __name__ == "__main__":
    unittest.main()
