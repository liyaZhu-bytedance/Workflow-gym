"""Live: POST /api/v1/sessions/{lease_id}/run-action (WGM → instance Flask)."""
from __future__ import annotations

import os
import unittest

from tests.wgm_http._common import make_client, require_lease_id, require_wgm_token


@require_wgm_token
class RunActionHttpTest(unittest.TestCase):
    def test_run_action(self):
        lease_id = require_lease_id()
        client = make_client()
        script = str(os.getenv("WGM_SCRIPT") or "print('WGM_ACTION_OK')").strip() or "print('WGM_ACTION_OK')"
        data = client.run_action(
            lease_id,
            script=script,
            timeout=int(os.getenv("WGM_ACTION_TIMEOUT") or "120"),
            action_id="wgm-http-test",
        )
        self.assertIsInstance(data, dict)
        self.assertEqual(str(data.get("lease_id") or ""), lease_id)
        self.assertTrue(data.get("instance_id"), msg=f"missing instance_id: {data}")
        print(f"\n[wgm_http] run-action ok data={data}")


if __name__ == "__main__":
    unittest.main()
