"""Shared helpers for live local -> WGM Session HTTP tests.

Requires WGM_TOKEN in the environment (e.g. export in ~/.zshrc).

Optional:
  WGM_API_BASE / WGM_HOST
  WGM_LEASE_ID          # override lease from prior acquire
  WGM_IMAGE_ID / WGM_OS_TYPE / WGM_TTL_SECONDS / WGM_SKIP_REPLACE
  WGM_COMMAND           # for run-command
  WGM_PREPARE_TIMEOUT_SECONDS / WGM_JOB_POLL_SECONDS
"""
from __future__ import annotations

import json
import os
import sys
import unittest
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
PACKAGE_ROOT = Path("/tmp/owg_path")
PACKAGE_ROOT.mkdir(parents=True, exist_ok=True)
_link = PACKAGE_ROOT / "open_workflowgym"
if _link.exists() or _link.is_symlink():
    _link.unlink()
_link.symlink_to(REPO_ROOT)
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

from open_workflowgym.envs.wgm_client import WgmClient  # noqa: E402

STATE_PATH = Path(__file__).resolve().parent / ".wgm_http_state.json"

require_wgm_token = unittest.skipUnless(
    bool(str(os.getenv("WGM_TOKEN") or "").strip()),
    "set WGM_TOKEN (e.g. in ~/.zshrc) to run live WGM HTTP tests",
)


def make_client() -> WgmClient:
    return WgmClient(
        api_base=os.getenv("WGM_API_BASE") or os.getenv("WGM_HOST") or None,
        api_token=os.getenv("WGM_TOKEN") or "",
        ttl_seconds=int(os.getenv("WGM_TTL_SECONDS") or "1800"),
        timeout_seconds=float(os.getenv("WGM_HTTP_TIMEOUT_SECONDS") or "120"),
    )


def load_state() -> dict[str, Any]:
    if not STATE_PATH.is_file():
        return {}
    try:
        data = json.loads(STATE_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def save_state(data: dict[str, Any]) -> None:
    STATE_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def clear_state() -> None:
    if STATE_PATH.exists():
        STATE_PATH.unlink()


def save_lease(lease_id: str, *, instance_id: str = "", job_id: str = "", extra: dict | None = None) -> None:
    payload: dict[str, Any] = {
        "lease_id": lease_id,
        "instance_id": instance_id,
        "job_id": job_id,
    }
    if extra:
        payload.update(extra)
    save_state(payload)


def resolve_lease_id() -> str:
    env_lease = str(os.getenv("WGM_LEASE_ID") or "").strip()
    if env_lease:
        return env_lease
    return str(load_state().get("lease_id") or "").strip()


def require_lease_id() -> str:
    lease_id = resolve_lease_id()
    if not lease_id:
        raise unittest.SkipTest(
            "missing lease_id: run test_acquire_and_prepare first, "
            "or export WGM_LEASE_ID=..."
        )
    return lease_id
