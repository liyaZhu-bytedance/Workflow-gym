from __future__ import annotations

import json
import os
import shlex
import subprocess
import sys
import unittest
import warnings
from pathlib import Path
from unittest.mock import patch

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.agents.factory import AgentFactory
from open_workflowgym.envs.volcengine_env import VolcengineEnv
from open_workflowgym.judgers.common import collect_reference_image_paths, load_traj, valid_screenshots
from open_workflowgym.records import InstanceLease, RunConfig, SampleJob, TaskRecord
from open_workflowgym.sampler import Sampler
from open_workflowgym.scorer import Scorer

from tests.e2e_reporting import maybe_write_e2e_sample_to_spreadsheet

DEFAULT_INSTANCE_ID = "i-yeq4neypkwuo7budzfbg"
TASK_ID = "42"
TASK_IMAGE_ID = "image-yepzwx7t5pkhx14h6iq3"
TASK_SHEETSHOT_URL = "https://cdn-icem.example.local/obj/worktime/example-asset-id.png"
STEP_NUM = 10
DEFAULT_E2E_RUN_DIR = "manual_task42_image_llm_e2e_10step"
FIXTURE_PATH = Path(__file__).resolve().parent / "fixtures" / "task42_fields.json"


class _FakeImageLlmJudgeClient:
    model = "fake-image-llm-model"

    def __init__(self, raw_response: str):
        self._raw_response = raw_response

    def call_model(self, messages, *, retry_count=None, delay_seconds=None) -> str:
        return self._raw_response


def project_output_dir() -> Path:
    return Path(__file__).resolve().parents[1] / "output"


def default_task42_e2e_output_root() -> str:
    return str(project_output_dir() / DEFAULT_E2E_RUN_DIR)


ZSHRC_ENV_NAMES = (
    "AK",
    "SK",
    "MOONSHOT_API_KEY",
    "KIMI_API_KEY",
    "KIMI_NATIVE_API_KEY",
    "VOLCENGINE_REGION",
    "SOURCE_REGION",
    "WORKFLOWGYM_TEST_INSTANCE_ID",
    "APP_ID",
    "APP_SECRET",
)


def read_env(name: str, default: str = "") -> str:
    return os.getenv(name, default)


def load_zshrc_env(names: tuple[str, ...] = ZSHRC_ENV_NAMES, zshrc_path: str = "") -> None:
    missing = [name for name in names if not read_env(name)]
    if not missing:
        return
    zshrc = Path(zshrc_path or os.path.expanduser("~/.zshrc"))
    if not zshrc.is_file():
        return
    zshrc_quoted = shlex.quote(str(zshrc))
    for name in missing:
        try:
            completed = subprocess.run(
                ["zsh", "-lc", "source %s >/dev/null 2>&1; print -r -- ${%s:-}" % (zshrc_quoted, name)],
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        value = (completed.stdout or "").strip()
        if value:
            os.environ[name] = value


def load_task42_fixture_fields() -> dict:
    if FIXTURE_PATH.is_file():
        return json.loads(FIXTURE_PATH.read_text(encoding="utf-8"))
    return {}


def load_task42_instruction() -> str:
    fields = load_task42_fixture_fields()
    instruction = str(fields.get("题目") or fields.get("up") or "").strip()
    if instruction:
        return instruction
    return "在 Blender 中制作低模小房子，并确认 Statistics 面板中的 Objects/Vertices/Edges/Faces/Triangles 数值。"


def build_task42_fields() -> dict[str, object]:
    fixture = load_task42_fixture_fields()
    instruction = load_task42_instruction()
    return {
        "id": TASK_ID,
        "题目": instruction,
        "up": instruction,
        "镜像ID": TASK_IMAGE_ID,
        "image": TASK_IMAGE_ID,
        "系统类型": fixture.get("系统类型") or "Ubuntu",
        "platform": "ubuntu",
        "启动方式": fixture.get("启动方式") or "/home/user/blender-4.5.4-linux-x64/blender",
        "tos_url": fixture.get("tos_url") or "[]",
        "输入文件路径": fixture.get("输入文件路径") or "",
        "输出文件路径": "",
        "final_answer文件名": fixture.get("final_answer文件名") or "",
        "final answer 文件": fixture.get("final answer 文件") or "[]",
        "answer_type": fixture.get("answer_type") or "数值/文本-多点验证",
        "metric_type": fixture.get("metric_type") or "image-llm",
        "判分类型": fixture.get("metric_type") or "image-llm",
        "sheetshot_url": fixture.get("sheetshot_url") or TASK_SHEETSHOT_URL,
        "response_reference": fixture.get("response_reference") or "",
    }


def build_task42_sample_job(*, instance_id: str, output_root: str) -> SampleJob:
    return SampleJob(
        run_id="task42-e2e",
        task_id=TASK_ID,
        sample_index=1,
        task=TaskRecord(
            run_id="task42-e2e",
            task_id=TASK_ID,
            row_number=1,
            fields=build_task42_fields(),
        ),
        config=RunConfig(
            run_id="task42-e2e",
            output_root=output_root,
            sample_num=1,
            step_num=STEP_NUM,
            player="kimi",
            judger="gemini3.1",
            enable_real_cloud=True,
            tosutil_timeout_seconds=180,
            write_step_traj=True,
        ),
        lease=InstanceLease(
            run_id="task42-e2e",
            lease_id="task42-e2e-lease",
            instance_id=instance_id,
            task_id=TASK_ID,
            sample_index=1,
            status="busy",
            acquired_at="2026-07-12 00:00:00",
        ),
    )


def ensure_instance_running(env: VolcengineEnv, instance_id: str) -> None:
    instance = env.describe_instance(instance_id)
    status = str(instance.get("Status") or instance.get("status") or "").upper()
    if status == "STOPPING":
        env.wait_for_status(instance_id, "STOPPED", timeout_seconds=600)
        status = "STOPPED"
    if status == "STOPPED":
        env.start_instance(instance_id)
    if status not in ("RUNNING",):
        env.wait_for_status(instance_id, "RUNNING", timeout_seconds=600)


def prepare_task42_image_llm_fixture(trajectory) -> list[str]:
    """下载参考图到 gt_sreenshot，并将末张学生截图替换为参考图（构造 image-llm 判分输入）。"""
    ref_paths = collect_reference_image_paths(trajectory)
    if not ref_paths:
        raise AssertionError("参考图下载失败")
    screenshots = valid_screenshots(load_traj(trajectory.traj_json_path))
    if not screenshots:
        raise AssertionError("轨迹无有效截图")
    last_screenshot = Path(screenshots[-1])
    last_screenshot.write_bytes(Path(ref_paths[0]).read_bytes())
    print(
        "WORKFLOWGYM_TASK42_REFERENCE_ALIGNED",
        last_screenshot,
        ref_paths[0],
        flush=True,
    )
    return ref_paths


load_zshrc_env()


@unittest.skipUnless(
    os.getenv("WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS") == "1",
    "set WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS=1 to run real Volcengine E2E",
)
class Task42ImageLlmE2ETest(unittest.TestCase):
    """任务 42：启动实例 -> 采样 10 步 -> 构造参考图对齐 -> image-llm 判分。"""

    def setUp(self):
        self.instance_id = read_env("WORKFLOWGYM_TEST_INSTANCE_ID", DEFAULT_INSTANCE_ID)
        self.region = read_env("VOLCENGINE_REGION", read_env("SOURCE_REGION", "cn-guangzhou"))
        self.output_root = read_env(
            "WORKFLOWGYM_TASK42_E2E_OUTPUT_ROOT",
            default_task42_e2e_output_root(),
        )
        self.env = VolcengineEnv(region=self.region)

    def tearDown(self):
        return

    def test_task42_sample_ten_steps_align_reference_and_score_image_llm(self):
        self.assertTrue(read_env("AK") and read_env("SK"), "set AK/SK for Volcengine")
        moonshot_key = read_env("MOONSHOT_API_KEY") or read_env("KIMI_API_KEY") or read_env("KIMI_NATIVE_API_KEY")
        self.assertTrue(moonshot_key, "set MOONSHOT_API_KEY or KIMI_API_KEY for kimi sampling")

        print("WORKFLOWGYM_TEST_INSTANCE", self.instance_id, flush=True)
        print("WORKFLOWGYM_TASK42_OUTPUT_ROOT", self.output_root, flush=True)

        ensure_instance_running(self.env, self.instance_id)

        job = build_task42_sample_job(instance_id=self.instance_id, output_root=self.output_root)
        trajectory = Sampler(AgentFactory(), self.env).run_sample(job)

        print("WORKFLOWGYM_TASK42_SAMPLE_STATUS", trajectory.status, flush=True)
        print("WORKFLOWGYM_TASK42_LAST_STEP", trajectory.last_step, flush=True)

        self.assertEqual(trajectory.last_step, STEP_NUM - 1)
        self.assertNotEqual(trajectory.status, "sample_failed", trajectory.error)
        self.assertTrue(Path(trajectory.traj_json_path).is_file())
        sample_dir = Path(trajectory.sample_dir)
        self.assertTrue(
            (sample_dir / "step_0.jpg").is_file() or (sample_dir / "env_ready.jpg").is_file(),
            "采样目录应至少有一张截图",
        )
        self.assertEqual(trajectory.task_files.final_answer_files, [])
        self.assertEqual(trajectory.task_files.output_uploads, [])

        ref_paths = prepare_task42_image_llm_fixture(trajectory)
        self.assertTrue(Path(ref_paths[0]).is_file())
        self.assertTrue((sample_dir / "gt_sreenshot").is_dir())

        if read_env("WORKFLOWGYM_MOCK_JUDGER", "0").lower() in {"1", "true", "yes", "on"}:
            fake_client = _FakeImageLlmJudgeClient('{"answer_score": 1, "evidence": "界面与参考图一致"}')
            with patch(
                "open_workflowgym.judgers.image_llm.JudgeModelFactory.create",
                return_value=fake_client,
            ):
                score = Scorer().score(trajectory)
        else:
            score = Scorer().score(trajectory)

        print("WORKFLOWGYM_TASK42_SCORE", score.check, flush=True)
        score_payload = json.loads(Path(score.score_json_path).read_text(encoding="utf-8"))
        self.assertEqual(score.check.get("answer_score"), 1, score_payload)
        self.assertTrue(score.check.get("exists"))
        self.assertEqual(score.check.get("answer_type"), "数值/文本-多点验证-image-llm")
        judge_result = score.check.get("judge_results", [{}])[0]
        self.assertEqual(judge_result.get("status"), "success")
        self.assertGreaterEqual(len(judge_result.get("reference_image_paths") or []), 1)
        self.assertGreaterEqual(judge_result.get("student_screenshots_used") or 0, 1)
        self.assertTrue(any(Path(path).is_file() for path in judge_result.get("reference_image_paths") or []))

        report = maybe_write_e2e_sample_to_spreadsheet(
            output_root=self.output_root,
            trajectory=trajectory,
            score=score,
        )
        if report is not None:
            self.assertTrue(Path(report["local_samples_csv"]).is_file())
            print("WORKFLOWGYM_TASK42_SPREADSHEET", report, flush=True)


if __name__ == "__main__":
    unittest.main()
