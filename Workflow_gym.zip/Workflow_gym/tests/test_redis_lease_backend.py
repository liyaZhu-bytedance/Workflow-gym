from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

REPO_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = Path("/tmp/owg_path")
PACKAGE_ROOT.mkdir(parents=True, exist_ok=True)
link = PACKAGE_ROOT / "open_workflowgym"
if link.exists() or link.is_symlink():
    link.unlink()
link.symlink_to(REPO_ROOT)
sys.path.insert(0, str(PACKAGE_ROOT))

from open_workflowgym.envs.lease_backend import RedisLeaseBackend, create_lease_backend
from open_workflowgym.envs.wgm_lease_handle import WgmLeaseHandle
from open_workflowgym.lease_renewal import LeaseRenewContext, renew_lease_from_context
from open_workflowgym.records import InstanceLease, RunConfig, SampleJob, TaskRecord
from open_workflowgym.state_store import StateStore


class WgmLeaseHandleTests(unittest.TestCase):
    def test_renew_release_use_lease_id(self):
        client = mock.Mock()
        client.renew.return_value = {"expires_at": "2026-07-25 12:00:00"}
        client.release.return_value = {"success": True}
        handle = WgmLeaseHandle.from_remote(
            run_id="run",
            task_id="42",
            sample_index=1,
            remote={
                "instance_id": "i-1",
                "lease_id": "lease-1",
                "os_type": "ubuntu",
                "expires_at": "2026-07-25 11:00:00",
            },
            client=client,
            required_platform="ubuntu",
        )
        self.assertIsNotNone(handle)
        assert handle is not None
        handle.renew(1800)
        client.renew.assert_called_once_with("lease-1", ttl_seconds=1800)
        self.assertEqual(handle.expires_at, "2026-07-25 12:00:00")
        handle.release("done")
        client.release.assert_called_once_with("lease-1")
        self.assertFalse(hasattr(handle.as_instance_lease(), "_client"))

    def test_no_class_level_lease_registry(self):
        self.assertFalse(hasattr(WgmLeaseHandle, "_leases_by_instance"))
        self.assertFalse(hasattr(WgmLeaseHandle, "_leases_by_id"))


class RedisLeaseBackendTests(unittest.TestCase):
    def test_create_lease_backend_redis_requires_token(self):
        with mock.patch.dict("os.environ", {"WGM_TOKEN": ""}, clear=False):
            with self.assertRaises(ValueError):
                create_lease_backend("redis", api_token="")

    def test_acquire_renew_release_via_handle_no_global_table(self):
        backend = RedisLeaseBackend(
            instance_ids=[],
            ttl_seconds=600,
            api_base="https://example.test",
            api_token="wgm-test",
        )
        self.assertFalse(hasattr(backend, "_leases_by_instance"))
        self.assertFalse(hasattr(backend, "_leases_by_id"))

        remote = {
            "instance_id": "i-1",
            "lease_id": "lease-remote-1",
            "os_type": "ubuntu",
            "expires_at": "2026-07-23 17:10:00",
        }
        with mock.patch.object(backend.client, "acquire_and_prepare_wait", return_value=remote):
            lease = backend.acquire("run", "42", 1, "ubuntu", image_id="img-1")
        self.assertIsInstance(lease, WgmLeaseHandle)
        assert isinstance(lease, WgmLeaseHandle)
        self.assertEqual(lease.instance_id, "i-1")
        self.assertEqual(lease.lease_id, "lease-remote-1")

        capacity = backend.platform_capacity("ubuntu")
        self.assertEqual(capacity["total"], -1)
        self.assertEqual(capacity["idle"], -1)

        with mock.patch.object(backend.client, "renew", return_value={"expires_at": "2026-07-23 18:00:00"}) as renew:
            lease.renew(3600)
            renew.assert_called_once_with("lease-remote-1", ttl_seconds=3600)
        self.assertEqual(lease.expires_at, "2026-07-23 18:00:00")

        with mock.patch.object(backend.client, "release", return_value={"success": True}) as release:
            backend.release(lease.lease_id, "done")
            release.assert_called_once_with("lease-remote-1")

    def test_release_held_only_active_leases_not_user_release_all(self):
        backend = RedisLeaseBackend(
            instance_ids=[],
            ttl_seconds=600,
            api_base="https://example.test",
            api_token="wgm-test",
        )
        remote = {
            "instance_id": "i-1",
            "lease_id": "lease-remote-1",
            "os_type": "ubuntu",
            "expires_at": "2026-07-23 17:10:00",
        }
        with mock.patch.object(backend.client, "acquire_and_prepare_wait", return_value=remote):
            lease = backend.acquire("run", "42", 1, "ubuntu", image_id="img-1")
        self.assertIsNotNone(lease)
        self.assertIn("lease-remote-1", backend._active_leases)

        with mock.patch.object(backend.client, "release", return_value={"success": True}) as release:
            with mock.patch.object(backend.client, "release_all") as release_all:
                result = backend.release_held("shutdown")
        release.assert_called_once_with("lease-remote-1")
        release_all.assert_not_called()
        self.assertEqual(result.get("released_count"), 1)
        self.assertEqual(result.get("scope"), "process_held")
        self.assertNotIn("lease-remote-1", backend._active_leases)

        # 兼容旧名：release_all 也不再打用户级 API
        with mock.patch.object(backend.client, "release_all") as release_all:
            empty = backend.release_all("shutdown")
        release_all.assert_not_called()
        self.assertEqual(empty.get("released_count"), 0)

    def test_renew_lease_from_context_hits_remote(self):
        with tempfile.TemporaryDirectory() as tmp:
            db_path = str(Path(tmp) / "state.db")
            store = StateStore(db_path)
            store.upsert_lease(
                InstanceLease(
                    run_id="run",
                    lease_id="lease-1",
                    instance_id="i-1",
                    task_id="42",
                    sample_index=1,
                    status="leased",
                    acquired_at="2026-07-23 17:00:00",
                    expires_at="2026-07-23 17:10:00",
                )
            )
            context = LeaseRenewContext(
                lease_id="lease-1",
                state_db_path=db_path,
                ttl_seconds=1200,
                instance_id="i-1",
                lease_backend="redis",
                wgm_api_base="https://example.test",
                wgm_token="wgm-test",
            )
            with mock.patch(
                "open_workflowgym.lease_renewal.renew_remote_lease",
                return_value="2026-07-23 18:30:00",
            ) as remote:
                expires = renew_lease_from_context(context)
            remote.assert_called_once()
            self.assertEqual(expires, "2026-07-23 18:30:00")
            row = store.get_lease("lease-1")
            self.assertTrue(str(row["expires_at"]))


class WorkerEnvSelectionTests(unittest.TestCase):
    def test_redis_worker_uses_gateway_env(self):
        from open_workflowgym.executors.local import build_worker_env
        from open_workflowgym.envs.gateway_volcengine_env import GatewayVolcengineEnv

        task = TaskRecord(run_id="run", task_id="42", row_number=1, fields={"image": "img"})
        job = SampleJob(
            run_id="run",
            task_id="42",
            sample_index=1,
            task=task,
            config=RunConfig(
                run_id="run",
                lease_backend="redis",
                wgm_token="tok",
                wgm_api_base="https://example.test",
                output_root="/tmp",
            ),
            lease=InstanceLease(
                run_id="run",
                lease_id="lease-1",
                instance_id="i-1",
                task_id="42",
                sample_index=1,
                status="leased",
                acquired_at="2026-07-25 09:00:00",
            ),
        )
        with mock.patch("open_workflowgym.envs.gateway_volcengine_env.WgmClient"):
            env = build_worker_env(job)
        self.assertIsInstance(env, GatewayVolcengineEnv)

    def test_local_worker_uses_volcengine_env(self):
        from open_workflowgym.executors.local import build_worker_env
        from open_workflowgym.envs.volcengine_env import VolcengineEnv
        from open_workflowgym.envs.gateway_volcengine_env import GatewayVolcengineEnv

        task = TaskRecord(run_id="run", task_id="42", row_number=1, fields={"image": "img"})
        job = SampleJob(
            run_id="run",
            task_id="42",
            sample_index=1,
            task=task,
            config=RunConfig(run_id="run", lease_backend="local", output_root="/tmp"),
            lease=InstanceLease(
                run_id="run",
                lease_id="lease-1",
                instance_id="i-1",
                task_id="42",
                sample_index=1,
                status="leased",
                acquired_at="2026-07-25 09:00:00",
            ),
        )
        env = build_worker_env(job)
        self.assertIsInstance(env, VolcengineEnv)
        self.assertNotIsInstance(env, GatewayVolcengineEnv)


class InstancePoolRedisCapacityTests(unittest.TestCase):
    def test_redis_acquire_status_never_unavailable_from_fake_idle(self):
        with tempfile.TemporaryDirectory() as tmp:
            from open_workflowgym.envs.instance_pool import InstancePool

            pool = InstancePool(
                [],
                StateStore(str(Path(tmp) / "state.db")),
                lease_backend_kind="redis",
                wgm_api_base="https://example.test",
                wgm_token="tok",
            )
            self.assertEqual(pool.acquire_status("ubuntu"), "available")
            self.assertEqual(pool.platform_capacity("ubuntu")["idle"], -1)


if __name__ == "__main__":
    unittest.main()
