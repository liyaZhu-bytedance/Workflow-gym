from __future__ import annotations

import base64
import os
import sys
import time
import unittest
import warnings
from pathlib import Path

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import volcenginesdkcore
import volcenginesdkecs

from open_workflowgym.envs.volcengine_env import (
    get_result_payload,
    maybe_decode_output,
    ps_single_quote,
    to_plain_dict,
    windows_login_password,
)


DEFAULT_INSTANCE_ID = "i-yeq4neypkwuo7budzfbg"


def read_env(name: str, default: str = "") -> str:
    return os.getenv(name, default)


def first_value(data: dict, *keys: str):
    for key in keys:
        value = data.get(key)
        if value:
            return value
    return ""


@unittest.skipUnless(
    os.getenv("WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS") == "1",
    "set WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS=1 to run real Volcengine calls",
)
class WindowsCloudAssistantAdminE2ETest(unittest.TestCase):
    """Manual E2E test for the Cloud Assistant Administrator-session hypothesis."""

    def setUp(self):
        self.instance_id = read_env("WORKFLOWGYM_TEST_INSTANCE_ID", DEFAULT_INSTANCE_ID)
        self.region = read_env("VOLCENGINE_REGION", read_env("SOURCE_REGION", "cn-guangzhou"))
        self.output_dir = Path(
            read_env("WORKFLOWGYM_CLOUD_ASSISTANT_TEST_OUTPUT_DIR", "output/manual_windows_cloud_assistant_admin_test")
        )
        self.output_dir.mkdir(parents=True, exist_ok=True)
        configuration = volcenginesdkcore.Configuration()
        configuration.ak = read_env("AK")
        configuration.sk = read_env("SK")
        configuration.region = self.region
        volcenginesdkcore.Configuration.set_default(configuration)
        self.api = volcenginesdkecs.ECSApi()

    def test_reinstall_cloud_assistant_and_probe_visible_desktop(self):
        password = windows_login_password()
        self.assertTrue(password, "set WINDOWS_LOGIN_PASSWORD or INSTANCE_PASSWORD")

        print("WORKFLOWGYM_TEST_INSTANCE", self.instance_id, flush=True)
        print("WORKFLOWGYM_CLOUD_ASSISTANT_STATUS_BEFORE", self.describe_cloud_assistant_status(), flush=True)
        print(
            "WORKFLOWGYM_CLOUD_ASSISTANT_SERVICE_BEFORE",
            self.command_decoded_output(self.run_powershell(self.service_probe_command(), timeout=60)),
            flush=True,
        )

        if read_env("WORKFLOWGYM_TEST_REINSTALL_CLOUD_ASSISTANT", "0").lower() in ("1", "true", "yes", "on"):
            self.reinstall_cloud_assistant()
            print("WORKFLOWGYM_CLOUD_ASSISTANT_STATUS_AFTER_REINSTALL", self.describe_cloud_assistant_status(), flush=True)
            print(
                "WORKFLOWGYM_CLOUD_ASSISTANT_SERVICE_AFTER_REINSTALL",
                self.command_decoded_output(self.run_powershell(self.service_probe_command(), timeout=60)),
                flush=True,
            )

        before = self.save_screenshot("before_notepad_probe.jpg")
        result = self.run_powershell(
            "\n".join(
                [
                    "$ErrorActionPreference = 'Stop'",
                    "Write-Output 'WORKFLOWGYM_ADMIN_STARTPROCESS_PROBE_START'",
                    "Start-Process -FilePath 'notepad.exe'",
                    "Start-Sleep -Seconds 5",
                    "Write-Output 'WORKFLOWGYM_ADMIN_STARTPROCESS_PROBE_DONE'",
                ]
            ),
            timeout=60,
            username="Administrator",
            windows_password=password,
        )
        print("WORKFLOWGYM_ADMIN_STARTPROCESS_RESULT", result, flush=True)
        after = self.save_screenshot("after_notepad_probe.jpg")
        print("WORKFLOWGYM_SCREENSHOT_BEFORE", before, flush=True)
        print("WORKFLOWGYM_SCREENSHOT_AFTER", after, flush=True)

        decoded_output = self.command_decoded_output(result)
        self.assertIn("WORKFLOWGYM_ADMIN_STARTPROCESS_PROBE_DONE", decoded_output)

    def test_administrator_pyautogui_click_bottom_left(self):
        password = windows_login_password()
        self.assertTrue(password, "set WINDOWS_LOGIN_PASSWORD or INSTANCE_PASSWORD")

        print("WORKFLOWGYM_TEST_INSTANCE", self.instance_id, flush=True)
        print("WORKFLOWGYM_CLOUD_ASSISTANT_STATUS", self.describe_cloud_assistant_status(), flush=True)
        before = self.save_screenshot("before_pyautogui_bottom_left.jpg")
        result = self.run_powershell(
            self.pyautogui_click_bottom_left_command(),
            timeout=90,
            username="Administrator",
            windows_password=password,
        )
        print("WORKFLOWGYM_ADMIN_PYAUTOGUI_BOTTOM_LEFT_RESULT", result, flush=True)
        after = self.save_screenshot("after_pyautogui_bottom_left.jpg")
        print("WORKFLOWGYM_SCREENSHOT_BEFORE", before, flush=True)
        print("WORKFLOWGYM_SCREENSHOT_AFTER", after, flush=True)

        decoded_output = self.command_decoded_output(result)
        self.assertIn("PYAUTOGUI_PROBE_START", decoded_output)
        self.assertIn("PYAUTOGUI_PROBE_DONE", decoded_output)

    def test_interactive_runner_click_win_icon_via_action_file(self):
        password = windows_login_password()
        self.assertTrue(password, "set WINDOWS_LOGIN_PASSWORD or INSTANCE_PASSWORD")

        print("WORKFLOWGYM_TEST_INSTANCE", self.instance_id, flush=True)
        print("WORKFLOWGYM_CLOUD_ASSISTANT_STATUS", self.describe_cloud_assistant_status(), flush=True)
        before = self.save_screenshot("before_interactive_runner_click_win_icon.jpg")
        result = self.run_powershell(
            self.interactive_runner_click_win_icon_command(password),
            timeout=90,
            windows_password=password,
        )
        print("WORKFLOWGYM_INTERACTIVE_RUNNER_CLICK_WIN_ICON_RESULT", result, flush=True)
        after = self.save_screenshot("after_interactive_runner_click_win_icon.jpg")
        print("WORKFLOWGYM_SCREENSHOT_BEFORE", before, flush=True)
        print("WORKFLOWGYM_SCREENSHOT_AFTER", after, flush=True)

        decoded_output = self.command_decoded_output(result)
        self.assertIn("WORKFLOWGYM_INTERACTIVE_RUNNER_RESULT", decoded_output)

    def test_cloud_assistant_file_queue_watchdog_agent_actions(self):
        password = windows_login_password()
        self.assertTrue(password, "set WINDOWS_LOGIN_PASSWORD or INSTANCE_PASSWORD")

        print("WORKFLOWGYM_TEST_INSTANCE", self.instance_id, flush=True)
        print("WORKFLOWGYM_CLOUD_ASSISTANT_STATUS", self.describe_cloud_assistant_status(), flush=True)

        setup_result = self.run_powershell(
            self.file_queue_watchdog_setup_command(password),
            timeout=90,
            windows_password=password,
        )
        print("WORKFLOWGYM_FILE_QUEUE_WATCHDOG_SETUP_RESULT", setup_result, flush=True)
        setup_output = self.command_decoded_output(setup_result)
        self.assertIn("WORKFLOWGYM_FILE_QUEUE_WATCHDOG_READY", setup_output)

        task_result = self.run_powershell(
            self.file_queue_agent_actions_task_command(),
            timeout=90,
            windows_password=password,
        )
        print("WORKFLOWGYM_FILE_QUEUE_WATCHDOG_TASK_RESULT", task_result, flush=True)
        decoded_output = self.command_decoded_output(task_result)
        self.assertIn("WORKFLOWGYM_FILE_QUEUE_AGENT_RESULT_HEALTH", decoded_output)
        self.assertIn("WORKFLOWGYM_FILE_QUEUE_AGENT_RESULT_MOVE", decoded_output)
        self.assertIn("WORKFLOWGYM_FILE_QUEUE_AGENT_RESULT_PRESS", decoded_output)
        self.assertIn("WORKFLOWGYM_FILE_QUEUE_AGENT_RESULT_HOTKEY_WIN_R", decoded_output)
        self.assertIn("WORKFLOWGYM_FILE_QUEUE_AGENT_RESULT_CLICK_WIN_ICON", decoded_output)
        self.assertIn('"ok": true', decoded_output)
        self.assertIn('"status": "health"', decoded_output)
        self.assertIn('"status": "moved"', decoded_output)
        self.assertIn('"status": "pressed"', decoded_output)
        self.assertIn('"status": "hotkeyed"', decoded_output)
        self.assertIn('"status": "clicked_win_icon"', decoded_output)
        self.assertIn('"screen_size"', decoded_output)
        self.assertIn('"runner": "file_queue"', decoded_output)

    def test_download_windows_tosutil_with_powershell(self):
        password = windows_login_password()
        self.assertTrue(password, "set WINDOWS_LOGIN_PASSWORD or INSTANCE_PASSWORD")
        tos_ak = read_env("TOS_AK", read_env("AK"))
        tos_sk = read_env("TOS_SK", read_env("SK"))
        tos_endpoint = read_env(
            "WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_TOS_ENDPOINT",
            read_env("TOS_ENDPOINT", "tos-cn-guangzhou.volces.com"),
        )
        tos_region = read_env(
            "WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_TOS_REGION",
            read_env("TOS_REGION", "cn-guangzhou"),
        )
        self.assertTrue(tos_ak and tos_sk, "set TOS_AK/TOS_SK or AK/SK for tosutil cp")

        print("WORKFLOWGYM_TEST_INSTANCE", self.instance_id, flush=True)
        print("WORKFLOWGYM_CLOUD_ASSISTANT_STATUS", self.describe_cloud_assistant_status(), flush=True)

        download_result = self.run_powershell(
            self.download_windows_tosutil_command(),
            timeout=300,
            windows_password=password,
        )
        print("WORKFLOWGYM_WINDOWS_TOSUTIL_DOWNLOAD_RESULT", download_result, flush=True)
        download_output = self.command_decoded_output(download_result)
        self.assertIn("WORKFLOWGYM_WINDOWS_TOSUTIL_DOWNLOAD_READY", download_output)
        self.assertIn("WORKFLOWGYM_WINDOWS_TOSUTIL_VERSION_DONE", download_output)

        config_result = self.run_powershell(
            self.configure_windows_tosutil_command(tos_ak, tos_sk, tos_endpoint, tos_region),
            timeout=60,
            windows_password=password,
        )
        print("WORKFLOWGYM_WINDOWS_TOSUTIL_CONFIG_RESULT", config_result, flush=True)
        config_output = self.command_decoded_output(config_result)
        self.assertIn("WORKFLOWGYM_WINDOWS_TOSUTIL_CONFIG_DONE", config_output)

        copy_result = self.run_powershell(
            self.copy_windows_python_installer_with_tosutil_command(),
            timeout=300,
            windows_password=password,
        )
        print("WORKFLOWGYM_WINDOWS_TOSUTIL_PYTHON_COPY_RESULT", copy_result, flush=True)
        copy_output = self.command_decoded_output(copy_result)
        self.assertIn("WORKFLOWGYM_WINDOWS_TOSUTIL_PYTHON_COPY_READY", copy_output)

    def reinstall_cloud_assistant(self):
        print("WORKFLOWGYM_UNINSTALL_CLOUD_ASSISTANT_START", flush=True)
        uninstall_request = volcenginesdkecs.UninstallCloudAssistantsRequest(instance_ids=[self.instance_id])
        print(
            "WORKFLOWGYM_UNINSTALL_CLOUD_ASSISTANT_RESPONSE",
            to_plain_dict(self.api.uninstall_cloud_assistants(uninstall_request)),
            flush=True,
        )
        time.sleep(int(read_env("WORKFLOWGYM_CLOUD_ASSISTANT_UNINSTALL_WAIT_SECONDS", "30")))

        print("WORKFLOWGYM_INSTALL_CLOUD_ASSISTANT_START", flush=True)
        install_request = volcenginesdkecs.InstallCloudAssistantRequest(instance_ids=[self.instance_id])
        print(
            "WORKFLOWGYM_INSTALL_CLOUD_ASSISTANT_RESPONSE",
            to_plain_dict(self.api.install_cloud_assistant(install_request)),
            flush=True,
        )
        self.wait_cloud_assistant_ready()

    def describe_cloud_assistant_status(self):
        request = volcenginesdkecs.DescribeCloudAssistantStatusRequest(instance_ids=[self.instance_id])
        response = self.api.describe_cloud_assistant_status(request)
        result = get_result_payload(to_plain_dict(response))
        instances = result.get("Instances") or result.get("instances") or []
        for item in instances:
            if first_value(item, "InstanceId", "instance_id") == self.instance_id:
                return item
        return None

    def wait_cloud_assistant_ready(self):
        deadline = time.time() + int(read_env("WORKFLOWGYM_CLOUD_ASSISTANT_WAIT_SECONDS", "300"))
        last_status = None
        while time.time() < deadline:
            time.sleep(int(read_env("WORKFLOWGYM_CLOUD_ASSISTANT_POLL_SECONDS", "10")))
            last_status = self.describe_cloud_assistant_status()
            value = str(first_value(last_status or {}, "Status", "status")).lower()
            print("WORKFLOWGYM_CLOUD_ASSISTANT_WAIT_STATUS", last_status, flush=True)
            if value in {"online", "running", "available", "normal"}:
                return last_status
        raise TimeoutError("waiting Cloud Assistant ready timed out: %s" % last_status)

    def run_powershell(self, command: str, timeout: int = 60, username: str = "", windows_password: str = ""):
        kwargs = {
            "command_content": command,
            "content_encoding": "PlainText",
            "instance_ids": [self.instance_id],
            "invocation_name": "workflowgym-cloud-assistant-admin-e2e",
            "timeout": timeout,
            "type": "PowerShell",
            "working_dir": "C:\\Users\\Administrator\\Desktop\\",
        }
        if username:
            kwargs["username"] = username
        if windows_password:
            kwargs["windows_password"] = windows_password
        request = volcenginesdkecs.RunCommandRequest(**kwargs)
        response = self.api.run_command(request)
        result = get_result_payload(to_plain_dict(response))
        invocation_id = result.get("InvocationId") or result.get("invocation_id")
        self.assertTrue(invocation_id)
        deadline = time.time() + timeout + 60
        while time.time() < deadline:
            time.sleep(5)
            results_request = volcenginesdkecs.DescribeInvocationResultsRequest(
                invocation_id=invocation_id,
                instance_id=self.instance_id,
                page_number=1,
                page_size=10,
            )
            result_data = get_result_payload(to_plain_dict(self.api.describe_invocation_results(results_request)))
            invocation_results = result_data.get("InvocationResults") or result_data.get("invocation_results") or []
            if not invocation_results:
                continue
            for item in invocation_results:
                output = item.get("Output") or item.get("output")
                if output:
                    item["decoded_output"] = maybe_decode_output(output)
            if any((item.get("InvocationResultStatus") or item.get("invocation_result_status")) in ("Pending", "Running") for item in invocation_results):
                continue
            return {"invocation_id": invocation_id, "results": invocation_results}
        raise TimeoutError("waiting RunCommand timed out: %s" % invocation_id)

    def save_screenshot(self, name: str) -> str:
        request = volcenginesdkecs.GetConsoleScreenshotRequest(instance_id=self.instance_id, wake_up=True)
        response = self.api.get_console_screenshot(request)
        result = get_result_payload(to_plain_dict(response))
        screenshot = result.get("Screenshot") or result.get("screenshot")
        self.assertTrue(screenshot)
        if "," in screenshot:
            screenshot = screenshot.split(",", 1)[1]
        path = self.output_dir / name
        path.write_bytes(base64.b64decode(screenshot))
        return str(path)

    @staticmethod
    def service_probe_command() -> str:
        return "\n".join(
            [
                "$ErrorActionPreference = 'Stop'",
                "$identity = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name",
                "$sessionId = (Get-Process -Id $PID).SessionId",
                "Write-Output ('WORKFLOWGYM_RUNCOMMAND_IDENTITY identity=' + $identity + ' session=' + $sessionId)",
                "$pattern = '(?i)(volc|assist|cloud|ecs|agent|tos)'",
                "$services = Get-CimInstance Win32_Service | Where-Object { $_.Name -match $pattern -or $_.DisplayName -match $pattern -or $_.PathName -match $pattern }",
                "$services | Select-Object Name,DisplayName,State,StartName,ProcessId,PathName | ConvertTo-Json -Compress",
            ]
        )

    @staticmethod
    def pyautogui_click_bottom_left_command() -> str:
        return r"""$ErrorActionPreference = 'Stop'

$scriptPath = Join-Path $env:TEMP 'workflowgym_pyautogui_probe.py'

@"
import time
import pyautogui

pyautogui.FAILSAFE = False

print("PYAUTOGUI_PROBE_START")
print("PYAUTOGUI_SIZE", pyautogui.size())

width, height = pyautogui.size()
pyautogui.click(1, height - 1)

time.sleep(3)
print("PYAUTOGUI_PROBE_DONE")
"@ | Set-Content -LiteralPath $scriptPath -Encoding UTF8

$python = "C:\Program Files\Python312\python.exe"
& $python $scriptPath
if ($LASTEXITCODE -ne 0) {
  exit $LASTEXITCODE
}
"""

    @staticmethod
    def download_windows_tosutil_command() -> str:
        return r"""$ErrorActionPreference = 'Stop'

$url = 'https://m645b3e1bb36e-mrap.mrap.accesspoint.tos-global.volces.com/windows/tosutil'
$target = Join-Path $env:TEMP 'workflowgym-tosutil-test.exe'
Remove-Item -LiteralPath $target -Force -ErrorAction SilentlyContinue

Write-Output ('WORKFLOWGYM_WINDOWS_TOSUTIL_DOWNLOAD_URL ' + $url)
Invoke-WebRequest -Uri $url -OutFile $target -UseBasicParsing -TimeoutSec 300
if (-not (Test-Path -LiteralPath $target)) {
  throw ('tosutil download target missing: ' + $target)
}
Unblock-File -LiteralPath $target -ErrorAction SilentlyContinue
$size = (Get-Item -LiteralPath $target).Length
Write-Output ('WORKFLOWGYM_WINDOWS_TOSUTIL_DOWNLOAD_READY path=' + $target + ' bytes=' + $size)

& $target version
if ($LASTEXITCODE -ne 0) {
  throw ('tosutil version failed with exit code ' + $LASTEXITCODE)
}
Write-Output 'WORKFLOWGYM_WINDOWS_TOSUTIL_VERSION_DONE'
"""

    @staticmethod
    def configure_windows_tosutil_command(tos_ak: str, tos_sk: str, tos_endpoint: str, tos_region: str) -> str:
        command = r"""$ErrorActionPreference = 'Stop'

$target = Join-Path $env:TEMP 'workflowgym-tosutil-test.exe'
$tosAk = __TOS_AK__
$tosSk = __TOS_SK__
$tosEndpoint = __TOS_ENDPOINT__
$tosRegion = __TOS_REGION__
if (-not (Test-Path -LiteralPath $target)) {
  throw ('tosutil missing, run download RunCommand first: ' + $target)
}
if (-not $tosAk -or -not $tosSk) {
  throw 'missing TOS_AK/TOS_SK or AK/SK for tosutil config'
}
& $target config -i $tosAk -k $tosSk -e $tosEndpoint -re $tosRegion
if ($LASTEXITCODE -ne 0) {
  throw ('tosutil config failed with exit code ' + $LASTEXITCODE)
}
Write-Output ('WORKFLOWGYM_WINDOWS_TOSUTIL_CONFIG_DONE endpoint=' + $tosEndpoint + ' region=' + $tosRegion)
"""
        return (
            command.replace("__TOS_AK__", ps_single_quote(tos_ak))
            .replace("__TOS_SK__", ps_single_quote(tos_sk))
            .replace("__TOS_ENDPOINT__", ps_single_quote(tos_endpoint))
            .replace("__TOS_REGION__", ps_single_quote(tos_region))
        )

    @staticmethod
    def copy_windows_python_installer_with_tosutil_command() -> str:
        return r"""$ErrorActionPreference = 'Stop'

$target = Join-Path $env:TEMP 'workflowgym-tosutil-test.exe'
$pythonTosUri = 'tos://open-workflowgym-win-python/python-3.12.8-amd64_1.exe'
$pythonInstaller = Join-Path $env:TEMP 'workflowgym-python-3.12.8-amd64-test.exe'
if (-not (Test-Path -LiteralPath $target)) {
  throw ('tosutil missing, run download RunCommand first: ' + $target)
}
Remove-Item -LiteralPath $pythonInstaller -Force -ErrorAction SilentlyContinue
Write-Output ('WORKFLOWGYM_WINDOWS_TOSUTIL_PYTHON_COPY_START ' + $pythonTosUri)
& $target cp $pythonTosUri $pythonInstaller
if ($LASTEXITCODE -ne 0) {
  throw ('tosutil cp Python installer failed with exit code ' + $LASTEXITCODE)
}
if (-not (Test-Path -LiteralPath $pythonInstaller)) {
  throw ('Python installer copy target missing: ' + $pythonInstaller)
}
$pythonInstallerSize = (Get-Item -LiteralPath $pythonInstaller).Length
Write-Output ('WORKFLOWGYM_WINDOWS_TOSUTIL_PYTHON_COPY_READY path=' + $pythonInstaller + ' bytes=' + $pythonInstallerSize)
"""

    @staticmethod
    def interactive_runner_click_win_icon_command(password: str) -> str:
        command = r"""$ErrorActionPreference = 'Stop'

$password = __PASSWORD__
$taskName = 'WorkflowGymInteractiveRunner'
$desktop = 'C:\Users\Administrator\Desktop'
$python = 'C:\Program Files\Python312\python.exe'
$runnerPath = Join-Path $desktop 'workflowgym_interactive_runner.py'
$runnerCmdPath = Join-Path $desktop 'workflowgym_interactive_runner.cmd'
$actionPath = Join-Path $desktop 'workflowgym_runner_command.json'
$resultPath = Join-Path $desktop 'workflowgym_runner_result.json'

if (-not (Test-Path $python)) {
  throw "python executable not found: $python"
}

Remove-Item -LiteralPath $actionPath -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $resultPath -Force -ErrorAction SilentlyContinue

@"
import json
import time
import traceback
from pathlib import Path

import pyautogui

pyautogui.FAILSAFE = False

desktop = Path(r"C:\Users\Administrator\Desktop")
action_path = desktop / "workflowgym_runner_command.json"
result_path = desktop / "workflowgym_runner_result.json"

def write_result(payload):
    result_path.write_text(json.dumps(payload, ensure_ascii=True), encoding="utf-8")

for _ in range(120):
    if action_path.exists():
        try:
            action = json.loads(action_path.read_text(encoding="utf-8-sig"))
            width, height = pyautogui.size()
            if action.get("action") == "click_win_icon":
                pyautogui.click(20, height - 20)
                status = "clicked"
            else:
                status = "unknown_action"
            write_result({
                "ok": True,
                "status": status,
                "screen_size": [width, height],
                "action": action,
            })
        except Exception as exc:
            write_result({
                "ok": False,
                "error": repr(exc),
                "traceback": traceback.format_exc(),
            })
        break
    time.sleep(0.5)
else:
    write_result({"ok": False, "error": "timeout waiting action file"})
"@ | Set-Content -LiteralPath $runnerPath -Encoding UTF8

('@echo off' + [Environment]::NewLine + '"' + $python + '" "' + $runnerPath + '"') | Set-Content -LiteralPath $runnerCmdPath -Encoding ASCII
$taskCommand = $runnerCmdPath
cmd.exe /c "schtasks /Delete /TN $taskName /F >nul 2>nul"
schtasks /Create /F /TN $taskName /SC ONCE /ST 23:59 /TR $taskCommand /RU Administrator /RP $password /RL HIGHEST /IT | Out-Null
schtasks /Run /TN $taskName | Out-Null

Start-Sleep -Seconds 3
'{"action":"click_win_icon"}' | Set-Content -LiteralPath $actionPath -Encoding UTF8

for ($i = 0; $i -lt 60; $i++) {
  if (Test-Path $resultPath) {
    Write-Output 'WORKFLOWGYM_INTERACTIVE_RUNNER_RESULT'
    Get-Content -LiteralPath $resultPath -Raw
    exit 0
  }
  Start-Sleep -Seconds 1
}

throw "interactive runner did not write result: $resultPath"
"""
        return command.replace("__PASSWORD__", ps_single_quote(password))

    @staticmethod
    def file_queue_watchdog_setup_command(password: str) -> str:
        command = r"""$ErrorActionPreference = 'Stop'

$password = __PASSWORD__
$taskName = 'WorkflowGymFileQueueWatchdog'
$desktop = 'C:\Users\Administrator\Desktop'
$python = 'C:\Program Files\Python312\python.exe'
$runnerPath = Join-Path $desktop 'workflowgym_file_queue_runner.py'
$watchdogPath = Join-Path $desktop 'workflowgym_file_queue_watchdog.py'
$watchdogCmdPath = Join-Path $desktop 'workflowgym_file_queue_watchdog.cmd'
$actionPath = Join-Path $desktop 'workflowgym_file_queue_action.json'
$resultPath = Join-Path $desktop 'workflowgym_file_queue_result.json'
$heartbeatPath = Join-Path $desktop 'workflowgym_file_queue_heartbeat.json'
$runnerLogPath = Join-Path $desktop 'workflowgym_file_queue_runner.log'
$watchdogLogPath = Join-Path $desktop 'workflowgym_file_queue_watchdog.log'

if (-not (Test-Path $python)) {
  throw "python executable not found: $python"
}

Get-CimInstance Win32_Process |
  Where-Object {
    $_.CommandLine -like '*workflowgym_file_queue_runner.py*' -or
    $_.CommandLine -like '*workflowgym_file_queue_watchdog.py*'
  } |
  ForEach-Object {
    Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
  }

Remove-Item -LiteralPath $actionPath -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $resultPath -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $heartbeatPath -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $runnerLogPath -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $watchdogLogPath -Force -ErrorAction SilentlyContinue

@"
import json
import os
import time
import traceback
from pathlib import Path

import pyautogui

pyautogui.FAILSAFE = False

desktop = Path(r"C:\Users\Administrator\Desktop")
action_path = desktop / "workflowgym_file_queue_action.json"
result_path = desktop / "workflowgym_file_queue_result.json"
heartbeat_path = desktop / "workflowgym_file_queue_heartbeat.json"
log_path = desktop / "workflowgym_file_queue_runner.log"

def log(message):
    with log_path.open("a", encoding="utf-8") as handle:
        handle.write(time.strftime("%Y-%m-%d %H:%M:%S") + " " + message + "\n")
        handle.flush()

def write_result(payload):
    tmp_path = result_path.with_suffix(".tmp")
    tmp_path.write_text(json.dumps(payload, ensure_ascii=True, indent=2), encoding="utf-8")
    tmp_path.replace(result_path)

log("START pid=%s" % os.getpid())
while True:
    heartbeat_tmp = heartbeat_path.with_suffix(".tmp")
    heartbeat_tmp.write_text(json.dumps({
        "ok": True,
        "runner": "file_queue",
        "pid": os.getpid(),
        "time": time.time(),
    }, ensure_ascii=True), encoding="utf-8")
    heartbeat_tmp.replace(heartbeat_path)
    if action_path.exists():
        try:
            action = json.loads(action_path.read_text(encoding="utf-8-sig"))
            action_path.unlink()
            width, height = pyautogui.size()
            if action.get("action") == "health":
                result = {
                    "ok": True,
                    "runner": "file_queue",
                    "status": "health",
                    "screen_size": [width, height],
                    "action": action,
                    "pid": os.getpid(),
                }
            elif action.get("action") == "moveTo":
                pyautogui.moveTo(int(action["x"]), int(action["y"]))
                result = {
                    "ok": True,
                    "runner": "file_queue",
                    "status": "moved",
                    "screen_size": [width, height],
                    "position": list(pyautogui.position()),
                    "action": action,
                    "pid": os.getpid(),
                }
            elif action.get("action") == "press":
                pyautogui.press(action["key"])
                result = {
                    "ok": True,
                    "runner": "file_queue",
                    "status": "pressed",
                    "screen_size": [width, height],
                    "action": action,
                    "pid": os.getpid(),
                }
            elif action.get("action") == "hotkey":
                keys = [str(key) for key in action["keys"]]
                pyautogui.hotkey(*keys)
                result = {
                    "ok": True,
                    "runner": "file_queue",
                    "status": "hotkeyed",
                    "screen_size": [width, height],
                    "keys": keys,
                    "action": action,
                    "pid": os.getpid(),
                }
            elif action.get("action") == "click_win_icon":
                taskbar_height = int(action.get("taskbar_height", 48))
                start_button_width = int(action.get("start_button_width", 48))
                target = [start_button_width // 2, height - (taskbar_height // 2)]
                pyautogui.click(target[0], target[1])
                result = {
                    "ok": True,
                    "runner": "file_queue",
                    "status": "clicked_win_icon",
                    "screen_size": [width, height],
                    "position": list(pyautogui.position()),
                    "target": target,
                    "calculation": {
                        "taskbar_height": taskbar_height,
                        "start_button_width": start_button_width,
                        "formula": "x=start_button_width/2, y=screen_height-taskbar_height/2",
                    },
                    "action": action,
                    "pid": os.getpid(),
                }
            elif action.get("action") == "click":
                pyautogui.click(int(action["x"]), int(action["y"]))
                result = {
                    "ok": True,
                    "runner": "file_queue",
                    "status": "clicked",
                    "screen_size": [width, height],
                    "action": action,
                    "pid": os.getpid(),
                }
            else:
                result = {
                    "ok": False,
                    "status": "unknown_action",
                    "screen_size": [width, height],
                    "action": action,
                    "pid": os.getpid(),
                }
            write_result(result)
            log("RESULT " + json.dumps(result, ensure_ascii=True))
        except Exception as exc:
            error = {
                "ok": False,
                "runner": "file_queue",
                "error": repr(exc),
                "traceback": traceback.format_exc(),
                "pid": os.getpid(),
            }
            write_result(error)
            log("ERROR " + json.dumps(error, ensure_ascii=True))
    time.sleep(0.2)
"@ | Set-Content -LiteralPath $runnerPath -Encoding UTF8

@"
import json
import os
import subprocess
import time
from pathlib import Path

desktop = Path(r"C:\Users\Administrator\Desktop")
python = r"C:\Program Files\Python312\python.exe"
runner_path = desktop / "workflowgym_file_queue_runner.py"
heartbeat_path = desktop / "workflowgym_file_queue_watchdog_heartbeat.json"
log_path = desktop / "workflowgym_file_queue_watchdog.log"

def log(message):
    with log_path.open("a", encoding="utf-8") as handle:
        handle.write(time.strftime("%Y-%m-%d %H:%M:%S") + " " + message + "\n")
        handle.flush()

def runner_process_exists():
    startupinfo = subprocess.STARTUPINFO()
    startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    output = subprocess.check_output(
        ["wmic", "process", "where", "name='python.exe'", "get", "CommandLine"],
        text=True,
        errors="ignore",
        startupinfo=startupinfo,
    )
    return str(runner_path).lower() in output.lower()

log("START pid=%s" % os.getpid())
while True:
    if not runner_process_exists():
        log("START_RUNNER " + str(runner_path))
        subprocess.Popen([python, str(runner_path)], cwd=str(desktop))
    tmp_path = heartbeat_path.with_suffix(".tmp")
    tmp_path.write_text(json.dumps({
        "ok": True,
        "watchdog": "file_queue",
        "pid": os.getpid(),
        "time": time.time(),
    }, ensure_ascii=True), encoding="utf-8")
    tmp_path.replace(heartbeat_path)
    time.sleep(5)
"@ | Set-Content -LiteralPath $watchdogPath -Encoding UTF8

('@echo off' + [Environment]::NewLine + '"' + $python + '" "' + $watchdogPath + '"') | Set-Content -LiteralPath $watchdogCmdPath -Encoding ASCII

cmd.exe /c "schtasks /Delete /TN $taskName /F >nul 2>nul"
schtasks /Create /F /TN $taskName /SC ONLOGON /TR $watchdogCmdPath /RU Administrator /RP $password /RL HIGHEST /IT | Out-Null
schtasks /Run /TN $taskName | Out-Null

for ($i = 0; $i -lt 30; $i++) {
  if ((Test-Path $heartbeatPath) -and (Test-Path $runnerLogPath)) {
    Write-Output 'WORKFLOWGYM_FILE_QUEUE_WATCHDOG_READY'
    Write-Output ('WORKFLOWGYM_FILE_QUEUE_WATCHDOG_PATH ' + $watchdogPath)
    Write-Output ('WORKFLOWGYM_FILE_QUEUE_RUNNER_PATH ' + $runnerPath)
    Write-Output ('WORKFLOWGYM_FILE_QUEUE_ACTION ' + $actionPath)
    Write-Output ('WORKFLOWGYM_FILE_QUEUE_RESULT ' + $resultPath)
    Write-Output 'WORKFLOWGYM_FILE_QUEUE_WATCHDOG_HEARTBEAT'
    Get-Content -LiteralPath $heartbeatPath -Raw
    Write-Output 'WORKFLOWGYM_FILE_QUEUE_RUNNER_LOG'
    Get-Content -LiteralPath $runnerLogPath -Tail 20
    exit 0
  }
  Start-Sleep -Seconds 1
}

if (Test-Path $watchdogLogPath) {
  Write-Output 'WORKFLOWGYM_FILE_QUEUE_WATCHDOG_LOG'
  Get-Content -LiteralPath $watchdogLogPath -Tail 20
}
throw "file queue watchdog did not start runner"
"""
        return command.replace("__PASSWORD__", ps_single_quote(password))

    @staticmethod
    def file_queue_agent_actions_task_command() -> str:
        return r"""$ErrorActionPreference = 'Stop'

$desktop = 'C:\Users\Administrator\Desktop'
$actionPath = Join-Path $desktop 'workflowgym_file_queue_action.json'
$resultPath = Join-Path $desktop 'workflowgym_file_queue_result.json'
$runnerHeartbeatPath = Join-Path $desktop 'workflowgym_file_queue_heartbeat.json'
$watchdogHeartbeatPath = Join-Path $desktop 'workflowgym_file_queue_watchdog_heartbeat.json'
$runnerLogPath = Join-Path $desktop 'workflowgym_file_queue_runner.log'
$watchdogLogPath = Join-Path $desktop 'workflowgym_file_queue_watchdog.log'

Remove-Item -LiteralPath $resultPath -Force -ErrorAction SilentlyContinue

$identity = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$sessionId = (Get-Process -Id $PID).SessionId
Write-Output ('WORKFLOWGYM_FILE_QUEUE_DELIVERY_IDENTITY identity=' + $identity + ' session=' + $sessionId)

if (Test-Path $watchdogHeartbeatPath) {
  Write-Output 'WORKFLOWGYM_FILE_QUEUE_WATCHDOG_HEARTBEAT_BEFORE'
  Get-Content -LiteralPath $watchdogHeartbeatPath -Raw
}
if (Test-Path $runnerHeartbeatPath) {
  Write-Output 'WORKFLOWGYM_FILE_QUEUE_RUNNER_HEARTBEAT_BEFORE'
  Get-Content -LiteralPath $runnerHeartbeatPath -Raw
}

function Invoke-WorkflowGymFileQueueAction {
  param(
    [string] $Name,
    [string] $Json
  )

  Remove-Item -LiteralPath $resultPath -Force -ErrorAction SilentlyContinue
  $Json | Set-Content -LiteralPath $actionPath -Encoding UTF8

  for ($i = 0; $i -lt 60; $i++) {
    if (Test-Path $resultPath) {
      Write-Output ('WORKFLOWGYM_FILE_QUEUE_AGENT_RESULT_' + $Name)
      Get-Content -LiteralPath $resultPath -Raw
      return
    }
    Start-Sleep -Seconds 1
  }

  throw "file queue agent did not write result for action: $Name"
}

Invoke-WorkflowGymFileQueueAction 'HEALTH' '{"action":"health","source":"cloud_assistant_file_queue_test"}'
Invoke-WorkflowGymFileQueueAction 'MOVE' '{"action":"moveTo","x":20,"y":20,"source":"cloud_assistant_file_queue_test"}'
Invoke-WorkflowGymFileQueueAction 'PRESS' '{"action":"press","key":"esc","source":"cloud_assistant_file_queue_test"}'
Invoke-WorkflowGymFileQueueAction 'HOTKEY_WIN_R' '{"action":"hotkey","keys":["winleft","r"],"source":"cloud_assistant_file_queue_test"}'
Invoke-WorkflowGymFileQueueAction 'CLICK_WIN_ICON' '{"action":"click_win_icon","source":"cloud_assistant_file_queue_test"}'

if (Test-Path $runnerHeartbeatPath) {
  Write-Output 'WORKFLOWGYM_FILE_QUEUE_RUNNER_HEARTBEAT_AFTER'
  Get-Content -LiteralPath $runnerHeartbeatPath -Raw
}
if (Test-Path $runnerLogPath) {
  Write-Output 'WORKFLOWGYM_FILE_QUEUE_RUNNER_LOG'
  Get-Content -LiteralPath $runnerLogPath -Tail 20
}
if (Test-Path $watchdogLogPath) {
  Write-Output 'WORKFLOWGYM_FILE_QUEUE_WATCHDOG_LOG'
  Get-Content -LiteralPath $watchdogLogPath -Tail 20
}
"""

    @staticmethod
    def command_decoded_output(response_data: dict) -> str:
        outputs = []
        for item in response_data.get("results") or []:
            output = item.get("decoded_output")
            if output:
                outputs.append(output)
        return "\n".join(outputs)


if __name__ == "__main__":
    unittest.main()
