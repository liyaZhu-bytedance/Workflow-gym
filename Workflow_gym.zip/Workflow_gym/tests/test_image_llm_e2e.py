from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.judgers.agent import JudgerAgent
from open_workflowgym.judgers.common import (
    IMAGE_LLM_EMPTY_EVALUATION_SCORE,
    collect_reference_image_paths,
    load_traj,
    valid_screenshots,
)
from open_workflowgym.records import TaskFileResult, TrajectoryResult
from open_workflowgym.scorer import Scorer

TASK42_RESPONSE_REFERENCE = "界面应显示 Statistics 复选框已勾选，且 Overlays 面板可见。"


def write_minimal_jpeg(path: Path, *, color: tuple[int, int, int] = (120, 80, 200)) -> None:
    from PIL import Image

    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", (48, 48), color=color).save(path, "JPEG")


def write_minimal_png(path: Path, *, color: tuple[int, int, int] = (30, 160, 90)) -> None:
    from PIL import Image

    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", (48, 48), color=color).save(path, "PNG")


def build_image_llm_sample_dir(sample_dir: Path, *, include_reference: bool = True) -> dict[str, Path]:
    reference_source = sample_dir / "reference_source.png"
    write_minimal_png(reference_source)

    screenshot_paths: list[Path] = []
    for step_index in range(10):
        screenshot_path = sample_dir / f"step_{step_index}.jpg"
        write_minimal_jpeg(screenshot_path, color=(step_index * 20 % 255, 40, 180))
        screenshot_paths.append(screenshot_path)

    if include_reference:
        reference_in_gt = sample_dir / "gt_sreenshot" / reference_source.name
        reference_in_gt.parent.mkdir(parents=True, exist_ok=True)
        reference_in_gt.write_bytes(reference_source.read_bytes())
        last_student = screenshot_paths[-1]
        last_student.write_bytes(reference_source.read_bytes())

    traj_path = sample_dir / "traj.json"
    traj_path.write_text(
        json.dumps(
            [{"step": index, "screenshot": str(path)} for index, path in enumerate(screenshot_paths)],
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    for name in ("traj.md", "sample_metadata.json", "sample_status.json"):
        (sample_dir / name).write_text("", encoding="utf-8")

    return {
        "reference_source": reference_source,
        "traj_json": traj_path,
        "last_screenshot": screenshot_paths[-1],
    }


def build_image_llm_trajectory(sample_dir: str, *, include_reference: bool = True) -> TrajectoryResult:
    task_fields = {
        "answer_type": "数值/文本-多点验证",
        "metric_type": "image-llm",
        "response_reference": TASK42_RESPONSE_REFERENCE,
    }
    if include_reference:
        task_fields["sheetshot_url"] = str(Path(sample_dir) / "reference_source.png")

    return TrajectoryResult(
        run_id="run-image-llm-e2e",
        task_id="42",
        sample_index=1,
        status="sample_completed",
        sample_dir=sample_dir,
        traj_json_path=str(Path(sample_dir) / "traj.json"),
        traj_md_path=str(Path(sample_dir) / "traj.md"),
        id_json_path=str(Path(sample_dir) / "sample_metadata.json"),
        sample_status_path=str(Path(sample_dir) / "sample_status.json"),
        last_step=9,
        task_files=TaskFileResult(),
        task_fields=task_fields,
    )


class _FakeJudgeClient:
    model = "fake-image-llm-model"

    def __init__(self, raw_response: str):
        self._raw_response = raw_response

    def call_model(self, messages, *, retry_count=None, delay_seconds=None) -> str:
        return self._raw_response


class ImageLlmE2ETest(unittest.TestCase):
    def test_reference_image_is_placed_into_sample_result_images(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            sample_dir = Path(temp_dir)
            artifacts = build_image_llm_sample_dir(sample_dir, include_reference=True)
            trajectory = build_image_llm_trajectory(temp_dir)

            reference_paths = collect_reference_image_paths(trajectory)
            student_paths = valid_screenshots(load_traj(trajectory.traj_json_path))

            self.assertEqual(len(reference_paths), 1)
            self.assertTrue(reference_paths[0].endswith("reference_source.png"))
            self.assertTrue(Path(reference_paths[0]).is_file())
            self.assertGreater(len(student_paths), 8)
            self.assertEqual(
                artifacts["last_screenshot"].read_bytes(),
                artifacts["reference_source"].read_bytes(),
            )

    def test_image_llm_e2e_scores_via_scorer_when_reference_present(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            build_image_llm_sample_dir(Path(temp_dir), include_reference=True)
            trajectory = build_image_llm_trajectory(temp_dir)
            fake_client = _FakeJudgeClient('{"answer_score": 1, "evidence": "界面与参考图一致"}')

            with patch(
                "open_workflowgym.judgers.image_llm.JudgeModelFactory.create",
                return_value=fake_client,
            ):
                score_result = Scorer().score(trajectory)

            score_payload = json.loads(Path(score_result.score_json_path).read_text(encoding="utf-8"))
            check = score_payload["check"]
            judge_result = check["judge_results"][0]

            self.assertEqual(check["answer_score"], 1)
            self.assertTrue(check["exists"])
            self.assertEqual(check["answer_type"], "数值/文本-多点验证-image-llm")
            self.assertEqual(judge_result["status"], "success")
            self.assertEqual(len(judge_result["reference_image_paths"]), 1)
            self.assertEqual(judge_result["student_screenshots_used"], 8)
            self.assertEqual(len(judge_result["last_screenshots"]), 8)
            self.assertIn("reference_images=1 张", check["evidence"])

    def test_image_llm_e2e_fails_when_reference_image_missing(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            build_image_llm_sample_dir(Path(temp_dir), include_reference=False)
            trajectory = build_image_llm_trajectory(temp_dir, include_reference=False)
            trajectory.task_fields["sheetshot_url"] = (
                "{'cellPosition': None, 'link': 'https://example.com/missing-ref.png', "
                "'text': 'https://example.com/missing-ref.png', 'type': 'url'}"
            )

            with patch("open_workflowgym.judgers.common.urllib.request.urlretrieve", side_effect=OSError("download failed")):
                result = JudgerAgent().judge(trajectory)

            judge_result = result["judge_results"][0]
            self.assertEqual(result["answer_score"], IMAGE_LLM_EMPTY_EVALUATION_SCORE)
            self.assertFalse(result["exists"])
            self.assertEqual(judge_result["reference_image_paths"], [])
            self.assertEqual(judge_result["student_screenshots_used"], 8)
            self.assertIn("输入不完整", judge_result["error"])

    def test_image_llm_e2e_uses_local_sheetshot_without_network(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            artifacts = build_image_llm_sample_dir(Path(temp_dir), include_reference=True)
            trajectory = build_image_llm_trajectory(temp_dir)
            fake_client = _FakeJudgeClient('{"answer_score": 0, "evidence": "界面不一致"}')

            with patch("open_workflowgym.judgers.common.urllib.request.urlretrieve") as urlretrieve:
                with patch(
                    "open_workflowgym.judgers.image_llm.JudgeModelFactory.create",
                    return_value=fake_client,
                ):
                    result = JudgerAgent().judge(trajectory)

            urlretrieve.assert_not_called()
            judge_result = result["judge_results"][0]
            self.assertEqual(judge_result["reference_image_filenames"], [artifacts["reference_source"].name])
            self.assertEqual(result["answer_score"], 0)
            self.assertFalse(result["exists"])


if __name__ == "__main__":
    unittest.main()
