from __future__ import annotations

import base64
import sys
import unittest
from pathlib import Path
from unittest import mock

REPO_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = Path("/tmp/owg_path")
PACKAGE_ROOT.mkdir(parents=True, exist_ok=True)
link = PACKAGE_ROOT / "open_workflowgym"
if link.exists() or link.is_symlink():
    link.unlink()
link.symlink_to(REPO_ROOT)
sys.path.insert(0, str(PACKAGE_ROOT))

from open_workflowgym.agents.pyautogui_actions import extract_flask_action_python_script
from open_workflowgym.records import RunConfig, SampleJob, TaskRecord
from open_workflowgym.sampler import should_use_wgm_direct_action_delivery


class ExtractFlaskActionScriptTests(unittest.TestCase):
    def test_extract_from_ubuntu_curl_wrapper(self):
        script = "import pyautogui\npyautogui.click(10, 20)\n"
        b64 = base64.b64encode(script.encode("utf-8")).decode("ascii")
        command = (
            "#!/bin/bash\n"
            "WORKFLOWGYM_FLASK_AGENT_RESULT\n"
            f'-d \'{{"action": "python", "script_b64": "{b64}"}}\'\n'
            "http://127.0.0.1:80/action\n"
        )
        self.assertEqual(extract_flask_action_python_script(command), script)

    def test_extract_from_windows_here_string(self):
        script = "import pyautogui\npyautogui.click(1, 2)"
        command = (
            "$ErrorActionPreference = 'Stop'\n"
            "$script = @'\n"
            f"{script}\n"
            "'@\n"
            "WORKFLOWGYM_FLASK_AGENT_RESULT\n"
        )
        self.assertEqual(extract_flask_action_python_script(command), script)

    def test_extract_bare_pyautogui(self):
        script = "import pyautogui\npyautogui.moveTo(1, 2)\n"
        self.assertEqual(extract_flask_action_python_script(script), script)

    def test_wgm_direct_gate(self):
        redis_job = SampleJob(
            run_id="r1",
            task_id="t1",
            sample_index=1,
            task=TaskRecord(run_id="r1", task_id="t1", row_number=1, fields={}),
            config=RunConfig(run_id="r1", lease_backend="redis"),
        )
        local_job = SampleJob(
            run_id="r1",
            task_id="t1",
            sample_index=1,
            task=TaskRecord(run_id="r1", task_id="t1", row_number=1, fields={}),
            config=RunConfig(run_id="r1", lease_backend="local"),
        )
        cmd = "#!/bin/bash\nWORKFLOWGYM_FLASK_AGENT_RESULT\n/action\n"
        self.assertTrue(should_use_wgm_direct_action_delivery(redis_job, cmd))
        self.assertFalse(should_use_wgm_direct_action_delivery(local_job, cmd))


if __name__ == "__main__":
    unittest.main()
