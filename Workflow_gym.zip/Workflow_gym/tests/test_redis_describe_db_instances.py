from __future__ import print_function

import os
import unittest
import warnings

warnings.filterwarnings(
    "ignore",
    message="urllib3 v2 only supports OpenSSL.*",
)

import volcenginesdkcore
import volcenginesdkredis
from volcenginesdkcore.rest import ApiException

from main import get_result_payload, to_plain_dict


REGION = os.getenv("REGION", "cn-guangzhou")


def create_api_instance():
    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = REGION
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkredis.REDISApi()


class TestRedisDescribeDBInstances(unittest.TestCase):
    def test_describe_db_instances(self):
        api_instance = create_api_instance()
        request = volcenginesdkredis.DescribeDBInstancesRequest()

        try:
            response = api_instance.describe_db_instances(request)
        except ApiException as exc:
            self.fail("DescribeDBInstances 调用失败: %s" % exc)

        response_data = to_plain_dict(response)
        result = get_result_payload(response_data)
        self.assertIsInstance(result, dict, "DescribeDBInstances 响应无法解析为 dict")

        instances = result.get("DBInstances") or result.get("db_instances") or []
        self.assertIsInstance(instances, list, "DescribeDBInstances 响应中的实例列表不是 list")
        print("Redis 实例数量: %s" % len(instances))


if __name__ == "__main__":
    unittest.main()
