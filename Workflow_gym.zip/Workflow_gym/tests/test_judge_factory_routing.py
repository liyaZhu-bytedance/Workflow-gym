from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.judgers.defaults import is_bytedance_search_gpt_base_url
from open_workflowgym.judgers.factory import JudgeModelClient, JudgeModelConfig


class JudgeFactoryRoutingTest(unittest.TestCase):
    def test_internal_judge_gpt_base_url_detection_disabled(self) -> None:
        self.assertFalse(
            is_bytedance_search_gpt_base_url("https://internal-judge.example.net/gpt/openapi/online/v2/crawl")
        )
        self.assertFalse(
            is_bytedance_search_gpt_base_url("https://api.openai.com/v1")
        )
        self.assertFalse(
            is_bytedance_search_gpt_base_url(
                "https://internal-judge.example.net/gpt/openapi/online/v2/crawl/chat/completions"
            )
        )

    def build_client(self, base_url: str) -> JudgeModelClient:
        return JudgeModelClient(
            JudgeModelConfig(
                name="routing_test",
                provider="openai",
                model="test-model",
                base_url=base_url,
                api_key_env=("TEST_JUDGE_API_KEY",),
            )
        )

    @patch.dict("os.environ", {"TEST_JUDGE_API_KEY": "test-key"})
    @patch("open_workflowgym.judgers.factory.resolve_provider_from_base_url", return_value="azure_openai")
    def test_internal_judge_url_can_route_to_azure_openai(self, _provider) -> None:
        client = self.build_client("https://internal-judge.example.net/gpt/openapi/online/v2/crawl")
        with (
            patch.object(client, "_call_azure_openai", return_value="azure") as azure_call,
            patch.object(client, "_call_openai", return_value="openai") as openai_call,
        ):
            self.assertEqual(client.call_model([]), "azure")
        azure_call.assert_called_once_with([], "test-key")
        openai_call.assert_not_called()

    @patch.dict("os.environ", {"TEST_JUDGE_API_KEY": "test-key"})
    def test_standard_openai_url_routes_to_openai(self) -> None:
        client = self.build_client("https://api.openai.com/v1")
        with (
            patch.object(client, "_call_azure_openai", return_value="azure") as azure_call,
            patch.object(client, "_call_openai", return_value="openai") as openai_call,
        ):
            self.assertEqual(client.call_model([]), "openai")
        openai_call.assert_called_once_with([], "test-key")
        azure_call.assert_not_called()


if __name__ == "__main__":
    unittest.main()
