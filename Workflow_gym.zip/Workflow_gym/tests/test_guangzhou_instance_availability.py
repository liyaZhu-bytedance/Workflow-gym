from __future__ import annotations

import json
import os
import sys
import unittest
import warnings
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

warnings.filterwarnings(
    "ignore",
    message="urllib3 v2 only supports OpenSSL.*",
)

import volcenginesdkcore
import volcenginesdkecs
from volcenginesdkcore.rest import ApiException

from open_workflowgym.envs.volcengine_env import (
    VolcengineEnv,
    get_result_payload,
    instance_platform_from_name,
    to_plain_dict,
)


REGION = os.getenv("VOLCENGINE_REGION", os.getenv("SOURCE_REGION", "cn-guangzhou"))
AVAILABLE_RESOURCE_ZONES = tuple(
    item.strip()
    for item in os.getenv("AVAILABLE_RESOURCE_ZONES", "cn-guangzhou-a,cn-guangzhou-b,cn-guangzhou-c").split(",")
    if item.strip()
)
INSTANCE_TYPE_IDS = tuple(
    item.strip()
    for item in os.getenv(
        "INSTANCE_TYPE_IDS",
        "ecs.r4il.4xlarge,ecs.r4il.2xlarge,ecs.r4il.xlarge,ecs.r4il.large,"
        "ecs.g3il.4xlarge,ecs.g3il.2xlarge,ecs.g3il.xlarge,ecs.g3il.large",
    ).split(",")
    if item.strip()
)
INSTANCE_NAME_PREFIX = os.getenv("WORKFLOWGYM_INSTANCE_NAME_PREFIX", "open_workflow_gym")
INSTANCE_DESCRIBE_LIMIT = int(os.getenv("INSTANCE_DESCRIBE_LIMIT", "100"))


def create_api_instance(region: str = REGION):
    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = region
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkecs.ECSApi()


def supported_resource_statuses(result: dict) -> list[str]:
    statuses: list[str] = []
    zones = result.get("AvailableZones") or result.get("available_zones") or []
    if not zones:
        return statuses
    zone = zones[0]
    for available_resource in zone.get("AvailableResources") or zone.get("available_resources") or []:
        for supported_resource in available_resource.get("SupportedResources") or available_resource.get(
            "supported_resources"
        ) or []:
            status = str(supported_resource.get("Status") or supported_resource.get("status") or "").strip()
            if status:
                statuses.append(status)
    return statuses


def describe_available_resource(api_instance, instance_type_id: str, zone_id: str) -> dict:
    request = volcenginesdkecs.DescribeAvailableResourceRequest(
        destination_resource="InstanceType",
        instance_type_id=instance_type_id,
        zone_id=zone_id,
    )
    response = api_instance.describe_available_resource(request)
    return get_result_payload(to_plain_dict(response))


def query_zone_inventory(api_instance, zone_id: str, instance_type_ids: tuple[str, ...]) -> dict[str, str]:
    inventory: dict[str, str] = {}
    for instance_type_id in instance_type_ids:
        try:
            result = describe_available_resource(api_instance, instance_type_id, zone_id)
            statuses = supported_resource_statuses(result)
            inventory[instance_type_id] = statuses[0] if statuses else "Unknown"
        except ApiException as exc:
            inventory[instance_type_id] = "Error"
            print(
                "DescribeAvailableResource 失败: zone_id=%s instance_type_id=%s error=%s"
                % (zone_id, instance_type_id, exc),
                flush=True,
            )
    return inventory


def summarize_inventory(inventory_by_zone: dict[str, dict[str, str]]) -> dict[str, object]:
    available_pairs: list[dict[str, str]] = []
    sold_out_pairs: list[dict[str, str]] = []
    for zone_id, inventory in inventory_by_zone.items():
        for instance_type_id, status in inventory.items():
            entry = {"zone_id": zone_id, "instance_type_id": instance_type_id, "status": status}
            normalized = status.lower()
            if normalized == "available":
                available_pairs.append(entry)
            elif normalized == "soldout":
                sold_out_pairs.append(entry)
    return {
        "available_count": len(available_pairs),
        "sold_out_count": len(sold_out_pairs),
        "available_pairs": available_pairs,
        "sold_out_pairs": sold_out_pairs,
    }


def instance_field(instance: dict, *keys: str) -> str:
    for key in keys:
        value = instance.get(key)
        if value:
            return str(value)
    return ""


def query_existing_instances(region: str = REGION, name_prefix: str = INSTANCE_NAME_PREFIX) -> list[dict[str, str]]:
    env = VolcengineEnv(region=region)
    rows: list[dict[str, str]] = []
    for instance in env.describe_instances(name_prefix=name_prefix, limit=INSTANCE_DESCRIBE_LIMIT):
        rows.append(
            {
                "instance_id": instance_field(instance, "InstanceId", "instance_id"),
                "instance_name": instance_field(instance, "InstanceName", "instance_name"),
                "status": instance_field(instance, "Status", "status"),
                "zone_id": instance_field(instance, "ZoneId", "zone_id"),
                "instance_type_id": instance_field(instance, "InstanceTypeId", "instance_type_id"),
                "platform": instance_platform_from_name(instance) or "unknown",
            }
        )
    return rows


def summarize_existing_instances(instances: list[dict[str, str]]) -> dict[str, object]:
    status_counter = Counter(row["status"] or "unknown" for row in instances)
    platform_counter = Counter(row["platform"] or "unknown" for row in instances)
    idle_like_statuses = {"RUNNING", "STOPPED"}
    idle_instances = [row for row in instances if row["status"] in idle_like_statuses]
    idle_by_platform = Counter(row["platform"] or "unknown" for row in idle_instances)
    return {
        "total": len(instances),
        "by_status": dict(status_counter),
        "by_platform": dict(platform_counter),
        "idle_like_total": len(idle_instances),
        "idle_like_by_platform": dict(idle_by_platform),
        "instances": instances,
    }


def build_availability_report(
    *,
    region: str,
    inventory_by_zone: dict[str, dict[str, str]],
    existing_summary: dict[str, object],
) -> dict[str, object]:
    inventory_summary = summarize_inventory(inventory_by_zone)
    return {
        "region": region,
        "zones": list(inventory_by_zone.keys()),
        "inventory_by_zone": inventory_by_zone,
        "inventory_summary": inventory_summary,
        "existing_instances": existing_summary,
    }


def print_availability_report(report: dict[str, object]) -> None:
    inventory_summary = report["inventory_summary"]
    existing = report["existing_instances"]
    print("=== cn-guangzhou 实例可用性报告 ===", flush=True)
    print("region=%s zones=%s" % (report["region"], ",".join(report["zones"])), flush=True)
    print(
        "可创建规格数: available=%s sold_out=%s"
        % (inventory_summary["available_count"], inventory_summary["sold_out_count"]),
        flush=True,
    )
    for entry in inventory_summary["available_pairs"]:
        print(
            "  [可创建] zone=%s spec=%s"
            % (entry["zone_id"], entry["instance_type_id"]),
            flush=True,
        )
    print(
        "现有实例: total=%s idle_like=%s by_platform=%s by_status=%s"
        % (
            existing["total"],
            existing["idle_like_total"],
            existing["by_platform"],
            existing["by_status"],
        ),
        flush=True,
    )
    for row in existing["instances"]:
        print(
            "  - %s name=%s platform=%s status=%s zone=%s spec=%s"
            % (
                row["instance_id"],
                row["instance_name"],
                row["platform"],
                row["status"],
                row["zone_id"],
                row["instance_type_id"],
            ),
            flush=True,
        )
    print("REPORT_JSON", json.dumps(report, ensure_ascii=False), flush=True)


@unittest.skipUnless(
    os.getenv("WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS") == "1",
    "set WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS=1 to run real Volcengine calls",
)
@unittest.skipUnless(os.getenv("AK") and os.getenv("SK"), "set AK and SK to query Volcengine inventory")
class TestGuangzhouInstanceAvailability(unittest.TestCase):
    """Read-only report for cn-guangzhou ECS stock and existing workflow instances."""

    def setUp(self):
        self.api = create_api_instance(REGION)

    def test_report_guangzhou_instance_availability(self):
        inventory_by_zone = {
            zone_id: query_zone_inventory(self.api, zone_id, INSTANCE_TYPE_IDS)
            for zone_id in AVAILABLE_RESOURCE_ZONES
        }
        existing_instances = query_existing_instances(REGION, INSTANCE_NAME_PREFIX)
        existing_summary = summarize_existing_instances(existing_instances)
        report = build_availability_report(
            region=REGION,
            inventory_by_zone=inventory_by_zone,
            existing_summary=existing_summary,
        )
        print_availability_report(report)

        self.assertEqual(report["region"], REGION)
        self.assertTrue(report["zones"])
        self.assertIn("available_count", report["inventory_summary"])
        self.assertIn("total", report["existing_instances"])


class TestGuangzhouInstanceAvailabilityHelpers(unittest.TestCase):
    def test_summarize_inventory_counts_available_specs(self):
        inventory_by_zone = {
            "cn-guangzhou-a": {
                "ecs.r4il.xlarge": "Available",
                "ecs.r4il.4xlarge": "SoldOut",
            },
            "cn-guangzhou-b": {
                "ecs.g3il.xlarge": "Available",
            },
        }
        summary = summarize_inventory(inventory_by_zone)
        self.assertEqual(summary["available_count"], 2)
        self.assertEqual(summary["sold_out_count"], 1)

    def test_summarize_existing_instances_groups_idle_like(self):
        instances = [
            {"instance_id": "i-1", "status": "RUNNING", "platform": "ubuntu"},
            {"instance_id": "i-2", "status": "STOPPED", "platform": "windows"},
            {"instance_id": "i-3", "status": "CREATING", "platform": "ubuntu"},
        ]
        summary = summarize_existing_instances(instances)
        self.assertEqual(summary["total"], 3)
        self.assertEqual(summary["idle_like_total"], 2)
        self.assertEqual(summary["idle_like_by_platform"], {"ubuntu": 1, "windows": 1})


if __name__ == "__main__":
    unittest.main()
