from __future__ import annotations

import json
import sys
import tempfile
import unittest
import unittest.mock
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.config import build_run_config, parse_args
from open_workflowgym.local_spreadsheet import (
    LocalSpreadsheetClient,
    MirroringSpreadsheetClient,
    read_csv_rows,
    resolve_local_samples_csv_path,
    resolve_report_csv_dir,
    resolve_source_csv_path,
    should_load_tasks_from_feishu,
    should_use_local_spreadsheet,
    write_csv_rows,
)
from open_workflowgym.main import build_feishu_source_client, build_spreadsheet_client, load_tasks_for_run
from open_workflowgym.records import TaskRecord
from open_workflowgym.source_reader import read_tasks_from_csv
from open_workflowgym.sample_log import read_existing_events
from open_workflowgym.writer_process import WriterProcess
from open_workflowgym.attachment_uploader import AttachmentUploader
from open_workflowgym.agents.factory import AgentFactory


class LocalSpreadsheetTest(unittest.TestCase):
    def test_write_values_creates_csv_sheet(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            client = LocalSpreadsheetClient(tmp_dir)
            report = client.create_or_get_report("WorkflowGym Report")
            client.write_values(report["spreadsheet_token"], "samples", "A1", [["task_id", "status"], ["258", "ok"]])
            rows = read_csv_rows(Path(tmp_dir) / "samples.csv")
            self.assertEqual(rows, [["task_id", "status"], ["258", "ok"]])

    def test_upload_attachment_copies_file(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            source = Path(tmp_dir) / "score.json"
            source.write_text('{"answer_score": 1}', encoding="utf-8")
            client = LocalSpreadsheetClient(tmp_dir)
            copied = client.upload_attachment(tmp_dir, str(source))
            self.assertTrue(Path(copied).is_file())
            self.assertTrue(str(copied).endswith("score.json"))

    def test_writer_process_writes_local_report(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            client = LocalSpreadsheetClient(tmp_dir)
            writer = WriterProcess(client, AttachmentUploader(client), AgentFactory())
            writer.write_validation_summary(
                {
                    "task_id": "258",
                    "validation": {
                        "task_id": "258",
                        "row_number": 2,
                        "status": "passed",
                        "passed": True,
                        "reason": "",
                    },
                }
            )
            rows = read_csv_rows(Path(tmp_dir) / "validation.csv")
            self.assertEqual(rows[0], ["task_id", "row_number", "status", "passed", "reason"])
            self.assertEqual(rows[1], ["258", "2", "passed", "true", ""])

    def test_read_tasks_from_csv(self):
        fixture = Path(__file__).resolve().parent / "fixtures" / "tasks.csv"
        tasks = read_tasks_from_csv(str(fixture), "run-test", start_row=2, limit=10)
        self.assertEqual(len(tasks), 2)
        self.assertEqual(tasks[0].task_id, "258")
        self.assertEqual(tasks[1].task_id, "324")
        self.assertIn("题目", tasks[0].fields)

    def test_should_use_local_spreadsheet_without_credentials(self):
        self.assertTrue(should_use_local_spreadsheet(False))

    def test_should_use_local_spreadsheet_without_admin_member_id(self):
        with unittest.mock.patch.dict(
            "os.environ",
            {"APP_ID": "app-id", "APP_SECRET": "app-secret"},
            clear=True,
        ):
            self.assertTrue(should_use_local_spreadsheet(True))

    def test_writer_process_writes_answer_score_after_trajectory(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            sample_dir = Path(tmp_dir) / "1381" / "sample_1"
            sample_dir.mkdir(parents=True)
            score_path = sample_dir / "score.json"
            score_path.write_text(
                '{"check": {"answer_score": 1, "evidence": "rubric pass", "error": "NA"}}',
                encoding="utf-8",
            )
            traj_json = sample_dir / "traj.json"
            traj_md = sample_dir / "traj.md"
            metadata_path = sample_dir / "sample_metadata.json"
            sample_log_path = sample_dir / "sample_log.json"
            traj_json.write_text("[]", encoding="utf-8")
            traj_md.write_text("# traj", encoding="utf-8")
            metadata_path.write_text('{"task_id": "1381"}', encoding="utf-8")
            sample_log_path.write_text('{"message": "sample completed"}\n', encoding="utf-8")
            gt_production_dir = sample_dir / "gt_production"
            gt_production_dir.mkdir(parents=True)
            (gt_production_dir / "case4.xml").write_text("<project/>", encoding="utf-8")

            client = LocalSpreadsheetClient(tmp_dir)
            writer = WriterProcess(client, AttachmentUploader(client), AgentFactory())
            writer.report["spreadsheet_url"] = "https://example.feishu.local/sheets/PLACEHOLDER"
            writer.write_trajectory_payload(
                {
                    "run_id": "run-test",
                    "task_id": "1381",
                    "sample_index": 1,
                    "status": "sample_completed",
                    "sample_dir": str(sample_dir),
                    "traj_json_path": str(traj_json),
                    "traj_md_path": str(traj_md),
                    "id_json_path": str(metadata_path),
                    "sample_status_path": str(sample_dir / "sample_status.json"),
                    "last_step": 9,
                    "error": "",
                    "task_fields": {"id": "1381", "题目": "demo"},
                }
            )
            writer.write_score_payload(
                {
                    "run_id": "run-test",
                    "task_id": "1381",
                    "sample_index": 1,
                    "score_json_path": str(score_path),
                    "task_fields": {"id": "1381", "题目": "demo"},
                }
            )

            rows = read_csv_rows(Path(tmp_dir) / "samples.csv")
            self.assertEqual(len(rows), 2)
            self.assertIn("sample_metadata.json", rows[0])
            self.assertIn("sample_log.json", rows[0])
            self.assertIn("score.json", rows[0])
            self.assertEqual(rows[1][7], str((Path(tmp_dir) / "attachments" / "case4.xml").resolve()))
            self.assertTrue((Path(tmp_dir) / "attachments" / "case4.xml").is_file())
            self.assertEqual(rows[1][12], "1")
            self.assertEqual(rows[1][13], "rubric pass")
            self.assertTrue((Path(tmp_dir) / "attachments" / "sample_metadata.json").is_file())
            self.assertTrue((Path(tmp_dir) / "attachments" / "sample_log.json").is_file())
            self.assertTrue((Path(tmp_dir) / "attachments" / "score.json").is_file())
            events = read_existing_events(sample_dir / "sample_log.json")
            self.assertEqual(events[-1]["source"], "writer")
            self.assertEqual(
                events[-1]["extra"]["report_url"],
                "https://example.feishu.local/sheets/PLACEHOLDER",
            )

    def test_writer_process_appends_report_url_after_trajectory_only(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            sample_dir = Path(tmp_dir) / "324" / "sample_1"
            sample_dir.mkdir(parents=True)
            traj_json = sample_dir / "traj.json"
            traj_md = sample_dir / "traj.md"
            metadata_path = sample_dir / "sample_metadata.json"
            sample_log_path = sample_dir / "sample_log.json"
            traj_json.write_text("[]", encoding="utf-8")
            traj_md.write_text("# traj", encoding="utf-8")
            metadata_path.write_text('{"task_id": "324"}', encoding="utf-8")
            sample_log_path.write_text('{"message": "sample completed"}\n', encoding="utf-8")

            client = LocalSpreadsheetClient(tmp_dir)
            writer = WriterProcess(client, AttachmentUploader(client), AgentFactory())
            writer.report["spreadsheet_url"] = "https://example.feishu.local/sheets/PLACEHOLDER"
            writer.write_trajectory_payload(
                {
                    "run_id": "run-test",
                    "task_id": "324",
                    "sample_index": 1,
                    "status": "sample_completed",
                    "sample_dir": str(sample_dir),
                    "traj_json_path": str(traj_json),
                    "traj_md_path": str(traj_md),
                    "id_json_path": str(metadata_path),
                    "sample_status_path": str(sample_dir / "sample_status.json"),
                    "last_step": 0,
                    "error": "",
                    "task_fields": {"id": "324", "题目": "demo"},
                }
            )

            events = read_existing_events(sample_dir / "sample_log.json")
            self.assertEqual(events[-1]["source"], "writer")
            self.assertEqual(
                events[-1]["extra"]["report_url"],
                "https://example.feishu.local/sheets/PLACEHOLDER",
            )

    def test_writer_process_reads_evidence_from_score_json(self):
        evidence = "rubric_score=1.0000, hard_avg=1.0000, quality=1.0000, answer_score=1（>0.8 为 1）"
        with tempfile.TemporaryDirectory() as tmp_dir:
            sample_dir = Path(tmp_dir) / "1381" / "sample_1"
            sample_dir.mkdir(parents=True)
            score_path = sample_dir / "score.json"
            score_path.write_text(
                json.dumps(
                    {
                        "saved_at": "2026-07-12 20:02:27",
                        "check": {
                            "answer_score": 1,
                            "evidence": evidence,
                            "error": "NA",
                        },
                    },
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )
            metadata_path = sample_dir / "sample_metadata.json"
            metadata_path.write_text('{"task_id": "1381"}', encoding="utf-8")
            (sample_dir / "sample_log.json").write_text('{"message": "done"}\n', encoding="utf-8")
            client = LocalSpreadsheetClient(tmp_dir)
            writer = WriterProcess(client, AttachmentUploader(client), AgentFactory())
            writer.write_trajectory_payload(
                {
                    "run_id": "run-test",
                    "task_id": "1381",
                    "sample_index": 1,
                    "status": "sample_completed",
                    "sample_dir": str(sample_dir),
                    "traj_json_path": str(sample_dir / "traj.json"),
                    "traj_md_path": str(sample_dir / "traj.md"),
                    "id_json_path": str(metadata_path),
                    "sample_status_path": str(sample_dir / "sample_status.json"),
                    "last_step": 9,
                    "error": "",
                    "task_fields": {"id": "1381"},
                }
            )
            Path(sample_dir / "traj.json").write_text("[]", encoding="utf-8")
            Path(sample_dir / "traj.md").write_text("# traj", encoding="utf-8")
            writer.write_score_payload(
                {
                    "run_id": "run-test",
                    "task_id": "1381",
                    "sample_index": 1,
                    "score_json_path": str(score_path),
                    "check": {},
                    "task_fields": {"id": "1381"},
                }
            )
            rows = read_csv_rows(Path(tmp_dir) / "samples.csv")
            self.assertEqual(rows[1][13], evidence)
            self.assertTrue(str(rows[1][14]).endswith("score.json"))

    def test_resolve_paths(self):
        configured = resolve_source_csv_path(str(Path(__file__).resolve().parent / "fixtures" / "tasks.csv"))
        self.assertTrue(Path(configured).is_file())
        report_dir = resolve_report_csv_dir("", "/tmp/output/run")
        self.assertEqual(report_dir, "/tmp/output/run/report")
        self.assertEqual(
            resolve_local_samples_csv_path("", "/tmp/output/run"),
            "/tmp/output/run/report/samples.csv",
        )

    def test_mirroring_spreadsheet_writes_local_csv(self):
        class FakePrimaryClient:
            dry_run = False

            def __init__(self):
                self.report = {
                    "spreadsheet_token": "feishu-token",
                    "spreadsheet_url": "https://feishu.example/sheet",
                    "validation_sheet_id": "validation",
                    "samples_sheet_id": "samples",
                    "agent_config_sheet_id": "agent_config",
                }
                self.write_calls: list[tuple[str, str, str]] = []

            def create_or_get_report(self, title: str) -> dict[str, str]:
                return dict(self.report)

            def read_values(self, spreadsheet_token: str, cell_range: str) -> list[list]:
                return []

            def write_values(self, spreadsheet_token: str, sheet_id: str, start_cell: str, values: list[list]) -> None:
                self.write_calls.append((spreadsheet_token, sheet_id, start_cell))

            def write_file_cell(self, spreadsheet_token: str, sheet_id: str, cell: str, file_token: str) -> None:
                self.write_calls.append((spreadsheet_token, sheet_id, cell))

            def upload_attachment(self, spreadsheet_token: str, file_path: str, file_name: str = "") -> str:
                return "feishu-file-token"

        with tempfile.TemporaryDirectory() as tmp_dir:
            local_dir = Path(tmp_dir) / "report"
            primary = FakePrimaryClient()
            client = MirroringSpreadsheetClient(primary, LocalSpreadsheetClient(str(local_dir)))
            report = client.create_or_get_report("WorkflowGym Report")
            client.write_values(report["spreadsheet_token"], "samples", "A1", [["task_id", "status"], ["258", "ok"]])
            rows = read_csv_rows(local_dir / "samples.csv")
            self.assertEqual(rows, [["task_id", "status"], ["258", "ok"]])
            self.assertEqual(len(primary.write_calls), 1)
            self.assertEqual(report["local_samples_csv"], str(local_dir / "samples.csv"))

    def test_mirroring_spreadsheet_delegates_feishu_helpers(self):
        class FakePrimaryClient:
            dry_run = False

            def resolve_wiki_spreadsheet_token(self, wiki_token: str) -> str:
                return "resolved-%s" % wiki_token

            def query_first_sheet_id(self, spreadsheet_token: str) -> str:
                return "sheet-1"

        client = MirroringSpreadsheetClient(FakePrimaryClient(), LocalSpreadsheetClient("/tmp/unused"))
        self.assertEqual(client.resolve_wiki_spreadsheet_token("wiki-token"), "resolved-wiki-token")
        self.assertEqual(client.query_first_sheet_id("spreadsheet-token"), "sheet-1")

    def test_build_spreadsheet_client_mirrors_when_feishu_enabled(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            args = parse_args(
                [
                    "--enable-real-feishu",
                    "--output-root",
                    str(Path(tmp_dir) / "output"),
                ]
            )
            config = build_run_config(args)
            with unittest.mock.patch.dict(
                "os.environ",
                {
                    "APP_ID": "app-id",
                    "APP_SECRET": "app-secret",
                    "FEISHU_SHEET_ADMIN_MEMBER_ID": "admin@example.com",
                },
                clear=False,
            ), unittest.mock.patch("open_workflowgym.main.FeishuClient") as feishu_cls:
                feishu_cls.return_value.dry_run = False
                client = build_spreadsheet_client(config)
            self.assertIsInstance(client, MirroringSpreadsheetClient)

    def test_build_spreadsheet_client_uses_local_without_admin_member_id(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            args = parse_args(
                [
                    "--enable-real-feishu",
                    "--output-root",
                    str(Path(tmp_dir) / "output"),
                ]
            )
            config = build_run_config(args)
            with unittest.mock.patch.dict(
                "os.environ",
                {"APP_ID": "app-id", "APP_SECRET": "app-secret"},
                clear=True,
            ):
                client = build_spreadsheet_client(config)
            self.assertIsInstance(client, LocalSpreadsheetClient)

    def test_should_load_tasks_from_feishu(self):
        self.assertFalse(should_load_tasks_from_feishu(""))
        self.assertTrue(should_load_tasks_from_feishu("https://example.com/sheet"))

    def test_build_feishu_source_client_requires_credentials(self):
        with unittest.mock.patch.dict("os.environ", {}, clear=True):
            with self.assertRaisesRegex(ValueError, "APP_ID"):
                build_feishu_source_client()

    def test_load_tasks_for_run_uses_csv_when_offline(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            csv_path = Path(tmp_dir) / "tasks.csv"
            write_csv_rows(csv_path, [["id", "题目", "image"], ["42", "demo task", "image-demo"]])
            args = parse_args(
                [
                    "--no-real-feishu",
                    "--source-feishu-url",
                    "",
                    "--source-csv-path",
                    str(csv_path),
                    "--id",
                    "42",
                    "--output-root",
                    str(Path(tmp_dir) / "output"),
                ]
            )
            config = build_run_config(args)
            client = build_spreadsheet_client(config)
            tasks = load_tasks_for_run(config, ("42",), client)
            self.assertEqual(len(tasks), 1)
            self.assertEqual(tasks[0].task_id, "42")
            self.assertEqual(tasks[0].fields["题目"], "demo task")

    def test_load_tasks_for_run_prefers_feishu_when_url_set(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            args = parse_args(
                [
                    "--no-real-feishu",
                    "--source-feishu-url",
                    "https://example.com/wiki/token?sheet=sheet1",
                    "--output-root",
                    str(Path(tmp_dir) / "output"),
                ]
            )
            config = build_run_config(args)
            fake_task = TaskRecord(run_id=config.run_id, task_id="258", row_number=2, fields={"id": "258"})
            with unittest.mock.patch.dict(
                "os.environ",
                {"APP_ID": "app-id", "APP_SECRET": "app-secret"},
                clear=False,
            ), unittest.mock.patch("open_workflowgym.main.build_feishu_source_client") as build_client, unittest.mock.patch(
                "open_workflowgym.main.SourceReader"
            ) as reader_cls:
                build_client.return_value = unittest.mock.Mock()
                reader_cls.return_value.read_tasks.return_value = [fake_task]
                tasks = load_tasks_for_run(config, ("258",), build_spreadsheet_client(config))
            reader_cls.return_value.read_tasks.assert_called_once()
            self.assertEqual(len(tasks), 1)
            self.assertEqual(tasks[0].task_id, "258")


if __name__ == "__main__":
    unittest.main()
