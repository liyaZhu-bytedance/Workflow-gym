from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.judgers.client import JudgeClient
from open_workflowgym.judgers.defaults import resolve_provider_from_base_url


def read_env(name: str, default: str = "") -> str:
    return (os.getenv(name, default) or "").strip()


def live_judge_enabled() -> bool:
    return read_env("RUN_LIVE_JUDGE", "0").lower() in ("1", "true", "yes", "on")


def resolve_live_judge_triple() -> tuple[str, str, str]:
    api_key = (
        read_env("GEMINI_JUDGE_API_KEY")
        or read_env("JUDGE_API_KEY")
        or read_env("GEMINI31_API_KEY")
    )
    base_url = read_env("GEMINI_JUDGE_BASE_URL") or read_env("JUDGE_BASE_URL")
    model = read_env("GEMINI_JUDGE_MODEL") or read_env("JUDGE_MODEL")
    return api_key, base_url, model


class JudgeClientProviderTest(unittest.TestCase):
    def test_resolve_provider_from_base_url(self) -> None:
        self.assertEqual(
            resolve_provider_from_base_url("https://internal-judge.example.net/gpt/openapi/online/v2/crawl"),
            "openai",
        )
        self.assertEqual(
            resolve_provider_from_base_url("https://api.openai.com/v1"),
            "openai",
        )
        self.assertEqual(
            resolve_provider_from_base_url("https://unknown.example/v1"),
            "openai",
        )

    def test_judge_client_provider_from_base_url(self) -> None:
        internal_client = JudgeClient(base_url="https://internal-judge.example.net/gpt/openapi/online/v2/crawl")
        self.assertEqual(internal_client.resolve_provider(), "openai")

        openai_client = JudgeClient(base_url="https://api.openai.com/v1")
        self.assertEqual(openai_client.resolve_provider(), "openai")

        default_client = JudgeClient(base_url="https://custom-gateway.example/v1")
        self.assertEqual(default_client.resolve_provider(), "openai")


class JudgeClientConfigTest(unittest.TestCase):
    def test_constructor_overrides_env(self) -> None:
        with patch.dict(
            os.environ,
            {
                "JUDGE_API_KEY": "env-key",
                "JUDGE_BASE_URL": "https://env.example/v1",
                "JUDGE_MODEL": "env-model",
            },
            clear=False,
        ):
            client = JudgeClient(
                api_key="explicit-key",
                base_url="https://explicit.example/v1/",
                model="explicit-model",
            )
            self.assertEqual(client.resolve_api_key(), "explicit-key")
            self.assertEqual(client.resolve_base_url(), "https://explicit.example/v1")
            self.assertEqual(client.resolve_model(), "explicit-model")

    def test_call_model_uses_openai_provider(self) -> None:
        client = JudgeClient(
            api_key="k",
            base_url="https://judge.example/v1",
            model="demo-model",
        )
        fake_response = MagicMock()
        fake_response.choices = [MagicMock(message=MagicMock(content='{"ok":true}'))]
        fake_openai = MagicMock()
        fake_openai.return_value.chat.completions.create.return_value = fake_response

        with patch.dict("sys.modules", {"openai": MagicMock(OpenAI=fake_openai, AzureOpenAI=MagicMock())}):
            content = client.call_model([{"role": "user", "content": "ping"}])

        self.assertEqual(content, '{"ok":true}')
        fake_openai.assert_called_once_with(api_key="k", base_url="https://judge.example/v1")

    @patch("open_workflowgym.judgers.client.resolve_provider_from_base_url", return_value="azure_openai")
    def test_call_model_uses_azure_provider_when_configured(self, _provider) -> None:
        client = JudgeClient(
            api_key="k",
            base_url="https://internal-judge.example.net/gpt/openapi/online/v2/crawl",
            model="demo-model",
        )
        fake_response = MagicMock()
        fake_response.choices = [MagicMock(message=MagicMock(content="azure-ok"))]
        fake_azure = MagicMock()
        fake_azure.return_value.chat.completions.create.return_value = fake_response
        fake_openai = MagicMock()

        with patch.dict("sys.modules", {"openai": MagicMock(OpenAI=fake_openai, AzureOpenAI=fake_azure)}):
            content = client.call_model([{"role": "user", "content": "ping"}])

        self.assertEqual(content, "azure-ok")
        fake_azure.assert_called_once()
        fake_openai.assert_not_called()


@unittest.skipUnless(
    live_judge_enabled(),
    "set RUN_LIVE_JUDGE=1 and JUDGE_API_KEY/JUDGE_BASE_URL/JUDGE_MODEL to run live call",
)
class JudgeClientLiveTest(unittest.TestCase):
    """真实请求：用配置的 base_url / api_key / model 调模型并返回内容。

    运行示例：
      export RUN_LIVE_JUDGE=1
      export JUDGE_API_KEY=...
      export JUDGE_BASE_URL=https://your-compatible-endpoint/v1
      export JUDGE_MODEL=gemini-3-pro-preview-new
      python -m unittest tests.test_judge_client.JudgeClientLiveTest -v
    """

    def test_call_model_returns_content(self) -> None:
        api_key, base_url, model = resolve_live_judge_triple()
        self.assertTrue(api_key, "缺少 JUDGE_API_KEY")
        self.assertTrue(base_url, "缺少 JUDGE_BASE_URL")
        self.assertTrue(model, "缺少 JUDGE_MODEL")

        client = JudgeClient(api_key=api_key, base_url=base_url, model=model)
        content = client.call_model(
            [{"role": "user", "content": "只返回一行文本：judge_client_ok"}]
        )

        self.assertTrue(str(content).strip(), "模型返回空内容")
        print("JUDGE_CLIENT_PROVIDER", client.resolve_provider(), flush=True)
        print("JUDGE_CLIENT_BASE_URL", base_url, flush=True)
        print("JUDGE_CLIENT_MODEL", model, flush=True)
        print("JUDGE_CLIENT_RESPONSE", content, flush=True)


if __name__ == "__main__":
    unittest.main()
