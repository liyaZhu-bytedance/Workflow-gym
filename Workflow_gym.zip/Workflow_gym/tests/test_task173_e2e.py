from __future__ import annotations

import json
import os
import shlex
import subprocess
import sys
import unittest
import warnings
from pathlib import Path
from unittest.mock import patch

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.agents.factory import AgentFactory
from open_workflowgym.envs.volcengine_env import VolcengineEnv
from open_workflowgym.records import InstanceLease, RunConfig, SampleJob, TaskRecord
from open_workflowgym.sampler import Sampler
from open_workflowgym.scorer import Scorer

from tests.e2e_reporting import maybe_write_e2e_sample_to_spreadsheet

DEFAULT_INSTANCE_ID = "i-yeq4neypkwuo7budzfbg"
TASK_ID = "173"
TASK_IMAGE_ID = "image-yepzwrabpklcg9mex7s2"
TASK_OUTPUT_PATH = "/home/user/Desktop/output/http_with_jpegs,/home/user/Desktop/output"
TASK_FINAL_ANSWER = "image_hash.txt"
TASK_FINAL_ANSWER_URL = "https://data.example.local/base_sheets_output/173/image_hash.txt"
TASK_INPUT_TOS_URL = "https://data.example.local/base_sheets_input/173/http_witp_jpegs.cap"
TASK_INPUT_PATH = "/home/user/Desktop/input"
TASK_IMAGE_HASH_CONTENT = "e4d909c290d0fb1ca068ffaddf22cbd0  bg2.jpg\n"
TASK_RESPONSE_REFERENCE = "image_hash.txt 应包含 bg2.jpg 的 MD5 哈希值"
DEFAULT_E2E_RUN_DIR = "manual_task173_e2e_1step"


def project_output_dir() -> Path:
    # 与工作区 output 目录一致：open_workflowgym/open_workflowgym/open_workflowgym/output
    return Path(__file__).resolve().parents[1] / "output"


def default_task173_e2e_output_root() -> str:
    return str(project_output_dir() / DEFAULT_E2E_RUN_DIR)


def reference_sample_metadata_paths() -> list[Path]:
    relative = Path("sample_kimi_native_1_200_202607121311/173/sample_1/sample_metadata.json")
    return [project_output_dir() / relative]


ZSHRC_ENV_NAMES = (
    "AK",
    "SK",
    "MOONSHOT_API_KEY",
    "KIMI_API_KEY",
    "KIMI_NATIVE_API_KEY",
    "VOLCENGINE_REGION",
    "SOURCE_REGION",
    "WORKFLOWGYM_TEST_INSTANCE_ID",
    "APP_ID",
    "APP_SECRET",
)


def read_env(name: str, default: str = "") -> str:
    return os.getenv(name, default)


def load_zshrc_env(names: tuple[str, ...] = ZSHRC_ENV_NAMES, zshrc_path: str = "") -> None:
    missing = [name for name in names if not read_env(name)]
    if not missing:
        return
    zshrc = Path(zshrc_path or os.path.expanduser("~/.zshrc"))
    if not zshrc.is_file():
        return
    zshrc_quoted = shlex.quote(str(zshrc))
    for name in missing:
        try:
            completed = subprocess.run(
                ["zsh", "-lc", "source %s >/dev/null 2>&1; print -r -- ${%s:-}" % (zshrc_quoted, name)],
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        value = (completed.stdout or "").strip()
        if value:
            os.environ[name] = value


def load_task173_instruction() -> str:
    for metadata_path in reference_sample_metadata_paths():
        if not metadata_path.is_file():
            continue
        payload = json.loads(metadata_path.read_text(encoding="utf-8"))
        up = str(payload.get("up") or "").strip()
        if up:
            return up
    return (
        "#软件启动方式: sudo wireshark ｜ root密码为：AlwaysDay1-BUPT-01\n\n"
        "在 Wireshark 中完成取证任务，并在 /home/user/Desktop/output/image_hash.txt 写入 bg2.jpg 的 MD5。"
    )


def build_task173_fields() -> dict[str, str]:
    return {
        "id": TASK_ID,
        "题目": load_task173_instruction(),
        "up": load_task173_instruction(),
        "镜像ID": TASK_IMAGE_ID,
        "image": TASK_IMAGE_ID,
        "系统类型": "Ubuntu",
        "platform": "ubuntu",
        "启动方式": "sudo wireshark ｜ root密码为：AlwaysDay1-BUPT-01",
        "tos_url": TASK_INPUT_TOS_URL,
        "输入文件路径": TASK_INPUT_PATH,
        "输出文件路径": TASK_OUTPUT_PATH,
        "final_answer文件名": TASK_FINAL_ANSWER,
        "final answer 文件": str([TASK_FINAL_ANSWER_URL]),
        "answer_type": "文件产物",
        "metric_type": "规则判分+LLM-as-judge",
        "判分类型": "规则判分+LLM-as-judge",
        "response_reference": TASK_RESPONSE_REFERENCE,
    }


def build_task173_sample_job(*, instance_id: str, output_root: str) -> SampleJob:
    return SampleJob(
        run_id="task173-e2e",
        task_id=TASK_ID,
        sample_index=1,
        task=TaskRecord(
            run_id="task173-e2e",
            task_id=TASK_ID,
            row_number=1,
            fields=build_task173_fields(),
        ),
        config=RunConfig(
            run_id="task173-e2e",
            output_root=output_root,
            sample_num=1,
            step_num=1,
            player="kimi",
            judger="gemini3.1",
            enable_real_cloud=True,
            tosutil_timeout_seconds=180,
            write_step_traj=True,
        ),
        lease=InstanceLease(
            run_id="task173-e2e",
            lease_id="task173-e2e-lease",
            instance_id=instance_id,
            task_id=TASK_ID,
            sample_index=1,
            status="busy",
            acquired_at="2026-07-12 00:00:00",
        ),
    )


def build_seed_image_hash_command() -> str:
    return "\n".join(
        [
            "#!/bin/bash",
            "set -e",
            "mkdir -p /home/user/Desktop/output/http_with_jpegs /home/user/Desktop/output",
            "cat > /home/user/Desktop/output/image_hash.txt <<'EOF'",
            TASK_IMAGE_HASH_CONTENT.rstrip("\n"),
            "EOF",
            "test -s /home/user/Desktop/output/image_hash.txt",
            "echo WORKFLOWGYM_TASK173_PRODUCT_READY",
        ]
    )


def seed_task173_product(env: VolcengineEnv, instance_id: str) -> None:
    result = env.run_command(instance_id, build_seed_image_hash_command(), timeout=120)
    output = ""
    for item in result.get("results") or []:
        if isinstance(item, dict):
            decoded = item.get("decoded_output")
            if decoded:
                output += str(decoded)
    print("WORKFLOWGYM_TASK173_SEED_OUTPUT", output, flush=True)
    if "WORKFLOWGYM_TASK173_PRODUCT_READY" not in output:
        raise AssertionError("构造 image_hash.txt 失败: %s" % output[-1000:])


def ensure_instance_running(env: VolcengineEnv, instance_id: str) -> None:
    instance = env.describe_instance(instance_id)
    status = str(instance.get("Status") or instance.get("status") or "").upper()
    if status == "STOPPING":
        env.wait_for_status(instance_id, "STOPPED", timeout_seconds=600)
        status = "STOPPED"
    if status == "STOPPED":
        env.start_instance(instance_id)
    if status not in ("RUNNING",):
        env.wait_for_status(instance_id, "RUNNING", timeout_seconds=600)


class Task173Sampler(Sampler):
    def collect_and_record_outputs(self, job: SampleJob, sample_dir: str, context, state) -> None:
        if job.lease and state.env_metadata.get("desktop_ready_at"):
            seed_task173_product(self.env, job.lease.instance_id)
        else:
            print("WORKFLOWGYM_TASK173_SKIP_SEED reason=env_not_ready", flush=True)
        super().collect_and_record_outputs(job, sample_dir, context, state)


load_zshrc_env()


@unittest.skipUnless(
    os.getenv("WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS") == "1",
    "set WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS=1 to run real Volcengine E2E",
)
class Task173E2ETest(unittest.TestCase):
    """任务 173：启动实例 -> 采样 1 步 -> 构造 image_hash.txt -> collect_outputs -> 判分。"""

    def setUp(self):
        self.instance_id = read_env("WORKFLOWGYM_TEST_INSTANCE_ID", DEFAULT_INSTANCE_ID)
        self.region = read_env("VOLCENGINE_REGION", read_env("SOURCE_REGION", "cn-guangzhou"))
        self.output_root = read_env(
            "WORKFLOWGYM_TASK173_E2E_OUTPUT_ROOT",
            default_task173_e2e_output_root(),
        )
        self.env = VolcengineEnv(region=self.region)

    def tearDown(self):
        # 采样流程中的 cleanup_public_ip_binding 会负责解绑 EIP，这里不再重复操作。
        return

    def test_task173_sample_one_step_seed_product_and_score(self):
        self.assertTrue(read_env("AK") and read_env("SK"), "set AK/SK for Volcengine")
        moonshot_key = read_env("MOONSHOT_API_KEY") or read_env("KIMI_API_KEY") or read_env("KIMI_NATIVE_API_KEY")
        self.assertTrue(moonshot_key, "set MOONSHOT_API_KEY or KIMI_API_KEY for kimi sampling")

        print("WORKFLOWGYM_TEST_INSTANCE", self.instance_id, flush=True)
        print("WORKFLOWGYM_TASK173_OUTPUT_ROOT", self.output_root, flush=True)

        ensure_instance_running(self.env, self.instance_id)

        job = build_task173_sample_job(instance_id=self.instance_id, output_root=self.output_root)
        sampler = Task173Sampler(AgentFactory(), self.env)
        trajectory = sampler.run_sample(job)

        print("WORKFLOWGYM_TASK173_SAMPLE_STATUS", trajectory.status, flush=True)
        print("WORKFLOWGYM_TASK173_LAST_STEP", trajectory.last_step, flush=True)
        print("WORKFLOWGYM_TASK173_OUTPUT_UPLOADS", trajectory.task_files.output_uploads, flush=True)

        self.assertEqual(trajectory.last_step, 0)
        self.assertNotEqual(trajectory.status, "sample_failed", trajectory.error)
        self.assertTrue(Path(trajectory.traj_json_path).is_file())
        sample_dir = Path(trajectory.sample_dir)
        self.assertTrue(
            (sample_dir / "step_0.jpg").is_file() or (sample_dir / "env_ready.jpg").is_file(),
            "采样目录应至少有一张截图",
        )
        self.assertEqual(trajectory.task_files.final_answer_files, [TASK_FINAL_ANSWER])
        self.assertEqual(len(trajectory.task_files.output_uploads), 1)

        upload = trajectory.task_files.output_uploads[0]
        self.assertTrue(upload.get("output_file_exists"), upload)
        self.assertEqual(upload.get("status"), "uploaded", upload)
        self.assertTrue(str(upload.get("tos_url", "")).startswith("https://"), upload)
        self.assertEqual(upload.get("source_path"), "/home/user/Desktop/output/image_hash.txt")

        if read_env("WORKFLOWGYM_MOCK_JUDGER", "0").lower() in {"1", "true", "yes", "on"}:
            with patch(
                "open_workflowgym.judgers.file_product.FileProductJudgerMixin.judge_file_contents",
                return_value={
                    "answer_score": 1,
                    "error": "NA",
                    "evidence": "image_hash.txt 包含 bg2.jpg 的 MD5",
                    "raw_response": '{"answer_score": 1}',
                },
            ):
                score = Scorer().score(trajectory)
        else:
            score = Scorer().score(trajectory)

        print("WORKFLOWGYM_TASK173_SCORE", score.check, flush=True)
        score_payload = json.loads(Path(score.score_json_path).read_text(encoding="utf-8"))
        self.assertEqual(score.check.get("answer_score"), 1, score_payload)
        self.assertNotIn("读取失败", str(score.check.get("evidence", "")))
        production_path = sample_dir / "production" / TASK_FINAL_ANSWER
        self.assertTrue(production_path.is_file(), "LLM 判分应落盘 production/")
        self.assertTrue(score.check.get("production_snapshots", [{}])[0].get("production_saved"))
        gt_production_path = sample_dir / "gt_production" / TASK_FINAL_ANSWER
        self.assertTrue(gt_production_path.is_file(), "应从数据集 final answer 文件 落盘 gt_production/")
        self.assertTrue(score.check.get("production_snapshots", [{}])[0].get("gt_production_saved"))

        report = maybe_write_e2e_sample_to_spreadsheet(
            output_root=self.output_root,
            trajectory=trajectory,
            score=score,
        )
        if report is not None:
            self.assertTrue(Path(report["local_samples_csv"]).is_file())
            print("WORKFLOWGYM_TASK173_SPREADSHEET", report, flush=True)


if __name__ == "__main__":
    unittest.main()
