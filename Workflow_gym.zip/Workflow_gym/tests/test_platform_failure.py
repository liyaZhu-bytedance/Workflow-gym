from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.envs.instance_pool import InstancePool
from open_workflowgym.judgers.agent import JudgerAgent
from open_workflowgym.judgers.common import ERROR_SCORE
from open_workflowgym.platform_failure import (
    PLATFORM_MATCH_UNAVAILABLE,
    PLATFORM_MISMATCH_EXHAUSTED,
    is_platform_mismatch_failure,
    write_platform_failure_artifacts,
)
from open_workflowgym.records import InstanceLease, RunConfig, TaskRecord, TrajectoryResult
from open_workflowgym.scheduler import Scheduler
from open_workflowgym.scorer import Scorer
from open_workflowgym.state_store import StateStore
from open_workflowgym.states import SampleStatus


class PlatformFailureTest(unittest.TestCase):
    def test_is_platform_mismatch_failure_from_error_text(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            sample_dir = str(Path(tmp_dir) / "sample_1")
            Path(sample_dir).mkdir(parents=True)
            mismatch = TrajectoryResult(
                run_id="run",
                task_id="42",
                sample_index=1,
                status=SampleStatus.SAMPLE_FAILED.value,
                sample_dir=sample_dir,
                traj_json_path=str(Path(sample_dir) / "traj.json"),
                traj_md_path=str(Path(sample_dir) / "traj.md"),
                id_json_path=str(Path(sample_dir) / "sample_metadata.json"),
                sample_status_path=str(Path(sample_dir) / "sample_status.json"),
                error="实例 i-bad 平台=ubuntu 与目标镜像 img-win 平台=windows 不一致，跳过换盘并停止采样。",
            )
            self.assertTrue(is_platform_mismatch_failure(mismatch))

    def test_platform_failure_judger_evidence(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            record = TaskRecord(
                run_id="run",
                task_id="42",
                row_number=2,
                fields={"系统类型": "Windows", "image": "img-win"},
            )
            trajectory = write_platform_failure_artifacts(
                record=record,
                sample_index=1,
                sample_dir=tmp_dir,
                reason=PLATFORM_MATCH_UNAVAILABLE,
                required_platform="windows",
            )
            result = JudgerAgent().judge(trajectory)
            self.assertEqual(result["answer_score"], ERROR_SCORE)
            self.assertIn("平台匹配失败", result["evidence"])
            self.assertIn("no_matching_instance", result["evidence"])

    def test_finish_platform_failure_sample_writes_score(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            store = StateStore(str(Path(tmp_dir) / "state.db"))
            pool = InstancePool(["i-ubuntu"], store, {"i-ubuntu": "ubuntu"})
            config = RunConfig(
                run_id="run",
                output_root=str(Path(tmp_dir) / "output"),
                state_db_path=str(Path(tmp_dir) / "state.db"),
            )
            scheduler = Scheduler(
                config=config,
                store=store,
                instance_pool=pool,
                executor=mock.Mock(supports_async=False),
                writer=mock.Mock(),
                scorer=Scorer(),
                agent_factory=mock.Mock(),
            )
            record = TaskRecord(
                run_id="run",
                task_id="42",
                row_number=2,
                fields={"系统类型": "Windows", "image": "img-win"},
            )
            ok = scheduler.finish_platform_failure_sample(
                record,
                1,
                reason=PLATFORM_MATCH_UNAVAILABLE,
                required_platform="windows",
            )
            self.assertTrue(ok)
            score_path = Path(tmp_dir) / "output" / "42" / "sample_1" / "score.json"
            self.assertTrue(score_path.exists())
            payload = json.loads(score_path.read_text(encoding="utf-8"))
            self.assertEqual(payload["check"]["answer_score"], ERROR_SCORE)
            self.assertIn("平台匹配失败", payload["check"]["evidence"])

    def test_handle_platform_mismatch_retries_other_instance(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            store = StateStore(str(Path(tmp_dir) / "state.db"))
            pool = InstancePool(
                ["i-ubuntu-bad", "i-ubuntu-good"],
                store,
                {"i-ubuntu-bad": "ubuntu", "i-ubuntu-good": "ubuntu"},
            )
            config = RunConfig(
                run_id="run",
                output_root=str(Path(tmp_dir) / "output"),
                state_db_path=str(Path(tmp_dir) / "state.db"),
            )
            sample_dir = str(Path(tmp_dir) / "output" / "42" / "sample_1")
            Path(sample_dir).mkdir(parents=True)
            bad_trajectory = TrajectoryResult(
                run_id="run",
                task_id="42",
                sample_index=1,
                status=SampleStatus.SAMPLE_FAILED.value,
                sample_dir=sample_dir,
                traj_json_path=str(Path(sample_dir) / "traj.json"),
                traj_md_path=str(Path(sample_dir) / "traj.md"),
                id_json_path=str(Path(sample_dir) / "sample_metadata.json"),
                sample_status_path=str(Path(sample_dir) / "sample_status.json"),
                error="实例 i-ubuntu-bad 平台=ubuntu 与目标镜像 img-win 平台=windows 不一致，跳过换盘并停止采样。",
            )
            Path(sample_dir, "exception.json").write_text(
                json.dumps(
                    [
                        {
                            "exception_type": "CloudAssistantPlatformMismatchError",
                            "instance_id": "i-ubuntu-bad",
                            "instance_platform": "ubuntu",
                            "expected_platform": "windows",
                        }
                    ]
                ),
                encoding="utf-8",
            )
            good_trajectory = TrajectoryResult(
                run_id="run",
                task_id="42",
                sample_index=1,
                status=SampleStatus.SAMPLE_COMPLETED.value,
                sample_dir=sample_dir,
                traj_json_path=str(Path(sample_dir) / "traj.json"),
                traj_md_path=str(Path(sample_dir) / "traj.md"),
                id_json_path=str(Path(sample_dir) / "sample_metadata.json"),
                sample_status_path=str(Path(sample_dir) / "sample_status.json"),
                last_step=1,
            )
            executor = mock.Mock()
            executor.submit_sample.return_value = good_trajectory
            scheduler = Scheduler(
                config=config,
                store=store,
                instance_pool=pool,
                executor=executor,
                writer=mock.Mock(),
                scorer=mock.Mock(),
                agent_factory=mock.Mock(),
            )
            scheduler.finish_trajectory = mock.Mock(return_value=True)
            lease_bad = InstanceLease(
                run_id="run",
                lease_id="lease-bad",
                instance_id="i-ubuntu-bad",
                task_id="42",
                sample_index=1,
                status="leased",
                acquired_at="2026-07-15 18:00:00",
                expires_at="2026-07-15 19:00:00",
            )
            pool.lease_backend._leases_by_instance["i-ubuntu-bad"] = lease_bad
            record = TaskRecord(
                run_id="run",
                task_id="42",
                row_number=2,
                fields={"系统类型": "ubuntu", "image": "img-win"},
            )
            ok = scheduler.handle_platform_mismatch_trajectory(
                record,
                1,
                lease_bad,
                SampleStatus.SAMPLING.value,
                bad_trajectory,
                set(),
            )
            self.assertTrue(ok)
            executor.submit_sample.assert_called_once()
            scheduler.finish_trajectory.assert_called_once()
            self.assertEqual(scheduler.finish_trajectory.call_args.args[2].instance_id, "i-ubuntu-good")

    def test_handle_platform_mismatch_exhausted_scores_failure(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            store = StateStore(str(Path(tmp_dir) / "state.db"))
            pool = InstancePool(["i-ubuntu-bad"], store, {"i-ubuntu-bad": "ubuntu"})
            config = RunConfig(
                run_id="run",
                output_root=str(Path(tmp_dir) / "output"),
                state_db_path=str(Path(tmp_dir) / "state.db"),
            )
            sample_dir = str(Path(tmp_dir) / "output" / "42" / "sample_1")
            Path(sample_dir).mkdir(parents=True)
            bad_trajectory = TrajectoryResult(
                run_id="run",
                task_id="42",
                sample_index=1,
                status=SampleStatus.SAMPLE_FAILED.value,
                sample_dir=sample_dir,
                traj_json_path=str(Path(sample_dir) / "traj.json"),
                traj_md_path=str(Path(sample_dir) / "traj.md"),
                id_json_path=str(Path(sample_dir) / "sample_metadata.json"),
                sample_status_path=str(Path(sample_dir) / "sample_status.json"),
                error="实例 i-ubuntu-bad 平台=ubuntu 与目标镜像 img-win 平台=windows 不一致，跳过换盘并停止采样。",
            )
            Path(sample_dir, "exception.json").write_text(
                json.dumps(
                    [
                        {
                            "exception_type": "CloudAssistantPlatformMismatchError",
                            "instance_id": "i-ubuntu-bad",
                            "instance_platform": "ubuntu",
                            "expected_platform": "windows",
                        }
                    ]
                ),
                encoding="utf-8",
            )
            scheduler = Scheduler(
                config=config,
                store=store,
                instance_pool=pool,
                executor=mock.Mock(),
                writer=mock.Mock(),
                scorer=Scorer(),
                agent_factory=mock.Mock(),
            )
            lease_bad = InstanceLease(
                run_id="run",
                lease_id="lease-bad",
                instance_id="i-ubuntu-bad",
                task_id="42",
                sample_index=1,
                status="leased",
                acquired_at="2026-07-15 18:00:00",
                expires_at="2026-07-15 19:00:00",
            )
            pool.lease_backend._leases_by_instance["i-ubuntu-bad"] = lease_bad
            record = TaskRecord(
                run_id="run",
                task_id="42",
                row_number=2,
                fields={"系统类型": "ubuntu", "image": "img-win"},
            )
            ok = scheduler.handle_platform_mismatch_trajectory(
                record,
                1,
                lease_bad,
                SampleStatus.SAMPLING.value,
                bad_trajectory,
                set(),
            )
            self.assertTrue(ok)
            score_path = Path(sample_dir) / "score.json"
            self.assertTrue(score_path.exists())
            payload = json.loads(score_path.read_text(encoding="utf-8"))
            self.assertEqual(payload["check"]["answer_score"], ERROR_SCORE)
            self.assertIn("platform_mismatch_exhausted", payload["check"]["evidence"])


if __name__ == "__main__":
    unittest.main()
