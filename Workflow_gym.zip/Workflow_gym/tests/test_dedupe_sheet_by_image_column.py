from __future__ import annotations

import unittest

from open_workflowgym.tools.dedupe_sheet_by_image_column import dedupe_rows_by_image_column


class DedupeSheetByImageColumnTests(unittest.TestCase):
    def test_keeps_header_and_first_unique_image_rows(self) -> None:
        rows = [
            ["id", "name", "image"],
            ["1", "task-a", "image-1"],
            ["2", "task-b", "image-2"],
            ["3", "task-c", "image-1"],
            ["4", "task-d", ""],
            ["5", "task-e", "image-3"],
            ["6", "task-f", "image-2"],
        ]
        output_rows, duplicate_count, skipped_empty_count = dedupe_rows_by_image_column(
            rows,
            image_column_index=2,
        )
        self.assertEqual(
            output_rows,
            [
                ["id", "name", "image"],
                ["1", "task-a", "image-1"],
                ["2", "task-b", "image-2"],
                ["5", "task-e", "image-3"],
            ],
        )
        self.assertEqual(duplicate_count, 2)
        self.assertEqual(skipped_empty_count, 1)


if __name__ == "__main__":
    unittest.main()
