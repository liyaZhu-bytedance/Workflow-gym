from __future__ import annotations

import json
import os
import re
import shlex
import subprocess
import sys
import time
import unittest
import warnings
from pathlib import Path

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.envs.volcengine_env import (
    RUN_COMMAND_MAX_CONTENT_BYTES,
    VolcengineEnv,
    build_ubuntu_flask_health_runcmd_python_command,
    build_ubuntu_flask_post_python_action_runcmd_python_command,
    build_ubuntu_interactive_flask_runner_setup_command,
    command_decoded_output,
    ubuntu_flask_exec_timeout_seconds,
    ubuntu_flask_runner_port,
    ubuntu_flask_runner_token,
    validate_run_command_payload,
)
from open_workflowgym.agents.pyautogui_actions import build_pyautogui_python_script

TARGET_INSTANCE_ID = "i-yeqjzn0lj4h2cbelplns"
DEFAULT_REGION = "cn-guangzhou"
DEFAULT_FLASK_RUNNER_PORT = 80
ZSHRC_ENV_NAMES = ("AK", "SK", "VOLCENGINE_REGION", "SOURCE_REGION", "WORKFLOWGYM_FLASK_RUNNER_TOKEN")


def read_env(name: str, default: str = "") -> str:
    return os.getenv(name, default)


def load_zshrc_env(names: tuple[str, ...] = ZSHRC_ENV_NAMES, zshrc_path: str = "") -> None:
    missing = [name for name in names if not read_env(name)]
    if not missing:
        return
    zshrc = Path(zshrc_path or os.path.expanduser("~/.zshrc"))
    if not zshrc.is_file():
        return
    zshrc_quoted = shlex.quote(str(zshrc))
    for name in missing:
        try:
            completed = subprocess.run(
                ["zsh", "-lc", "source %s >/dev/null 2>&1; print -r -- ${%s:-}" % (zshrc_quoted, name)],
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        value = (completed.stdout or "").strip()
        if value:
            os.environ[name] = value


def parse_flask_health_payload(output: str) -> dict:
    marker = "WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_HEALTH"
    for line in output.splitlines():
        if marker not in line:
            continue
        json_part = line.split(marker, 1)[-1].strip()
        match = re.search(r"\{.*\}", json_part)
        if not match:
            continue
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            continue
    return {}


def pyautogui_probe_script() -> str:
    return """import pyautogui

pyautogui.FAILSAFE = False
width, height = pyautogui.size()
print("PYAUTOGUI_UBUNTU_RUNCMD_PYTHON_HTTP_SIZE", (int(width), int(height)))
center_x, center_y = int(width // 2), int(height // 2)
pyautogui.moveTo(center_x, center_y, duration=0.1)
print("PYAUTOGUI_UBUNTU_RUNCMD_PYTHON_HTTP_MOVE", (center_x, center_y))
print("PYAUTOGUI_UBUNTU_RUNCMD_PYTHON_HTTP_DONE")
"""


def netstat_port80_terminal_script() -> str:
    action_code = """import time

width, height = pyautogui.size()
print("WORKFLOWGYM_TERMINAL_STEP_SCREEN", (int(width), int(height)))

rx, ry = int(width * 0.30), int(height * 0.78)
pyautogui.click(rx, ry, button="right")
print("WORKFLOWGYM_TERMINAL_STEP_RIGHT_CLICK", (rx, ry))
time.sleep(1.0)

for _ in range(3):
    pyautogui.press("down")
    time.sleep(0.15)
pyautogui.press("enter")
print("WORKFLOWGYM_TERMINAL_STEP_OPEN_TERMINAL_MENU")
time.sleep(2.0)

if not activate_linux_window("gnome-terminal"):
    print("WORKFLOWGYM_TERMINAL_STEP_FALLBACK_HOTKEY")
    pyautogui.hotkey("ctrl", "alt", "t")
    time.sleep(2.0)
    activate_linux_window("gnome-terminal")

command = "netstat -tuln | grep ':80 ' || netstat -tuln | grep ':80'"
pyautogui.write(command, interval=0.02)
pyautogui.press("enter")
time.sleep(2.5)
print("WORKFLOWGYM_NETSTAT_COMMAND", command)
print("WORKFLOWGYM_NETSTAT_DONE")
"""
    return build_pyautogui_python_script(action_code, platform="ubuntu")


load_zshrc_env()


class UbuntuRunCommandPythonHttpE2ETest(unittest.TestCase):
    """E2E: RunCommand(Type=Python) sends GET/POST to local Flask runner."""

    def setUp(self):
        load_zshrc_env()
        os.environ.setdefault("PIP_INDEX_URL", "https://mirrors.ivolces.com/pypi/simple/")
        os.environ.setdefault("PIP_TRUSTED_HOST", "mirrors.ivolces.com")
        self.assertTrue(read_env("AK") and read_env("SK"), "AK/SK missing")
        self.instance_id = read_env("WORKFLOWGYM_TEST_INSTANCE_ID", TARGET_INSTANCE_ID)
        self.region = read_env("VOLCENGINE_REGION", read_env("SOURCE_REGION", DEFAULT_REGION))
        self.flask_token = read_env("WORKFLOWGYM_FLASK_RUNNER_TOKEN", ubuntu_flask_runner_token())
        self.flask_port = int(read_env("UBUNTU_FLASK_RUNNER_PORT", str(ubuntu_flask_runner_port() or DEFAULT_FLASK_RUNNER_PORT)))
        self.flask_exec_timeout = ubuntu_flask_exec_timeout_seconds()
        self.flask_http_timeout = max(30, self.flask_exec_timeout + 15)
        self.output_dir = Path(
            read_env(
                "WORKFLOWGYM_UBUNTU_RUNCMD_PYTHON_HTTP_OUTPUT_DIR",
                "output/manual_ubuntu_runcmd_python_http_e2e",
            )
        )
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.env = VolcengineEnv(region=self.region)
        self.desktop_metadata: dict[str, str] = {}

    def resolve_desktop_session(self) -> dict[str, str]:
        if self.desktop_metadata:
            return self.desktop_metadata
        sample_dir = str(self.output_dir / "env_probe")
        metadata = self.env.prepare_desktop_for_pyautogui(self.instance_id, sample_dir=sample_dir)
        self.desktop_metadata = {
            "desktop_user": str(metadata.get("desktop_user") or "user"),
            "desktop_home": str(metadata.get("desktop_home") or "/home/user"),
            "display": str(metadata.get("display") or ":0"),
            "xauthority": str(metadata.get("xauthority") or ""),
        }
        self.assertTrue(self.desktop_metadata["xauthority"], "missing xauthority")
        print("WORKFLOWGYM_UBUNTU_DESKTOP_METADATA", self.desktop_metadata, flush=True)
        return self.desktop_metadata

    def runner_log_path(self) -> str:
        desktop_home = str(self.desktop_metadata.get("desktop_home") or "/home/user").rstrip("/")
        return "%s/.workflowgym/workflowgym_interactive_flask_runner.log" % desktop_home

    def run_flask_setup(self) -> str:
        desktop = self.resolve_desktop_session()
        setup_result = self.env.run_command(
            self.instance_id,
            build_ubuntu_interactive_flask_runner_setup_command(
                desktop["desktop_user"],
                desktop["desktop_home"],
                desktop["display"],
                desktop["xauthority"],
                self.flask_token,
                self.flask_port,
            ),
            timeout=int(read_env("UBUNTU_FLASK_RUNNER_SETUP_TIMEOUT_SECONDS", "300")),
            command_type="Shell",
        )
        setup_output = command_decoded_output(setup_result)
        print("WORKFLOWGYM_UBUNTU_FLASK_RUNNER_SETUP_OUTPUT", setup_output, flush=True)
        self.assertIn("WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_STARTED", setup_output)
        self.assertIn("WORKFLOWGYM_PROBE_FLASK_RUNNER_OK", setup_output)
        return setup_output

    def run_health_via_runcmd_python(self) -> str:
        command = build_ubuntu_flask_health_runcmd_python_command(
            self.flask_port,
            self.flask_token,
            self.flask_http_timeout,
            log_path=self.runner_log_path(),
        )
        validate_run_command_payload(command, "Python")
        print(
            "WORKFLOWGYM_RUNCMD_PYTHON_HEALTH_BYTES",
            len(command.encode("utf-8")),
            "limit",
            RUN_COMMAND_MAX_CONTENT_BYTES,
            flush=True,
        )
        probe_result = self.env.run_command(
            self.instance_id,
            command,
            timeout=max(self.flask_http_timeout + 30, 90),
            command_type="Python",
        )
        probe_output = command_decoded_output(probe_result)
        print("WORKFLOWGYM_UBUNTU_RUNCMD_PYTHON_HEALTH_OUTPUT", probe_output, flush=True)
        self.assertIn("WORKFLOWGYM_RUNCOMMAND_IDENTITY", probe_output)
        self.assertIn("WORKFLOWGYM_PROBE_FLASK_RUNNER_OK", probe_output)
        return probe_output

    def run_action_via_runcmd_python(self, script: str) -> str:
        command = build_ubuntu_flask_post_python_action_runcmd_python_command(
            script,
            self.flask_port,
            self.flask_token,
            self.flask_http_timeout,
            log_path=self.runner_log_path(),
        )
        validate_run_command_payload(command, "Python")
        print(
            "WORKFLOWGYM_RUNCMD_PYTHON_ACTION_BYTES",
            len(command.encode("utf-8")),
            "limit",
            RUN_COMMAND_MAX_CONTENT_BYTES,
            flush=True,
        )
        action_result = self.env.run_command(
            self.instance_id,
            command,
            timeout=max(self.flask_http_timeout + 30, 90),
            command_type="Python",
        )
        action_output = command_decoded_output(action_result)
        print("WORKFLOWGYM_UBUNTU_RUNCMD_PYTHON_ACTION_OUTPUT", action_output, flush=True)
        self.assertIn("WORKFLOWGYM_RUNCOMMAND_IDENTITY", action_output)
        self.assertIn("WORKFLOWGYM_FLASK_AGENT_RESULT", action_output)
        return action_output

    def save_screenshot(self, name: str) -> str:
        screenshot = self.env.get_console_screenshot(self.instance_id)
        self.assertTrue(screenshot, "GetConsoleScreenshot returned empty payload")
        path = self.output_dir / name
        path.write_bytes(screenshot)
        return str(path)

    def test_ubuntu_runcmd_python_http_runner_pyautogui_e2e(self):
        print("WORKFLOWGYM_TEST_INSTANCE", self.instance_id, flush=True)
        print("WORKFLOWGYM_REGION", self.region, flush=True)
        print("WORKFLOWGYM_UBUNTU_FLASK_PORT", self.flask_port, flush=True)

        self.env.ensure_cloud_assistant_ready(self.instance_id)
        before = self.save_screenshot("before_runcmd_python_http.jpg")
        print("WORKFLOWGYM_SCREENSHOT_BEFORE", before, flush=True)

        self.run_flask_setup()
        time.sleep(int(read_env("UBUNTU_FLASK_RUNNER_SETTLE_SECONDS", "3")))

        probe_output = self.run_health_via_runcmd_python()
        health_payload = parse_flask_health_payload(probe_output)
        print("WORKFLOWGYM_UBUNTU_FLASK_HEALTH_PAYLOAD", health_payload, flush=True)
        self.assertTrue(health_payload.get("ok"), health_payload)
        self.assertEqual(health_payload.get("runner"), "flask")
        screen_size = health_payload.get("screen_size") or []
        self.assertEqual(len(screen_size), 2, "expected desktop screen_size from /health")

        action_output = self.run_action_via_runcmd_python(pyautogui_probe_script())
        self.assertIn("PYAUTOGUI_UBUNTU_RUNCMD_PYTHON_HTTP_SIZE", action_output)
        self.assertIn("PYAUTOGUI_UBUNTU_RUNCMD_PYTHON_HTTP_MOVE", action_output)
        self.assertIn("PYAUTOGUI_UBUNTU_RUNCMD_PYTHON_HTTP_DONE", action_output)

        netstat_output = self.run_action_via_runcmd_python(
            netstat_port80_terminal_script(),
        )
        self.assertIn("WORKFLOWGYM_TERMINAL_STEP_RIGHT_CLICK", netstat_output)
        self.assertIn("WORKFLOWGYM_TERMINAL_STEP_OPEN_TERMINAL_MENU", netstat_output)
        self.assertIn("WORKFLOWGYM_NETSTAT_COMMAND", netstat_output)
        self.assertIn("WORKFLOWGYM_NETSTAT_DONE", netstat_output)
        self.assertTrue(
            "tcp" in netstat_output.lower() or "80" in netstat_output,
            "expected netstat output to mention tcp or port 80: %s" % netstat_output[-2000:],
        )

        after_netstat = self.save_screenshot("after_netstat_port80_terminal.jpg")
        print("WORKFLOWGYM_SCREENSHOT_AFTER_NETSTAT", after_netstat, flush=True)

        after = self.save_screenshot("after_runcmd_python_http.jpg")
        print("WORKFLOWGYM_SCREENSHOT_AFTER", after, flush=True)


if __name__ == "__main__":
    unittest.main()
