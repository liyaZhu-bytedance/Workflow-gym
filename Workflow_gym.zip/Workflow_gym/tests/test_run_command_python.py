from __future__ import annotations

import base64
import os
import subprocess
import time
import unittest
import warnings

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

import volcenginesdkcore
import volcenginesdkecs


DEFAULT_INSTANCE_ID = "i-yepu8vh7nkt56ongwkqb"
CURRENT_PYTHON_RUNCOMMAND_INSTANCE_ID = "i-yeq4neypkwuo7budzfbg"


def read_system_env(name: str) -> str:
    value = os.getenv(name)
    if value:
        return value
    try:
        return subprocess.check_output(["launchctl", "getenv", name], text=True).strip()
    except Exception:
        return ""


def get_result_payload(data):
    return data.get("Result") or data.get("result") or data


def to_plain_dict(value):
    if hasattr(value, "to_dict"):
        return value.to_dict()
    if isinstance(value, dict):
        return value
    return dict(value)


def maybe_decode_output(output):
    if not output:
        return output
    try:
        return base64.b64decode(output, validate=True).decode("utf-8")
    except Exception:
        return output


def print_command_result(invocation_name, command_content, invocation_results):
    print("命令执行结果: %s" % invocation_name)
    print("执行命令:")
    print(command_content)
    for item in invocation_results:
        status = item.get("InvocationResultStatus") or item.get("invocation_result_status")
        exit_code = item.get("ExitCode")
        if exit_code is None:
            exit_code = item.get("exit_code")
        error_code = item.get("ErrorCode") or item.get("error_code")
        error_message = item.get("ErrorMessage") or item.get("error_message")
        output = item.get("decoded_output")
        if output is None:
            output = maybe_decode_output(item.get("Output") or item.get("output"))

        print("实例: %s" % (item.get("InstanceId") or item.get("instance_id")))
        print("状态: %s" % status)
        print("退出码: %s" % exit_code)
        if error_code:
            print("错误码: %s" % error_code)
        if error_message:
            print("错误信息: %s" % error_message)
        print("输出:")
        print(output if output else "<无输出>")


def cloud_assistant_status_value(status):
    if not status:
        return ""
    return str(status.get("Status") or status.get("status") or "")


def cloud_assistant_ready(status):
    return cloud_assistant_status_value(status).lower() in {
        "online",
        "running",
        "available",
        "normal",
    }


def cloud_assistant_needs_reboot(status):
    return cloud_assistant_status_value(status).lower() == "readyreboot"


class RunCommandPythonTest(unittest.TestCase):
    def setUp(self):
        ak = read_system_env("AK")
        sk = read_system_env("SK")
        if not ak or not sk:
            self.skipTest("需要设置 AK/SK 环境变量才会执行真实 RunCommand 测试")
        configuration = volcenginesdkcore.Configuration()
        configuration.ak = ak
        configuration.sk = sk
        configuration.region = read_system_env("VOLCENGINE_REGION") or read_system_env("SOURCE_REGION") or "cn-guangzhou"
        volcenginesdkcore.Configuration.set_default(configuration)
        self.api = volcenginesdkecs.ECSApi()
        self.instance_id = read_system_env("RUNCOMMAND_TEST_INSTANCE_ID") or DEFAULT_INSTANCE_ID

    def describe_cloud_assistant_status(self):
        request = volcenginesdkecs.DescribeCloudAssistantStatusRequest(
            instance_ids=[self.instance_id],
        )
        response = self.api.describe_cloud_assistant_status(request)
        result = get_result_payload(to_plain_dict(response))
        instances = result.get("Instances") or result.get("instances") or []
        for item in instances:
            item_id = item.get("InstanceId") or item.get("instance_id")
            if item_id == self.instance_id:
                return item
        return None

    def ensure_cloud_assistant_ready(self):
        status = self.describe_cloud_assistant_status()
        if cloud_assistant_ready(status):
            return status or {}
        if cloud_assistant_needs_reboot(status):
            raise RuntimeError("Cloud Assistant 已安装但需要重启实例后才能使用: instance_id=%s" % self.instance_id)
        if status is None:
            print("Cloud Assistant 未注册，开始安装: instance_id=%s" % self.instance_id)
            request = volcenginesdkecs.InstallCloudAssistantRequest(
                instance_ids=[self.instance_id],
            )
            self.api.install_cloud_assistant(request)
        else:
            print(
                "Cloud Assistant 尚未可用，等待状态恢复: instance_id=%s status=%s"
                % (self.instance_id, cloud_assistant_status_value(status))
            )

        timeout_seconds = int(read_system_env("CLOUD_ASSISTANT_WAIT_TIMEOUT_SECONDS") or "300")
        poll_interval_seconds = int(read_system_env("CLOUD_ASSISTANT_POLL_INTERVAL_SECONDS") or "10")
        deadline = time.time() + timeout_seconds
        last_status = status
        while time.time() < deadline:
            time.sleep(poll_interval_seconds)
            last_status = self.describe_cloud_assistant_status()
            if cloud_assistant_ready(last_status):
                print("Cloud Assistant 已可用: instance_id=%s" % self.instance_id)
                return last_status or {}
            if cloud_assistant_needs_reboot(last_status):
                raise RuntimeError("Cloud Assistant 已安装但需要重启实例后才能使用: instance_id=%s" % self.instance_id)
        raise TimeoutError("等待 Cloud Assistant 可用超时: instance_id=%s status=%s" % (self.instance_id, last_status))

    def run_command_and_wait(self, invocation_name, command_content, command_type="Python", timeout=60, wait_seconds=120):
        self.ensure_cloud_assistant_ready()
        request = volcenginesdkecs.RunCommandRequest(
            command_content=command_content,
            content_encoding="PlainText",
            instance_ids=[self.instance_id],
            invocation_name=invocation_name,
            timeout=timeout,
            type=command_type,
            working_dir="/home",
        )
        response = self.api.run_command(request)
        result = get_result_payload(to_plain_dict(response))
        invocation_id = result.get("InvocationId") or result.get("invocation_id")
        self.assertTrue(invocation_id)

        deadline = time.time() + wait_seconds
        while time.time() < deadline:
            time.sleep(5)
            results_request = volcenginesdkecs.DescribeInvocationResultsRequest(
                invocation_id=invocation_id,
                instance_id=self.instance_id,
                page_number=1,
                page_size=10,
            )
            results_response = self.api.describe_invocation_results(results_request)
            results_payload = get_result_payload(to_plain_dict(results_response))
            invocation_results = results_payload.get("InvocationResults") or results_payload.get("invocation_results") or []
            if not invocation_results:
                continue
            item = invocation_results[0]
            status = item.get("InvocationResultStatus") or item.get("invocation_result_status")
            exit_code = item.get("ExitCode")
            if exit_code is None:
                exit_code = item.get("exit_code")
            if status in ("Pending", "Running"):
                continue
            print_command_result(invocation_name, command_content, invocation_results)
            self.assertEqual(status, "Success")
            self.assertEqual(exit_code, 0)
            return invocation_results
        self.fail("等待 RunCommand Python 测试结果超时: %s" % invocation_id)

    def test_run_python_command(self):
        command_content = '#!/usr/bin/python\nprint("nihao")'
        self.run_command_and_wait("test_python", command_content)

    def test_run_python_command_direct_on_current_instance(self):
        self.instance_id = (
            read_system_env("RUNCOMMAND_PYTHON_INSTANCE_ID")
            or CURRENT_PYTHON_RUNCOMMAND_INSTANCE_ID
        )
        command_content = "\n".join([
            "#!/usr/bin/python",
            "import os",
            "import platform",
            "print('RUNCOMMAND_PYTHON_DIRECT_OK')",
            "print('python_executable=%s' % os.sys.executable)",
            "print('python_version=%s' % platform.python_version())",
        ])
        invocation_results = self.run_command_and_wait(
            "test_python_direct_current_instance",
            command_content,
            command_type="Python",
            timeout=60,
            wait_seconds=120,
        )
        outputs = [
            maybe_decode_output(item.get("Output") or item.get("output") or "")
            for item in invocation_results
        ]
        self.assertTrue(
            any("RUNCOMMAND_PYTHON_DIRECT_OK" in str(output) for output in outputs),
            outputs,
        )

    def test_install_pyautogui_with_shell_command(self):
        command_content = r"""#!/bin/bash
set -euxo pipefail
echo "whoami=$(whoami)"
echo "HOME=${HOME:-}"
export HOME="${HOME:-/root}"
echo "normalized HOME=$HOME"
which python3
python3 --version
python3 -m pip --version || true
python3 -m pip config list || true
env | grep -Ei 'proxy|pip|index' || true

sudo apt-get update
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y python3-tk python3-dev python3-pip xdotool x11-utils
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y python3-pyautogui || true
if [ ! -x /usr/bin/python ]; then
  sudo ln -sf /usr/bin/python3 /usr/bin/python
fi
python3 - <<'PY'
import tkinter
print("tkinter ready:", tkinter.TkVersion)
PY

desktop_user="${DESKTOP_USER:-user}"
desktop_home="${DESKTOP_HOME:-/home/${desktop_user}}"
display="${DESKTOP_DISPLAY:-:0}"
pip_index_url="${PIP_INDEX_URL:-https://mirrors.ivolces.com/pypi/simple/}"
pip_trusted_host="${PIP_TRUSTED_HOST:-mirrors.ivolces.com}"
id "$desktop_user"
echo "desktop_user=$desktop_user"
echo "desktop_home=$desktop_home"
if ! /usr/bin/python -m pip show pyautogui >/dev/null 2>&1; then
  if ! sudo env PIP_INDEX_URL="$pip_index_url" PIP_TRUSTED_HOST="$pip_trusted_host" /usr/bin/python -m pip install --upgrade pyautogui; then
    sudo env PIP_INDEX_URL="$pip_index_url" PIP_TRUSTED_HOST="$pip_trusted_host" PIP_BREAK_SYSTEM_PACKAGES=1 /usr/bin/python -m pip install --upgrade --break-system-packages pyautogui
  fi
fi
/usr/bin/python -m pip show pyautogui

xauthority="${XAUTHORITY:-}"
if [ -z "$xauthority" ]; then
  if [ -f "${desktop_home}/.Xauthority" ]; then
    xauthority="${desktop_home}/.Xauthority"
  else
    xauthority="$(find /home /run/user \( -name ".Xauthority" -o -name "Xauthority" \) 2>/dev/null | head -n 1 || true)"
  fi
fi
echo "DISPLAY=$display"
echo "XAUTHORITY=$xauthority"
ls -la "$desktop_home" || true
if [ -n "$xauthority" ]; then
  ls -la "$xauthority" || true
fi
sudo -H -u "$desktop_user" env DISPLAY="$display" HOME="$desktop_home" XAUTHORITY="$xauthority" /usr/bin/python - <<'PY'
import pyautogui
print("pyautogui ready:", getattr(pyautogui, "__file__", ""))
print("pyautogui version:", getattr(pyautogui, "__version__", "unknown"))
print("screen size:", pyautogui.size())
PY
"""
        self.run_command_and_wait(
            "test_install_pyautogui",
            command_content,
            command_type="Shell",
            timeout=600,
            wait_seconds=720,
        )


if __name__ == "__main__":
    unittest.main()
