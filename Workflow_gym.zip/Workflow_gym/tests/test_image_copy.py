from __future__ import print_function

import os
import time
import unittest
import warnings

warnings.filterwarnings(
    "ignore",
    message="urllib3 v2 only supports OpenSSL.*",
)

import volcenginesdkcore
import volcenginesdkecs
from volcenginesdkcore.rest import ApiException

from main import get_result_payload, to_plain_dict


SOURCE_REGION = os.getenv("SOURCE_REGION", "cn-beijing")
DESTINATION_REGION = os.getenv("DESTINATION_REGION", "cn-guangzhou")
IMAGE_ID = os.getenv("IMAGE_ID", "image-yej26l6jetl6wl14r0q6")
IMAGE_NAME = os.getenv("IMAGE_NAME")
PROJECT_NAME = os.getenv("PROJECT_NAME", "default")
COPY_IMAGE_TAGS = os.getenv("COPY_IMAGE_TAGS", "false").lower() == "true"
TASK_POLL_INTERVAL_SECONDS = int(os.getenv("TASK_POLL_INTERVAL_SECONDS", "30"))
TASK_TIMEOUT_SECONDS = int(os.getenv("TASK_TIMEOUT_SECONDS", "1800"))


def create_api_instance(region):
    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = region
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkecs.ECSApi()


def describe_image(api_instance, image_id):
    request = volcenginesdkecs.DescribeImagesRequest(
        image_ids=[image_id],
    )
    response = api_instance.describe_images(request)
    response_data = to_plain_dict(response)
    result = get_result_payload(response_data)
    images = result.get("Images") or result.get("images") or []
    return images[0] if images else None


def describe_copy_tasks(api_instance, image_id):
    request = volcenginesdkecs.DescribeTasksRequest(
        resource_ids=[image_id],
    )
    response = api_instance.describe_tasks(request)
    response_data = to_plain_dict(response)
    result = get_result_payload(response_data)
    return result.get("Tasks") or result.get("tasks") or []


class TestCopyImage(unittest.TestCase):
    def test_copy_image_to_destination_region(self):
        api_instance = create_api_instance(SOURCE_REGION)
        try:
            source_image = describe_image(api_instance, IMAGE_ID)
        except ApiException as exc:
            self.fail("DescribeImages 调用失败: %s" % exc)

        self.assertTrue(source_image, "源镜像不存在: %s" % IMAGE_ID)
        source_image_name = source_image.get("ImageName") or source_image.get("image_name")
        self.assertTrue(source_image_name, "源镜像信息中没有返回 ImageName")

        destination_image_name = IMAGE_NAME or "%s_bj" % source_image_name
        print("源镜像名称: %s" % source_image_name)
        print("目标镜像名称: %s" % destination_image_name)

        request = volcenginesdkecs.CopyImageRequest(
            copy_image_tags=COPY_IMAGE_TAGS,
            destination_region=DESTINATION_REGION,
            image_id=IMAGE_ID,
            image_name=destination_image_name,
            project_name=PROJECT_NAME,
        )

        try:
            response = api_instance.copy_image(request)
        except ApiException as exc:
            self.fail("CopyImage 调用失败: %s" % exc)

        response_data = to_plain_dict(response)
        result = get_result_payload(response_data)
        copied_image_id = result.get("ImageId") or result.get("image_id")

        self.assertTrue(copied_image_id, "CopyImage 响应中没有返回 ImageId")
        print("镜像复制任务已提交，目标地域: %s" % DESTINATION_REGION)
        print("复制后的 ImageId: %s" % copied_image_id)

        destination_api_instance = create_api_instance(DESTINATION_REGION)
        deadline = time.time() + TASK_TIMEOUT_SECONDS
        last_tasks = []
        while time.time() < deadline:
            try:
                tasks = describe_copy_tasks(destination_api_instance, copied_image_id)
            except ApiException as exc:
                self.fail("DescribeTasks 调用失败: %s" % exc)

            if tasks:
                last_tasks = tasks
                for task in tasks:
                    task_id = task.get("Id") or task.get("id")
                    task_type = task.get("Type") or task.get("type")
                    status = task.get("Status") or task.get("status")
                    process = task.get("Process")
                    if process is None:
                        process = task.get("process")
                    resource_id = task.get("ResourceId") or task.get("resource_id")
                    print(
                        "复制任务进展: id=%s type=%s status=%s process=%s resource=%s"
                        % (task_id, task_type, status, process, resource_id)
                    )

                    if status in ("Failed", "FAILED", "Error", "ERROR"):
                        self.fail("镜像复制任务失败: %s" % task)
                    if status in (
                        "Success",
                        "SUCCESS",
                        "Succeeded",
                        "SUCCEEDED",
                        "Finished",
                        "FINISHED",
                    ) or process == 100:
                        self.assertEqual(resource_id, copied_image_id)
                        return

            time.sleep(TASK_POLL_INTERVAL_SECONDS)

        self.fail("等待镜像复制任务完成超时，最后任务信息: %s" % last_tasks)


if __name__ == "__main__":
    unittest.main()
