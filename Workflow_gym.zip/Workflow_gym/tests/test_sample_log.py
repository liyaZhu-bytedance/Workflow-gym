from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.sample_log import append_sample_log, read_existing_events


class SampleLogTest(unittest.TestCase):
    def test_append_sample_log_keeps_events_in_sample_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            sample_dir = Path(tmpdir) / "258" / "sample_1"

            append_sample_log(
                str(sample_dir),
                "初始化环境开始",
                source="sampler",
                task_id="258",
                sample_index=1,
                line="[2026-07-09 08:32:48] sample trace task_id=258 sample_index=1 初始化环境开始",
            )
            append_sample_log(
                str(sample_dir),
                "准备桌面: instance_id=i-1",
                source="env",
                extra={"instance_id": "i-1"},
            )

            lines = (sample_dir / "sample_log.json").read_text(encoding="utf-8").splitlines()
            payload = [json.loads(line) for line in lines]

        self.assertEqual(len(lines), 2)
        self.assertEqual([item["source"] for item in payload], ["sampler", "env"])
        self.assertEqual(payload[0]["task_id"], "258")
        self.assertEqual(payload[0]["sample_index"], 1)
        self.assertEqual(payload[1]["extra"]["instance_id"], "i-1")

    def test_append_sample_log_migrates_legacy_json_array(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            sample_dir = Path(tmpdir) / "258" / "sample_1"
            sample_dir.mkdir(parents=True)
            path = sample_dir / "sample_log.json"
            path.write_text(json.dumps([{"source": "legacy", "message": "old"}], ensure_ascii=False), encoding="utf-8")

            append_sample_log(str(sample_dir), "new", source="sampler")

            lines = path.read_text(encoding="utf-8").splitlines()
            payload = [json.loads(line) for line in lines]
            read_back = read_existing_events(path)

        self.assertEqual(len(lines), 2)
        self.assertEqual([item["source"] for item in payload], ["legacy", "sampler"])
        self.assertEqual([item["source"] for item in read_back], ["legacy", "sampler"])


if __name__ == "__main__":
    unittest.main()
