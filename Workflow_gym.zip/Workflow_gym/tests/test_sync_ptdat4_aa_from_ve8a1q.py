from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.feishu_client import column_to_number
from open_workflowgym.tools.sync_ptdat4_aa_from_ve8a1q import (
    build_image_id_lookup,
    find_updates,
    parse_image_ids,
)

E_COLUMN_INDEX = column_to_number("E") - 1
Z_COLUMN_INDEX = column_to_number("Z") - 1
AA_COLUMN_INDEX = column_to_number("AA") - 1


class SyncPtdat4AaFromVe8a1qTest(unittest.TestCase):
    def test_parse_image_ids_splits_semicolon(self):
        self.assertEqual(
            parse_image_ids("image-a ; image-b"),
            ["image-a", "image-b"],
        )
        self.assertEqual(parse_image_ids("image-a,image-b"), ["image-a", "image-b"])

    def test_build_image_id_lookup(self):
        source_rows = [
            ["", "", "C", "", "E"],
            ["", "", "image-a", "", "export-a"],
            ["", "", "image-b", "", "export-b"],
        ]
        lookup = build_image_id_lookup(source_rows)
        self.assertEqual(lookup, {"image-a": "export-a", "image-b": "export-b"})

    def test_build_image_id_lookup_splits_multi_c_values(self):
        source_rows = [
            ["", "", "C", "", "E"],
            [
                "",
                "",
                "image-yeaeisz2pokhx26nc06i ; image-yeaefjlv21hli6nron6j",
                "",
                "image-yepztd5qqqghga774oo7",
            ],
        ]
        lookup = build_image_id_lookup(source_rows)
        self.assertEqual(
            lookup,
            {
                "image-yeaeisz2pokhx26nc06i": "image-yepztd5qqqghga774oo7",
                "image-yeaefjlv21hli6nron6j": "image-yepztd5qqqghga774oo7",
            },
        )
    def test_find_updates_writes_aa_from_e(self):
        lookup = {"image-a": "export-a"}

        def target_row(z_value: str, aa_value: str) -> list[str]:
            row = [""] * (AA_COLUMN_INDEX + 1)
            row[Z_COLUMN_INDEX] = z_value
            row[AA_COLUMN_INDEX] = aa_value
            return row

        target_rows = [
            target_row("Z", "AA"),
            target_row("image-a", "old-value"),
            target_row("image-missing", ""),
            target_row("", ""),
        ]
        updates = find_updates(target_rows, lookup)
        self.assertEqual(len(updates), 1)
        self.assertEqual(updates[0]["expected_value"], "export-a")
        self.assertEqual(updates[0]["match_image_id"], "image-a")


if __name__ == "__main__":
    unittest.main()
