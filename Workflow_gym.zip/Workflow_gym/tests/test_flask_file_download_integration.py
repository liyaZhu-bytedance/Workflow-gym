"""集成测试：Redis/wgm-direct 模式下通过 Flask Runner /file 接口下载产物。

运行前置条件（通过环境变量或 launchctl setenv 配置）：
  WGM_TOKEN         必须设置，否则测试跳过
  WGM_API_BASE      可选，默认使用 wgm_client 的内置默认值
  WGM_TEST_LEASE_ID 必须设置，需指向一个活跃 Session 的 lease_id

可选覆盖：
  WGM_TEST_OUTPUT_DIR   VM 上的测试目录（默认按 lease 平台自动选择）
  WGM_TEST_FILENAME     测试文件名（默认 wgm_flask_dl_test.txt）

说明：
  平台类型（windows/ubuntu）会从 WGM ensure-ready 自动识别，无需手动设 WGM_TEST_OS_TYPE。
  在 VM 上创建/删除测试文件走 Flask run_action（Python），避免 RunCommand Shell/PowerShell 类型错配。

运行方式（在仓库根目录）：
  WGM_TOKEN=xxx WGM_TEST_LEASE_ID=lease-xxx python3 -m unittest \
    tests.test_flask_file_download_integration -v
"""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import time
import types
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = Path("/tmp/owg_path_flask_dl_test")
PACKAGE_ROOT.mkdir(parents=True, exist_ok=True)
link = PACKAGE_ROOT / "open_workflowgym"
if link.exists() or link.is_symlink():
    link.unlink()
link.symlink_to(REPO_ROOT)
sys.path.insert(0, str(PACKAGE_ROOT))

if "PIL" not in sys.modules:
    pil_module = types.ModuleType("PIL")
    pil_image_module = types.ModuleType("PIL.Image")
    pil_module.Image = pil_image_module
    sys.modules["PIL"] = pil_module
    sys.modules["PIL.Image"] = pil_image_module


def _read_env(name: str, default: str = "") -> str:
    value = os.getenv(name)
    if value:
        return value
    try:
        return subprocess.check_output(["launchctl", "getenv", name], text=True).strip() or default
    except Exception:
        return default


WGM_TOKEN = _read_env("WGM_TOKEN")
WGM_API_BASE = _read_env("WGM_API_BASE")
WGM_TEST_LEASE_ID = _read_env("WGM_TEST_LEASE_ID")
WGM_TEST_FILENAME = _read_env("WGM_TEST_FILENAME", "wgm_flask_dl_test.txt")

_SKIP_REASON = ""
if not WGM_TOKEN:
    _SKIP_REASON = "WGM_TOKEN 未设置"
elif not WGM_TEST_LEASE_ID:
    _SKIP_REASON = "WGM_TEST_LEASE_ID 未设置（需指向活跃 session 的 lease_id）"


@unittest.skipIf(_SKIP_REASON, _SKIP_REASON)
class FlaskFileDownloadIntegrationTest(unittest.TestCase):
    """经 WGM → Flask /file 下载 VM 产物。"""

    def setUp(self):
        from open_workflowgym.envs.gateway_volcengine_env import GatewayVolcengineEnv
        from open_workflowgym.lease_renewal import LeaseRenewContext

        self.env = GatewayVolcengineEnv(
            region="cn-guangzhou",
            wgm_api_base=WGM_API_BASE or None,
            wgm_token=WGM_TOKEN,
            ttl_seconds=3600,
        )
        self.env.lease_renew_context = LeaseRenewContext(
            lease_id=WGM_TEST_LEASE_ID,
            state_db_path="",
            ttl_seconds=3600,
            lease_backend="redis",
            wgm_token=WGM_TOKEN,
            wgm_api_base=WGM_API_BASE,
        )

        ready = self.env.wgm.ensure_ready(
            WGM_TEST_LEASE_ID,
            ttl_seconds=3600,
            allow_heal=True,
            wait_timeout_seconds=180,
        )
        platform = str(ready.get("platform") or "").lower()
        if platform == "windows":
            self.os_type = "windows"
            default_dir = r"C:\Users\Administrator\Desktop\output"
        else:
            self.os_type = "ubuntu"
            default_dir = "/home/user/Desktop/output"
        self.output_dir = _read_env("WGM_TEST_OUTPUT_DIR", default_dir)

        explicit_os = _read_env("WGM_TEST_OS_TYPE")
        if explicit_os and explicit_os.lower() not in (self.os_type, "linux" if self.os_type == "ubuntu" else ""):
            print(
                "[warn] WGM_TEST_OS_TYPE=%s 与 lease 平台 %s 不一致，以 lease 为准"
                % (explicit_os, self.os_type)
            )

        print(
            "[setup] lease_id=%s platform=%s output_dir=%s ready=%s"
            % (WGM_TEST_LEASE_ID, self.os_type, self.output_dir, ready.get("ready"))
        )
        flask_ok = bool((ready.get("checks") or {}).get("flask", {}).get("ok"))
        if not flask_ok:
            self.fail("Flask runner 未就绪，无法测试 /file 下载: %s" % (ready.get("checks") or ready))

    def _file_path_on_vm(self) -> str:
        if self.os_type == "ubuntu":
            return self.output_dir.rstrip("/") + "/" + WGM_TEST_FILENAME
        return self.output_dir.rstrip("\\") + "\\" + WGM_TEST_FILENAME

    def _build_create_file_action_script(self, vm_path: str, content: str) -> str:
        return (
            "from pathlib import Path\n"
            "p = Path(%r)\n" % vm_path
            + "p.parent.mkdir(parents=True, exist_ok=True)\n"
            + "p.write_text(%r, encoding='utf-8')\n" % content
            + "print('CREATE_OK')\n"
        )

    def _build_delete_file_action_script(self, vm_path: str) -> str:
        return (
            "from pathlib import Path\n"
            "p = Path(%r)\n" % vm_path
            + "try:\n"
            + "    p.unlink(missing_ok=True)\n"
            + "except TypeError:\n"
            + "    if p.is_file():\n"
            + "        p.unlink()\n"
            + "print('DELETE_OK')\n"
        )

    def _decoded_output(self, result: dict) -> str:
        import base64 as _b64

        outputs = []
        for item in result.get("results") or []:
            out = item.get("decoded_output")
            if out is None:
                raw = item.get("Output") or item.get("output") or ""
                try:
                    out = _b64.b64decode(raw).decode("utf-8", errors="replace") if raw else ""
                except Exception:
                    out = str(raw)
            if out:
                outputs.append(str(out))
        for key in ("output", "stderr"):
            extra = str(result.get(key) or "")
            if extra:
                outputs.append(extra)
        return "\n".join(outputs)

    def _run_flask_action(self, script: str, timeout: int = 60) -> str:
        result = self.env.run_action(
            "",
            script,
            timeout=timeout,
            action_id="flask-dl-test-%s" % int(time.time()),
        )
        output = self._decoded_output(result)
        if result.get("ok") is False:
            raise AssertionError("Flask run_action 失败: %s" % (output or result))
        return output

    def _normalize_text(self, text: str) -> str:
        return text.replace("\r\n", "\n").replace("\r", "\n").strip()

    def _create_file_on_vm(self, vm_path: str, content: str) -> None:
        out = self._run_flask_action(self._build_create_file_action_script(vm_path, content))
        print("[test] 创建文件输出: %s" % out[:300])
        self.assertIn("CREATE_OK", out, "VM 上创建文件失败: %s" % out[:500])

    def _delete_file_on_vm(self, vm_path: str) -> None:
        try:
            out = self._run_flask_action(self._build_delete_file_action_script(vm_path), timeout=30)
            print("[test] 删除文件输出: %s" % out[:200])
        except Exception as exc:
            print("[test] 清理文件失败（忽略）: %s" % exc)

    def test_create_file_on_vm_then_download_via_flask(self):
        timestamp = str(int(time.time()))
        expected_content = "wgm-flask-download-test ts=%s\nhello from integration test\n" % timestamp
        vm_path = self._file_path_on_vm()

        self._create_file_on_vm(vm_path, expected_content)

        print("[test] 下载文件: %s" % vm_path)
        try:
            dl_result = self.env.download_file("", [vm_path], timeout=60)
        except Exception as exc:
            self.fail("download_file 失败: %s" % exc)

        print(
            "[test] 下载结果: ok=%s size=%s via=%s"
            % (dl_result.get("ok"), dl_result.get("size"), dl_result.get("via"))
        )
        self.assertTrue(dl_result.get("ok"), "download_file 返回 ok=False: %s" % dl_result)
        self.assertIsInstance(dl_result.get("content"), (bytes, bytearray))
        self.assertGreater(len(dl_result["content"]), 0)

        actual_content = dl_result["content"].decode("utf-8", errors="replace")
        self.assertEqual(
            self._normalize_text(actual_content),
            self._normalize_text(expected_content),
        )
        self.assertEqual(dl_result.get("via"), "wgm_flask_http")

        self._delete_file_on_vm(vm_path)

    def test_collect_outputs_http_downloaded_path(self):
        from open_workflowgym.records import InstanceLease, RunConfig, SampleJob, TaskRecord
        from open_workflowgym.sampler import Sampler

        timestamp = str(int(time.time()))
        expected_content = "collect-outputs-http-test ts=%s\n" % timestamp
        filename = WGM_TEST_FILENAME
        vm_path = self._file_path_on_vm()

        self._create_file_on_vm(vm_path, expected_content)

        lease = InstanceLease(
            run_id="flask-dl-test",
            lease_id=WGM_TEST_LEASE_ID,
            instance_id="",
            task_id="test",
            sample_index=1,
            status="busy",
            acquired_at="2026-01-01 00:00:00",
        )
        config = RunConfig(
            run_id="flask-dl-test",
            output_root="output/flask_dl_integration_test",
            tosutil_timeout_seconds=120,
            lease_backend="redis",
            remote_action_delivery="wgm-direct",
        )
        job = SampleJob(
            run_id="flask-dl-test",
            task_id="test",
            sample_index=1,
            task=TaskRecord(
                run_id="flask-dl-test",
                task_id="test",
                row_number=1,
                fields={
                    "输出文件路径": self.output_dir,
                    "final_answer文件名": filename,
                },
            ),
            config=config,
            lease=lease,
        )
        sampler = Sampler(None, self.env)

        with tempfile.TemporaryDirectory(prefix="flask_dl_test_") as tmp:
            old_via = os.environ.get("WGM_FILE_COLLECT_VIA")
            os.environ["WGM_FILE_COLLECT_VIA"] = "http"
            try:
                result = sampler.collect_outputs(job, sample_dir=tmp)
            finally:
                if old_via is None:
                    os.environ.pop("WGM_FILE_COLLECT_VIA", None)
                else:
                    os.environ["WGM_FILE_COLLECT_VIA"] = old_via

            print("[test] collect_outputs errors: %s" % result.errors)
            for upload in result.output_uploads:
                print(
                    "[test] upload: status=%s http=%s"
                    % (upload.get("status"), upload.get("http_download"))
                )

            self.assertEqual(len(result.output_uploads), 1)
            upload = result.output_uploads[0]
            self.assertEqual(
                upload.get("status"),
                "http_downloaded",
                "期望 http_downloaded，实际: %s，http_download: %s"
                % (upload.get("status"), upload.get("http_download")),
            )
            self.assertTrue(upload.get("output_file_exists"))
            self.assertEqual(result.errors, [])

            local_path = Path(tmp) / "production" / filename
            self.assertTrue(local_path.is_file(), "本地 production 文件不存在: %s" % local_path)
            actual = local_path.read_text(encoding="utf-8", errors="replace")
            self.assertEqual(
                self._normalize_text(actual),
                self._normalize_text(expected_content),
            )

        self._delete_file_on_vm(vm_path)

    def test_download_nonexistent_file_raises(self):
        nonexistent = (
            r"C:\NONEXISTENT_PATH\no_such_file_xyz.txt"
            if self.os_type == "windows"
            else "/tmp/no_such_file_xyz_wgm_test.txt"
        )
        with self.assertRaises((ValueError, Exception)) as ctx:
            self.env.download_file("", [nonexistent], timeout=30)
        print("[test] 预期异常: %s" % ctx.exception)
        self.assertIn("not_found", str(ctx.exception).lower())


if __name__ == "__main__":
    unittest.main(verbosity=2)
