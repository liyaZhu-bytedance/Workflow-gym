import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))

from export_guangzhou_ubuntu_images_to_tos import (
    DEFAULT_EXPORT_CONCURRENCY,
    export_images_concurrently,
)


class TestExportImagesConcurrency(unittest.TestCase):
    def test_export_images_concurrently_caps_workers_at_ten(self):
        images = [{"ImageId": "image-%s" % index, "ImageName": "name-%s" % index} for index in range(12)]
        observed_workers: list[int] = []

        class FakeExecutor:
            def __init__(self, max_workers: int):
                observed_workers.append(max_workers)

            def __enter__(self):
                return self

            def __exit__(self, exc_type, exc, tb):
                return False

            def submit(self, fn, image):
                from concurrent.futures import Future

                future: Future = Future()
                future.set_result(
                    {
                        "image_id": image["ImageId"],
                        "image_name": image["ImageName"],
                        "tos_uri": "tos://bucket/open/",
                        "tos_object_uri": "tos://bucket/open_%s_system.qcow2" % image["ImageId"],
                    }
                )
                return future

        with patch("export_guangzhou_ubuntu_images_to_tos.ThreadPoolExecutor", FakeExecutor):
            results, errors = export_images_concurrently(
                images,
                tos_bucket="bucket",
                poll_interval_seconds=1,
                timeout_seconds=60,
                max_concurrency=DEFAULT_EXPORT_CONCURRENCY,
            )
        self.assertEqual(observed_workers, [DEFAULT_EXPORT_CONCURRENCY])
        self.assertEqual(len(results), 12)
        self.assertEqual(errors, [])


if __name__ == "__main__":
    unittest.main()
