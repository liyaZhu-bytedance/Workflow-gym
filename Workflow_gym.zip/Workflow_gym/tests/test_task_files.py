from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.task_files import (
    DownloadPlan,
    build_download_plan,
    build_linux_prepare_input_command,
    build_linux_tosutil_upload_command,
    build_prepare_output_command,
    parse_final_answer_names,
    parse_tos_urls,
    split_output_paths,
)


class TaskFilesTest(unittest.TestCase):
    def test_parse_final_answer_names_from_python_repr_link_items(self):
        raw_value = "[{'cellPosition': None, 'link': 'expense.csv', 'text': 'expense.csv', 'type': 'url'}]"

        self.assertEqual(parse_final_answer_names(raw_value), ["expense.csv"])

    def test_parse_final_answer_names_from_python_repr_link_item(self):
        raw_value = "{'cellPosition': None, 'link': 'KKX.pdf', 'text': 'KKX.pdf', 'type': 'url'}"

        self.assertEqual(parse_final_answer_names(raw_value), ["KKX.pdf"])

    def test_parse_tos_urls_from_python_repr_list_string(self):
        raw_value = (
            "['https://cdn.example.local/obj/synthetic-gui-data/base_sheets_input/"
            "1746_recv7C2yI5ZfGn/%E6%BC%94%E7%BB%83%E6%95%B0%E6%8D%AE6.xlsx']"
        )

        self.assertEqual(
            parse_tos_urls(raw_value),
            [
                "https://cdn.example.local/obj/synthetic-gui-data/base_sheets_input/"
                "1746_recv7C2yI5ZfGn/%E6%BC%94%E7%BB%83%E6%95%B0%E6%8D%AE6.xlsx"
            ],
        )

    def test_parse_tos_urls_from_feishu_rich_text_tokens(self):
        raw_value = [
            {"text": "['", "type": "text"},
            {
                "link": "https://cdn.example.local/obj/synthetic-gui-data/base_sheets_input/1746/file.xlsx",
                "text": "file.xlsx",
                "type": "url",
            },
            {"text": "']", "type": "text"},
        ]

        self.assertEqual(
            parse_tos_urls(raw_value),
            ["https://cdn.example.local/obj/synthetic-gui-data/base_sheets_input/1746/file.xlsx"],
        )

    def test_linux_prepare_input_command_cleans_dir_and_uses_wget(self):
        command = build_linux_prepare_input_command(
            "/home/user/Desktop/input",
            [DownloadPlan(url="https://example.com/input.xlsx", filename="input.xlsx")],
            30,
        )

        self.assertIn('mkdir -p "$input_dir"', command)
        self.assertIn('find "$input_dir" -mindepth 1 -maxdepth 1 -exec rm -rf {} +', command)
        self.assertIn("'wget'", command)
        self.assertNotIn("urllib.request", command)

    def test_download_plan_strips_url_query_for_download(self):
        plan = build_download_plan(
            [
                "https://data.example.local/base_sheets_input/252/She.mp3"
                "?timeout=60s&uploadID=b5dafeebe4b90eaed3b2287e-0000"
            ]
        )

        self.assertEqual(
            plan,
            [
                DownloadPlan(
                    url="https://cdn.example.local/obj/synthetic-gui-data/base_sheets_input/252/She.mp3",
                    filename="She.mp3",
                )
            ],
        )

    def test_download_plan_rewrites_synthetic_gui_output_url(self):
        plan = build_download_plan(
            [
                "https://data.example.local/base_sheets_output/252/result.csv"
                "?timeout=60s&uploadID=abc"
            ]
        )

        self.assertEqual(
            plan,
            [
                DownloadPlan(
                    url="https://cdn.example.local/obj/synthetic-gui-data/base_sheets_output/252/result.csv",
                    filename="result.csv",
                )
            ],
        )

    def test_linux_tosutil_upload_command_generates_presigned_url_marker(self):
        command = build_linux_tosutil_upload_command(
            "/home/user/Desktop/output",
            ["result.csv"],
            "tos://bucket/base_sheets_output/1746",
            "24h",
        )

        self.assertIn("tosutil cp", command)
        self.assertIn("tosutil presign 'tos://bucket/base_sheets_output/1746/result.csv' -vp=\"$presign_valid_period\"", command)
        self.assertIn("WORKFLOWGYM_TOS_PRESIGN", command)

    def test_split_output_paths_keeps_comma_separated_dirs(self):
        self.assertEqual(
            split_output_paths("/home/user/Desktop/output/http_with_jpegs,/home/user/Desktop/output"),
            [
                "/home/user/Desktop/output/http_with_jpegs",
                "/home/user/Desktop/output",
            ],
        )

    def test_prepare_output_command_prepares_each_output_dir(self):
        command = build_prepare_output_command(
            "/home/user/Desktop/output/http_with_jpegs,/home/user/Desktop/output"
        )

        self.assertIn("output_dir='/home/user/Desktop/output/http_with_jpegs'", command)
        self.assertIn("output_dir='/home/user/Desktop/output'", command)
        self.assertIn('if [ ! -d "$output_dir" ]; then', command)
        self.assertIn('  rm -rf "$output_dir"', command)

    def test_prepare_output_command_prepares_parent_before_nested_dir(self):
        command = build_prepare_output_command(
            "/home/user/Desktop/output/Article2,/home/user/Desktop/output"
        )

        parent_index = command.index("output_dir='/home/user/Desktop/output'")
        child_index = command.index("output_dir='/home/user/Desktop/output/Article2'")
        self.assertLess(parent_index, child_index)

    def test_linux_tosutil_upload_command_tries_each_output_dir(self):
        command = build_linux_tosutil_upload_command(
            "/home/user/Desktop/output/http_with_jpegs,/home/user/Desktop/output",
            ["image_hash.txt"],
            "tos://bucket/base_sheets_output/173",
            "24h",
        )

        self.assertIn("'/home/user/Desktop/output/http_with_jpegs/image_hash.txt'", command)
        self.assertIn("'/home/user/Desktop/output/image_hash.txt'", command)


if __name__ == "__main__":
    unittest.main()
