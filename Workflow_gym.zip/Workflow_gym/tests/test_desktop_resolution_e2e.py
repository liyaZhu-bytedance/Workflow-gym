from __future__ import annotations

# pyright: reportMissingImports=false

import os
import re
import sys
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.agents.pyautogui_actions import image_size
from open_workflowgym.envs.volcengine_env import VolcengineEnv


INSTANCE_ID = os.getenv("DESKTOP_RESOLUTION_E2E_INSTANCE_ID", "i-yeq4l3b400obzsyfqeqs")
REGION = os.getenv("VOLCENGINE_REGION", "cn-guangzhou")
TARGET_WIDTH = int(os.getenv("DESKTOP_RESOLUTION_WIDTH", "1920"))
TARGET_HEIGHT = int(os.getenv("DESKTOP_RESOLUTION_HEIGHT", "1080"))


class DesktopResolutionE2ETest(unittest.TestCase):
    def test_set_desktop_resolution_and_verify_console_screenshot(self):
        print(
            "desktop resolution e2e: instance_id=%s region=%s target=%sx%s"
            % (INSTANCE_ID, REGION, TARGET_WIDTH, TARGET_HEIGHT)
        )
        env = VolcengineEnv(dry_run="", region=REGION)
        metadata = env.prepare_desktop_for_pyautogui(INSTANCE_ID)
        print(
            "desktop metadata: user=%s home=%s display=%s xauthority=%s"
            % (
                metadata["desktop_user"],
                metadata["desktop_home"],
                metadata["display"],
                metadata["xauthority"],
            )
        )

        verify_output = command_output(
            env.run_command(
                INSTANCE_ID,
                build_verify_resolution_command(
                    metadata["desktop_user"],
                    metadata["desktop_home"],
                    metadata["display"],
                    metadata["xauthority"],
                ),
                timeout=60,
            )
        )
        print("resolution verify output:")
        print(verify_output)

        expected = "%sx%s" % (TARGET_WIDTH, TARGET_HEIGHT)
        self.assertRegex(verify_output, r"xdpyinfo dimensions:\s*%s\b" % re.escape(expected))
        self.assertRegex(verify_output, r"xrandr current:\s*%s\b" % re.escape(expected))
        self.assertRegex(verify_output, r"pyautogui size:\s*%s\b" % re.escape(expected))

        time.sleep(int(os.getenv("DESKTOP_RESOLUTION_SCREENSHOT_WAIT_SECONDS", "3")))
        screenshot_bytes = env.get_console_screenshot(INSTANCE_ID)
        artifact_dir = Path(os.getenv("DESKTOP_RESOLUTION_E2E_ARTIFACT_DIR", "test_artifacts/desktop_resolution"))
        artifact_dir.mkdir(parents=True, exist_ok=True)
        screenshot_path = artifact_dir / ("%s.jpg" % INSTANCE_ID)
        screenshot_path.write_bytes(screenshot_bytes)

        size = image_size(screenshot_path)
        print("console screenshot: %s size=%s" % (screenshot_path, size))
        self.assertEqual(size, (TARGET_WIDTH, TARGET_HEIGHT))


def command_output(response: dict) -> str:
    return "\n".join(item.get("decoded_output") or "" for item in response.get("results", []))


def build_verify_resolution_command(desktop_user: str, desktop_home: str, display: str, xauthority: str) -> str:
    return """#!/bin/bash
set -euo pipefail
sudo -H -u {desktop_user} env DISPLAY={display} HOME={desktop_home} XAUTHORITY={xauthority} bash -lc '
set -euo pipefail
xdpyinfo_dimensions="$(xdpyinfo 2>/dev/null | awk "/dimensions:/ {{print \\$2; exit}}" || true)"
xrandr_current="$(xrandr --current 2>/dev/null | awk "/\\*/ {{print \\$1; exit}}" || true)"
echo "xdpyinfo dimensions: $xdpyinfo_dimensions"
echo "xrandr current: $xrandr_current"
/usr/bin/python - <<'"'"'PY'"'"'
import pyautogui
size = pyautogui.size()
print("pyautogui size: %sx%s" % (int(size.width), int(size.height)))
PY
'
""".format(
        desktop_user=shell_quote(desktop_user),
        desktop_home=shell_quote(desktop_home),
        display=shell_quote(display),
        xauthority=shell_quote(xauthority),
    )


def shell_quote(value: str) -> str:
    import shlex

    return shlex.quote(value)


if __name__ == "__main__":
    unittest.main()
