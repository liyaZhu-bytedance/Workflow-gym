from __future__ import annotations

import os
import shlex
import subprocess
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.judgers.common import extract_json_object
from open_workflowgym.judgers.defaults import is_bytedance_search_gpt_base_url
from open_workflowgym.judgers.factory import JudgeModelFactory

JUDGE_ZSHRC_ENV_NAMES = (
    "JUDGE_API_KEY",
    "JUDGE_BASE_URL",
    "JUDGE_MODEL",
    "GEMINI31_API_KEY",
)
LIVE_JUDGE_MODEL_FALLBACK = "gemini-3-pro-preview-new"


def read_env(name: str, default: str = "") -> str:
    return os.getenv(name, default)


def load_zshrc_env(names: tuple[str, ...] = JUDGE_ZSHRC_ENV_NAMES, zshrc_path: str = "") -> None:
    missing = [name for name in names if not read_env(name)]
    if not missing:
        return
    zshrc = Path(zshrc_path or os.path.expanduser("~/.zshrc"))
    if not zshrc.is_file():
        return
    zshrc_quoted = shlex.quote(str(zshrc))
    for name in missing:
        try:
            completed = subprocess.run(
                ["zsh", "-lc", "source %s >/dev/null 2>&1; print -r -- ${%s:-}" % (zshrc_quoted, name)],
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        value = (completed.stdout or "").strip()
        if value:
            os.environ[name] = value


def live_judge_enabled() -> bool:
    return read_env("RUN_LIVE_JUDGE", "1").strip().lower() not in ("0", "false", "no", "off")


def judge_model_permission_error(exc: BaseException) -> bool:
    text = str(exc)
    return "no model permission" in text or '"code":"-1002"' in text


def call_gemini3_pro_with_model(model_name: str) -> str:
    previous = os.environ.get("JUDGE_MODEL")
    os.environ["JUDGE_MODEL"] = model_name
    try:
        client = JudgeModelFactory().create("gemini3_pro")
        return client.call_model(
            [
                {
                    "role": "user",
                    "content": '只返回 JSON：{"score":0,"reason":"live_judge_ok"}',
                }
            ],
            retry_count=1,
            delay_seconds=0,
        )
    finally:
        if previous is None:
            os.environ.pop("JUDGE_MODEL", None)
        else:
            os.environ["JUDGE_MODEL"] = previous


@unittest.skipUnless(live_judge_enabled(), "set RUN_LIVE_JUDGE=1 to run live judge model tests")
class JudgeModelLiveTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        load_zshrc_env()

    def test_zshrc_judge_env_loaded(self) -> None:
        self.assertTrue(read_env("JUDGE_API_KEY") or read_env("GEMINI31_API_KEY"), "缺少 JUDGE_API_KEY")
        self.assertTrue(read_env("JUDGE_BASE_URL"), "缺少 JUDGE_BASE_URL")
        self.assertTrue(read_env("JUDGE_MODEL"), "缺少 JUDGE_MODEL")

    def test_bytedance_judge_base_url_detection(self) -> None:
        self.assertTrue(
            is_bytedance_search_gpt_base_url(read_env("JUDGE_BASE_URL")),
            "当前 JUDGE_BASE_URL 应走 ByteDance GPT 直连，而不是 /chat/completions",
        )

    def test_gemini3_pro_live_call_from_zshrc(self) -> None:
        configured_model = read_env("JUDGE_MODEL")
        try:
            raw = call_gemini3_pro_with_model(configured_model)
        except Exception as exc:
            if judge_model_permission_error(exc) and configured_model != LIVE_JUDGE_MODEL_FALLBACK:
                raw = call_gemini3_pro_with_model(LIVE_JUDGE_MODEL_FALLBACK)
                print(
                    "JUDGE_MODEL=%s 无权限，live test 已改用 %s；请更新 ~/.zshrc"
                    % (configured_model, LIVE_JUDGE_MODEL_FALLBACK)
                )
            else:
                raise

        self.assertTrue(str(raw).strip(), "判分模型返回空内容")
        parsed = extract_json_object(str(raw))
        self.assertIsInstance(parsed, dict)
        self.assertIn("score", parsed)
        print("live judge response:", raw)


if __name__ == "__main__":
    unittest.main()
