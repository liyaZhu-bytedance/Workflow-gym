"""查询 Hugging Face 仓库已用容量（需 HF_TOKEN / HF_REPO_ID）。

示例:
  export HF_TOKEN=hf_xxx
  export HF_REPO_ID=zilou25/test
  export HF_REPO_TYPE=dataset
  python -m unittest tests.test_hf_repo_storage -v
"""

from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))

from publish_guangzhou_images_to_huggingface import HfRepoRotator, resolve_hf_token

DEFAULT_REPO_ID = "zilou25/test"
DEFAULT_REPO_TYPE = "dataset"


def _format_bytes(num_bytes: int | None) -> str:
    if num_bytes is None:
        return "unknown"
    gib = num_bytes / (1024 ** 3)
    return "%s bytes (%.6f GiB)" % (num_bytes, gib)


class TestHfRepoStorage(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.token = resolve_hf_token()
        cls.repo_id = (os.getenv("HF_REPO_ID") or DEFAULT_REPO_ID).strip()
        cls.repo_type = (os.getenv("HF_REPO_TYPE") or DEFAULT_REPO_TYPE).strip() or DEFAULT_REPO_TYPE

    def test_query_repo_used_storage(self) -> None:
        if not self.token:
            self.skipTest("缺少 HF_TOKEN / HUGGINGFACE_HUB_TOKEN，跳过真实 HF 查询")

        rotator = HfRepoRotator(
            base_repo_id=self.repo_id,
            repo_type=self.repo_type,
            private=None,
        )
        used = rotator.repo_used_bytes(self.repo_id)
        self.assertIsNotNone(used, "repo_info.used_storage 为空，无法读取仓库用量")
        assert used is not None

        from huggingface_hub import HfApi

        info = HfApi(token=self.token).repo_info(repo_id=self.repo_id, repo_type=self.repo_type)
        private = bool(getattr(info, "private", False))
        siblings = getattr(info, "siblings", None) or []
        sibling_sum = sum(int(getattr(item, "size", 0) or 0) for item in siblings)

        print("")
        print("HF_REPO_ID=%s" % self.repo_id)
        print("repo_type=%s" % self.repo_type)
        print("private=%s" % private)
        print("used_storage=%s" % _format_bytes(used))
        print("siblings_count=%s" % len(siblings))
        print("siblings_size_sum=%s" % _format_bytes(sibling_sum))
        print(
            "说明: HF 不按单仓返回固定上限；Free 账号 private 总量约 100GB，"
            "public 为 best-effort。当前查询到的是该仓已用容量。"
        )

        self.assertGreaterEqual(used, 0)
        self.assertEqual(getattr(info, "id", None), self.repo_id)


if __name__ == "__main__":
    unittest.main()
