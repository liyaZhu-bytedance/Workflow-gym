from __future__ import print_function

import os
import shlex
import sys
import unittest
import warnings
from pathlib import Path

warnings.filterwarnings(
    "ignore",
    message="urllib3 v2 only supports OpenSSL.*",
)

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import volcenginesdkcore
import volcenginesdkecs

from main import get_result_payload, run_command_and_wait
from open_workflowgym.envs.volcengine_env import (  # type: ignore[import-not-found]
    build_linux_configure_tosutil_command,
    build_linux_download_tosutil_command,
)


INSTANCE_ID = os.getenv("INSTANCE_ID", "i-yeprxlt3i8bw80dfwlbv")
TOS_AK = os.getenv("TOS_AK") or os.getenv("AK")
TOS_SK = os.getenv("TOS_SK") or os.getenv("SK")
TOS_ENDPOINT = os.getenv("TOS_ENDPOINT", "tos-cn-beijing.volces.com")
TOS_REGION = os.getenv("TOS_REGION", "cn-beijing")
TOS_UPLOAD_SOURCE_FILE = os.getenv(
    "TOS_UPLOAD_SOURCE_FILE",
    "/home/cloud_assistant_cmd.sh",
)
TOS_UPLOAD_BUCKET = os.getenv("TOS_UPLOAD_BUCKET", "tos://open-workflowgym-sample")
TOSUTIL_DOWNLOAD_URL = (
    "https://m645b3e1bb36e-mrap.mrap.accesspoint.tos-global.volces.com"
    "/linux/amd64/tosutil"
)


def create_api_instance():
    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = "cn-beijing"
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkecs.ECSApi()


class TestInstanceTosUpload(unittest.TestCase):
    def test_config_tosutil_version_and_list_buckets(self):
        self.assertTrue(
            TOS_AK and TOS_SK,
            "缺少 TOS 配置：请设置 TOS_AK/TOS_SK，或确认当前 shell 已设置 AK/SK",
        )

        api_instance = create_api_instance()
        download_command = build_linux_download_tosutil_command()
        run_command_and_wait(
            api_instance,
            INSTANCE_ID,
            download_command,
            "test-tosutil-download",
            working_dir="/home",
            timeout=120,
        )

        config_command = build_linux_configure_tosutil_command(TOS_AK, TOS_SK, TOS_ENDPOINT, TOS_REGION)
        display_config_command = build_linux_configure_tosutil_command(
            "<access key>",
            "<secret key>",
            TOS_ENDPOINT,
            TOS_REGION,
        )
        config_response = run_command_and_wait(
            api_instance,
            INSTANCE_ID,
            config_command,
            "test-tosutil-config-list-buckets",
            working_dir="/home",
            timeout=120,
            display_command=display_config_command,
        )
        config_output = decoded_invocation_output(config_response)
        self.assertIn("WORKFLOWGYM_LINUX_TOSUTIL_CONFIG_DONE", config_output)
        self.assertIn("tos://open-workflowgym-sample/", config_output)

        command = """#!/bin/bash
set -euo pipefail
cd /home
test -f {source_file}
/usr/local/bin/tosutil cp {source_file} {upload_bucket}/{instance_id}/
echo "uploaded {source_file} to {upload_bucket}/{instance_id}/"
""".format(
            source_file=shlex.quote(TOS_UPLOAD_SOURCE_FILE),
            upload_bucket=shlex.quote(TOS_UPLOAD_BUCKET),
            instance_id=shlex.quote(INSTANCE_ID),
        )
        display_command = """#!/bin/bash
set -euo pipefail
cd /home
test -f {source_file}
/usr/local/bin/tosutil cp {source_file} {upload_bucket}/{instance_id}/
echo "uploaded {source_file} to {upload_bucket}/{instance_id}/"
""".format(
            source_file=shlex.quote(TOS_UPLOAD_SOURCE_FILE),
            upload_bucket=shlex.quote(TOS_UPLOAD_BUCKET),
            instance_id=shlex.quote(INSTANCE_ID),
        )

        try:
            response_data = run_command_and_wait(
                api_instance,
                INSTANCE_ID,
                command,
                "test-tosutil-config-version-list-buckets",
                working_dir="/home",
                timeout=120,
                display_command=display_command,
            )
        except Exception as exc:
            self.fail("tosutil 配置、列桶或上传文件失败: %s" % exc)

        result = get_result_payload(response_data)
        invocation_results = (
            result.get("InvocationResults")
            or result.get("invocation_results")
            or []
        )
        self.assertTrue(invocation_results, "没有获取到 tosutil 上传执行结果")

        for item in invocation_results:
            status = (
                item.get("InvocationResultStatus")
                or item.get("invocation_result_status")
            )
            exit_code = item.get("ExitCode")
            if exit_code is None:
                exit_code = item.get("exit_code")
            output = item.get("decoded_output") or ""

            self.assertEqual(status, "Success")
            self.assertEqual(exit_code, 0)
            self.assertIn("uploaded", output)
            print("tosutil 上传结果:")
            print(output)


def decoded_invocation_output(response_data):
    result = get_result_payload(response_data)
    invocation_results = result.get("InvocationResults") or result.get("invocation_results") or []
    return "\n".join(item.get("decoded_output") or "" for item in invocation_results)


if __name__ == "__main__":
    unittest.main()
