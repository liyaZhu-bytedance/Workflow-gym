from __future__ import annotations

import os
from pathlib import Path

from open_workflowgym.agents.factory import AgentFactory
from open_workflowgym.attachment_uploader import AttachmentUploader
from open_workflowgym.feishu_client import FeishuClient
from open_workflowgym.local_spreadsheet import (
    LocalSpreadsheetClient,
    MirroringSpreadsheetClient,
    feishu_credentials_configured,
    resolve_local_samples_csv_path,
    resolve_report_csv_dir,
)
from open_workflowgym.records import ScoreResult, TrajectoryResult, to_jsonable
from open_workflowgym.writer_process import WriterProcess


def e2e_enable_real_feishu() -> bool:
    return os.getenv("WORKFLOWGYM_ENABLE_REAL_FEISHU", "0").lower() in {"1", "true", "yes", "on"}


def e2e_spreadsheet_write_enabled() -> bool:
    return os.getenv("WORKFLOWGYM_SKIP_E2E_SPREADSHEET", "0").lower() not in {"1", "true", "yes", "on"}


def build_e2e_spreadsheet_client(output_root: str):
    local_client = LocalSpreadsheetClient(resolve_report_csv_dir("", output_root))
    if not e2e_enable_real_feishu() or not feishu_credentials_configured():
        return local_client
    return MirroringSpreadsheetClient(FeishuClient(dry_run=False), local_client)


def build_e2e_writer(output_root: str) -> WriterProcess:
    client = build_e2e_spreadsheet_client(output_root)
    return WriterProcess(client, AttachmentUploader(client), AgentFactory())


def write_e2e_sample_to_spreadsheet(
    *,
    output_root: str,
    trajectory: TrajectoryResult,
    score: ScoreResult,
) -> dict[str, str]:
    writer = build_e2e_writer(output_root)
    writer.write_trajectory_payload(to_jsonable(trajectory))
    writer.write_score_payload(
        {
            **to_jsonable(score),
            "task_fields": trajectory.task_fields or {},
        }
    )
    report_url = str(writer.report.get("spreadsheet_url") or "")
    local_csv = resolve_local_samples_csv_path("", output_root)
    print("WORKFLOWGYM_E2E_SPREADSHEET_URL", report_url, flush=True)
    print("WORKFLOWGYM_E2E_SPREADSHEET_CSV", local_csv, flush=True)
    return {
        "spreadsheet_url": report_url,
        "local_samples_csv": local_csv,
        "real_feishu": str(e2e_enable_real_feishu() and feishu_credentials_configured()).lower(),
    }


def maybe_write_e2e_sample_to_spreadsheet(
    *,
    output_root: str,
    trajectory: TrajectoryResult,
    score: ScoreResult,
) -> dict[str, str] | None:
    if not e2e_spreadsheet_write_enabled():
        print("WORKFLOWGYM_E2E_SKIP_SPREADSHEET reason=WORKFLOWGYM_SKIP_E2E_SPREADSHEET", flush=True)
        return None
    return write_e2e_sample_to_spreadsheet(
        output_root=output_root,
        trajectory=trajectory,
        score=score,
    )
