from __future__ import annotations

import os
import sys
import unittest
import warnings
from pathlib import Path

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.envs.volcengine_eip import allocate_and_associate_eip
from open_workflowgym.envs.volcengine_env import (
    VolcengineEnv,
    build_prepare_windows_pyautogui_command,
    command_decoded_output,
)


DEFAULT_INSTANCE_ID = "i-yeq4lc7dhch2cbesrqlo"


def read_env(name: str, default: str = "") -> str:
    return os.getenv(name, default)


@unittest.skipUnless(
    os.getenv("WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS") == "1",
    "set WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS=1 to run real Volcengine calls",
)
class WindowsPrepareInstanceE2ETest(unittest.TestCase):
    """Manual E2E test for binding public IP and preparing a Windows instance."""

    def test_bind_public_ip_and_prepare_windows_pyautogui(self):
        instance_id = read_env("WORKFLOWGYM_TEST_INSTANCE_ID", DEFAULT_INSTANCE_ID)
        region = read_env("VOLCENGINE_REGION", read_env("SOURCE_REGION", "cn-guangzhou"))
        project_name = read_env("VOLCENGINE_EIP_PROJECT_NAME", "default")
        billing_type = int(read_env("VOLCENGINE_EIP_BILLING_TYPE", "2"))
        timeout = int(read_env("WORKFLOWGYM_WINDOWS_PREPARE_TEST_TIMEOUT_SECONDS", "1800"))

        print("WORKFLOWGYM_TEST_INSTANCE", instance_id, flush=True)
        print("WORKFLOWGYM_TEST_BIND_PUBLIC_IP_START", flush=True)
        eip_result = allocate_and_associate_eip(
            instance_id=instance_id,
            region=region,
            billing_type=billing_type,
            project_name=project_name,
        )
        print("WORKFLOWGYM_TEST_BIND_PUBLIC_IP_RESULT", eip_result, flush=True)

        print("WORKFLOWGYM_TEST_WINDOWS_PREPARE_START", flush=True)
        env = VolcengineEnv(region=region)
        command = build_prepare_windows_pyautogui_command()
        installer_tos_uri = "tos://open-workflowgym-win-python/python-3.12.8-amd64_1.exe"
        self.assertIn(installer_tos_uri, command)
        self.assertNotIn("https://www.python.org/ftp/python/3.12.8/python-3.12.8-amd64.exe", command)

        command_result = env.run_command(
            instance_id,
            command,
            timeout=timeout,
            command_type="PowerShell",
        )
        decoded_output = command_decoded_output(command_result)
        print("WORKFLOWGYM_TEST_WINDOWS_PREPARE_RESULT", command_result, flush=True)
        print("WORKFLOWGYM_TEST_WINDOWS_PREPARE_OUTPUT", decoded_output, flush=True)

        self.assertIn("WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_TOS_URI", decoded_output)
        self.assertIn(installer_tos_uri, decoded_output)
        self.assertIn("WORKFLOWGYM_WINDOWS_PYAUTOGUI_READY", decoded_output)
        self.assertIn("WORKFLOWGYM_WINDOWS_PYAUTOGUI_SIZE", decoded_output)


if __name__ == "__main__":
    unittest.main()
