from __future__ import annotations

import sys
import tempfile
import types
import unittest
import os
import shlex
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.agents.pyautogui_actions import (
    action_execution_should_continue,
    action_timeout_should_continue,
    disallowed_pyautogui_action_reason,
    is_disallowed_pyautogui_action_error,
    is_remote_action_execution_error,
    is_remote_action_timeout_error,
    is_remote_screenshot_error,
    is_runcommand_python_execution_error,
    is_windows_file_queue_action_execution_error,
    remote_action_timeout_seconds,
    screenshot_failure_should_continue,
    should_retry_windows_file_queue_error,
    ubuntu_desktop_session_from_context,
    wrap_pyautogui_python,
    windows_file_queue_poll_seconds,
)
from open_workflowgym.agents.kimi26 import KimiNativeAgentAdapter, parse_response_to_cot_and_action
from open_workflowgym.agents.base import SampleContext
from open_workflowgym.records import RunConfig, SampleJob, TaskRecord
from open_workflowgym.sampler import SampleRunState, Sampler, StepActionResult
from open_workflowgym.states import SampleStatus


class PyautoguiWindowsWrapperTest(unittest.TestCase):
    def test_windows_defaults_to_flask_wrapper_without_explicit_runner_mode(self):
        with mock.patch.dict("os.environ", {}, clear=True):
            os.environ.pop("WINDOWS_ACTION_RUNNER", None)
            os.environ.pop("WINDOWS_FILE_QUEUE_RUNNER", None)
            command = wrap_pyautogui_python("pyautogui.click(1, 2)", platform="windows")

        self.assertIn("WORKFLOWGYM_FLASK_AGENT_RESULT", command)
        self.assertNotIn("workflowgym_file_queue_action.json", command)

    def test_windows_flask_wrapper_uses_local_powershell_proxy(self):
        command = wrap_pyautogui_python("pyautogui.click(1, 2)", platform="windows", windows_runner_mode="flask")

        self.assertIn("$ErrorActionPreference = 'Stop'", command)
        self.assertIn("127.0.0.1", command)
        self.assertIn("WORKFLOWGYM_FLASK_AGENT_RESULT", command)
        self.assertNotIn("workflowgym_file_queue_action.json", command)

    def test_windows_file_queue_wrapper_uses_powershell_temp_python(self):
        command = wrap_pyautogui_python("pyautogui.click(1, 2)", platform="windows", windows_runner_mode="file_queue")

        self.assertIn("$ErrorActionPreference = 'Stop'", command)
        self.assertIn("workflowgym_file_queue_action.json", command)
        self.assertIn("WORKFLOWGYM_FILE_QUEUE_AGENT_RESULT", command)
        self.assertIn("script_b64", command)
        self.assertIn("for ($i = 0; $i -lt %s; $i++)" % windows_file_queue_poll_seconds(), command)
        self.assertNotIn("#!/bin/bash", command)

    def test_remote_action_timeout_matches_file_queue_poll(self):
        command = wrap_pyautogui_python("pyautogui.click(1, 2)", platform="windows", windows_runner_mode="file_queue")
        timeout = remote_action_timeout_seconds(command, 60)
        self.assertGreaterEqual(timeout, windows_file_queue_poll_seconds() + 15)
        self.assertGreaterEqual(windows_file_queue_poll_seconds(), 90)

    def test_linux_wrapper_uses_flask_http_by_default(self):
        command = wrap_pyautogui_python("pyautogui.click(1, 2)", platform="ubuntu")

        self.assertTrue(command.startswith("#!/bin/bash"))
        self.assertIn("WORKFLOWGYM_FLASK_AGENT_RESULT", command)
        self.assertIn("127.0.0.1", command)
        self.assertIn("/action", command)
        self.assertNotIn("/tmp/workflowgym_pyautogui.py", command)

    def test_linux_wrapper_legacy_keeps_bash(self):
        command = wrap_pyautogui_python(
            "pyautogui.click(1, 2)",
            platform="ubuntu",
            ubuntu_runner_mode="legacy",
        )

        self.assertTrue(command.startswith("#!/bin/bash"))
        self.assertIn('desktop_user="${DESKTOP_USER:-user}"', command)
        self.assertIn("/tmp/workflowgym_pyautogui.py", command)
        self.assertNotIn("WORKFLOWGYM_FLASK_AGENT_RESULT", command)

    def test_linux_wrapper_uses_init_desktop_session_from_context(self):
        context = SampleContext(
            run_id="run-test",
            task=TaskRecord(run_id="run-test", task_id="330", row_number=1, fields={}),
            sample_index=1,
            sample_dir="/tmp/sample",
            metadata={
                "platform": "ubuntu",
                "env_metadata": {
                    "desktop_user": "user",
                    "desktop_home": "/home/user",
                    "display": ":0",
                    "xauthority": "/run/user/1000/gdm/Xauthority",
                },
            },
        )
        self.assertEqual(
            ubuntu_desktop_session_from_context(context),
            {
                "desktop_user": "user",
                "desktop_home": "/home/user",
                "display": ":0",
                "xauthority": "/run/user/1000/gdm/Xauthority",
            },
        )
        command = wrap_pyautogui_python("pyautogui.click(1, 2)", platform="ubuntu", context=context)

        self.assertIn("/home/user/.workflowgym/workflowgym_interactive_flask_runner.log", command)
        self.assertIn("WORKFLOWGYM_FLASK_AGENT_RESULT", command)
        self.assertNotIn("/tmp/workflowgym_pyautogui.py", command)

    def test_wrapper_aliases_pyautogui_sleep_to_time_sleep(self):
        windows_command = wrap_pyautogui_python("pyautogui.sleep(0.5)", platform="windows")
        linux_command = wrap_pyautogui_python(
            "pyautogui.sleep(0.5)",
            platform="ubuntu",
            ubuntu_runner_mode="legacy",
        )

        self.assertIn("import time", windows_command)
        self.assertIn("pyautogui.sleep = time.sleep", windows_command)
        self.assertIn("pyautogui.sleep(0.5)", windows_command)
        self.assertIn("pyautogui.sleep = time.sleep", linux_command)


class RemoteActionTimeoutPolicyTest(unittest.TestCase):
    def test_is_remote_action_timeout_error_detects_runcommand_timeout(self):
        self.assertTrue(is_remote_action_timeout_error(TimeoutError("等待 RunCommand 超时: ivk-test")))
        self.assertTrue(
            is_remote_action_timeout_error(ValueError("RunCommand 执行失败: TaskExecutionTimeout"))
        )
        self.assertTrue(
            is_remote_action_timeout_error(
                ValueError("workflowgym file queue action timed out: action-id")
            )
        )

    def test_is_remote_action_timeout_error_rejects_non_timeout_failures(self):
        self.assertFalse(is_remote_action_timeout_error(ValueError("RunCommand 执行失败: awk syntax error")))

    def test_action_timeout_should_continue_by_default(self):
        with mock.patch.dict("os.environ", {}, clear=True):
            self.assertTrue(action_timeout_should_continue())

    def test_action_timeout_fail_sample_env_restores_old_behavior(self):
        with mock.patch.dict("os.environ", {"ACTION_TIMEOUT_FAIL_SAMPLE": "1"}, clear=False):
            self.assertFalse(action_timeout_should_continue())


class SamplerActionTimeoutContinueTest(unittest.TestCase):
    def test_execute_step_actions_continues_after_timeout(self):
        env = types.SimpleNamespace(run_command=mock.Mock(side_effect=TimeoutError("等待 RunCommand 超时: ivk-test")))
        sampler = Sampler(agent_factory=mock.Mock(), env=env)
        job = SampleJob(
            run_id="run-test",
            task_id="42",
            sample_index=1,
            task=TaskRecord(run_id="run-test", task_id="42", row_number=1, fields={}),
            config=RunConfig(run_id="run-test", player="kimi", step_num=1),
            lease=types.SimpleNamespace(instance_id="i-test"),
        )
        context = sampler.create_context(job, "/tmp/sample")
        run_state = SampleRunState()
        action_result = StepActionResult(executed_code=["pyautogui.click(1, 2)"])

        with mock.patch("open_workflowgym.sampler.append_exception"), mock.patch(
            "open_workflowgym.sampler.trace_sample"
        ), mock.patch.object(sampler, "wait_after_action"), mock.patch(
            "open_workflowgym.sampler.prepare_remote_action_command", return_value=("#!/bin/bash\necho ok", None)
        ):
            should_stop = sampler.execute_step_actions(job, "/tmp/sample", context, mock.Mock(), run_state, action_result, 0)

        self.assertFalse(should_stop)
        self.assertEqual(len(run_state.exceptions), 1)
        self.assertEqual(run_state.exceptions[0]["stage"], "execute_action_timeout")
        self.assertEqual(run_state.status, SampleStatus.SAMPLE_MAX_STEPS_REACHED.value)

    def test_execute_step_actions_continues_after_runcommand_timeout_value_error(self):
        timeout_error = ValueError(
            "RunCommand 执行失败: [{'error_code': 'TaskExecutionTimeout', 'error_message': 'Task execution timeout'}]"
        )
        env = types.SimpleNamespace(run_command=mock.Mock(side_effect=timeout_error))
        sampler = Sampler(agent_factory=mock.Mock(), env=env)
        job = SampleJob(
            run_id="run-test",
            task_id="258",
            sample_index=1,
            task=TaskRecord(run_id="run-test", task_id="258", row_number=1, fields={"系统类型": "Ubuntu"}),
            config=RunConfig(run_id="run-test", player="kimi", step_num=2),
            lease=types.SimpleNamespace(instance_id="i-test"),
        )
        context = sampler.create_context(job, "/tmp/sample")
        run_state = SampleRunState()
        run_state.env_metadata = {
            "instance_platform": "ubuntu",
            "described_os_type": "Linux",
            "target_image_platform": "ubuntu",
            "target_image_os_type": "Linux/Ubuntu",
        }
        action_result = StepActionResult(executed_code=["paste_text(\"李明\")"])

        with mock.patch("open_workflowgym.sampler.append_exception") as append_exception, mock.patch(
            "open_workflowgym.sampler.trace_sample"
        ), mock.patch.object(sampler, "wait_after_action"), mock.patch(
            "open_workflowgym.sampler.prepare_remote_action_command", return_value=("#!/bin/bash\necho ok", None)
        ):
            should_stop = sampler.execute_step_actions(job, "/tmp/sample", context, mock.Mock(), run_state, action_result, 9)

        self.assertFalse(should_stop)
        self.assertEqual(len(run_state.exceptions), 1)
        self.assertEqual(run_state.exceptions[0]["stage"], "execute_action_timeout")
        self.assertEqual(run_state.exceptions[0]["instance_platform"], "ubuntu")
        append_exception.assert_called_once()


class FileQueueRetryPolicyTest(unittest.TestCase):
    def test_should_retry_only_for_infrastructure_errors(self):
        self.assertTrue(
            should_retry_windows_file_queue_error(
                ValueError("workflowgym file queue runner process missing")
            )
        )
        self.assertTrue(
            should_retry_windows_file_queue_error(
                ValueError("workflowgym file queue runner heartbeat stale age=999s")
            )
        )
        self.assertFalse(
            should_retry_windows_file_queue_error(
                ValueError("workflowgym file queue action failed: SyntaxError: unterminated string literal")
            )
        )
        self.assertFalse(
            should_retry_windows_file_queue_error(
                ValueError('RunCommand 执行失败: {"ok": false, "status": "error"}')
            )
        )
        self.assertTrue(
            should_retry_windows_file_queue_error(
                ValueError(
                    "RunCommand 执行失败: "
                    'if (-not $result.ok) { throw ("workflowgym file queue action failed: " + ...) } '
                    "workflowgym file queue action timed out: action-id"
                )
            )
        )

    def test_is_windows_file_queue_action_execution_error(self):
        self.assertTrue(
            is_windows_file_queue_action_execution_error(
                ValueError("workflowgym file queue action failed: exit_code=1")
            )
        )
        self.assertFalse(
            is_windows_file_queue_action_execution_error(
                ValueError("workflowgym file queue runner process missing")
            )
        )
        self.assertFalse(
            is_windows_file_queue_action_execution_error(
                ValueError(
                    'throw ("workflowgym file queue action failed: " + ($result | ConvertTo-Json)) '
                    "workflowgym file queue action timed out: action-id"
                )
            )
        )

    def test_is_remote_action_execution_error(self):
        self.assertTrue(
            is_remote_action_execution_error(
                ValueError("workflowgym file queue action failed: SyntaxError")
            )
        )
        self.assertTrue(
            is_runcommand_python_execution_error(
                ValueError(
                    "RunCommand 执行失败: [{'error_code': 'TaskExecutionFailed', "
                    "'decoded_output': 'IndentationError: unexpected indent\\n'}]"
                )
            )
        )
        self.assertTrue(
            is_remote_action_execution_error(
                ValueError(
                    "RunCommand 执行失败: [{'error_code': 'TaskExecutionFailed', "
                    "'decoded_output': '  File \"/tmp/workflowgym_pyautogui.py\", line 156\\n"
                    "    python3 /tmp/create_homebank.py\\nIndentationError: unexpected indent\\n'}]"
                )
            )
        )
        self.assertFalse(
            is_runcommand_python_execution_error(
                ValueError("RunCommand 执行失败: [{'error_code': 'TaskExecutionFailed', 'decoded_output': 'permission denied'}]")
            )
        )

    def test_disallowed_pyautogui_action_reason_rejects_shell_snippets(self):
        self.assertIsNotNone(
            disallowed_pyautogui_action_reason("cat > /tmp/create_homebank.py << 'EOF'\npyautogui.click(1, 2)")
        )
        self.assertIsNotNone(disallowed_pyautogui_action_reason("python3 /tmp/create_homebank.py"))
        self.assertIsNone(disallowed_pyautogui_action_reason("pyautogui.click(100, 200)\npyautogui.typewrite('hello')"))

    def test_wrap_pyautogui_python_rejects_shell_snippets(self):
        with self.assertRaises(ValueError):
            wrap_pyautogui_python("cat << 'EOF'\npyautogui.click(1, 2)", platform="ubuntu")

    def test_kimi_to_pyautogui_skips_disallowed_code(self):
        adapter = KimiNativeAgentAdapter()
        context = SampleContext(
            run_id="run-test",
            task=TaskRecord(run_id="run-test", task_id="330", row_number=1, fields={}),
            sample_index=1,
            sample_dir="/tmp/sample",
            metadata={"platform": "ubuntu"},
        )
        executed_code = adapter.to_pyautogui(
            [{"action": "python3 /tmp/create_homebank.py\npyautogui.click(1, 2)"}],
            context,
        )
        self.assertEqual(executed_code, [])

    def test_parse_response_to_cot_and_action_rejects_shell_code_block(self):
        response = {
            "content": "## Action\n\n```code\ncat > /tmp/foo.py << 'EOF'\nprint('bad')\nEOF\npyautogui.click(0.1, 0.2)\n```"
        }
        _, actions, sections = parse_response_to_cot_and_action(response, (1920, 1080))
        self.assertEqual(actions, ["SKIP"])
        self.assertIn("rejected_code_reason", sections)

    def test_is_disallowed_pyautogui_action_error(self):
        self.assertTrue(is_disallowed_pyautogui_action_error(ValueError("disallowed non-pyautogui snippet: cat heredoc")))
        self.assertFalse(is_disallowed_pyautogui_action_error(ValueError("RunCommand 执行失败")))

    def test_action_execution_should_continue_by_default(self):
        with mock.patch.dict("os.environ", {}, clear=True):
            self.assertTrue(action_execution_should_continue())

    def test_action_execution_fail_sample_env_restores_old_behavior(self):
        with mock.patch.dict("os.environ", {"ACTION_EXECUTION_FAIL_SAMPLE": "1"}, clear=False):
            self.assertFalse(action_execution_should_continue())


class SamplerActionExecutionContinueTest(unittest.TestCase):
    def test_execute_step_actions_continues_after_action_failure(self):
        env = types.SimpleNamespace(
            run_command=mock.Mock(
                side_effect=ValueError(
                    "workflowgym file queue action failed: SyntaxError: unterminated string literal"
                )
            )
        )
        sampler = Sampler(agent_factory=mock.Mock(), env=env)
        job = SampleJob(
            run_id="run-test",
            task_id="324",
            sample_index=1,
            task=TaskRecord(run_id="run-test", task_id="324", row_number=1, fields={}),
            config=RunConfig(run_id="run-test", player="kimi", step_num=1),
            lease=types.SimpleNamespace(instance_id="i-test"),
        )
        context = sampler.create_context(job, "/tmp/sample")
        run_state = SampleRunState()
        action_result = StepActionResult(executed_code=['pyautogui.typewrite("bad")'])

        with mock.patch("open_workflowgym.sampler.append_exception"), mock.patch(
            "open_workflowgym.sampler.trace_sample"
        ), mock.patch.object(sampler, "wait_after_action"), mock.patch(
            "open_workflowgym.sampler.prepare_remote_action_command",
            return_value=("workflowgym_file_queue_action.json", None),
        ):
            should_stop = sampler.execute_step_actions(
                job, "/tmp/sample", context, mock.Mock(), run_state, action_result, 16
            )

        self.assertFalse(should_stop)
        self.assertEqual(len(run_state.exceptions), 1)
        self.assertEqual(run_state.exceptions[0]["stage"], "execute_action_action_error")


class ScreenshotFailurePolicyTest(unittest.TestCase):
    def test_is_remote_screenshot_error_detects_console_screenshot_timeout(self):
        self.assertTrue(
            is_remote_screenshot_error(TimeoutError("GetConsoleScreenshot 总超时: instance_id=i-test timeout=120s"))
        )
        self.assertTrue(
            is_remote_screenshot_error(
                ValueError('{"Error":{"Code":"InvalidTimestamp","Message":"The Signature of the request is expired"}}')
            )
        )

    def test_screenshot_failure_should_continue_by_default(self):
        with mock.patch.dict("os.environ", {}, clear=True):
            self.assertTrue(screenshot_failure_should_continue())

    def test_screenshot_fail_sample_env_restores_old_behavior(self):
        with mock.patch.dict("os.environ", {"SCREENSHOT_FAIL_SAMPLE": "1"}, clear=False):
            self.assertFalse(screenshot_failure_should_continue())


class SamplerScreenshotContinueTest(unittest.TestCase):
    def test_capture_step_screenshot_retries_once_after_flow_limit(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            flow_error = RuntimeError(
                "(429)\nReason: Too Many Requests\nFlowLimitExceeded"
            )
            screenshot_path = Path(temp_dir) / "screenshot_1.png"
            screenshot_path.write_bytes(b"png")
            env = types.SimpleNamespace(
                capture_screenshot=mock.Mock(side_effect=[flow_error, str(screenshot_path)])
            )
            sampler = Sampler(agent_factory=mock.Mock(), env=env)
            job = SampleJob(
                run_id="run-test",
                task_id="173",
                sample_index=1,
                task=TaskRecord(run_id="run-test", task_id="173", row_number=1, fields={}),
                config=RunConfig(run_id="run-test", player="kimi", step_num=2),
                lease=types.SimpleNamespace(instance_id="i-test"),
            )
            context = sampler.create_context(job, temp_dir)
            run_state = SampleRunState()

            with mock.patch.dict(
                "os.environ",
                {"SCREENSHOT_RETRY_MAX_ATTEMPTS": "2", "SCREENSHOT_RETRY_SLEEP_SECONDS": "10"},
                clear=False,
            ), mock.patch("open_workflowgym.sampler.time.sleep", return_value=None) as sleep:
                out = sampler.capture_step_screenshot(job, temp_dir, context, run_state, 1)

            self.assertEqual(out, str(screenshot_path))
            self.assertEqual(env.capture_screenshot.call_count, 2)
            sleep.assert_called_once_with(10.0)
            self.assertEqual(run_state.exceptions, [])

    def test_capture_step_screenshot_uses_fallback_and_records_exception(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            fallback = Path(temp_dir) / "step_0.jpg"
            fallback.write_bytes(b"jpeg")
            env = types.SimpleNamespace(
                capture_screenshot=mock.Mock(
                    side_effect=TimeoutError("GetConsoleScreenshot 总超时: instance_id=i-test timeout=120s")
                )
            )
            sampler = Sampler(agent_factory=mock.Mock(), env=env)
            job = SampleJob(
                run_id="run-test",
                task_id="173",
                sample_index=1,
                task=TaskRecord(run_id="run-test", task_id="173", row_number=1, fields={}),
                config=RunConfig(run_id="run-test", player="kimi", step_num=2),
                lease=types.SimpleNamespace(instance_id="i-test"),
            )
            context = sampler.create_context(job, temp_dir)
            context.current_screenshot = str(fallback)
            run_state = SampleRunState()

            with mock.patch.dict(
                "os.environ",
                {"SCREENSHOT_RETRY_MAX_ATTEMPTS": "2", "SCREENSHOT_RETRY_SLEEP_SECONDS": "0"},
                clear=False,
            ), mock.patch("open_workflowgym.sampler.append_exception"), mock.patch(
                "open_workflowgym.sampler.trace_sample"
            ):
                screenshot = sampler.capture_step_screenshot(job, temp_dir, context, run_state, 1)

            self.assertEqual(screenshot, str(fallback))
            self.assertEqual(env.capture_screenshot.call_count, 2)
            self.assertEqual(len(run_state.exceptions), 1)
            self.assertEqual(run_state.exceptions[0]["stage"], "capture_screenshot_timeout")

    def test_run_step_skips_model_when_screenshot_fails_without_fallback(self):
        env = types.SimpleNamespace(
            capture_screenshot=mock.Mock(
                side_effect=TimeoutError("GetConsoleScreenshot 总超时: instance_id=i-test timeout=120s")
            )
        )
        sampler = Sampler(agent_factory=mock.Mock(), env=env)
        job = SampleJob(
            run_id="run-test",
            task_id="173",
            sample_index=1,
            task=TaskRecord(run_id="run-test", task_id="173", row_number=1, fields={}),
            config=RunConfig(run_id="run-test", player="kimi", step_num=2),
            lease=types.SimpleNamespace(instance_id="i-test"),
        )
        context = sampler.create_context(job, "/tmp/sample")
        run_state = SampleRunState()
        player = mock.Mock()
        player.dynamic_prompts = False
        player.before_step = mock.Mock()

        with mock.patch("open_workflowgym.sampler.append_exception"), mock.patch(
            "open_workflowgym.sampler.trace_sample"
        ), mock.patch.object(sampler, "build_step_action") as build_step_action:
            should_stop = sampler.run_step(job, "/tmp/sample", context, player, run_state, 0)

        self.assertFalse(should_stop)
        build_step_action.assert_not_called()
        self.assertEqual(len(run_state.exceptions), 1)


if __name__ == "__main__":
    unittest.main()
