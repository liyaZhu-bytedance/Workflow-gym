from __future__ import annotations

import json
import os
import re
import shlex
import subprocess
import sys
import time
import unittest
import warnings
from pathlib import Path

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.envs.volcengine_env import (
    VolcengineEnv,
    build_windows_autologon_command,
    build_windows_interactive_flask_runner_setup_command,
    build_windows_probe_flask_runner_command,
    command_decoded_output,
    windows_flask_exec_timeout_seconds,
    windows_flask_runner_port,
    windows_flask_runner_token,
    windows_login_password,
    windows_login_user,
)


DEFAULT_INSTANCE_ID = "i-yeq4lecmpsnu262idoso"
DEFAULT_FLASK_RUNNER_PORT = 8080
REF_SCREEN_WIDTH = 1024
REF_SCREEN_HEIGHT = 768
# Win10/Server 任务栏：开始按钮宽约 48px，搜索框在其右侧
REF_START_BUTTON_WIDTH = 48
REF_TASKBAR_HEIGHT = 40
REF_SEARCH_BOX_LEFT = 52
REF_SEARCH_BOX_WIDTH = 220
REF_SEARCH_BOX_X = REF_SEARCH_BOX_LEFT + REF_SEARCH_BOX_WIDTH // 2
REF_SEARCH_BOX_Y = REF_SCREEN_HEIGHT - REF_TASKBAR_HEIGHT // 2
DEFAULT_SEARCH_TEXT = "photoshop"
DEFAULT_UI_SETTLE_SECONDS = 5
DEFAULT_POST_CLICK_SCREENSHOT_SECONDS = 3
DEFAULT_POST_CLICK_UI_ANIMATION_SECONDS = 0
ZSHRC_ENV_NAMES = (
    "AK",
    "SK",
    "WINDOWS_LOGIN_PASSWORD",
    "INSTANCE_PASSWORD",
    "VOLCENGINE_REGION",
    "SOURCE_REGION",
    "WORKFLOWGYM_TEST_INSTANCE_ID",
)


def read_env(name: str, default: str = "") -> str:
    return os.getenv(name, default)


def load_zshrc_env(names: tuple[str, ...] = ZSHRC_ENV_NAMES, zshrc_path: str = "") -> None:
    missing = [name for name in names if not read_env(name)]
    if not missing:
        return
    zshrc = Path(zshrc_path or os.path.expanduser("~/.zshrc"))
    if not zshrc.is_file():
        return
    zshrc_quoted = shlex.quote(str(zshrc))
    for name in missing:
        try:
            completed = subprocess.run(
                ["zsh", "-lc", "source %s >/dev/null 2>&1; print -r -- ${%s:-}" % (zshrc_quoted, name)],
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        value = (completed.stdout or "").strip()
        if value:
            os.environ[name] = value


def resolve_flask_runner_port() -> int:
    raw = read_env("WORKFLOWGYM_FLASK_RUNNER_PORT")
    if raw:
        return int(raw)
    return windows_flask_runner_port() or DEFAULT_FLASK_RUNNER_PORT


def flask_action_http_timeout_seconds() -> int:
    explicit = read_env("WORKFLOWGYM_FLASK_ACTION_HTTP_TIMEOUT_SECONDS")
    if explicit:
        return max(30, int(explicit))
    return max(30, windows_flask_exec_timeout_seconds() + 15)


def compute_search_box_coords(width: int, height: int) -> tuple[int, int]:
    scale = width / REF_SCREEN_WIDTH if REF_SCREEN_WIDTH > 0 else 1.0
    start_w = max(32, round(REF_START_BUTTON_WIDTH * scale))
    search_left = max(start_w + 4, round(REF_SEARCH_BOX_LEFT * scale))
    search_w = max(120, round(REF_SEARCH_BOX_WIDTH * scale))
    x = search_left + search_w // 2
    taskbar_h = max(32, round(REF_TASKBAR_HEIGHT * scale))
    y = max(1, height - taskbar_h // 2)
    return x, y


def resolve_search_box_coords(screen_size: list[int] | tuple[int, ...] | None = None) -> tuple[int, int, str]:
    explicit_x = read_env("WORKFLOWGYM_SEARCH_BOX_X")
    explicit_y = read_env("WORKFLOWGYM_SEARCH_BOX_Y")
    if explicit_x and explicit_y:
        return int(explicit_x), int(explicit_y), "fixed"
    if screen_size and len(screen_size) >= 2:
        width, height = int(screen_size[0]), int(screen_size[1])
        if width > 0 and height > 0:
            return (*compute_search_box_coords(width, height), "auto")
    return REF_SEARCH_BOX_X, REF_SEARCH_BOX_Y, "fallback"


def parse_flask_health_payload(output: str) -> dict:
    marker = "WORKFLOWGYM_FLASK_HEALTH_RESULT"
    if marker not in output:
        marker = "WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_HEALTH"
    start = output.find(marker)
    if start < 0:
        return {}
    tail = output[start:].split("\n", 1)[-1].strip()
    match = re.search(r"\{.*\}", tail)
    if not match:
        return {}
    try:
        return json.loads(match.group(0))
    except json.JSONDecodeError:
        return {}


load_zshrc_env()
os.environ.setdefault("WINDOWS_ACTION_RUNNER", "flask")
os.environ.setdefault("WORKFLOWGYM_FLASK_RUNNER_PORT", str(DEFAULT_FLASK_RUNNER_PORT))


def flask_get_health_command(port: int, token: str) -> str:
    token_literal = json.dumps(str(token))
    return r"""$ErrorActionPreference = 'Stop'
$port = __PORT__
$token = __TOKEN__
$logPath = 'C:\Users\Administrator\Desktop\workflowgym_interactive_flask_runner.log'

$identity = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$sessionId = (Get-Process -Id $PID).SessionId
Write-Output ('WORKFLOWGYM_RUNCOMMAND_IDENTITY identity=' + $identity + ' session=' + $sessionId)

$headers = @{ 'X-WorkflowGym-Token' = $token }
try {
  $health = Invoke-RestMethod -Uri ('http://127.0.0.1:' + $port + '/health') -Method Get -Headers $headers -TimeoutSec 30
} catch {
  if (Test-Path -LiteralPath $logPath) {
    Write-Output 'WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_LOG'
    Get-Content -LiteralPath $logPath -Tail 40
  }
  throw $_
}
Write-Output 'WORKFLOWGYM_FLASK_HEALTH_RESULT'
$health | ConvertTo-Json -Depth 8 -Compress
if (-not $health.ok) {
  throw ('flask health not ok: ' + ($health | ConvertTo-Json -Compress))
}
""".replace("__PORT__", str(int(port))).replace("__TOKEN__", token_literal)


def flask_post_python_action_command(script: str, port: int, token: str, http_timeout: int) -> str:
    token_literal = json.dumps(str(token))
    return r"""$ErrorActionPreference = 'Stop'
$port = __PORT__
$token = __TOKEN__
$httpTimeout = __HTTP_TIMEOUT__
$logPath = 'C:\Users\Administrator\Desktop\workflowgym_interactive_flask_runner.log'
$script = @'
__PYTHON_SCRIPT__
'@

$identity = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$sessionId = (Get-Process -Id $PID).SessionId
Write-Output ('WORKFLOWGYM_RUNCOMMAND_IDENTITY identity=' + $identity + ' session=' + $sessionId)

$actionId = [guid]::NewGuid().ToString()
$payload = [ordered]@{
  action = 'python'
  id = $actionId
  source = 'workflowgym_stop_start_flask_e2e'
  script_b64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($script))
}
$headers = @{
  'X-WorkflowGym-Token' = $token
  'Content-Type' = 'application/json'
}
try {
  $result = Invoke-RestMethod -Uri ('http://127.0.0.1:' + $port + '/action') -Method Post -Headers $headers -Body ($payload | ConvertTo-Json -Depth 8 -Compress) -TimeoutSec $httpTimeout
} catch {
  if (Test-Path -LiteralPath $logPath) {
    Write-Output 'WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_LOG'
    Get-Content -LiteralPath $logPath -Tail 40
  }
  throw $_
}
Write-Output 'WORKFLOWGYM_FLASK_ACTION_RESULT'
$result | ConvertTo-Json -Depth 12 -Compress
if ($result.output) {
  Write-Output $result.output
}
if ($result.stderr) {
  Write-Output $result.stderr
}
if (-not $result.ok) {
  throw ("workflowgym flask action failed: " + ($result | ConvertTo-Json -Depth 12 -Compress))
}
""".replace("__PYTHON_SCRIPT__", script).replace("__PORT__", str(int(port))).replace("__TOKEN__", token_literal).replace("__HTTP_TIMEOUT__", str(int(http_timeout)))


def pyautogui_click_search_box_and_type_script(
    search_text: str = DEFAULT_SEARCH_TEXT,
    search_box_x: int | None = None,
    search_box_y: int | None = None,
    post_type_animation_seconds: float = DEFAULT_POST_CLICK_UI_ANIMATION_SECONDS,
) -> str:
    search_text_literal = json.dumps(str(search_text))
    if search_box_x is not None and search_box_y is not None:
        coord_block = (
            "width, height = pyautogui.size()\n"
            "search_box_x = __SEARCH_BOX_X__\n"
            "search_box_y = __SEARCH_BOX_Y__\n"
            'print("PYAUTOGUI_SEARCH_BOX_MODE fixed")'
        )
        coord_block = coord_block.replace("__SEARCH_BOX_X__", str(int(search_box_x))).replace("__SEARCH_BOX_Y__", str(int(search_box_y)))
    else:
        coord_block = (
            "width, height = pyautogui.size()\n"
            "ref_w, ref_h = __REF_W__, __REF_H__\n"
            "start_btn_w, taskbar_h = __START_BTN_W__, __TASKBAR_H__\n"
            "search_left_ref, search_w_ref = __SEARCH_LEFT__, __SEARCH_WIDTH__\n"
            "scale = width / ref_w if ref_w > 0 else 1.0\n"
            "start_w = max(32, round(start_btn_w * scale))\n"
            "search_left = max(start_w + 4, round(search_left_ref * scale))\n"
            "search_w = max(120, round(search_w_ref * scale))\n"
            "search_box_x = search_left + search_w // 2\n"
            "bar_h = max(32, round(taskbar_h * scale))\n"
            "search_box_y = max(1, height - bar_h // 2)\n"
            'print("PYAUTOGUI_SEARCH_BOX_MODE auto")'
        )
        coord_block = (
            coord_block.replace("__REF_W__", str(REF_SCREEN_WIDTH))
            .replace("__REF_H__", str(REF_SCREEN_HEIGHT))
            .replace("__START_BTN_W__", str(REF_START_BUTTON_WIDTH))
            .replace("__TASKBAR_H__", str(REF_TASKBAR_HEIGHT))
            .replace("__SEARCH_LEFT__", str(REF_SEARCH_BOX_LEFT))
            .replace("__SEARCH_WIDTH__", str(REF_SEARCH_BOX_WIDTH))
        )
    return (
        """import subprocess
import time
import ctypes
import pyautogui

pyautogui.FAILSAFE = False
SEARCH_TEXT = __SEARCH_TEXT__
POST_TYPE_ANIMATION_SECONDS = __POST_TYPE_ANIMATION_SECONDS__

def enable_dpi_awareness():
    if not hasattr(ctypes, "windll"):
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass

enable_dpi_awareness()

def close_visible_cmd_windows():
    ps = (
        "$ErrorActionPreference='SilentlyContinue';"
        "Get-Process cmd -ErrorAction SilentlyContinue | "
        "Where-Object { $_.MainWindowHandle -ne 0 } | "
        "Stop-Process -Force"
    )
    subprocess.run(
        ["powershell", "-NoProfile", "-Command", ps],
        capture_output=True,
        text=True,
        timeout=15,
    )

def dismiss_ui():
    pyautogui.press("esc")
    time.sleep(0.3)
    pyautogui.press("esc")
    time.sleep(0.2)
    close_visible_cmd_windows()
    time.sleep(0.5)

print("PYAUTOGUI_PREP_CLOSE_CMD_START")
dismiss_ui()
print("PYAUTOGUI_PREP_CLOSE_CMD_DONE")

__COORD_BLOCK__
print("PYAUTOGUI_SIZE", (width, height))

print("PYAUTOGUI_SEARCH_BOX_START")
print("PYAUTOGUI_SEARCH_BOX_COORDS", (search_box_x, search_box_y))
pyautogui.moveTo(search_box_x, search_box_y, duration=0.2)
time.sleep(0.2)
print("WORKFLOWGYM_DEBUG_BEFORE_CLICK_SEARCH_BOX", (search_box_x, search_box_y))
pyautogui.click(search_box_x, search_box_y)
print("WORKFLOWGYM_DEBUG_AFTER_CLICK_SEARCH_BOX", (search_box_x, search_box_y))
time.sleep(0.3)
print("PYAUTOGUI_TYPE_TEXT", SEARCH_TEXT)
pyautogui.write(SEARCH_TEXT, interval=0.05)
time.sleep(POST_TYPE_ANIMATION_SECONDS)
print("PYAUTOGUI_SEARCH_BOX_DONE")
"""
        .replace("__COORD_BLOCK__", coord_block)
        .replace("__SEARCH_TEXT__", search_text_literal)
        .replace("__POST_TYPE_ANIMATION_SECONDS__", str(float(post_type_animation_seconds)))
    )


class WindowsStopStartFlaskE2ETest(unittest.TestCase):
    """Manual E2E: stop/start Windows instance, Flask runner in Session 1, RunCommand proxies HTTP."""

    def setUp(self):
        load_zshrc_env()
        os.environ["WINDOWS_ACTION_RUNNER"] = "flask"
        os.environ.setdefault("WORKFLOWGYM_FLASK_RUNNER_PORT", str(DEFAULT_FLASK_RUNNER_PORT))
        self.assertTrue(read_env("AK") and read_env("SK"), "AK/SK missing; set them in ~/.zshrc or the environment")
        self.instance_id = read_env("WORKFLOWGYM_TEST_INSTANCE_ID", DEFAULT_INSTANCE_ID)
        self.region = read_env("VOLCENGINE_REGION", read_env("SOURCE_REGION", "cn-guangzhou"))
        self.flask_token = read_env("WORKFLOWGYM_FLASK_RUNNER_TOKEN", windows_flask_runner_token())
        self.flask_port = resolve_flask_runner_port()
        self.flask_exec_timeout = windows_flask_exec_timeout_seconds()
        self.flask_http_timeout = flask_action_http_timeout_seconds()
        self.output_dir = Path(
            read_env(
                "WORKFLOWGYM_STOP_START_FLASK_TEST_OUTPUT_DIR",
                "output/manual_windows_stop_start_flask_test",
            )
        )
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.env = VolcengineEnv(region=self.region)
        self.admin_user = windows_login_user()
        self.ui_settle_seconds = int(read_env("WORKFLOWGYM_UI_SETTLE_SECONDS", str(DEFAULT_UI_SETTLE_SECONDS)))
        self.post_click_screenshot_seconds = float(
            read_env("WORKFLOWGYM_POST_CLICK_SCREENSHOT_SECONDS", str(DEFAULT_POST_CLICK_SCREENSHOT_SECONDS))
        )
        self.post_click_animation_seconds = float(
            read_env("WORKFLOWGYM_POST_CLICK_UI_ANIMATION_SECONDS", str(DEFAULT_POST_CLICK_UI_ANIMATION_SECONDS))
        )

    def debug_break(self, label: str) -> None:
        if read_env("WORKFLOWGYM_E2E_DEBUG", "0").lower() not in ("1", "true", "yes", "on"):
            return
        print("WORKFLOWGYM_E2E_DEBUG_BREAK", label, flush=True)
        breakpoint()

    def wait_for_ui_stable(self, label: str = "") -> None:
        print("WORKFLOWGYM_UI_SETTLE_WAIT", label, self.ui_settle_seconds, flush=True)
        time.sleep(self.ui_settle_seconds)

    def save_screenshot_after_settle(self, name: str, label: str = "") -> str:
        self.wait_for_ui_stable(label or name)
        return self.save_screenshot(name)

    def save_screenshot_after_click(self, name: str) -> str:
        # 输入完成后尽快截图（默认 3s 内），捕获搜索 面板/结果
        print("WORKFLOWGYM_POST_CLICK_SCREENSHOT_WAIT", self.post_click_screenshot_seconds, flush=True)
        time.sleep(self.post_click_screenshot_seconds)
        return self.save_screenshot(name)

    def run_flask_setup(self, password: str) -> str:
        setup_result = self.env.run_command(
            self.instance_id,
            build_windows_interactive_flask_runner_setup_command(
                self.admin_user,
                password,
                self.flask_token,
                self.flask_port,
            ),
            timeout=int(read_env("WINDOWS_FLASK_RUNNER_SETUP_TIMEOUT_SECONDS", "300")),
            command_type="PowerShell",
        )
        setup_output = command_decoded_output(setup_result)
        print("WORKFLOWGYM_FLASK_RUNNER_SETUP_RESULT", setup_result, flush=True)
        print("WORKFLOWGYM_FLASK_RUNNER_SETUP_OUTPUT", setup_output, flush=True)
        self.assertIn("WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_STARTED", setup_output)
        self.assertIn("WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_LAUNCH hidden_ps1", setup_output)
        self.assertIn("WORKFLOWGYM_PROBE_FLASK_RUNNER_OK", setup_output)
        if "hidden_vbs" in setup_output:
            raise AssertionError(
                "Flask setup 仍在使用 hidden_vbs 启动方式，请确认已加载最新 volcengine_env.py 后重试"
            )
        return setup_output

    def run_flask_probe(self, allow_setup_recovery: bool = True, password: str = "") -> str:
        probe_timeout = int(read_env("WINDOWS_FLASK_RUNNER_PROBE_TIMEOUT_SECONDS", "180"))
        try:
            probe_result = self.env.run_command(
                self.instance_id,
                build_windows_probe_flask_runner_command(self.flask_port, self.flask_token),
                timeout=probe_timeout,
                command_type="PowerShell",
            )
        except ValueError as exc:
            if not allow_setup_recovery or not password:
                raise
            print("WORKFLOWGYM_FLASK_RUNNER_PROBE_RECOVERY_SETUP", exc, flush=True)
            self.run_flask_setup(password)
            self.wait_for_ui_stable("after_flask_setup_recovery")
            probe_result = self.env.run_command(
                self.instance_id,
                build_windows_probe_flask_runner_command(self.flask_port, self.flask_token),
                timeout=probe_timeout,
                command_type="PowerShell",
            )
        probe_output = command_decoded_output(probe_result)
        print("WORKFLOWGYM_FLASK_RUNNER_PROBE_RESULT", probe_result, flush=True)
        print("WORKFLOWGYM_FLASK_RUNNER_PROBE_OUTPUT", probe_output, flush=True)
        self.assertIn("WORKFLOWGYM_PROBE_FLASK_RUNNER_OK", probe_output)
        return probe_output

    def configure_windows_autologin(self, password: str) -> str:
        if read_env("WINDOWS_CONFIGURE_AUTO_LOGIN", "1").lower() not in ("1", "true", "yes", "on"):
            print("WORKFLOWGYM_WINDOWS_AUTOLOGIN_SKIPPED", flush=True)
            return ""
        print("WORKFLOWGYM_WINDOWS_AUTOLOGIN_START", self.admin_user, flush=True)
        result = self.env.run_command(
            self.instance_id,
            build_windows_autologon_command(self.admin_user, password),
            timeout=int(read_env("WINDOWS_AUTO_LOGIN_TIMEOUT_SECONDS", "300")),
            command_type="PowerShell",
        )
        output = command_decoded_output(result)
        print("WORKFLOWGYM_WINDOWS_AUTOLOGIN_RESULT", result, flush=True)
        print("WORKFLOWGYM_WINDOWS_AUTOLOGIN_OUTPUT", output, flush=True)
        self.assertIn("WORKFLOWGYM_WINDOWS_AUTOLOGIN user=", output)
        return output

    def run_search_type_via_flask(self, action_script: str) -> str:
        """向 Flask runner 发送 pyautogui 点击搜索框并输入文本脚本。

        调试时在下列两行设断点，或开启 WORKFLOWGYM_E2E_DEBUG=1：
        - debug_break('before_search_type') 之后（action 尚未发出）
        - debug_break('after_search_type') 之后（VM 内 click+type 已完成）
        """
        run_command_timeout = max(
            self.flask_http_timeout + 30,
            int(read_env("WORKFLOWGYM_STOP_START_FLASK_ACTION_TIMEOUT_SECONDS", str(self.flask_http_timeout + 30))),
        )
        self.debug_break("before_search_type")
        action_result = self.env.run_command(
            self.instance_id,
            flask_post_python_action_command(
                action_script,
                self.flask_port,
                self.flask_token,
                self.flask_http_timeout,
            ),
            timeout=run_command_timeout,
            command_type="PowerShell",
        )
        action_output = command_decoded_output(action_result)
        self.debug_break("after_search_type")
        return action_output

    def test_stop_start_flask_runner_health_and_search_photoshop(self):
        password = windows_login_password()
        self.assertTrue(password, "WINDOWS_LOGIN_PASSWORD or INSTANCE_PASSWORD missing; set in ~/.zshrc or the environment")

        stop_timeout = int(read_env("INSTANCE_STOP_TIMEOUT_SECONDS", "600"))
        start_timeout = int(read_env("INSTANCE_START_TIMEOUT_SECONDS", "600"))
        autologin_wait = int(read_env("WINDOWS_AUTO_LOGIN_WAIT_SECONDS", "30"))
        search_text = read_env("WORKFLOWGYM_SEARCH_TEXT", DEFAULT_SEARCH_TEXT)
        search_mode = read_env("WORKFLOWGYM_SEARCH_BOX_X") and read_env("WORKFLOWGYM_SEARCH_BOX_Y")
        use_fixed_search = bool(search_mode)

        print("WORKFLOWGYM_TEST_INSTANCE", self.instance_id, flush=True)
        print("WORKFLOWGYM_TEST_ADMIN_USER", self.admin_user, flush=True)
        print("WORKFLOWGYM_WINDOWS_ACTION_RUNNER", read_env("WINDOWS_ACTION_RUNNER", "flask"), flush=True)
        print("WORKFLOWGYM_FLASK_PORT", self.flask_port, flush=True)
        print("WORKFLOWGYM_FLASK_EXEC_TIMEOUT", self.flask_exec_timeout, flush=True)
        print("WORKFLOWGYM_FLASK_HTTP_TIMEOUT", self.flask_http_timeout, flush=True)
        print("WORKFLOWGYM_SEARCH_TEXT", search_text, flush=True)
        print("WORKFLOWGYM_SEARCH_BOX_MODE", "fixed" if use_fixed_search else "auto", flush=True)
        print("WORKFLOWGYM_UI_SETTLE_SECONDS", self.ui_settle_seconds, flush=True)
        print("WORKFLOWGYM_POST_CLICK_SCREENSHOT_SECONDS", self.post_click_screenshot_seconds, flush=True)
        print("WORKFLOWGYM_POST_CLICK_UI_ANIMATION_SECONDS", self.post_click_animation_seconds, flush=True)

        before_stop = self.save_screenshot_after_settle("before_stop.jpg", "before_stop")
        print("WORKFLOWGYM_SCREENSHOT_BEFORE_STOP", before_stop, flush=True)

        self.env.ensure_cloud_assistant_ready(self.instance_id)
        self.configure_windows_autologin(password)

        print("WORKFLOWGYM_TEST_STOP_INSTANCE_START", flush=True)
        self.env.stop_instance(self.instance_id)
        self.env.wait_for_status(self.instance_id, "STOPPED", timeout_seconds=stop_timeout)
        print("WORKFLOWGYM_TEST_STOP_INSTANCE_DONE", flush=True)

        print("WORKFLOWGYM_TEST_START_INSTANCE_START", flush=True)
        self.env.start_instance(self.instance_id)
        self.env.wait_for_status(self.instance_id, "RUNNING", timeout_seconds=start_timeout)
        self.env.ensure_cloud_assistant_ready(self.instance_id)
        time.sleep(autologin_wait)
        print("WORKFLOWGYM_TEST_START_INSTANCE_DONE", flush=True)

        after_start = self.save_screenshot_after_settle("after_start_before_flask.jpg", "after_start_before_flask")
        print("WORKFLOWGYM_SCREENSHOT_AFTER_START", after_start, flush=True)

        self.run_flask_setup(password)

        self.wait_for_ui_stable("after_flask_setup")
        self.run_flask_probe(password=password)

        health_result = self.env.run_command(
            self.instance_id,
            flask_get_health_command(self.flask_port, self.flask_token),
            timeout=int(read_env("WORKFLOWGYM_STOP_START_FLASK_HEALTH_TIMEOUT_SECONDS", "60")),
            command_type="PowerShell",
        )
        health_output = command_decoded_output(health_result)
        health_payload = parse_flask_health_payload(health_output)
        print("WORKFLOWGYM_FLASK_HEALTH_VIA_RUNCOMMAND_RESULT", health_result, flush=True)
        print("WORKFLOWGYM_FLASK_HEALTH_VIA_RUNCOMMAND_OUTPUT", health_output, flush=True)
        print("WORKFLOWGYM_FLASK_HEALTH_PAYLOAD", health_payload, flush=True)
        self.assertIn("WORKFLOWGYM_FLASK_HEALTH_RESULT", health_output)
        self.assertTrue(health_payload.get("ok"), health_payload)
        self.assertEqual(health_payload.get("exec_mode"), "subprocess")
        self.assertEqual(int(health_payload.get("exec_timeout_seconds") or 0), self.flask_exec_timeout)
        screen_size = health_payload.get("screen_size") or []
        if screen_size and len(screen_size) >= 2:
            print(
                "WORKFLOWGYM_FLASK_HEALTH_SCREEN",
                screen_size[0],
                screen_size[1],
                flush=True,
            )

        search_box_x, search_box_y, coord_mode = resolve_search_box_coords(screen_size)
        print("WORKFLOWGYM_SEARCH_BOX_COORDS", search_box_x, search_box_y, coord_mode, flush=True)

        self.wait_for_ui_stable("before_search_box_click")

        if use_fixed_search:
            action_script = pyautogui_click_search_box_and_type_script(
                search_text,
                search_box_x,
                search_box_y,
                self.post_click_animation_seconds,
            )
        else:
            action_script = pyautogui_click_search_box_and_type_script(
                search_text,
                post_type_animation_seconds=self.post_click_animation_seconds,
            )

        action_output = self.run_search_type_via_flask(action_script)
        after_search = self.save_screenshot_after_click("after_flask_search_photoshop.jpg")
        print("WORKFLOWGYM_SCREENSHOT_AFTER_SEARCH", after_search, flush=True)

        print("WORKFLOWGYM_FLASK_ACTION_VIA_RUNCOMMAND_OUTPUT", action_output, flush=True)

        self.assertIn("PYAUTOGUI_PREP_CLOSE_CMD_START", action_output)
        self.assertIn("PYAUTOGUI_PREP_CLOSE_CMD_DONE", action_output)
        self.assertIn("PYAUTOGUI_SEARCH_BOX_START", action_output)
        self.assertIn("WORKFLOWGYM_DEBUG_BEFORE_CLICK_SEARCH_BOX", action_output)
        self.assertIn("WORKFLOWGYM_DEBUG_AFTER_CLICK_SEARCH_BOX", action_output)
        self.assertIn("PYAUTOGUI_TYPE_TEXT %s" % search_text, action_output)
        self.assertIn("PYAUTOGUI_SEARCH_BOX_DONE", action_output)
        if use_fixed_search:
            self.assertIn("PYAUTOGUI_SEARCH_BOX_MODE fixed", action_output)
            self.assertIn("PYAUTOGUI_SEARCH_BOX_COORDS (%s, %s)" % (search_box_x, search_box_y), action_output)
        else:
            self.assertIn("PYAUTOGUI_SEARCH_BOX_MODE auto", action_output)
            self.assertIn("PYAUTOGUI_SEARCH_BOX_COORDS (%s, %s)" % (search_box_x, search_box_y), action_output)

        self.assertIn("WORKFLOWGYM_RUNCOMMAND_IDENTITY", action_output)
        self.assertIn("WORKFLOWGYM_FLASK_ACTION_RESULT", action_output)

    def save_screenshot(self, name: str) -> str:
        screenshot = self.env.get_console_screenshot(self.instance_id)
        self.assertTrue(screenshot, "GetConsoleScreenshot returned empty payload")
        path = self.output_dir / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(screenshot)
        return str(path)


if __name__ == "__main__":
    unittest.main()
