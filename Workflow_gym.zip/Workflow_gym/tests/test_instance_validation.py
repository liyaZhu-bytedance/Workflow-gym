from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.envs.instance_validation import (
    append_env_exception,
    resolve_probe_max_workers,
    validate_discovered_instances,
)
from open_workflowgym.envs.lease_backend import LocalLeaseBackend
from open_workflowgym.envs.instance_pool import InstancePool
from open_workflowgym.platform_utils import resolve_task_platform
from open_workflowgym.records import RunConfig, SampleJob, TaskRecord
from open_workflowgym.state_store import StateStore


class InstanceValidationTest(unittest.TestCase):
    def test_validate_discovered_instances_logs_only_failures(self):
        env = mock.Mock()
        env.dry_run = False
        env.ensure_instance_running = mock.Mock(return_value="RUNNING")
        env.probe_cloud_assistant_platform = mock.Mock(return_value={"Output": "ok"})
        instances = [
            {"InstanceId": "i-ubuntu", "InstanceName": "open_workflow_gym_ubuntu", "Status": "RUNNING"},
            {"InstanceId": "i-bad", "InstanceName": "open_workflow_gym_unknown", "Status": "RUNNING"},
        ]
        with tempfile.TemporaryDirectory() as tmp_dir:
            log_path = Path(tmp_dir) / "env_exception.log"
            validated, platforms = validate_discovered_instances(env, instances, log_path)
            self.assertEqual(validated, ["i-ubuntu"])
            self.assertEqual(platforms["i-ubuntu"], "ubuntu")
            lines = log_path.read_text(encoding="utf-8").strip().splitlines()
            self.assertEqual(len(lines), 1)
            payload = json.loads(lines[0])
            self.assertEqual(payload["status"], "failed")
            self.assertEqual(payload["instance_id"], "i-bad")

    def test_validate_discovered_instances_runs_probes_in_parallel(self):
        env = mock.Mock()
        env.dry_run = False
        env.ensure_instance_running = mock.Mock(return_value="RUNNING")
        started = []
        lock = __import__("threading").Lock()

        def fake_probe(instance_id: str, _platform: str):
            with lock:
                started.append(instance_id)
            return {"Output": "WORKFLOWGYM_CA_PROBE_OK"}

        env.probe_cloud_assistant_platform = mock.Mock(side_effect=fake_probe)
        instances = [
            {"InstanceId": "i-1", "InstanceName": "open_workflow_gym_ubuntu", "Status": "RUNNING"},
            {"InstanceId": "i-2", "InstanceName": "open_workflow_gym_ubuntu", "Status": "RUNNING"},
            {"InstanceId": "i-3", "InstanceName": "open_workflow_gym_windows", "Status": "RUNNING"},
        ]
        with tempfile.TemporaryDirectory() as tmp_dir:
            log_path = Path(tmp_dir) / "env_exception.log"
            validated, platforms = validate_discovered_instances(env, instances, log_path, max_workers=3)
            self.assertEqual(sorted(validated), ["i-1", "i-2", "i-3"])
            self.assertEqual(platforms["i-3"], "windows")
            self.assertEqual(env.probe_cloud_assistant_platform.call_count, 3)
            self.assertEqual(env.ensure_instance_running.call_count, 3)

    def test_validate_discovered_instances_starts_stopped_instance_before_probe(self):
        env = mock.Mock()
        env.dry_run = False
        env.ensure_instance_running = mock.Mock(return_value="RUNNING")
        env.probe_cloud_assistant_platform = mock.Mock(return_value={"Output": "WORKFLOWGYM_CA_PROBE_OK"})
        instances = [
            {"InstanceId": "i-stopped", "InstanceName": "open_workflow_gym_ubuntu", "Status": "STOPPED"},
        ]
        with tempfile.TemporaryDirectory() as tmp_dir:
            log_path = Path(tmp_dir) / "env_exception.log"
            validated, platforms = validate_discovered_instances(env, instances, log_path)
            self.assertEqual(validated, ["i-stopped"])
            self.assertEqual(platforms["i-stopped"], "ubuntu")
            env.ensure_instance_running.assert_called_once_with("i-stopped")
            env.probe_cloud_assistant_platform.assert_called_once_with("i-stopped", "ubuntu")

    def test_resolve_probe_max_workers_caps_by_instance_count(self):
        self.assertEqual(resolve_probe_max_workers(26, 8), 8)
        self.assertEqual(resolve_probe_max_workers(3, 8), 3)
        self.assertEqual(resolve_probe_max_workers(0, 8), 1)

    def test_local_lease_backend_acquires_matching_platform_only(self):
        backend = LocalLeaseBackend(
            ["i-win", "i-ubuntu"],
            {"i-win": "windows", "i-ubuntu": "ubuntu"},
        )
        ubuntu_lease = backend.acquire("run", "42", 1, "ubuntu")
        self.assertEqual(ubuntu_lease.instance_id, "i-ubuntu")
        backend.release(ubuntu_lease.lease_id)
        win_lease = backend.acquire("run", "324", 1, "windows")
        self.assertEqual(win_lease.instance_id, "i-win")
        self.assertIsNone(backend.acquire("run", "324", 2, "windows"))
        backend.release(win_lease.lease_id)
        self.assertIsNotNone(backend.acquire("run", "42", 2, "ubuntu"))

    def test_instance_pool_acquire_status(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            pool = InstancePool(
                ["i-ubuntu"],
                StateStore(str(Path(tmp_dir) / "state.db")),
                {"i-ubuntu": "ubuntu"},
            )
            self.assertEqual(pool.acquire_status("ubuntu"), "available")
            pool.acquire("run", "42", 1, "ubuntu")
            self.assertEqual(pool.acquire_status("ubuntu"), "wait")
            self.assertEqual(pool.acquire_status("windows"), "unavailable")

    def test_resolve_task_platform_prefers_task_fields(self):
        task = TaskRecord(
            run_id="run",
            task_id="42",
            row_number=1,
            fields={"系统类型": "Ubuntu", "image": "image-ubuntu"},
        )
        self.assertEqual(resolve_task_platform(task, {"image-ubuntu": "windows"}), "ubuntu")


if __name__ == "__main__":
    unittest.main()
