import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))

from publish_guangzhou_images_to_huggingface import (
    STATUS_DOWNLOADED,
    STATUS_EXPORTED,
    STATUS_FAILED,
    STATUS_PENDING,
    STATUS_SKIPPED_DISK,
    STATUS_SKIPPED_WINDOWS,
    STATUS_UPLOADED,
    apply_manifest_record_to_csv_row,
    cleanup_local_image_files,
    empty_csv_row,
    estimate_tos_object_bytes,
    inventory_tos_ready_images,
    lookup_tos_object_size,
    match_tos_uris_for_image,
    parse_tosutil_ls_entries,
    parse_tosutil_ls_object_sizes,
    parse_tosutil_ls_object_uris,
    produce_tos_ready_job,
    reconcile_uploaded_from_hf_repos,
    run_producer_consumer_pipeline,
    sort_images_tos_ready_first,
    sync_csv_from_manifest,
)


class TestPublishGuangzhouImagesHelpers(unittest.TestCase):
    def test_parse_tosutil_ls_object_uris(self):
        stdout = """
Start at 2026-07-16 13:19:50.040074 +0000 UTC

Listing objects .

Object list:
key                                               LastModified                  Size      StorageClass        ETag
tos://open-workflowgym-sample/open_image-abc/image.qcow2
                                                  2026-07-16T13:19:50Z          10GB      STANDARD            "abc"
tos://open-workflowgym-sample/open_image-def/image.qcow2    2026-07-16T13:19:50Z          12GB   STANDARD "def"

Total size of prefix [open/] is: 10GB
File number is: 2
"""
        uris = parse_tosutil_ls_object_uris(stdout, "open-workflowgym-sample", "open_image-abc")
        self.assertEqual(
            uris,
            [
                "tos://open-workflowgym-sample/open_image-abc/image.qcow2",
                "tos://open-workflowgym-sample/open_image-def/image.qcow2",
            ],
        )

    def test_parse_tosutil_multiline_table_and_raw_sizes(self):
        human = """
Object list:
key                                               LastModified                  Size      StorageClass        ETag
tos://open-workflowgym-sample/yepzr00q2xkhx1xt8gw6_image-yepzr00q2xkhx1xt8gw6_system.qcow2
                                                  2026-07-16T15:37:49Z          48.02GB   STANDARD            "etag-1"
"""
        sizes = parse_tosutil_ls_object_sizes(human, "open-workflowgym-sample")
        uri = "tos://open-workflowgym-sample/yepzr00q2xkhx1xt8gw6_image-yepzr00q2xkhx1xt8gw6_system.qcow2"
        self.assertIn(uri, sizes)
        self.assertAlmostEqual(sizes[uri] / (1024 ** 3), 48.02, places=2)

        raw = """
Object list:
key                                               LastModified                  Size      StorageClass        ETag
tos://open-workflowgym-sample/yepzr00q2xkhx1xt8gw6_image-yepzr00q2xkhx1xt8gw6_system.qcow2
                                                                                51562086400B
                                                  2026-07-16T15:37:49Z                    STANDARD            "etag-1"
"""
        raw_sizes = parse_tosutil_ls_object_sizes(raw, "open-workflowgym-sample")
        self.assertEqual(raw_sizes[uri], 51562086400)
        entries = parse_tosutil_ls_entries(raw, "open-workflowgym-sample")
        self.assertEqual(entries, [(uri, 51562086400)])

    def test_match_prefers_system_qcow2_over_data_vdb(self):
        stdout = """
tos://open-workflowgym-sample/yepz_image-yepz_data_vdb.qcow2
                                                                                100B
tos://open-workflowgym-sample/yepz_image-yepz_system.qcow2
                                                                                200B
"""
        matched = match_tos_uris_for_image(
            image_id="image-yepz",
            image_name="preview-foo_i-yepz_bj",
            bucket="open-workflowgym-sample",
            stdout=stdout,
        )
        self.assertTrue(matched)
        self.assertTrue(matched[0].endswith("_system.qcow2"))

    def test_inventory_marks_skipped_disk_as_exported_with_real_size(self):
        import publish_guangzhou_images_to_huggingface as mod

        stdout = """
tos://bucket/abc_image-abc_system.qcow2
                                                                                123456789B
"""
        original = mod.list_bucket_ls_stdout
        mod.list_bucket_ls_stdout = lambda bucket, force_refresh=False: stdout
        try:
            with tempfile.TemporaryDirectory() as tmpdir:
                root = Path(tmpdir)
                manifest_path = root / "manifest.json"
                csv_path = root / "progress.csv"
                candidates = [{"ImageId": "image-abc", "ImageName": "preview-abc_i-abc_bj"}]
                manifest = {
                    "images": {
                        "image-abc": {
                            "image_id": "image-abc",
                            "image_name": "preview-abc_i-abc_bj",
                            "status": STATUS_SKIPPED_DISK,
                            "tos_object_uri": "",
                            "size_text": "1024.000 GiB",
                            "error": "磁盘不足",
                        }
                    }
                }
                csv_rows = {"image-abc": empty_csv_row("image-abc", "preview-abc_i-abc_bj")}
                ready = inventory_tos_ready_images(
                    candidates,
                    bucket="bucket",
                    manifest=manifest,
                    manifest_path=manifest_path,
                    csv_rows=csv_rows,
                    csv_path=csv_path,
                    ordered_ids=["image-abc"],
                    local_root=root,
                )
                self.assertEqual(ready["image-abc"]["size_bytes"], 123456789)
                self.assertEqual(manifest["images"]["image-abc"]["status"], STATUS_EXPORTED)
                self.assertIn("system.qcow2", manifest["images"]["image-abc"]["tos_object_uri"])
                self.assertEqual(csv_rows["image-abc"]["上传tos镜像结果"], "成功")
        finally:
            mod.list_bucket_ls_stdout = original

    def test_sort_images_tos_ready_first(self):
        images = [
            {"ImageId": "image-b", "ImageName": "b"},
            {"ImageId": "image-a", "ImageName": "a"},
        ]
        manifest = {
            "images": {
                "image-a": {"status": STATUS_PENDING, "tos_object_uri": ""},
                "image-b": {
                    "status": STATUS_EXPORTED,
                    "tos_object_uri": "tos://bucket/b_system.qcow2",
                    "size_text": "1.000 GiB",
                },
            }
        }
        import publish_guangzhou_images_to_huggingface as mod

        mod._TOS_OBJECT_SIZE_CACHE["tos://bucket/b_system.qcow2"] = 1024 ** 3
        ordered = sort_images_tos_ready_first(images, manifest)
        self.assertEqual(
            [item["ImageId"] for item in ordered],
            ["image-b", "image-a"],
        )


    def test_cleanup_local_image_files_removes_qcow2_and_empty_dir(self):
        import publish_guangzhou_images_to_huggingface as mod

        called = {"trash": 0}
        original = mod.empty_local_trash
        mod.empty_local_trash = lambda: called.__setitem__("trash", called["trash"] + 1)
        try:
            with tempfile.TemporaryDirectory() as tmpdir:
                local_root = Path(tmpdir)
                image_dir = local_root / "sample_image_bj"
                image_dir.mkdir()
                local_file = image_dir / "sample_image_bj_system.qcow2"
                local_file.write_bytes(b"x" * 1024)
                cleanup_local_image_files(
                    [{"image_id": "image-abc", "local_file": str(local_file)}],
                    local_root=local_root,
                )
                self.assertFalse(local_file.exists())
                self.assertFalse(image_dir.exists())
                self.assertEqual(called["trash"], 1)
        finally:
            mod.empty_local_trash = original

    def test_sync_csv_updates_only_requested_image_id(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            local_root = Path(tmpdir)
            csv_path = local_root / "progress.csv"
            csv_rows = {
                "image-a": empty_csv_row("image-a", "name-a"),
                "image-b": empty_csv_row("image-b", "name-b"),
            }
            manifest = {
                "images": {
                    "image-a": {
                        "image_name": "name-a",
                        "status": STATUS_FAILED,
                        "tos_object_uri": "",
                        "local_file": "",
                        "hf_path": "name-a/name-a_system.qcow2",
                        "size_text": "",
                    },
                    "image-b": {
                        "image_name": "name-b",
                        "status": STATUS_DOWNLOADED,
                        "tos_object_uri": "tos://bucket/b.qcow2",
                        "local_file": "",
                        "hf_path": "name-b/name-b_system.qcow2",
                        "size_text": "12.000 GiB",
                    },
                }
            }
            sync_csv_from_manifest(
                csv_rows=csv_rows,
                csv_path=csv_path,
                ordered_ids=["image-a", "image-b"],
                manifest=manifest,
                local_root=local_root,
                image_ids=["image-b"],
            )
            self.assertEqual(csv_rows["image-b"]["上传tos镜像结果"], "成功")
            self.assertEqual(csv_rows["image-b"]["是否下载到本地"], "是")
            self.assertEqual(csv_rows["image-a"]["上传tos镜像结果"], "")
            apply_manifest_record_to_csv_row(
                csv_rows,
                "image-a",
                manifest["images"]["image-a"],
                local_root=local_root,
            )
            self.assertEqual(csv_rows["image-a"]["上传tos镜像结果"], "失败")

    def test_lookup_tos_object_size_matches_uri_and_basename(self):
        sizes = {
            "tos://bucket/a/foo_system.qcow2": 12 * (1024 ** 3),
            "tos://bucket/b/bar_system.qcow2": 16 * (1024 ** 3),
        }
        self.assertEqual(
            lookup_tos_object_size(sizes, "tos://bucket/a/foo_system.qcow2"),
            12 * (1024 ** 3),
        )
        self.assertEqual(
            lookup_tos_object_size(sizes, "tos://bucket/a/foo_system.qcow2/"),
            12 * (1024 ** 3),
        )
        self.assertEqual(
            lookup_tos_object_size(sizes, "tos://other/foo_system.qcow2"),
            12 * (1024 ** 3),
        )

    def test_parse_tosutil_ls_object_sizes_reads_human_size(self):
        stdout = """
        tos://open-workflowgym-sample/yepz/foo_system.qcow2    15.998 GiB
        tos://open-workflowgym-sample/yepz/bar_system.qcow2    13421772800
"""
        sizes = parse_tosutil_ls_object_sizes(stdout, "open-workflowgym-sample")
        self.assertIn("tos://open-workflowgym-sample/yepz/foo_system.qcow2", sizes)
        self.assertAlmostEqual(sizes["tos://open-workflowgym-sample/yepz/foo_system.qcow2"] / (1024 ** 3), 15.998, places=2)
        self.assertEqual(sizes["tos://open-workflowgym-sample/yepz/bar_system.qcow2"], 13421772800)

    def test_estimate_tos_object_bytes_does_not_fallback_to_ecs_size(self):
        image = {"Size": 1024, "ImageId": "image-abc"}
        from publish_guangzhou_images_to_huggingface import _TOS_LS_CACHE, _TOS_OBJECT_SIZE_CACHE
        import publish_guangzhou_images_to_huggingface as mod

        _TOS_LS_CACHE.clear()
        _TOS_OBJECT_SIZE_CACHE.clear()
        _TOS_LS_CACHE["bucket"] = "Listing objects .\n"
        original_stat = mod.stat_tos_object_bytes
        mod.stat_tos_object_bytes = lambda tos_uri: None
        try:
            size = estimate_tos_object_bytes(
                tos_uri="tos://bucket/missing.qcow2",
                bucket="bucket",
                image=image,
                allow_image_fallback=False,
            )
            self.assertIsNone(size)
            with_fallback = estimate_tos_object_bytes(
                tos_uri="tos://bucket/missing.qcow2",
                bucket="bucket",
                image=image,
                allow_image_fallback=True,
            )
            self.assertEqual(with_fallback, 1024 * (1024 ** 3))
        finally:
            mod.stat_tos_object_bytes = original_stat

    def test_produce_existing_tos_enqueues_without_export(self):
        import argparse
        import threading
        from queue import Queue

        import publish_guangzhou_images_to_huggingface as mod

        calls = {"export": 0}
        original_find = mod.find_existing_tos_object
        original_export = mod.export_image_to_tos
        original_stat = mod.stat_tos_object_bytes
        mod.find_existing_tos_object = lambda **kwargs: "tos://bucket/abc_image-abc_system.qcow2"
        mod.export_image_to_tos = lambda *a, **k: calls.__setitem__("export", calls["export"] + 1)
        mod.stat_tos_object_bytes = lambda uri: 12345
        try:
            with tempfile.TemporaryDirectory() as tmpdir:
                root = Path(tmpdir)
                manifest_path = root / "m.json"
                csv_path = root / "c.csv"
                image = {"ImageId": "image-abc", "ImageName": "preview-abc_i-abc_bj"}
                manifest = {
                    "images": {
                        "image-abc": {
                            "image_id": "image-abc",
                            "image_name": "preview-abc_i-abc_bj",
                            "status": STATUS_PENDING,
                            "tos_object_uri": "",
                        }
                    }
                }
                csv_rows = {"image-abc": empty_csv_row("image-abc", "preview-abc_i-abc_bj")}
                q: Queue = Queue()
                args = argparse.Namespace(
                    skip_export=False,
                    skip_download=False,
                    tos_bucket="bucket",
                    poll_interval_seconds=1,
                    timeout_seconds=1,
                    continue_on_error=True,
                )
                produce_tos_ready_job(
                    image=image,
                    args=args,
                    ready_queue=q,
                    manifest=manifest,
                    manifest_path=manifest_path,
                    csv_rows=csv_rows,
                    csv_path=csv_path,
                    ordered_ids=["image-abc"],
                    local_root=root,
                    state_lock=threading.Lock(),
                    stop_event=threading.Event(),
                )
                job = q.get_nowait()
                self.assertEqual(job["tos_object_uri"], "tos://bucket/abc_image-abc_system.qcow2")
                self.assertEqual(calls["export"], 0)
                self.assertEqual(manifest["images"]["image-abc"]["status"], STATUS_EXPORTED)
                self.assertEqual(csv_rows["image-abc"]["上传tos镜像结果"], "成功")
        finally:
            mod.find_existing_tos_object = original_find
            mod.export_image_to_tos = original_export
            mod.stat_tos_object_bytes = original_stat

    def test_pipeline_consumer_download_upload_cleanup_order(self):
        import argparse

        import publish_guangzhou_images_to_huggingface as mod

        order: list[str] = []
        original_find = mod.find_existing_tos_object
        original_download = mod.process_single_image_download
        original_upload = mod.upload_large_folder_to_hub
        original_cleanup = mod.cleanup_local_image_files

        mod.find_existing_tos_object = lambda **kwargs: "tos://bucket/a_image-a_system.qcow2"

        def fake_download(**kwargs):
            order.append("download")
            image = kwargs["image"]
            image_id = image["ImageId"]
            return {
                "image_id": image_id,
                "image_name": image["ImageName"],
                "tos_object_uri": "tos://bucket/a_image-a_system.qcow2",
                "local_file": "/tmp/a.qcow2",
                "hf_path": "a/a_system.qcow2",
                "allow_pattern": "a/**",
                "size_bytes": 100,
            }

        def fake_upload(**kwargs):
            order.append("upload")
            return "https://huggingface.co/demo/repo"

        def fake_cleanup(records, local_root=None):
            order.append("cleanup")

        mod.process_single_image_download = fake_download
        mod.upload_large_folder_to_hub = fake_upload
        mod.cleanup_local_image_files = fake_cleanup
        try:
            with tempfile.TemporaryDirectory() as tmpdir:
                root = Path(tmpdir)
                manifest_path = root / "m.json"
                csv_path = root / "c.csv"
                image = {"ImageId": "image-a", "ImageName": "name-a"}
                manifest = {
                    "images": {
                        "image-a": {
                            "image_id": "image-a",
                            "image_name": "name-a",
                            "status": STATUS_PENDING,
                            "tos_object_uri": "",
                        }
                    }
                }
                csv_rows = {"image-a": empty_csv_row("image-a", "name-a")}
                args = argparse.Namespace(
                    skip_export=False,
                    skip_download=False,
                    skip_upload=False,
                    cleanup_after_upload=True,
                    continue_on_error=True,
                    tos_bucket="bucket",
                    poll_interval_seconds=1,
                    timeout_seconds=1,
                    export_concurrency=1,
                    num_workers=1,
                    batch_size=1,
                    repo_id="user/repo",
                    repo_type="dataset",
                    revision=None,
                    private=None,
                )
                run_producer_consumer_pipeline(
                    work_images=[image],
                    args=args,
                    local_root=root,
                    manifest=manifest,
                    manifest_path=manifest_path,
                    csv_rows=csv_rows,
                    csv_path=csv_path,
                    ordered_ids=["image-a"],
                    hf_rotator=None,
                )
                self.assertEqual(order, ["download", "upload", "cleanup"])
                self.assertEqual(manifest["images"]["image-a"]["status"], STATUS_UPLOADED)
        finally:
            mod.find_existing_tos_object = original_find
            mod.process_single_image_download = original_download
            mod.upload_large_folder_to_hub = original_upload
            mod.cleanup_local_image_files = original_cleanup

    def test_reconcile_uploaded_from_hf_prefers_base_repo(self):
        class FakeApi:
            def list_repo_files(self, repo_id, repo_type="dataset"):
                files = {
                    "user/openworkflowgym": [
                        "img-blender/img-blender_system.qcow2",
                        "README.md",
                    ],
                    "user/openworkflowgym-2": [
                        "img-blender/img-blender_system.qcow2",
                        "img-meshlab/img-meshlab_system.qcow2",
                    ],
                    "user/openworkflowgym-3": [],
                }
                if repo_id not in files:
                    raise RuntimeError("missing repo")
                return files[repo_id]

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            manifest_path = root / "manifest.json"
            csv_path = root / "out.csv"
            candidates = [
                {"ImageId": "image-a", "ImageName": "img-blender"},
                {"ImageId": "image-b", "ImageName": "img-meshlab"},
                {"ImageId": "image-c", "ImageName": "img-missing"},
                {"ImageId": "image-w", "ImageName": "img-windows"},
            ]
            manifest = {
                "images": {
                    "image-a": {
                        "image_id": "image-a",
                        "image_name": "img-blender",
                        "status": STATUS_EXPORTED,
                        "hf_path": "user/openworkflowgym-2:img-blender/img-blender_system.qcow2",
                        "hf_repo_id": "user/openworkflowgym-2",
                    },
                    "image-b": {
                        "image_id": "image-b",
                        "image_name": "img-meshlab",
                        "status": STATUS_PENDING,
                        "hf_path": "",
                    },
                    "image-c": {
                        "image_id": "image-c",
                        "image_name": "img-missing",
                        "status": STATUS_EXPORTED,
                        "hf_path": "",
                    },
                    "image-w": {
                        "image_id": "image-w",
                        "image_name": "img-windows",
                        "status": STATUS_SKIPPED_WINDOWS,
                        "hf_path": "",
                    },
                }
            }
            csv_rows = {
                "image-a": empty_csv_row("image-a", "img-blender"),
                "image-b": empty_csv_row("image-b", "img-meshlab"),
                "image-c": empty_csv_row("image-c", "img-missing"),
                "image-w": empty_csv_row("image-w", "img-windows"),
            }
            updated = reconcile_uploaded_from_hf_repos(
                candidates,
                base_repo_id="user/openworkflowgym",
                repo_type="dataset",
                max_repos=3,
                manifest=manifest,
                manifest_path=manifest_path,
                csv_rows=csv_rows,
                csv_path=csv_path,
                ordered_ids=list(csv_rows.keys()),
                local_root=root,
                api=FakeApi(),
            )
            self.assertEqual(
                updated["image-a"],
                "user/openworkflowgym:img-blender/img-blender_system.qcow2",
            )
            self.assertEqual(
                updated["image-b"],
                "user/openworkflowgym-2:img-meshlab/img-meshlab_system.qcow2",
            )
            self.assertNotIn("image-c", updated)
            self.assertNotIn("image-w", updated)
            self.assertEqual(manifest["images"]["image-a"]["status"], STATUS_UPLOADED)
            self.assertEqual(manifest["images"]["image-a"]["hf_repo_id"], "user/openworkflowgym")
            self.assertEqual(manifest["images"]["image-b"]["status"], STATUS_UPLOADED)
            self.assertEqual(manifest["images"]["image-c"]["status"], STATUS_EXPORTED)
            self.assertEqual(manifest["images"]["image-w"]["status"], STATUS_SKIPPED_WINDOWS)
            self.assertEqual(csv_rows["image-a"]["是否已经上传huggingface"], "是")
            self.assertTrue(
                csv_rows["image-a"]["huggingface上对应的镜像名和目录"].startswith(
                    "user/openworkflowgym:"
                )
            )


if __name__ == "__main__":
    unittest.main()
