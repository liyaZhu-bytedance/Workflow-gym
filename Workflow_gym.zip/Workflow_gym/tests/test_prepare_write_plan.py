from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.tools.match_feishu_image_ids import (
    ATTACHMENT_PLACEHOLDER,
    MAX_SHEET_CELL_BYTES,
    prepare_write_plan,
)


class PrepareWritePlanTest(unittest.TestCase):
    def test_large_cell_uses_attachment_placeholder(self):
        large_text = "x" * (MAX_SHEET_CELL_BYTES + 100)
        plan = prepare_write_plan([["标题"], ["正常", large_text]])
        self.assertEqual(plan.rows[1][0], "正常")
        self.assertEqual(plan.rows[1][1], ATTACHMENT_PLACEHOLDER)
        self.assertEqual(len(plan.attachments), 1)
        self.assertEqual(plan.attachments[0][2], large_text)


if __name__ == "__main__":
    unittest.main()
