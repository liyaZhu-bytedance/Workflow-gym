from __future__ import print_function

import os
import shlex
import time
import unittest
import warnings

warnings.filterwarnings(
    "ignore",
    message="urllib3 v2 only supports OpenSSL.*",
)

import volcenginesdkcore
import volcenginesdkecs

from main import capture_console_screenshot, get_result_payload, run_command_and_wait


INSTANCE_ID = os.getenv("INSTANCE_ID", "i-yeprxlt3i8bw80dfwlbv")
DESKTOP_USER = os.getenv("DESKTOP_USER", "user")
DISPLAY = os.getenv("DISPLAY", ":0")
DESKTOP_HOME = os.getenv("DESKTOP_HOME", "/home/%s" % DESKTOP_USER)
XAUTHORITY = os.getenv("XAUTHORITY", os.path.join(DESKTOP_HOME, ".Xauthority"))


def create_api_instance():
    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = "cn-beijing"
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkecs.ECSApi()


def get_first_decoded_output(response_data):
    result = get_result_payload(response_data)
    invocation_results = (
        result.get("InvocationResults")
        or result.get("invocation_results")
        or []
    )
    if not invocation_results:
        return ""
    return invocation_results[0].get("decoded_output") or ""


class TestInstancePyAutoGUI(unittest.TestCase):
    def test_install_and_run_pyautogui_python_script(self):
        api_instance = create_api_instance()
        self.assertTrue(
            DESKTOP_USER.replace("_", "").replace("-", "").isalnum(),
            "DESKTOP_USER 只能包含字母、数字、下划线或中划线",
        )

        configure_xorg_command = """#!/bin/bash
set -euo pipefail
sudo mkdir -p /etc/gdm3
config_ok=false
if sudo test -f /etc/gdm3/custom.conf; then
  if sudo grep -q '^WaylandEnable=false$' /etc/gdm3/custom.conf && sudo grep -q '^AutomaticLoginEnable=true$' /etc/gdm3/custom.conf && sudo grep -q '^AutomaticLogin={desktop_user}$' /etc/gdm3/custom.conf; then
    config_ok=true
  fi
fi
if [ "$config_ok" = true ]; then
  echo "GDM config already satisfied"
else
  sudo cp /etc/gdm3/custom.conf /etc/gdm3/custom.conf.bak 2>/dev/null || true
  sudo bash -c 'cat > /etc/gdm3/custom.conf <<EOF
[daemon]
WaylandEnable=false
AutomaticLoginEnable=true
AutomaticLogin={desktop_user}
EOF'
  echo "GDM config updated, restarting gdm3"
  sudo systemctl restart gdm3 || sudo reboot
fi
""".format(desktop_user=DESKTOP_USER)
        try:
            configure_response = run_command_and_wait(
                api_instance,
                INSTANCE_ID,
                configure_xorg_command,
                "test-configure-xorg-autologin",
                working_dir="/home",
                timeout=120,
            )
        except Exception as exc:
            self.fail("配置 Xorg 自动登录失败: %s" % exc)

        configure_output = get_first_decoded_output(configure_response)
        if "GDM config updated" in configure_output:
            print("等待 GDM/Xorg 自动登录完成...")
            time.sleep(90)
        else:
            print("GDM/Xorg 配置已满足，跳过重启等待。")

        prepare_dependency_command = """#!/bin/bash
set -euo pipefail
if [ ! -x /usr/bin/python ]; then
  sudo ln -sf /usr/bin/python3 /usr/bin/python
fi
if /usr/bin/python - <<'PY'
import tkinter
PY
then
  echo "tkinter already installed"
else
  sudo apt-get update
  sudo apt-get install -y python3-tk python3-dev
fi
sudo -H -u {desktop_user} /usr/bin/python - <<'PY'
import importlib.util

spec = importlib.util.find_spec("pyautogui")
if spec is None:
    raise SystemExit("pyautogui is not installed")
print("pyautogui installed")
PY
echo "desktop home: {desktop_home}"
echo "display: {display}"
ls -la {desktop_home} || true
ls -la {xauthority} || true
""".format(
            desktop_user=shlex.quote(DESKTOP_USER),
            desktop_home=DESKTOP_HOME,
            display=DISPLAY,
            xauthority=XAUTHORITY,
        )
        try:
            run_command_and_wait(
                api_instance,
                INSTANCE_ID,
                prepare_dependency_command,
                "test-prepare-pyautogui-dependencies",
                working_dir="/home",
                timeout=300,
            )
        except Exception as exc:
            self.fail("准备 pyautogui 运行依赖失败: %s" % exc)

        discover_command = """#!/bin/bash
set -euo pipefail
echo "DESKTOP_USER={desktop_user}"
id {desktop_user} || true
echo "HOME_CANDIDATE={desktop_home}"
ls -la {desktop_home} || true
echo "XAUTHORITY_CANDIDATES"
find /home /run/user -name ".Xauthority" -o -name "Xauthority" 2>/dev/null || true
echo "DISPLAY_PROCESSES"
ps aux | grep -E "Xorg|Xwayland|gnome-session|gdm" | grep -v grep || true
echo "LOGINCTL_SESSIONS"
loginctl list-sessions || true
""".format(
            desktop_user=shlex.quote(DESKTOP_USER),
            desktop_home=shlex.quote(DESKTOP_HOME),
        )
        try:
            discover_response = run_command_and_wait(
                api_instance,
                INSTANCE_ID,
                discover_command,
                "test-discover-x-session",
                working_dir="/home",
                timeout=60,
            )
        except Exception as exc:
            self.fail("探测 X11 环境失败: %s" % exc)

        discover_output = get_first_decoded_output(discover_response)
        xauthority = XAUTHORITY
        found_xauthority = False
        for line in discover_output.splitlines():
            line = line.strip()
            if line.endswith(".Xauthority") or line.endswith("Xauthority"):
                xauthority = line
                found_xauthority = True
                break

        if not found_xauthority:
            self.fail("没有找到可用 XAUTHORITY，诊断输出:\n%s" % discover_output)

        unlock_desktop_command = """#!/bin/bash
set -euo pipefail
user_name={desktop_user}
user_id=$(id -u "$user_name")
bus_address="unix:path=/run/user/${{user_id}}/bus"
sudo -H -u "$user_name" env DBUS_SESSION_BUS_ADDRESS="$bus_address" gsettings set org.gnome.desktop.screensaver lock-enabled false || true
sudo -H -u "$user_name" env DBUS_SESSION_BUS_ADDRESS="$bus_address" gsettings set org.gnome.desktop.screensaver ubuntu-lock-on-suspend false || true
sudo -H -u "$user_name" env DBUS_SESSION_BUS_ADDRESS="$bus_address" gsettings set org.gnome.desktop.session idle-delay 0 || true
for session_id in $(loginctl list-sessions --no-legend | awk -v user="$user_name" '$3 == user {{print $1}}'); do
  sudo loginctl unlock-session "$session_id" || true
  sudo loginctl activate "$session_id" || true
done
sudo loginctl unlock-sessions || true
sudo -H -u "$user_name" env DISPLAY={display} HOME={desktop_home} XAUTHORITY={xauthority} gnome-screensaver-command -d || true
echo "desktop unlock requested"
""".format(
            desktop_user=shlex.quote(DESKTOP_USER),
            display=shlex.quote(DISPLAY),
            desktop_home=shlex.quote(DESKTOP_HOME),
            xauthority=shlex.quote(xauthority),
        )
        try:
            run_command_and_wait(
                api_instance,
                INSTANCE_ID,
                unlock_desktop_command,
                "test-unlock-desktop-session",
                working_dir="/home",
                timeout=60,
            )
        except Exception as exc:
            self.fail("解锁桌面会话失败: %s" % exc)

        pyautogui_script = """#!/usr/bin/python
import os
import time

os.environ.setdefault("DISPLAY", "{display}")
os.environ.setdefault("HOME", "{desktop_home}")
os.environ.setdefault("XAUTHORITY", "{xauthority}")

print("DISPLAY:", os.environ.get("DISPLAY"))
print("HOME:", os.environ.get("HOME"))
print("XAUTHORITY:", os.environ.get("XAUTHORITY"))

import pyautogui

print("pyautogui version:", pyautogui.__version__)
print("failsafe:", pyautogui.FAILSAFE)
size = pyautogui.size()
print("screen size: %sx%s" % (size.width, size.height))
center_x = size.width // 2
center_y = size.height // 2
pyautogui.moveTo(center_x, center_y)
pyautogui.click(button="right")
time.sleep(1)
print("right clicked screen center: %s,%s" % (center_x, center_y))

print("pyautogui script completed")
""".format(
            display=DISPLAY,
            desktop_home=DESKTOP_HOME,
            xauthority=xauthority,
        )
        run_pyautogui_command = """#!/bin/bash
set -euo pipefail
sudo rm -f /tmp/test_pyautogui.py
sudo tee /tmp/test_pyautogui.py >/dev/null <<'PY'
{pyautogui_script}
PY
sudo chown {desktop_user}:{desktop_user} /tmp/test_pyautogui.py
sudo chmod 644 /tmp/test_pyautogui.py
sudo -H -u {desktop_user} env DISPLAY={display} HOME={desktop_home} XAUTHORITY={xauthority} /usr/bin/python /tmp/test_pyautogui.py
""".format(
            pyautogui_script=pyautogui_script,
            desktop_user=shlex.quote(DESKTOP_USER),
            display=shlex.quote(DISPLAY),
            desktop_home=shlex.quote(DESKTOP_HOME),
            xauthority=shlex.quote(xauthority),
        )
        display_run_pyautogui_command = """#!/bin/bash
set -euo pipefail
sudo rm -f /tmp/test_pyautogui.py
sudo tee /tmp/test_pyautogui.py >/dev/null <<'PY'
{pyautogui_script}
PY
sudo chown {desktop_user}:{desktop_user} /tmp/test_pyautogui.py
sudo chmod 644 /tmp/test_pyautogui.py
sudo -H -u {desktop_user} env DISPLAY={display} HOME={desktop_home} XAUTHORITY={xauthority} /usr/bin/python /tmp/test_pyautogui.py
""".format(
            pyautogui_script=pyautogui_script,
            desktop_user=shlex.quote(DESKTOP_USER),
            display=shlex.quote(DISPLAY),
            desktop_home=shlex.quote(DESKTOP_HOME),
            xauthority=shlex.quote(xauthority),
        )
        try:
            response_data = run_command_and_wait(
                api_instance,
                INSTANCE_ID,
                run_pyautogui_command,
                "test-run-pyautogui-as-desktop-user",
                working_dir="/home",
                timeout=120,
                display_command=display_run_pyautogui_command,
            )
        except Exception as exc:
            self.fail("运行 pyautogui Python 脚本失败: %s" % exc)

        result = get_result_payload(response_data)
        invocation_results = (
            result.get("InvocationResults")
            or result.get("invocation_results")
            or []
        )
        self.assertTrue(invocation_results, "没有获取到 pyautogui 执行结果")

        for item in invocation_results:
            status = (
                item.get("InvocationResultStatus")
                or item.get("invocation_result_status")
            )
            exit_code = item.get("ExitCode")
            if exit_code is None:
                exit_code = item.get("exit_code")
            output = item.get("decoded_output") or ""

            self.assertEqual(status, "Success")
            self.assertEqual(exit_code, 0)
            self.assertIn("pyautogui script completed", output)
            print("pyautogui 执行输出:")
            print(output)

        print("等待 pyautogui 操作后的桌面状态刷新...")
        time.sleep(5)
        capture_console_screenshot(api_instance, INSTANCE_ID)


if __name__ == "__main__":
    unittest.main()
