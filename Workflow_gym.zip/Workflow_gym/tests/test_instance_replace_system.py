from __future__ import print_function

import os
import time
import unittest
import uuid
import warnings

warnings.filterwarnings(
    "ignore",
    message="urllib3 v2 only supports OpenSSL.*",
)

import volcenginesdkcore
import volcenginesdkecs
from volcenginesdkcore.rest import ApiException

from main import get_result_payload, to_plain_dict


REGION = os.getenv("REGION", "cn-guangzhou")
INSTANCE_ID = os.getenv("INSTANCE_ID", "i-yepu2rdi4guo7bu5dssv")
IMAGE_ID = os.getenv("IMAGE_ID", "image-yepueicd3ekhx23yrlel")
INSTANCE_PASSWORD = os.getenv("INSTANCE_PASSWORD", "AlwaysDay1-BUPT-01")
KEEP_IMAGE_CREDENTIAL = os.getenv("KEEP_IMAGE_CREDENTIAL", "false").lower() == "true"
POLL_INTERVAL_SECONDS = int(os.getenv("POLL_INTERVAL_SECONDS", "30"))
STOP_TIMEOUT_SECONDS = int(os.getenv("STOP_TIMEOUT_SECONDS", "900"))
START_TIMEOUT_SECONDS = int(os.getenv("START_TIMEOUT_SECONDS", "900"))


def create_api_instance():
    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = REGION
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkecs.ECSApi()


def describe_instance(api_instance, instance_id):
    request = volcenginesdkecs.DescribeInstancesRequest(
        instance_ids=[instance_id],
    )
    response = api_instance.describe_instances(request)
    response_data = to_plain_dict(response)
    result = get_result_payload(response_data)
    instances = result.get("Instances") or result.get("instances") or []
    if not instances:
        raise ValueError("DescribeInstances 响应中没有找到实例: %s" % instance_id)
    return instances[0]


def get_instance_status(api_instance, instance_id):
    instance = describe_instance(api_instance, instance_id)
    return instance.get("Status") or instance.get("status")


def wait_instance_status(api_instance, instance_id, expected_status, timeout_seconds):
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        status = get_instance_status(api_instance, instance_id)
        print("实例状态: %s，期望: %s" % (status, expected_status))
        if status == expected_status:
            return status
        time.sleep(POLL_INTERVAL_SECONDS)
    raise AssertionError("等待实例状态超时: expected=%s" % expected_status)


def start_instance_when_ready(api_instance, instance_id, timeout_seconds):
    deadline = time.time() + timeout_seconds
    start_request = volcenginesdkecs.StartInstanceRequest(
        instance_id=instance_id,
    )
    last_error = None

    while time.time() < deadline:
        status = get_instance_status(api_instance, instance_id)
        print("启动前实例状态: %s" % status)
        if status == "RUNNING":
            print("实例已经 RUNNING，启动流程完成")
            return status

        try:
            api_instance.start_instance(start_request)
            print("StartInstance 调用成功")
        except ApiException as exc:
            last_error = exc
            print("StartInstance 暂不可用，继续等待: %s" % exc)

        status = get_instance_status(api_instance, instance_id)
        print("启动后实例状态: %s" % status)
        if status == "RUNNING":
            print("实例状态已是 RUNNING")
            return status

        time.sleep(POLL_INTERVAL_SECONDS)

    raise AssertionError("等待实例启动超时，最后错误: %s" % last_error)


class TestReplaceSystemVolume(unittest.TestCase):
    def test_stop_replace_system_volume_and_start(self):
        api_instance = create_api_instance()

        status = get_instance_status(api_instance, INSTANCE_ID)
        print("当前实例状态: %s" % status)
        if status != "STOPPED":
            stop_request = volcenginesdkecs.StopInstanceRequest(
                instance_id=INSTANCE_ID,
                force_stop=False,
            )
            try:
                api_instance.stop_instance(stop_request)
            except ApiException as exc:
                self.fail("StopInstance 调用失败: %s" % exc)
            wait_instance_status(
                api_instance,
                INSTANCE_ID,
                "STOPPED",
                STOP_TIMEOUT_SECONDS,
            )

        replace_kwargs = dict(
            image_id=IMAGE_ID,
            instance_id=INSTANCE_ID,
            keep_image_credential=KEEP_IMAGE_CREDENTIAL,
            client_token=str(uuid.uuid4()),
        )
        if INSTANCE_PASSWORD:
            replace_kwargs["password"] = INSTANCE_PASSWORD

        replace_request = volcenginesdkecs.ReplaceSystemVolumeRequest(**replace_kwargs)
        try:
            response = api_instance.replace_system_volume(replace_request)
        except ApiException as exc:
            self.fail("ReplaceSystemVolume 调用失败: %s" % exc)

        print("ReplaceSystemVolume 调用成功，响应: %s" % to_plain_dict(response))
        start_instance_when_ready(api_instance, INSTANCE_ID, START_TIMEOUT_SECONDS)


if __name__ == "__main__":
    unittest.main()
