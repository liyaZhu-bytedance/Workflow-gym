from __future__ import annotations

import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from open_workflowgym.judgers.common import download_remote_file, read_remote_file
from open_workflowgym.tosutil_local import (
    cached_tosutil_path,
    download_tosutil,
    ensure_tosutil_configured,
    local_platform_key,
    resolve_tosutil_binary,
    tosutil_download_url,
)


class _FakeResponse:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def read(self):
        return b"binary"


class TosutilLocalTest(unittest.TestCase):
    def test_local_platform_key_on_darwin_arm64(self):
        with patch("open_workflowgym.tosutil_local.platform.system", return_value="Darwin"), patch(
            "open_workflowgym.tosutil_local.platform.machine",
            return_value="arm64",
        ):
            self.assertEqual(local_platform_key(), ("darwin", "arm64"))

    def test_tosutil_download_url_for_windows(self):
        self.assertEqual(
            tosutil_download_url(("windows", "amd64")),
            "https://m645b3e1bb36e-mrap.mrap.accesspoint.tos-global.volces.com/windows/tosutil",
        )

    def test_resolve_tosutil_binary_prefers_path(self):
        with patch.dict(os.environ, {"TOSUTIL_BINARY": "/tmp/custom-tosutil"}, clear=False), patch(
            "open_workflowgym.tosutil_local.Path.is_file",
            return_value=True,
        ), patch("open_workflowgym.tosutil_local.ensure_tosutil_configured") as configure:
            self.assertEqual(resolve_tosutil_binary(), "/tmp/custom-tosutil")
            configure.assert_called_once_with("/tmp/custom-tosutil")

    def test_resolve_tosutil_binary_uses_which_before_cache(self):
        with patch.dict(os.environ, {}, clear=True), patch(
            "open_workflowgym.tosutil_local.shutil.which",
            return_value="/usr/local/bin/tosutil",
        ), patch("open_workflowgym.tosutil_local.ensure_tosutil_configured") as configure:
            self.assertEqual(resolve_tosutil_binary(), "/usr/local/bin/tosutil")
            configure.assert_called_once_with("/usr/local/bin/tosutil")

    def test_resolve_tosutil_binary_uses_cached_binary(self):
        cached = cached_tosutil_path(("darwin", "arm64"))
        with patch.dict(os.environ, {}, clear=True), patch(
            "open_workflowgym.tosutil_local.shutil.which",
            return_value=None,
        ), patch("open_workflowgym.tosutil_local._binary_is_usable", return_value=True), patch(
            "open_workflowgym.tosutil_local.cached_tosutil_path",
            return_value=cached,
        ), patch("open_workflowgym.tosutil_local.ensure_tosutil_configured") as configure:
            self.assertEqual(resolve_tosutil_binary(), str(cached))
            configure.assert_called_once_with(str(cached))

    def test_ensure_tosutil_configured_defaults_to_guangzhou(self):
        with patch.dict(os.environ, {"AK": "ak-test", "SK": "sk-test"}, clear=True), patch(
            "open_workflowgym.tosutil_local.subprocess.run",
        ) as run_command:
            ensure_tosutil_configured("/tmp/tosutil")
            run_command.assert_called_once_with(
                [
                    "/tmp/tosutil",
                    "config",
                    "-i",
                    "ak-test",
                    "-k",
                    "sk-test",
                    "-e",
                    "tos-cn-guangzhou.volces.com",
                    "-re",
                    "cn-guangzhou",
                ],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=60,
            )

    def test_download_tosutil_writes_cache_and_marks_executable(self):
        with tempfile.TemporaryDirectory() as temp_dir, patch(
            "open_workflowgym.tosutil_local.local_tosutil_cache_dir",
            return_value=Path(temp_dir),
        ), patch(
            "open_workflowgym.tosutil_local.local_platform_key",
            return_value=("darwin", "arm64"),
        ), patch("open_workflowgym.tosutil_local.urllib.request.urlopen", return_value=_FakeResponse()), patch(
            "open_workflowgym.tosutil_local._binary_is_usable",
            return_value=True,
        ):
            path = download_tosutil()
            self.assertEqual(path, Path(temp_dir) / "darwin-arm64" / "tosutil")
            self.assertTrue(path.is_file())
            self.assertTrue(os.access(path, os.X_OK))

    def test_read_remote_file_uses_resolved_tosutil_for_tos_url(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            target = Path(temp_dir) / "object.bin"
            target.write_bytes(b"payload")
            with patch("open_workflowgym.judgers.common.run_tosutil_cp", side_effect=lambda url, out: Path(out).write_bytes(b"payload")):
                content = read_remote_file("tos://bucket/object.bin")
            self.assertEqual(content, b"payload")

    def test_download_remote_file_uses_resolved_tosutil_for_tos_url(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            target = Path(temp_dir) / "object.bin"
            with patch("open_workflowgym.judgers.common.run_tosutil_cp", side_effect=lambda url, out: Path(out).write_bytes(b"payload")):
                download_remote_file("tos://bucket/object.bin", str(target))
            self.assertEqual(target.read_bytes(), b"payload")


if __name__ == "__main__":
    unittest.main()
