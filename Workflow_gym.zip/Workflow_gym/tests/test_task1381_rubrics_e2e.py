from __future__ import annotations

import json
import os
import shlex
import subprocess
import sys
import unittest
import warnings
from pathlib import Path
from unittest.mock import patch

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.agents.factory import AgentFactory
from open_workflowgym.envs.volcengine_env import VolcengineEnv
from open_workflowgym.records import InstanceLease, RunConfig, SampleJob, TaskRecord
from open_workflowgym.sampler import Sampler
from open_workflowgym.scorer import Scorer

from tests.e2e_reporting import maybe_write_e2e_sample_to_spreadsheet

DEFAULT_INSTANCE_ID = "i-yeq4neypkwuo7budzfbg"
TASK_ID = "1381"
TASK_IMAGE_ID = "image-yepzo9qeebhli7o0nboc"
TASK_OUTPUT_PATH = "/home/user/Desktop/output/"
TASK_INPUT_PATH = "/home/user/Desktop/input/"
TASK_FINAL_ANSWER = "case4.xml"
TASK_FINAL_ANSWER_URL = "https://cdn.example.local/obj/synthetic-gui-data/base_sheets_output/1381/case4.xml"
TASK_INPUT_TOS_URLS = [
    "https://cdn.example.local/obj/synthetic-gui-data/base_sheets_input/1381/53140-472583447_small.mp4",
    "https://cdn.example.local/obj/synthetic-gui-data/base_sheets_input/1381/89370-614024444_small.mp4",
    "https://cdn.example.local/obj/synthetic-gui-data/base_sheets_input/1381/music1.mp3",
]
STEP_NUM = 10
DEFAULT_E2E_RUN_DIR = "manual_task1381_rubrics_e2e_10step"
FIXTURE_PATH = Path(__file__).resolve().parent / "fixtures" / "task1381_fields.json"


def project_output_dir() -> Path:
    return Path(__file__).resolve().parents[1] / "output"


def default_task1381_e2e_output_root() -> str:
    return str(project_output_dir() / DEFAULT_E2E_RUN_DIR)


ZSHRC_ENV_NAMES = (
    "AK",
    "SK",
    "MOONSHOT_API_KEY",
    "KIMI_API_KEY",
    "KIMI_NATIVE_API_KEY",
    "VOLCENGINE_REGION",
    "SOURCE_REGION",
    "WORKFLOWGYM_TEST_INSTANCE_ID",
    "APP_ID",
    "APP_SECRET",
)


def read_env(name: str, default: str = "") -> str:
    return os.getenv(name, default)


def load_zshrc_env(names: tuple[str, ...] = ZSHRC_ENV_NAMES, zshrc_path: str = "") -> None:
    missing = [name for name in names if not read_env(name)]
    if not missing:
        return
    zshrc = Path(zshrc_path or os.path.expanduser("~/.zshrc"))
    if not zshrc.is_file():
        return
    zshrc_quoted = shlex.quote(str(zshrc))
    for name in missing:
        try:
            completed = subprocess.run(
                ["zsh", "-lc", "source %s >/dev/null 2>&1; print -r -- ${%s:-}" % (zshrc_quoted, name)],
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        value = (completed.stdout or "").strip()
        if value:
            os.environ[name] = value


def load_task1381_fixture_fields() -> dict:
    if FIXTURE_PATH.is_file():
        return json.loads(FIXTURE_PATH.read_text(encoding="utf-8"))
    return {}


def load_task1381_instruction() -> str:
    fields = load_task1381_fixture_fields()
    instruction = str(fields.get("题目") or fields.get("up") or "").strip()
    if instruction:
        return instruction
    return (
        "在 OpenShot 中完成视频剪辑任务，导出 case4.xml 到 /home/user/Desktop/output/case4.xml。"
    )


def load_task1381_rubrics() -> str:
    fields = load_task1381_fixture_fields()
    rubrics = str(fields.get("rubrics") or "").strip()
    if rubrics:
        return rubrics
    return json.dumps(
        {
            "硬约束": [
                {
                    "rubric描述": "检查输出文件中是否存在case4.xml",
                    "0分情况": "不存在case4.xml文件",
                    "1分情况": "存在case4.xml文件",
                }
            ],
            "软约束": [],
        },
        ensure_ascii=False,
    )


def build_task1381_fields() -> dict[str, object]:
    fixture = load_task1381_fixture_fields()
    instruction = load_task1381_instruction()
    return {
        "id": TASK_ID,
        "题目": instruction,
        "up": instruction,
        "镜像ID": TASK_IMAGE_ID,
        "image": TASK_IMAGE_ID,
        "系统类型": fixture.get("系统类型") or "Ubuntu",
        "platform": "ubuntu",
        "启动方式": fixture.get("启动方式") or "cd ~/download ./OpenShot-v3.3.0-x86_64.AppImage",
        "tos_url": fixture.get("tos_url") or str(TASK_INPUT_TOS_URLS),
        "输入文件路径": fixture.get("输入文件路径") or TASK_INPUT_PATH,
        "输出文件路径": fixture.get("输出文件路径") or TASK_OUTPUT_PATH,
        "final_answer文件名": fixture.get("final_answer文件名") or TASK_FINAL_ANSWER,
        "final answer 文件": fixture.get("final answer 文件") or str([TASK_FINAL_ANSWER_URL]),
        "metric_type": fixture.get("metric_type") or "rubrics",
        "判分类型": fixture.get("metric_type") or "rubrics",
        "rubrics": load_task1381_rubrics(),
        "response_reference": fixture.get("response_reference") or "",
    }


def build_task1381_sample_job(*, instance_id: str, output_root: str) -> SampleJob:
    return SampleJob(
        run_id="task1381-e2e",
        task_id=TASK_ID,
        sample_index=1,
        task=TaskRecord(
            run_id="task1381-e2e",
            task_id=TASK_ID,
            row_number=1,
            fields=build_task1381_fields(),
        ),
        config=RunConfig(
            run_id="task1381-e2e",
            output_root=output_root,
            sample_num=1,
            step_num=STEP_NUM,
            player="kimi",
            judger="gemini3.1",
            enable_real_cloud=True,
            tosutil_timeout_seconds=180,
            write_step_traj=True,
        ),
        lease=InstanceLease(
            run_id="task1381-e2e",
            lease_id="task1381-e2e-lease",
            instance_id=instance_id,
            task_id=TASK_ID,
            sample_index=1,
            status="busy",
            acquired_at="2026-07-12 00:00:00",
        ),
    )


def build_seed_case4_xml_command() -> str:
    return "\n".join(
        [
            "#!/bin/bash",
            "set -e",
            "mkdir -p /home/user/Desktop/output",
            "curl -fsSL %s -o /home/user/Desktop/output/%s" % (
                shlex.quote(TASK_FINAL_ANSWER_URL),
                shlex.quote(TASK_FINAL_ANSWER),
            ),
            "test -s /home/user/Desktop/output/%s" % shlex.quote(TASK_FINAL_ANSWER),
            "echo WORKFLOWGYM_TASK1381_PRODUCT_READY",
        ]
    )


def seed_task1381_product(env: VolcengineEnv, instance_id: str) -> None:
    result = env.run_command(instance_id, build_seed_case4_xml_command(), timeout=180)
    output = ""
    for item in result.get("results") or []:
        if isinstance(item, dict):
            decoded = item.get("decoded_output")
            if decoded:
                output += str(decoded)
    print("WORKFLOWGYM_TASK1381_SEED_OUTPUT", output, flush=True)
    if "WORKFLOWGYM_TASK1381_PRODUCT_READY" not in output:
        raise AssertionError("构造 case4.xml 失败: %s" % output[-1000:])


def ensure_instance_running(env: VolcengineEnv, instance_id: str) -> None:
    instance = env.describe_instance(instance_id)
    status = str(instance.get("Status") or instance.get("status") or "").upper()
    if status == "STOPPING":
        env.wait_for_status(instance_id, "STOPPED", timeout_seconds=600)
        status = "STOPPED"
    if status == "STOPPED":
        env.start_instance(instance_id)
    if status not in ("RUNNING",):
        env.wait_for_status(instance_id, "RUNNING", timeout_seconds=600)


def mock_rubrics_call_judge_model(factory, model_name, messages, *, retry_count=2) -> str:
    system_prompt = ""
    if messages and isinstance(messages[0], dict):
        system_prompt = str(messages[0].get("content") or "")
    if "硬约束" in system_prompt:
        return json.dumps({"score": 1, "reason": "mock hard pass"}, ensure_ascii=False)
    return json.dumps({"score": 2, "reason": "mock soft pass"}, ensure_ascii=False)


class Task1381Sampler(Sampler):
    def collect_and_record_outputs(self, job: SampleJob, sample_dir: str, context, state) -> None:
        if job.lease and state.env_metadata.get("desktop_ready_at"):
            seed_task1381_product(self.env, job.lease.instance_id)
        else:
            print("WORKFLOWGYM_TASK1381_SKIP_SEED reason=env_not_ready", flush=True)
        super().collect_and_record_outputs(job, sample_dir, context, state)


load_zshrc_env()


@unittest.skipUnless(
    os.getenv("WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS") == "1",
    "set WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS=1 to run real Volcengine E2E",
)
class Task1381RubricsE2ETest(unittest.TestCase):
    """任务 1381：启动实例 -> 采样 10 步 -> 构造 case4.xml -> collect_outputs -> Rubrics 判分。"""

    def setUp(self):
        self.instance_id = read_env("WORKFLOWGYM_TEST_INSTANCE_ID", DEFAULT_INSTANCE_ID)
        self.region = read_env("VOLCENGINE_REGION", read_env("SOURCE_REGION", "cn-guangzhou"))
        self.output_root = read_env(
            "WORKFLOWGYM_TASK1381_E2E_OUTPUT_ROOT",
            default_task1381_e2e_output_root(),
        )
        self.env = VolcengineEnv(region=self.region)

    def tearDown(self):
        return

    def test_task1381_sample_ten_steps_seed_product_and_score_rubrics(self):
        self.assertTrue(read_env("AK") and read_env("SK"), "set AK/SK for Volcengine")
        moonshot_key = read_env("MOONSHOT_API_KEY") or read_env("KIMI_API_KEY") or read_env("KIMI_NATIVE_API_KEY")
        self.assertTrue(moonshot_key, "set MOONSHOT_API_KEY or KIMI_API_KEY for kimi sampling")

        print("WORKFLOWGYM_TEST_INSTANCE", self.instance_id, flush=True)
        print("WORKFLOWGYM_TASK1381_OUTPUT_ROOT", self.output_root, flush=True)

        ensure_instance_running(self.env, self.instance_id)

        job = build_task1381_sample_job(instance_id=self.instance_id, output_root=self.output_root)
        sampler = Task1381Sampler(AgentFactory(), self.env)
        trajectory = sampler.run_sample(job)

        print("WORKFLOWGYM_TASK1381_SAMPLE_STATUS", trajectory.status, flush=True)
        print("WORKFLOWGYM_TASK1381_LAST_STEP", trajectory.last_step, flush=True)
        print("WORKFLOWGYM_TASK1381_OUTPUT_UPLOADS", trajectory.task_files.output_uploads, flush=True)

        self.assertEqual(trajectory.last_step, STEP_NUM - 1)
        self.assertNotEqual(trajectory.status, "sample_failed", trajectory.error)
        self.assertTrue(Path(trajectory.traj_json_path).is_file())
        sample_dir = Path(trajectory.sample_dir)
        self.assertTrue(
            (sample_dir / "step_0.jpg").is_file() or (sample_dir / "env_ready.jpg").is_file(),
            "采样目录应至少有一张截图",
        )
        self.assertEqual(trajectory.task_files.final_answer_files, [TASK_FINAL_ANSWER])
        self.assertEqual(len(trajectory.task_files.output_uploads), 1)

        upload = trajectory.task_files.output_uploads[0]
        self.assertTrue(upload.get("output_file_exists"), upload)
        self.assertEqual(upload.get("status"), "uploaded", upload)
        self.assertTrue(str(upload.get("tos_url", "")).startswith("https://"), upload)
        self.assertEqual(upload.get("source_path"), "/home/user/Desktop/output/case4.xml")

        if read_env("WORKFLOWGYM_MOCK_JUDGER", "0").lower() in {"1", "true", "yes", "on"}:
            with patch(
                "open_workflowgym.judgers.rubrics.call_judge_model",
                side_effect=mock_rubrics_call_judge_model,
            ):
                score = Scorer().score(trajectory)
        else:
            score = Scorer().score(trajectory)

        print("WORKFLOWGYM_TASK1381_SCORE", score.check, flush=True)
        score_payload = json.loads(Path(score.score_json_path).read_text(encoding="utf-8"))
        self.assertEqual(score.check.get("answer_score"), 1, score_payload)
        self.assertNotIn("rubrics 解析失败", str(score.check.get("evidence", "")))
        production_path = sample_dir / "production" / TASK_FINAL_ANSWER
        self.assertTrue(production_path.is_file(), "Rubrics 判分应落盘 production/")
        self.assertTrue(score.check.get("production_snapshots", [{}])[0].get("production_saved"))
        gt_production_path = sample_dir / "gt_production" / TASK_FINAL_ANSWER
        self.assertTrue(gt_production_path.is_file(), "应从数据集 final answer 文件 落盘 gt_production/")
        self.assertTrue(score.check.get("production_snapshots", [{}])[0].get("gt_production_saved"))
        self.assertIn("rubric_score", score.check)
        self.assertIn("hard_item_scores", score.check)

        report = maybe_write_e2e_sample_to_spreadsheet(
            output_root=self.output_root,
            trajectory=trajectory,
            score=score,
        )
        if report is not None:
            self.assertTrue(Path(report["local_samples_csv"]).is_file())
            print("WORKFLOWGYM_TASK1381_SPREADSHEET", report, flush=True)


if __name__ == "__main__":
    unittest.main()
