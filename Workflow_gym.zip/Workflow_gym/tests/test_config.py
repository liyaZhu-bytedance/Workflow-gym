from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest import mock

REPO_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = Path("/tmp/owg_path")
PACKAGE_ROOT.mkdir(parents=True, exist_ok=True)
link = PACKAGE_ROOT / "open_workflowgym"
if link.exists() or link.is_symlink():
    link.unlink()
link.symlink_to(REPO_ROOT)
sys.path.insert(0, str(PACKAGE_ROOT))

from open_workflowgym.config import (
    build_run_config,
    default_output_root,
    normalize_sampling_mode,
    parse_args,
    resolve_lease_backend,
)


class ConfigTest(unittest.TestCase):
    def test_write_step_traj_flag(self):
        args = parse_args(["--write-step-traj"])
        config = build_run_config(args)

        self.assertTrue(config.write_step_traj)

    def test_action_timeout_seconds_flag(self):
        args = parse_args(["--action-timeout-seconds", "30"])
        config = build_run_config(args)

        self.assertEqual(config.action_timeout_seconds, 30)

    def test_multiple_target_ids_flag(self):
        args = parse_args(["--id", "42", "1746"])
        config = build_run_config(args)

        self.assertEqual(config.target_id, "42 1746")

    def test_default_output_root_uses_sample_and_step_labels(self):
        path = default_output_root("kimi", 1, 100)
        name = Path(path).name

        self.assertTrue(name.startswith("sample_kimi_1_step_100_"))

    def test_lease_and_init_timeout_flags(self):
        args = parse_args(["--lease-ttl-seconds", "900", "--sample-init-timeout-seconds", "1200", "--allow-unknown-platform"])
        config = build_run_config(args)

        self.assertEqual(config.lease_ttl_seconds, 900)
        self.assertEqual(config.sample_init_timeout_seconds, 1200)
        self.assertFalse(config.fail_on_unknown_platform)

    def test_default_sample_init_timeout_seconds(self):
        config = build_run_config(parse_args([]))
        self.assertEqual(config.sample_init_timeout_seconds, 3600)

    def test_default_lease_ttl_seconds(self):
        config = build_run_config(parse_args([]))
        self.assertEqual(config.lease_ttl_seconds, 3600)
        self.assertEqual(config.sample_future_max_seconds, 3600 * 2 + 3600)

    def test_mode_redis_sets_lease_backend(self):
        config = build_run_config(parse_args(["--mode", "redis"]))
        self.assertEqual(config.lease_backend, "redis")

    def test_mode_online_alias(self):
        config = build_run_config(parse_args(["--mode", "online"]))
        self.assertEqual(config.lease_backend, "redis")

    def test_mode_overrides_lease_backend(self):
        config = build_run_config(parse_args(["--mode", "local", "--lease-backend", "redis"]))
        self.assertEqual(config.lease_backend, "local")

    def test_normalize_sampling_mode(self):
        self.assertEqual(normalize_sampling_mode("online"), "redis")
        self.assertEqual(normalize_sampling_mode("local"), "local")
        with self.assertRaises(ValueError):
            normalize_sampling_mode("invalid")

    def test_resolve_lease_backend_from_env(self):
        with mock.patch.dict("os.environ", {"SAMPLING_MODE": "redis"}, clear=False):
            self.assertEqual(resolve_lease_backend(mode="", lease_backend=""), "redis")


if __name__ == "__main__":
    unittest.main()
