from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.judgers.common import ERROR_SCORE
from open_workflowgym.judgers.rubrics import RubricsJudgerMixin
from open_workflowgym.records import TaskFileResult, TrajectoryResult

TASK_FINAL_ANSWER = "image_hash.txt"
TASK_FINAL_ANSWER_URL = "https://data.example.local/base_sheets_output/173/image_hash.txt"
TASK_IMAGE_HASH_CONTENT = "e4d909c290d0fb1ca068ffaddf22cbd0  bg2.jpg\n"
RUBRICS_JSON = json.dumps(
    {
        "硬约束": [{"rubric描述": "产物正确", "0分情况": "错误", "1分情况": "正确"}],
        "软约束": [],
    },
    ensure_ascii=False,
)


def write_minimal_jpeg(path: Path) -> None:
    from PIL import Image

    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", (48, 48), color=(120, 80, 200)).save(path, "JPEG")


def build_rubrics_trajectory(sample_dir: str, *, tos_url: str) -> TrajectoryResult:
    screenshot_path = Path(sample_dir) / "step_0.jpg"
    write_minimal_jpeg(screenshot_path)
    traj_path = Path(sample_dir) / "traj.json"
    traj_path.write_text(
        json.dumps([{"step": 0, "screenshot": str(screenshot_path), "response": "done"}], ensure_ascii=False),
        encoding="utf-8",
    )
    for name in ("traj.md", "sample_metadata.json", "sample_status.json"):
        (Path(sample_dir) / name).write_text("", encoding="utf-8")

    return TrajectoryResult(
        run_id="run-rubrics",
        task_id="173",
        sample_index=1,
        status="sample_completed",
        sample_dir=sample_dir,
        traj_json_path=str(traj_path),
        traj_md_path=str(Path(sample_dir) / "traj.md"),
        id_json_path=str(Path(sample_dir) / "sample_metadata.json"),
        sample_status_path=str(Path(sample_dir) / "sample_status.json"),
        task_files=TaskFileResult(
            final_answer_files=[TASK_FINAL_ANSWER],
            output_uploads=[
                {
                    "relative_path": TASK_FINAL_ANSWER,
                    "source_path": "/home/user/Desktop/output/image_hash.txt",
                    "tos_url": tos_url,
                    "status": "uploaded",
                }
            ],
        ),
        task_fields={
            "answer_type": "文件产物",
            "metric_type": "Rubrics",
            "rubrics": RUBRICS_JSON,
            "final_answer文件名": TASK_FINAL_ANSWER,
            "final answer 文件": str([TASK_FINAL_ANSWER_URL]),
        },
    )


class RubricsProductArchiveTest(unittest.TestCase):
    def test_judge_rubrics_archives_production_and_gt_production(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            student_file = Path(temp_dir) / "student" / TASK_FINAL_ANSWER
            student_file.parent.mkdir(parents=True, exist_ok=True)
            student_file.write_text(TASK_IMAGE_HASH_CONTENT, encoding="utf-8")
            gt_file = Path(temp_dir) / "gt" / TASK_FINAL_ANSWER
            gt_file.parent.mkdir(parents=True, exist_ok=True)
            gt_file.write_text("ba1a813191165661b6cc5ef4344141c2  bg2.jpg\n", encoding="utf-8")

            trajectory = build_rubrics_trajectory(
                temp_dir,
                tos_url="https://example.com/student/image_hash.txt",
            )

            def fake_download(url: str, target_path: str) -> None:
                Path(target_path).parent.mkdir(parents=True, exist_ok=True)
                if "gt" in url or TASK_FINAL_ANSWER_URL in url:
                    Path(target_path).write_bytes(gt_file.read_bytes())
                else:
                    Path(target_path).write_bytes(student_file.read_bytes())

            judger = RubricsJudgerMixin()
            with patch("open_workflowgym.judgers.file_product.download_remote_file", side_effect=fake_download):
                with patch(
                    "open_workflowgym.judgers.rubrics.call_judge_model",
                    return_value='{"score": 1, "reason": "ok"}',
                ):
                    result = judger.judge_rubrics(trajectory, "文件产物", "Rubrics")

            self.assertEqual(result["status"], "success")
            self.assertTrue((Path(temp_dir) / "production" / TASK_FINAL_ANSWER).is_file())
            self.assertTrue((Path(temp_dir) / "gt_production" / TASK_FINAL_ANSWER).is_file())
            self.assertTrue(result["production_snapshots"][0]["production_saved"])
            self.assertTrue(result["production_snapshots"][0]["gt_production_saved"])
            self.assertIn("vm_output_listing", result)

    def test_rubrics_parse_failure_still_reports_production_snapshots(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            student_file = Path(temp_dir) / "student" / TASK_FINAL_ANSWER
            student_file.parent.mkdir(parents=True, exist_ok=True)
            student_file.write_text(TASK_IMAGE_HASH_CONTENT, encoding="utf-8")
            trajectory = build_rubrics_trajectory(
                temp_dir,
                tos_url="https://example.com/student/image_hash.txt",
            )
            trajectory.task_fields["rubrics"] = "{invalid"

            def fake_download(url: str, target_path: str) -> None:
                Path(target_path).parent.mkdir(parents=True, exist_ok=True)
                Path(target_path).write_bytes(student_file.read_bytes())

            with patch("open_workflowgym.judgers.file_product.download_remote_file", side_effect=fake_download):
                result = RubricsJudgerMixin().judge_rubrics(trajectory, "文件产物", "Rubrics")

            self.assertEqual(result["answer_score"], ERROR_SCORE)
            self.assertIn("production_snapshots", result)
            self.assertTrue(result["production_snapshots"][0]["production_saved"])
            self.assertTrue((Path(temp_dir) / "production" / TASK_FINAL_ANSWER).is_file())

    def test_judger_agent_attaches_production_snapshots_on_rubrics_parse_failure(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            student_file = Path(temp_dir) / "student" / TASK_FINAL_ANSWER
            student_file.parent.mkdir(parents=True, exist_ok=True)
            student_file.write_text(TASK_IMAGE_HASH_CONTENT, encoding="utf-8")
            trajectory = build_rubrics_trajectory(
                temp_dir,
                tos_url="https://example.com/student/image_hash.txt",
            )
            trajectory.task_fields["rubrics"] = "{invalid"

            def fake_download(url: str, target_path: str) -> None:
                Path(target_path).parent.mkdir(parents=True, exist_ok=True)
                Path(target_path).write_bytes(student_file.read_bytes())

            with patch("open_workflowgym.judgers.file_product.download_remote_file", side_effect=fake_download):
                from open_workflowgym.judgers.agent import JudgerAgent

                result = JudgerAgent().judge(trajectory)

            self.assertIn("production_snapshots", result)
            self.assertTrue(result["production_snapshots"][0]["production_saved"])


if __name__ == "__main__":
    unittest.main()
