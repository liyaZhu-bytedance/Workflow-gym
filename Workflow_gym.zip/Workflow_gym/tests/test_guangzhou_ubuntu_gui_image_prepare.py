from __future__ import annotations

import collections
import json
import os
import sys
import threading
import time
import unittest
import warnings
from collections.abc import Callable
from unittest import mock
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

warnings.filterwarnings(
    "ignore",
    message="urllib3 v2 only supports OpenSSL.*",
)

from open_workflowgym.envs.volcengine_env import (
    VolcengineEnv,
    build_disable_ubuntu_update_prompts_command,
    build_prepare_pyautogui_dependencies_command,
    build_probe_desktop_user_command,
    command_decoded_output,
    gui_image_enable_auto_login,
    image_record_field,
    resolve_desktop_user_from_probe,
)
from open_workflowgym.feishu_client import (
    FeishuClient,
    spreadsheet_token_from_url,
)
from open_workflowgym.local_spreadsheet import feishu_credentials_configured
from tests.test_guangzhou_linux_image_desktop_user_probe import (
    DEFAULT_IMAGE_PROBE_INSTANCE_IDS,
    DEFAULT_IMAGE_PROBE_SPREADSHEET_URL,
    IMAGE_PROBE_MAX_IMAGES,
    IMAGE_PROBE_SPREADSHEET_URL,
    IMAGE_PROBE_TARGET_IMAGE_ID,
    IMAGE_PROBE_WAIT_SECONDS,
    PROBE_INSTANCE_IDS,
    REGION,
    create_api_instance,
    filter_ubuntu_images,
    image_display_name,
    list_region_images,
    parse_probe_instance_ids,
)
GUI_IMAGE_RESOLUTION_WIDTH = int(os.getenv("DESKTOP_RESOLUTION_WIDTH", "1920"))
GUI_IMAGE_RESOLUTION_HEIGHT = int(os.getenv("DESKTOP_RESOLUTION_HEIGHT", "1080"))
GUI_IMAGE_PREPARE_WAIT_SECONDS = int(os.getenv("GUI_IMAGE_PREPARE_WAIT_SECONDS", str(IMAGE_PROBE_WAIT_SECONDS)))
GUI_IMAGE_PREPARE_COMMAND_TIMEOUT_SECONDS = int(os.getenv("GUI_IMAGE_PREPARE_COMMAND_TIMEOUT_SECONDS", "900"))
GUI_IMAGE_SHEET_TITLE = os.getenv("GUI_IMAGE_SHEET_TITLE", "linux_gui_image").strip()
GUI_IMAGE_HEADERS = ("序号", "源镜像名", "源镜像id", "用户名", "导出镜像名", "导出镜像id", "状态")
GUI_IMAGE_SKIP_EXISTING = os.getenv("GUI_IMAGE_SKIP_EXISTING", "1").lower() not in ("0", "false", "no", "off")
GUI_IMAGE_PREPARE_MAX_WORKERS = max(1, int(os.getenv("GUI_IMAGE_PREPARE_MAX_WORKERS", "20")))


class GuiBakeInstanceUnavailableError(RuntimeError):
    """实例基础设施不可用，应隔离该实例并在其他实例上重试镜像烘焙。"""


class GuiBakeImageIncompatibleError(RuntimeError):
    """镜像与实例类型不匹配等问题，属于镜像侧永久失败，不应重试或隔离实例。"""


def is_instance_type_mismatch_error(exc: BaseException) -> bool:
    message = str(exc)
    return (
        "InvalidImage.InstanceTypeMismatch" in message
        or "instance type do not match" in message.lower()
        or "instance type does not match" in message.lower()
    )


def available_gui_bake_instances(instance_ids: list[str], quarantined_instance_ids: set[str]) -> list[str]:
    return [instance_id for instance_id in instance_ids if instance_id not in quarantined_instance_ids]


def plan_gui_bake_round(
    retry_jobs: list[tuple[int, dict]],
    instance_ids: list[str],
    quarantined_instance_ids: set[str],
    *,
    max_workers: int = GUI_IMAGE_PREPARE_MAX_WORKERS,
) -> tuple[list[tuple[int, dict, str]], list[tuple[int, dict]], list[str]]:
    available_instances = available_gui_bake_instances(instance_ids, quarantined_instance_ids)
    if not retry_jobs or not available_instances:
        return [], list(retry_jobs), available_instances

    worker_count = min(max_workers, len(available_instances), len(retry_jobs))
    current_jobs = retry_jobs[:worker_count]
    deferred_jobs = retry_jobs[worker_count:]
    assignments = [
        (job[0], job[1], available_instances[index])
        for index, job in enumerate(current_jobs)
    ]
    return assignments, deferred_jobs, available_instances


def run_gui_bake_pipeline(
    pending_jobs: list[tuple[int, dict]],
    instance_ids: list[str],
    *,
    prepare_one: Callable[[dict, str], dict[str, str]],
    on_no_available_instances: Callable[[dict, set[str]], dict[str, str]],
    max_workers: int = GUI_IMAGE_PREPARE_MAX_WORKERS,
) -> tuple[list[dict[str, str]], list[str]]:
    """流水线调度：实例完成一个镜像后立即从队列取下一个，而非等整批结束。"""
    if not pending_jobs:
        return [], []

    job_deque: collections.deque[tuple[int, dict]] = collections.deque(pending_jobs)
    job_lock = threading.Lock()
    quarantined_instance_ids: set[str] = set()
    quarantine_lock = threading.Lock()
    results: list[dict[str, str]] = []
    results_lock = threading.Lock()

    def pop_job() -> tuple[int, dict] | None:
        with job_lock:
            if not job_deque:
                return None
            return job_deque.popleft()

    def requeue_job_front(job: tuple[int, dict]) -> None:
        with job_lock:
            job_deque.appendleft(job)

    def has_pending_jobs() -> bool:
        with job_lock:
            return bool(job_deque)

    def instance_worker(instance_id: str) -> None:
        while True:
            job = pop_job()
            if job is None:
                return

            index, source_image = job
            with quarantine_lock:
                available_instances = available_gui_bake_instances(instance_ids, quarantined_instance_ids)
            source_image_id = image_record_field(source_image, "ImageId", "image_id")
            source_image_name = image_display_name(source_image)
            print(
                "GUI_PREPARE_PIPELINE index=%s instance_id=%s source_image_id=%s source_image_name=%s available_instances=%s quarantined_instances=%s pending_jobs=%s"
                % (
                    index,
                    instance_id,
                    source_image_id,
                    source_image_name,
                    ",".join(available_instances),
                    ",".join(sorted(quarantined_instance_ids)),
                    len(job_deque) + 1,
                ),
                flush=True,
            )
            try:
                record = prepare_one(source_image, instance_id)
            except GuiBakeInstanceUnavailableError as exc:
                with quarantine_lock:
                    if instance_id not in quarantined_instance_ids:
                        quarantined_instance_ids.add(instance_id)
                        print(
                            "GUI_PREPARE_INSTANCE_UNAVAILABLE instance_id=%s error=%s"
                            % (instance_id, exc),
                            flush=True,
                        )
                requeue_job_front(job)
                return

            with results_lock:
                results.append(record)

    available_instances = available_gui_bake_instances(instance_ids, set())
    worker_count = min(max_workers, len(available_instances), len(pending_jobs))
    active_instances = available_instances[:worker_count]
    standby_instances: collections.deque[str] = collections.deque(available_instances[worker_count:])

    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        futures = {
            executor.submit(instance_worker, instance_id): instance_id
            for instance_id in active_instances
        }

        while futures:
            done, _ = wait(futures.keys(), return_when=FIRST_COMPLETED)
            for future in done:
                finished_instance = futures.pop(future)
                future.result()
                if not has_pending_jobs():
                    continue
                with quarantine_lock:
                    replacement_instance: str | None = None
                    while standby_instances:
                        candidate = standby_instances.popleft()
                        if candidate not in quarantined_instance_ids:
                            replacement_instance = candidate
                            break
                    if replacement_instance is not None:
                        print(
                            "GUI_PREPARE_REPLACE_INSTANCE finished=%s replacement=%s"
                            % (finished_instance, replacement_instance),
                            flush=True,
                        )
                        futures[executor.submit(instance_worker, replacement_instance)] = replacement_instance

    with job_lock:
        remaining_jobs = list(job_deque)
    if remaining_jobs:
        with quarantine_lock:
            for _, source_image in remaining_jobs:
                record = on_no_available_instances(source_image, quarantined_instance_ids)
                with results_lock:
                    results.append(record)

    if quarantined_instance_ids:
        print(
            "GUI_PREPARE_QUARANTINED_INSTANCES %s"
            % ",".join(sorted(quarantined_instance_ids)),
            flush=True,
        )

    return results, sorted(quarantined_instance_ids)


def resolve_gui_prepare_worker_count(pending_image_count: int, instance_ids: list[str] | None = None) -> int:
    """并发上限 = min(max_workers, 已配置实例数, 待烘镜像数)。"""
    probe_instance_ids = instance_ids if instance_ids is not None else parse_probe_instance_ids()
    if not probe_instance_ids:
        return 1
    if pending_image_count <= 0:
        return 1
    return min(GUI_IMAGE_PREPARE_MAX_WORKERS, len(probe_instance_ids), pending_image_count)


def is_gui_bake_success(record: dict[str, str]) -> bool:
    status = str(record.get("status") or "").strip().lower()
    gui_image_id = str(record.get("gui_image_id") or "").strip()
    return status == "success" and bool(gui_image_id)


def find_gui_record(records: list[dict[str, str]], source_image_id: str) -> dict[str, str] | None:
    for record in records:
        if record.get("source_image_id") == source_image_id:
            return record
    return None


def build_gui_image_name(source_image_name: str) -> str:
    name = str(source_image_name or "").strip()
    if not name:
        raise ValueError("源镜像名为空，无法生成 GUI 镜像名")
    if name.endswith("_gui"):
        return name
    return "%s_gui" % name


def build_gui_image_rows(records: list[dict[str, str]]) -> list[list[str]]:
    rows = [list(GUI_IMAGE_HEADERS)]
    for index, record in enumerate(records, start=1):
        rows.append(
            [
                str(index),
                record.get("source_image_name", ""),
                record.get("source_image_id", ""),
                record.get("desktop_user", ""),
                record.get("gui_image_name", ""),
                record.get("gui_image_id", ""),
                record.get("status", ""),
            ]
        )
    return rows


def resolve_gui_spreadsheet(client: FeishuClient) -> dict[str, str]:
    spreadsheet_url = IMAGE_PROBE_SPREADSHEET_URL or DEFAULT_IMAGE_PROBE_SPREADSHEET_URL
    spreadsheet_token = spreadsheet_token_from_url(spreadsheet_url)
    if not spreadsheet_token:
        raise ValueError("无法从飞书表格 URL 解析 spreadsheet_token: %s" % spreadsheet_url)
    admin_member_id = os.getenv("FEISHU_SHEET_ADMIN_MEMBER_ID", "").strip()
    if admin_member_id:
        try:
            client.grant_admin_permission(spreadsheet_token, admin_member_id)
        except Exception as exc:
            print("授权飞书电子表格管理员失败，继续写入表格: %s" % exc, flush=True)
    sheet_id = client.get_or_add_sheet(spreadsheet_token, GUI_IMAGE_SHEET_TITLE)
    return {
        "spreadsheet_token": spreadsheet_token,
        "spreadsheet_url": spreadsheet_url,
        "sheet_id": sheet_id,
    }


def sync_gui_records_to_feishu(
    client: FeishuClient,
    sheet_info: dict[str, str],
    records: list[dict[str, str]],
) -> None:
    client.write_values(
        sheet_info["spreadsheet_token"],
        sheet_info["sheet_id"],
        "A1",
        build_gui_image_rows(records),
    )


def load_gui_records_from_feishu(client: FeishuClient, sheet_info: dict[str, str]) -> list[dict[str, str]]:
    rows = client.read_values(sheet_info["spreadsheet_token"], "%s!A:G" % sheet_info["sheet_id"])
    records: list[dict[str, str]] = []
    for row in rows:
        if not row or len(row) < 3:
            continue
        source_image_id = str(row[2] or "").strip() if len(row) > 2 else ""
        if not source_image_id or source_image_id == "源镜像id":
            continue
        records.append(
            {
                "source_image_name": str(row[1] or "").strip() if len(row) > 1 else "",
                "source_image_id": source_image_id,
                "desktop_user": str(row[3] or "").strip() if len(row) > 3 else "",
                "gui_image_name": str(row[4] or "").strip() if len(row) > 4 else "",
                "gui_image_id": str(row[5] or "").strip() if len(row) > 5 else "",
                "status": str(row[6] or "").strip() if len(row) > 6 else "",
            }
        )
    return records


def merge_gui_record(records: list[dict[str, str]], record: dict[str, str]) -> list[dict[str, str]]:
    source_image_id = record.get("source_image_id", "")
    merged = [item for item in records if item.get("source_image_id") != source_image_id]
    merged.append(record)
    return merged


def build_gui_bake_no_instance_record(source_image: dict, quarantined_instance_ids: set[str]) -> dict[str, str]:
    source_image_id = image_record_field(source_image, "ImageId", "image_id")
    source_image_name = image_display_name(source_image)
    return {
        "source_image_id": source_image_id,
        "source_image_name": source_image_name,
        "desktop_user": "",
        "gui_image_name": build_gui_image_name(source_image_name),
        "gui_image_id": "",
        "status": "failed: no available instances, quarantined=%s"
        % ",".join(sorted(quarantined_instance_ids)),
    }


def run_gui_bake_instance_setup(
    env: VolcengineEnv,
    instance_id: str,
    source_image_id: str,
) -> None:
    try:
        env.ensure_stopped(instance_id)
        env.replace_system_volume(instance_id, source_image_id)
        env.wait_for_replace_system_volume(
            instance_id,
            source_image_id,
            timeout_seconds=int(os.getenv("REPLACE_SYSTEM_VOLUME_TIMEOUT_SECONDS", "600")),
        )
        env.start_instance(instance_id)
        env.wait_for_status(
            instance_id,
            "RUNNING",
            timeout_seconds=int(os.getenv("INSTANCE_START_TIMEOUT_SECONDS", "600")),
        )
        env.ensure_cloud_assistant_ready(instance_id)
    except Exception as exc:
        if is_instance_type_mismatch_error(exc):
            raise GuiBakeImageIncompatibleError(
                "instance_id=%s source_image_id=%s phase=instance_setup error=%s"
                % (instance_id, source_image_id, exc)
            ) from exc
        raise GuiBakeInstanceUnavailableError(
            "instance_id=%s source_image_id=%s phase=instance_setup error=%s"
            % (instance_id, source_image_id, exc)
        ) from exc


def process_ubuntu_image_to_gui(
    env: VolcengineEnv,
    instance_id: str,
    source_image: dict,
) -> dict[str, str]:
    source_image_id = image_record_field(source_image, "ImageId", "image_id")
    source_image_name = image_display_name(source_image)
    gui_image_name = build_gui_image_name(source_image_name)

    print(
        "GUI_PREPARE_START instance_id=%s source_image_id=%s source_image_name=%s gui_image_name=%s"
        % (instance_id, source_image_id, source_image_name, gui_image_name),
        flush=True,
    )

    run_gui_bake_instance_setup(env, instance_id, source_image_id)
    if GUI_IMAGE_PREPARE_WAIT_SECONDS > 0:
        time.sleep(GUI_IMAGE_PREPARE_WAIT_SECONDS)

    print("GUI_PREPARE_DISABLE_UBUNTU_UPDATES instance_id=%s" % instance_id, flush=True)
    env.run_command(
        instance_id,
        build_disable_ubuntu_update_prompts_command(),
        timeout=int(os.getenv("DISABLE_UBUNTU_UPDATES_TIMEOUT_SECONDS", "300")),
    )

    print("GUI_PREPARE_PYAUTOGUI_INSTALL instance_id=%s" % instance_id, flush=True)
    install_result = env.run_command(
        instance_id,
        build_prepare_pyautogui_dependencies_command(),
        timeout=GUI_IMAGE_PREPARE_COMMAND_TIMEOUT_SECONDS,
    )
    install_output = command_decoded_output(install_result)
    if "WORKFLOWGYM_PYAUTOGUI_INSTALL_OK" not in install_output:
        raise RuntimeError("pyautogui 安装失败: %s" % install_output[:1000])
    print("GUI_PREPARE_PYAUTOGUI_INSTALL_OK instance_id=%s" % instance_id, flush=True)

    print("GUI_PREPARE_PROBE_USER instance_id=%s" % instance_id, flush=True)
    probe_result = env.run_command(
        instance_id,
        build_probe_desktop_user_command(),
        timeout=int(os.getenv("DESKTOP_PROBE_COMMAND_TIMEOUT_SECONDS", "180")),
    )
    probe_output = command_decoded_output(probe_result)
    resolved = resolve_desktop_user_from_probe(probe_output)
    desktop_user = str(resolved.get("desktop_user") or "")
    if not desktop_user:
        raise RuntimeError("探测桌面用户失败: source_image_id=%s output=%s" % (source_image_id, probe_output))

    enable_auto_login = gui_image_enable_auto_login()
    print(
        "GUI_PREPARE_DESKTOP_SESSION instance_id=%s desktop_user=%s resolution=%sx%s auto_login=%s"
        % (
            instance_id,
            desktop_user,
            GUI_IMAGE_RESOLUTION_WIDTH,
            GUI_IMAGE_RESOLUTION_HEIGHT,
            int(enable_auto_login),
        ),
        flush=True,
    )
    session_metadata = env.prepare_gui_desktop_session(
        instance_id,
        desktop_user,
        resolution_width=GUI_IMAGE_RESOLUTION_WIDTH,
        resolution_height=GUI_IMAGE_RESOLUTION_HEIGHT,
        enable_auto_login=enable_auto_login,
    )

    print("GUI_PREPARE_STOP_INSTANCE instance_id=%s desktop_user=%s" % (instance_id, desktop_user), flush=True)
    env.ensure_stopped(instance_id)

    print("GUI_PREPARE_CREATE_IMAGE instance_id=%s image_name=%s" % (instance_id, gui_image_name), flush=True)
    gui_image_id = env.create_image_from_instance(instance_id, gui_image_name)
    env.wait_for_image_task(gui_image_id)

    return {
        "source_image_id": source_image_id,
        "source_image_name": source_image_name,
        "desktop_user": desktop_user,
        "desktop_user_source": str(resolved.get("desktop_user_source") or ""),
        "gui_image_name": gui_image_name,
        "gui_image_id": gui_image_id,
        "status": "success",
        "probe_output": probe_output,
        "target_resolution": session_metadata.get("target_resolution", ""),
        "auto_login_enabled": str(session_metadata.get("auto_login_enabled", "")),
    }


@unittest.skipUnless(
    os.getenv("WORKFLOWGYM_RUN_GUI_IMAGE_PREPARE") == "1",
    "set WORKFLOWGYM_RUN_GUI_IMAGE_PREPARE=1 to bake GUI images",
)
@unittest.skipUnless(os.getenv("AK") and os.getenv("SK"), "set AK and SK to call Volcengine APIs")
@unittest.skipUnless(feishu_credentials_configured(), "set APP_ID and APP_SECRET to publish Feishu spreadsheet")
class TestGuangzhouUbuntuGuiImagePrepare(unittest.TestCase):
    def setUp(self):
        self.api = create_api_instance(REGION)
        self.env = VolcengineEnv(region=REGION)
        self.feishu_client = FeishuClient(dry_run=False)
        self.sheet_info = resolve_gui_spreadsheet(self.feishu_client)
        self.records = load_gui_records_from_feishu(self.feishu_client, self.sheet_info)
        self._records_lock = threading.Lock()
        self.probe_instance_ids = list(PROBE_INSTANCE_IDS)
        if not self.probe_instance_ids:
            self.probe_instance_ids = parse_probe_instance_ids()

    def _save_record(self, record: dict[str, str]) -> None:
        with self._records_lock:
            self.records = merge_gui_record(self.records, record)
            sync_gui_records_to_feishu(self.feishu_client, self.sheet_info, self.records)

    def _should_skip_existing(self, source_image_id: str, source_image_name: str) -> bool:
        if not GUI_IMAGE_SKIP_EXISTING:
            return False
        existing = find_gui_record(self.records, source_image_id)
        if not existing or not is_gui_bake_success(existing):
            return False
        print(
            "SKIP_EXISTING_GUI_BAKE source_image_id=%s source_image_name=%s gui_image_id=%s gui_image_name=%s"
            % (
                source_image_id,
                source_image_name,
                existing.get("gui_image_id", ""),
                existing.get("gui_image_name", ""),
            ),
            flush=True,
        )
        return True

    def _prepare_one_image(
        self,
        source_image: dict,
        *,
        instance_id: str,
        env: VolcengineEnv | None = None,
        raise_on_failure: bool,
    ) -> dict[str, str]:
        source_image_id = image_record_field(source_image, "ImageId", "image_id")
        source_image_name = image_display_name(source_image)
        record = {
            "source_image_id": source_image_id,
            "source_image_name": source_image_name,
            "desktop_user": "",
            "gui_image_name": build_gui_image_name(source_image_name),
            "gui_image_id": "",
            "status": "running@%s" % instance_id,
        }
        self._save_record(record)
        worker_env = env or VolcengineEnv(region=REGION)
        try:
            result = process_ubuntu_image_to_gui(worker_env, instance_id, source_image)
            record.update(
                {
                    "desktop_user": result["desktop_user"],
                    "gui_image_name": result["gui_image_name"],
                    "gui_image_id": result["gui_image_id"],
                    "status": result["status"],
                }
            )
        except GuiBakeInstanceUnavailableError as exc:
            record["status"] = "pending_retry: %s" % exc
            self._save_record(record)
            raise
        except GuiBakeImageIncompatibleError as exc:
            record["status"] = "failed: image_incompatible@%s" % exc
            self._save_record(record)
            print(
                "GUI_PREPARE_IMAGE_INCOMPATIBLE source_image_id=%s instance_id=%s error=%s"
                % (source_image_id, instance_id, exc),
                flush=True,
            )
        except Exception as exc:
            record["status"] = "failed@%s: %s" % (instance_id, exc)
            self._save_record(record)
            print(
                "GUI_PREPARE_FAILED source_image_id=%s source_image_name=%s instance_id=%s status=%s"
                % (source_image_id, source_image_name, instance_id, record["status"]),
                flush=True,
            )
            if raise_on_failure:
                raise
        else:
            self._save_record(record)
        return record

    def _prepare_batch_concurrently(
        self,
        pending_jobs: list[tuple[int, dict]],
        *,
        raise_on_failure: bool,
    ) -> tuple[list[dict[str, str]], list[str]]:
        if not self.probe_instance_ids:
            raise ValueError(
                "未配置探测实例，请设置 IMAGE_PROBE_INSTANCE_IDS、IMAGE_PROBE_INSTANCE_ID 或 INSTANCE_IDS"
            )

        def _prepare_one(source_image: dict, instance_id: str) -> dict[str, str]:
            return self._prepare_one_image(
                source_image,
                instance_id=instance_id,
                raise_on_failure=False,
            )

        def _on_no_available_instances(source_image: dict, quarantined: set[str]) -> dict[str, str]:
            record = build_gui_bake_no_instance_record(source_image, quarantined)
            self._save_record(record)
            return record

        results, quarantined_instance_ids = run_gui_bake_pipeline(
            pending_jobs,
            self.probe_instance_ids,
            prepare_one=_prepare_one,
            on_no_available_instances=_on_no_available_instances,
        )

        if raise_on_failure:
            for record in results:
                status = str(record.get("status") or "")
                if status.startswith("failed: no available instances"):
                    raise RuntimeError(status)

        return results, quarantined_instance_ids

    def test_prepare_ubuntu_images_to_gui(self):
        if IMAGE_PROBE_TARGET_IMAGE_ID:
            ubuntu_images = [self.env.describe_image(IMAGE_PROBE_TARGET_IMAGE_ID)]
        else:
            images = list_region_images(self.api, region=REGION)
            ubuntu_images = filter_ubuntu_images(images)
            if IMAGE_PROBE_MAX_IMAGES > 0:
                ubuntu_images = ubuntu_images[:IMAGE_PROBE_MAX_IMAGES]

        worker_count = resolve_gui_prepare_worker_count(len(ubuntu_images), self.probe_instance_ids)
        print(
            "开始 GUI 烘焙: region=%s configured_instances=%s instance_ids=%s max_workers=%s effective_workers=%s ubuntu_image_count=%s skip_existing=%s"
            % (
                REGION,
                len(self.probe_instance_ids),
                ",".join(self.probe_instance_ids),
                GUI_IMAGE_PREPARE_MAX_WORKERS,
                worker_count,
                len(ubuntu_images),
                GUI_IMAGE_SKIP_EXISTING,
            ),
            flush=True,
        )
        if len(self.probe_instance_ids) < GUI_IMAGE_PREPARE_MAX_WORKERS:
            print(
                "GUI_PREPARE_CONCURRENCY_CAPPED 已配置 %s 台实例，并发自动限制为 %s（max_workers=%s）"
                % (len(self.probe_instance_ids), worker_count, GUI_IMAGE_PREPARE_MAX_WORKERS),
                flush=True,
            )
        self.assertTrue(ubuntu_images, "cn-guangzhou 下没有可烘焙的 Ubuntu 镜像")
        self.assertTrue(
            self.probe_instance_ids,
            "未配置探测实例，请设置 IMAGE_PROBE_INSTANCE_IDS、IMAGE_PROBE_INSTANCE_ID 或 INSTANCE_IDS",
        )

        baked_count = 0
        skipped_count = 0
        failed_count = 0
        raise_on_failure = bool(IMAGE_PROBE_TARGET_IMAGE_ID)
        pending_jobs: list[tuple[int, dict]] = []
        for index, image in enumerate(ubuntu_images, start=1):
            source_image_id = image_record_field(image, "ImageId", "image_id")
            source_image_name = image_display_name(image)
            if self._should_skip_existing(source_image_id, source_image_name):
                skipped_count += 1
                if raise_on_failure:
                    self.skipTest(
                        "源镜像已完成 GUI 烘焙，跳过重复处理: source_image_id=%s" % source_image_id
                    )
                continue
            pending_jobs.append((index, image))

        if pending_jobs:
            records, quarantined_instance_ids = self._prepare_batch_concurrently(
                pending_jobs,
                raise_on_failure=raise_on_failure,
            )
            for record in records:
                if record["status"] == "success":
                    baked_count += 1
                else:
                    failed_count += 1
        else:
            quarantined_instance_ids = []

        report = {
            "region": REGION,
            "instance_ids": self.probe_instance_ids,
            "max_workers": GUI_IMAGE_PREPARE_MAX_WORKERS,
            "effective_workers": worker_count,
            "quarantined_instance_ids": quarantined_instance_ids,
            "ubuntu_image_count": len(ubuntu_images),
            "baked_count": baked_count,
            "skipped_count": skipped_count,
            "failed_count": failed_count,
            "spreadsheet_url": self.sheet_info["spreadsheet_url"],
            "sheet_title": GUI_IMAGE_SHEET_TITLE,
            "finished_at": datetime.now().strftime("%Y%m%d_%H%M%S"),
        }
        print("REPORT_JSON", json.dumps(report, ensure_ascii=False), flush=True)
        print("飞书电子表格: %s" % self.sheet_info["spreadsheet_url"], flush=True)

        self.assertTrue(self.sheet_info["spreadsheet_url"])
        if raise_on_failure:
            record = find_gui_record(self.records, image_record_field(ubuntu_images[0], "ImageId", "image_id"))
            self.assertIsNotNone(record)
            assert record is not None
            self.assertEqual(record["status"], "success")
            self.assertTrue(record["gui_image_id"])
            self.assertTrue(record["desktop_user"])
        else:
            self.assertGreater(baked_count + skipped_count + failed_count, 0)


class TestGuangzhouUbuntuGuiImagePrepareHelpers(unittest.TestCase):
    def test_build_gui_image_name_appends_suffix(self):
        self.assertEqual(build_gui_image_name("ubuntu-bios-init_bj"), "ubuntu-bios-init_bj_gui")

    def test_build_gui_image_name_avoids_duplicate_suffix(self):
        self.assertEqual(build_gui_image_name("ubuntu-bios-init_bj_gui"), "ubuntu-bios-init_bj_gui")

    def test_assert_pyautogui_size_output_requires_expected_resolution(self):
        from open_workflowgym.envs.volcengine_env import assert_pyautogui_size_output

        output = "WORKFLOWGYM_PYAUTOGUI_SIZE 1920x1080"
        width, height = assert_pyautogui_size_output(output, 1920, 1080)
        self.assertEqual((width, height), (1920, 1080))

    def test_gui_image_enable_auto_login_defaults_true(self):
        from open_workflowgym.envs.volcengine_env import gui_image_enable_auto_login

        previous = os.environ.get("GUI_IMAGE_ENABLE_AUTO_LOGIN")
        try:
            os.environ.pop("GUI_IMAGE_ENABLE_AUTO_LOGIN", None)
            self.assertTrue(gui_image_enable_auto_login())
            os.environ["GUI_IMAGE_ENABLE_AUTO_LOGIN"] = "0"
            self.assertFalse(gui_image_enable_auto_login())
        finally:
            if previous is None:
                os.environ.pop("GUI_IMAGE_ENABLE_AUTO_LOGIN", None)
            else:
                os.environ["GUI_IMAGE_ENABLE_AUTO_LOGIN"] = previous

    def test_build_prepare_pyautogui_dependencies_command_sanitizes_broken_apt_sources(self):
        command = build_prepare_pyautogui_dependencies_command()
        self.assertIn("workflowgym_sanitize_apt_sources", command)
        self.assertIn("puppet_enterprise", command)
        self.assertIn("adoptium", command)
        self.assertIn("zabbix", command)
        self.assertIn("file:", command)
        self.assertIn("/etc/apt/sources.list", command)
        self.assertIn("URIs:", command)
        self.assertIn("workflowgym_pip_install_pyautogui", command)
        self.assertIn("pypi.tuna.tsinghua.edu.cn", command)
        self.assertIn("pip install --upgrade pip setuptools packaging wheel", command)

    def test_is_gui_bake_success_requires_success_status_and_image_id(self):
        self.assertTrue(
            is_gui_bake_success(
                {
                    "source_image_id": "image-1",
                    "status": "success",
                    "gui_image_id": "image-gui-1",
                }
            )
        )
        self.assertFalse(
            is_gui_bake_success(
                {
                    "source_image_id": "image-1",
                    "status": "running",
                    "gui_image_id": "",
                }
            )
        )
        self.assertFalse(
            is_gui_bake_success(
                {
                    "source_image_id": "image-1",
                    "status": "failed: timeout",
                    "gui_image_id": "image-gui-1",
                }
            )
        )

    def test_find_gui_record_matches_source_image_id(self):
        records = [
            {"source_image_id": "image-a", "status": "success", "gui_image_id": "image-a-gui"},
            {"source_image_id": "image-b", "status": "running", "gui_image_id": ""},
        ]
        self.assertEqual(find_gui_record(records, "image-a"), records[0])
        self.assertIsNone(find_gui_record(records, "image-missing"))

    def test_parse_probe_instance_ids_falls_back_to_instance_ids(self):
        previous_multi = os.environ.get("IMAGE_PROBE_INSTANCE_IDS")
        previous_single = os.environ.get("IMAGE_PROBE_INSTANCE_ID")
        previous_shared = os.environ.get("INSTANCE_IDS")
        try:
            os.environ.pop("IMAGE_PROBE_INSTANCE_IDS", None)
            os.environ.pop("IMAGE_PROBE_INSTANCE_ID", None)
            os.environ["INSTANCE_IDS"] = "i-shared-a,i-shared-b"
            self.assertEqual(parse_probe_instance_ids(), ["i-shared-a", "i-shared-b"])
        finally:
            if previous_multi is None:
                os.environ.pop("IMAGE_PROBE_INSTANCE_IDS", None)
            else:
                os.environ["IMAGE_PROBE_INSTANCE_IDS"] = previous_multi
            if previous_single is None:
                os.environ.pop("IMAGE_PROBE_INSTANCE_ID", None)
            else:
                os.environ["IMAGE_PROBE_INSTANCE_ID"] = previous_single
            if previous_shared is None:
                os.environ.pop("INSTANCE_IDS", None)
            else:
                os.environ["INSTANCE_IDS"] = previous_shared

    def test_parse_probe_instance_ids_returns_builtin_defaults_when_unconfigured(self):
        previous_multi = os.environ.get("IMAGE_PROBE_INSTANCE_IDS")
        previous_single = os.environ.get("IMAGE_PROBE_INSTANCE_ID")
        previous_shared = os.environ.get("INSTANCE_IDS")
        previous_auto = os.environ.get("IMAGE_PROBE_AUTO_DISCOVER")
        try:
            os.environ.pop("IMAGE_PROBE_INSTANCE_IDS", None)
            os.environ.pop("IMAGE_PROBE_INSTANCE_ID", None)
            os.environ.pop("INSTANCE_IDS", None)
            os.environ["IMAGE_PROBE_AUTO_DISCOVER"] = "0"
            self.assertEqual(parse_probe_instance_ids(), list(DEFAULT_IMAGE_PROBE_INSTANCE_IDS))
            self.assertGreater(len(parse_probe_instance_ids()), 0)
        finally:
            if previous_multi is None:
                os.environ.pop("IMAGE_PROBE_INSTANCE_IDS", None)
            else:
                os.environ["IMAGE_PROBE_INSTANCE_IDS"] = previous_multi
            if previous_single is None:
                os.environ.pop("IMAGE_PROBE_INSTANCE_ID", None)
            else:
                os.environ["IMAGE_PROBE_INSTANCE_ID"] = previous_single
            if previous_shared is None:
                os.environ.pop("INSTANCE_IDS", None)
            else:
                os.environ["INSTANCE_IDS"] = previous_shared
            if previous_auto is None:
                os.environ.pop("IMAGE_PROBE_AUTO_DISCOVER", None)
            else:
                os.environ["IMAGE_PROBE_AUTO_DISCOVER"] = previous_auto

    def test_parse_probe_instance_ids_uses_auto_discovered_instances(self):
        import tests.test_guangzhou_linux_image_desktop_user_probe as probe_module

        previous_auto = os.environ.get("IMAGE_PROBE_AUTO_DISCOVER")
        try:
            os.environ.pop("IMAGE_PROBE_INSTANCE_IDS", None)
            os.environ.pop("IMAGE_PROBE_INSTANCE_ID", None)
            os.environ.pop("INSTANCE_IDS", None)
            os.environ["IMAGE_PROBE_AUTO_DISCOVER"] = "1"
            with mock.patch.object(
                probe_module,
                "discover_image_probe_instance_ids",
                return_value=["i-discovered-a", "i-discovered-b"],
            ):
                self.assertEqual(parse_probe_instance_ids(), ["i-discovered-a", "i-discovered-b"])
        finally:
            if previous_auto is None:
                os.environ.pop("IMAGE_PROBE_AUTO_DISCOVER", None)
            else:
                os.environ["IMAGE_PROBE_AUTO_DISCOVER"] = previous_auto

    def test_parse_probe_instance_ids_prefers_multi_value_env(self):
        previous_multi = os.environ.get("IMAGE_PROBE_INSTANCE_IDS")
        previous_single = os.environ.get("IMAGE_PROBE_INSTANCE_ID")
        try:
            os.environ["IMAGE_PROBE_INSTANCE_IDS"] = "i-a, i-b ,i-c"
            os.environ["IMAGE_PROBE_INSTANCE_ID"] = "i-single"
            self.assertEqual(parse_probe_instance_ids(), ["i-a", "i-b", "i-c"])
        finally:
            if previous_multi is None:
                os.environ.pop("IMAGE_PROBE_INSTANCE_IDS", None)
            else:
                os.environ["IMAGE_PROBE_INSTANCE_IDS"] = previous_multi
            if previous_single is None:
                os.environ.pop("IMAGE_PROBE_INSTANCE_ID", None)
            else:
                os.environ["IMAGE_PROBE_INSTANCE_ID"] = previous_single

    def test_resolve_gui_prepare_worker_count_caps_by_instances_and_pending_jobs(self):
        instance_ids = ["i-a", "i-b", "i-c"]
        self.assertEqual(resolve_gui_prepare_worker_count(20, instance_ids), 3)
        self.assertEqual(resolve_gui_prepare_worker_count(2, instance_ids), 2)
        self.assertEqual(resolve_gui_prepare_worker_count(0, instance_ids), 1)

    def test_resolve_gui_prepare_worker_count_uses_configured_instance_count_when_below_max(self):
        import tests.test_guangzhou_ubuntu_gui_image_prepare as gui_prepare_module

        original = gui_prepare_module.GUI_IMAGE_PREPARE_MAX_WORKERS
        try:
            gui_prepare_module.GUI_IMAGE_PREPARE_MAX_WORKERS = 10
            instance_ids = ["i-a", "i-b", "i-c"]
            self.assertEqual(gui_prepare_module.resolve_gui_prepare_worker_count(100, instance_ids), 3)
        finally:
            gui_prepare_module.GUI_IMAGE_PREPARE_MAX_WORKERS = original

    def test_resolve_gui_prepare_worker_count_limits_to_max_workers(self):
        import tests.test_guangzhou_ubuntu_gui_image_prepare as gui_prepare_module

        original = gui_prepare_module.GUI_IMAGE_PREPARE_MAX_WORKERS
        try:
            gui_prepare_module.GUI_IMAGE_PREPARE_MAX_WORKERS = 10
            instance_ids = ["i-%s" % index for index in range(20)]
            self.assertEqual(gui_prepare_module.resolve_gui_prepare_worker_count(20, instance_ids), 10)
        finally:
            gui_prepare_module.GUI_IMAGE_PREPARE_MAX_WORKERS = original

    def test_plan_gui_bake_round_assigns_unique_available_instances(self):
        retry_jobs = [(1, {"ImageId": "image-1"}), (2, {"ImageId": "image-2"}), (3, {"ImageId": "image-3"})]
        assignments, deferred_jobs, available_instances = plan_gui_bake_round(
            retry_jobs,
            ["i-a", "i-b", "i-c", "i-d"],
            set(),
            max_workers=2,
        )
        self.assertEqual(len(assignments), 2)
        self.assertEqual(assignments[0][2], "i-a")
        self.assertEqual(assignments[1][2], "i-b")
        self.assertEqual(len(deferred_jobs), 1)
        self.assertEqual(deferred_jobs[0][0], 3)
        self.assertEqual(available_instances, ["i-a", "i-b", "i-c", "i-d"])

    def test_plan_gui_bake_round_skips_quarantined_instances(self):
        retry_jobs = [(1, {"ImageId": "image-1"})]
        assignments, deferred_jobs, available_instances = plan_gui_bake_round(
            retry_jobs,
            ["i-a", "i-b"],
            {"i-a"},
            max_workers=10,
        )
        self.assertEqual(assignments, [(1, {"ImageId": "image-1"}, "i-b")])
        self.assertEqual(deferred_jobs, [])
        self.assertEqual(available_instances, ["i-b"])

    def test_run_gui_bake_pipeline_reuses_instance_for_next_job(self):
        import tests.test_guangzhou_ubuntu_gui_image_prepare as gui_prepare_module

        jobs = [
            (1, {"ImageId": "image-1", "ImageName": "preview-1"}),
            (2, {"ImageId": "image-2", "ImageName": "preview-2"}),
            (3, {"ImageId": "image-3", "ImageName": "preview-3"}),
        ]
        instance_usage: list[str] = []
        usage_lock = threading.Lock()

        def prepare_one(source_image: dict, instance_id: str) -> dict[str, str]:
            with usage_lock:
                instance_usage.append(instance_id)
            return {
                "source_image_id": source_image["ImageId"],
                "status": "success",
            }

        results, quarantined = gui_prepare_module.run_gui_bake_pipeline(
            jobs,
            ["i-a"],
            prepare_one=prepare_one,
            on_no_available_instances=lambda source_image, quarantined: {
                "source_image_id": source_image["ImageId"],
                "status": "failed: no available instances",
            },
            max_workers=10,
        )
        self.assertEqual(len(results), 3)
        self.assertEqual(instance_usage, ["i-a", "i-a", "i-a"])
        self.assertEqual(quarantined, [])

    def test_run_gui_bake_pipeline_replaces_quarantined_instance(self):
        import tests.test_guangzhou_ubuntu_gui_image_prepare as gui_prepare_module

        jobs = [(1, {"ImageId": "image-1", "ImageName": "preview-1"})]
        calls: list[str] = []

        def prepare_one(source_image: dict, instance_id: str) -> dict[str, str]:
            calls.append(instance_id)
            if instance_id == "i-a":
                raise gui_prepare_module.GuiBakeInstanceUnavailableError("broken")
            return {
                "source_image_id": source_image["ImageId"],
                "status": "success",
            }

        results, quarantined = gui_prepare_module.run_gui_bake_pipeline(
            jobs,
            ["i-a", "i-b"],
            prepare_one=prepare_one,
            on_no_available_instances=lambda source_image, quarantined: {
                "source_image_id": source_image["ImageId"],
                "status": "failed: no available instances",
            },
            max_workers=10,
        )
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["status"], "success")
        self.assertEqual(calls, ["i-a", "i-b"])
        self.assertEqual(quarantined, ["i-a"])

    def test_run_gui_bake_pipeline_marks_remaining_jobs_when_all_instances_quarantined(self):
        import tests.test_guangzhou_ubuntu_gui_image_prepare as gui_prepare_module

        jobs = [
            (1, {"ImageId": "image-1", "ImageName": "preview-1"}),
            (2, {"ImageId": "image-2", "ImageName": "preview-2"}),
        ]

        def prepare_one(source_image: dict, instance_id: str) -> dict[str, str]:
            raise gui_prepare_module.GuiBakeInstanceUnavailableError("broken")

        results, quarantined = gui_prepare_module.run_gui_bake_pipeline(
            jobs,
            ["i-a"],
            prepare_one=prepare_one,
            on_no_available_instances=lambda source_image, quarantined: {
                "source_image_id": source_image["ImageId"],
                "status": "failed: no available instances, quarantined=%s"
                % ",".join(sorted(quarantined)),
            },
            max_workers=10,
        )
        self.assertEqual(len(results), 2)
        self.assertTrue(all("failed: no available instances" in record["status"] for record in results))
        self.assertEqual(quarantined, ["i-a"])

    def test_run_gui_bake_instance_setup_wraps_instance_errors(self):
        class _BrokenEnv:
            def ensure_stopped(self, instance_id: str, timeout_seconds: int = 600, sample_dir: str = "") -> None:
                raise RuntimeError("instance unreachable")

        with self.assertRaises(GuiBakeInstanceUnavailableError) as ctx:
            run_gui_bake_instance_setup(_BrokenEnv(), "i-broken", "image-1")
        self.assertIn("i-broken", str(ctx.exception))
        self.assertIn("image-1", str(ctx.exception))

    def test_is_arm_image_detects_arm_markers_in_name(self):
        from tests.test_guangzhou_linux_image_desktop_user_probe import is_arm_image

        self.assertTrue(
            is_arm_image(
                {
                    "ImageName": "Ubuntu 24.04 ARM 64 bit",
                    "ImageId": "image-arm",
                }
            )
        )
        self.assertFalse(
            is_arm_image(
                {
                    "ImageName": "Ubuntu 24.04 64 bit",
                    "ImageId": "image-x86",
                }
            )
        )

    def test_is_instance_type_mismatch_error_detects_volcengine_code(self):
        self.assertTrue(
            is_instance_type_mismatch_error(
                RuntimeError(
                    '{"Error":{"Code":"InvalidImage.InstanceTypeMismatch","Message":"The specified image and instance type do not match."}}'
                )
            )
        )
        self.assertFalse(is_instance_type_mismatch_error(RuntimeError("instance unreachable")))

    def test_run_gui_bake_instance_setup_raises_image_incompatible_for_arch_mismatch(self):
        class _MismatchEnv:
            def ensure_stopped(self, instance_id: str, timeout_seconds: int = 600, sample_dir: str = "") -> None:
                return None

            def replace_system_volume(self, instance_id: str, image_id: str) -> None:
                raise RuntimeError(
                    '{"Error":{"Code":"InvalidImage.InstanceTypeMismatch","Message":"The specified image and instance type do not match."}}'
                )

        with self.assertRaises(GuiBakeImageIncompatibleError):
            run_gui_bake_instance_setup(_MismatchEnv(), "i-x86", "image-arm")


if __name__ == "__main__":
    unittest.main()
