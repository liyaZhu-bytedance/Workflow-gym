from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.judgers.agent import JudgerAgent
from open_workflowgym.records import TaskFileResult, TrajectoryResult

TASK_FINAL_ANSWER = "image_hash.txt"
TASK_IMAGE_HASH_CONTENT = "e4d909c290d0fb1ca068ffaddf22cbd0  bg2.jpg\n"


def write_minimal_jpeg(path: Path) -> None:
    from PIL import Image

    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", (48, 48), color=(120, 80, 200)).save(path, "JPEG")


def build_trajectory_with_product(sample_dir: str, *, metric_type: str, answer_type: str) -> TrajectoryResult:
    screenshot_path = Path(sample_dir) / "step_0.jpg"
    write_minimal_jpeg(screenshot_path)
    traj_path = Path(sample_dir) / "traj.json"
    traj_path.write_text(
        json.dumps([{"step": 0, "screenshot": str(screenshot_path), "response": "done"}], ensure_ascii=False),
        encoding="utf-8",
    )
    for name in ("traj.md", "sample_metadata.json", "sample_status.json"):
        (Path(sample_dir) / name).write_text("", encoding="utf-8")

    task_fields = {
        "answer_type": answer_type,
        "metric_type": metric_type,
        "response_reference": "检查界面状态",
        "final_answer文件名": TASK_FINAL_ANSWER,
    }
    if metric_type == "image-llm":
        task_fields["sheetshot_url"] = str(Path(sample_dir) / "reference.png")
        (Path(sample_dir) / "reference.png").write_bytes(screenshot_path.read_bytes())

    return TrajectoryResult(
        run_id="run-archive",
        task_id="42",
        sample_index=1,
        status="sample_completed",
        sample_dir=sample_dir,
        traj_json_path=str(traj_path),
        traj_md_path=str(Path(sample_dir) / "traj.md"),
        id_json_path=str(Path(sample_dir) / "sample_metadata.json"),
        sample_status_path=str(Path(sample_dir) / "sample_status.json"),
        task_files=TaskFileResult(
            final_answer_files=[TASK_FINAL_ANSWER],
            output_uploads=[
                {
                    "relative_path": TASK_FINAL_ANSWER,
                    "tos_url": "https://example.com/student/image_hash.txt",
                    "status": "uploaded",
                }
            ],
        ),
        task_fields=task_fields,
    )


class JudgerProductArchiveTest(unittest.TestCase):
    def test_last_screenshot_judge_archives_production(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            student_file = Path(temp_dir) / "student" / TASK_FINAL_ANSWER
            student_file.parent.mkdir(parents=True, exist_ok=True)
            student_file.write_text(TASK_IMAGE_HASH_CONTENT, encoding="utf-8")
            trajectory = build_trajectory_with_product(
                temp_dir,
                metric_type="LLM-as-judge",
                answer_type="数值/文本-多点验证",
            )

            def fake_download(url: str, target_path: str) -> None:
                Path(target_path).parent.mkdir(parents=True, exist_ok=True)
                Path(target_path).write_bytes(student_file.read_bytes())

            with patch("open_workflowgym.judgers.file_product.download_remote_file", side_effect=fake_download):
                with patch(
                    "open_workflowgym.judgers.screenshot.JudgeModelFactory.create"
                ) as create_factory:
                    create_factory.return_value.call_model.return_value = '{"answer_score": 1, "exists": true}'
                    result = JudgerAgent().judge(trajectory)

            self.assertTrue((Path(temp_dir) / "production" / TASK_FINAL_ANSWER).is_file())
            self.assertTrue(result["production_snapshots"][0]["production_saved"])

    def test_image_llm_judge_archives_production(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            student_file = Path(temp_dir) / "student" / TASK_FINAL_ANSWER
            student_file.parent.mkdir(parents=True, exist_ok=True)
            student_file.write_text(TASK_IMAGE_HASH_CONTENT, encoding="utf-8")
            trajectory = build_trajectory_with_product(
                temp_dir,
                metric_type="image-llm",
                answer_type="数值/文本-多点验证",
            )

            def fake_download(url: str, target_path: str) -> None:
                Path(target_path).parent.mkdir(parents=True, exist_ok=True)
                if "student" in url:
                    Path(target_path).write_bytes(student_file.read_bytes())
                else:
                    Path(target_path).write_bytes((Path(temp_dir) / "reference.png").read_bytes())

            with patch("open_workflowgym.judgers.file_product.download_remote_file", side_effect=fake_download):
                with patch(
                    "open_workflowgym.judgers.image_llm.JudgeModelFactory.create"
                ) as create_factory:
                    create_factory.return_value.call_model.return_value = '{"answer_score": 1}'
                    result = JudgerAgent().judge(trajectory)

            self.assertTrue((Path(temp_dir) / "production" / TASK_FINAL_ANSWER).is_file())
            self.assertTrue(result["production_snapshots"][0]["production_saved"])


if __name__ == "__main__":
    unittest.main()
