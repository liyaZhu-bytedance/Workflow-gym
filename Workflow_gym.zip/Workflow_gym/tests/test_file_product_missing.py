from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.judgers.agent import JudgerAgent
from open_workflowgym.judgers.file_product import (
    archive_student_products,
    product_text_from_production_snapshots,
)
from open_workflowgym.judgers.rubrics import RubricsJudgerMixin
from open_workflowgym.records import TaskFileResult, TrajectoryResult

TASK_FINAL_ANSWER = "Mix.wav"
TASK_FINAL_ANSWER_URL = "https://cdn.example.local/obj/synthetic-gui-data/base_sheets_output/589/Mix.wav"
RUBRICS_JSON = json.dumps(
    {
        "硬约束": [{"rubric描述": "产物正确", "0分情况": "未生成", "1分情况": "正确"}],
        "软约束": [],
    },
    ensure_ascii=False,
)


def write_minimal_jpeg(path: Path) -> None:
    from PIL import Image

    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", (48, 48), color=(120, 80, 200)).save(path, "JPEG")


def build_missing_output_trajectory(
    sample_dir: str,
    *,
    metric_type: str,
    answer_type: str = "文件产物",
) -> TrajectoryResult:
    screenshot_path = Path(sample_dir) / "step_0.jpg"
    write_minimal_jpeg(screenshot_path)
    traj_path = Path(sample_dir) / "traj.json"
    traj_path.write_text(
        json.dumps([{"step": 0, "screenshot": str(screenshot_path), "response": "finished"}], ensure_ascii=False),
        encoding="utf-8",
    )
    for name in ("traj.md", "sample_metadata.json", "sample_status.json"):
        (Path(sample_dir) / name).write_text("", encoding="utf-8")

    return TrajectoryResult(
        run_id="run-missing",
        task_id="589",
        sample_index=1,
        status="sample_completed",
        sample_dir=sample_dir,
        traj_json_path=str(traj_path),
        traj_md_path=str(Path(sample_dir) / "traj.md"),
        id_json_path=str(Path(sample_dir) / "sample_metadata.json"),
        sample_status_path=str(Path(sample_dir) / "sample_status.json"),
        task_files=TaskFileResult(
            final_answer_files=[TASK_FINAL_ANSWER],
            errors=["缺少 final answer 文件: /home/user/Desktop/output/Mix.wav"],
            output_uploads=[
                {
                    "relative_path": TASK_FINAL_ANSWER,
                    "source_path": "/home/user/Desktop/output/Mix.wav",
                    "tos_url": "tos://open-workflowgym-sample/sample_run/589/sample_1/production/Mix.wav",
                    "tos_path": "tos://open-workflowgym-sample/sample_run/589/sample_1/production/Mix.wav",
                    "status": "missing",
                    "output_file_exists": False,
                    "file_check": {"exists": False},
                }
            ],
        ),
        task_fields={
            "answer_type": answer_type,
            "metric_type": metric_type,
            "final_answer文件名": TASK_FINAL_ANSWER,
            "final answer 文件": str([TASK_FINAL_ANSWER_URL]),
            "rubrics": RUBRICS_JSON,
            "response_reference": "检查混音结果",
        },
    )


class FileProductMissingTest(unittest.TestCase):
    def test_archive_student_products_skips_download_when_output_missing(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            trajectory = build_missing_output_trajectory(temp_dir, metric_type="规则判分")
            with patch("open_workflowgym.judgers.file_product.download_remote_file") as download:
                snapshots = archive_student_products(trajectory)

            download.assert_not_called()
            self.assertFalse(snapshots[0]["production_saved"])
            self.assertEqual(snapshots[0]["error"], "产物未生成，跳过下载")

    def test_judge_rule_files_scores_zero_without_student_download(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            trajectory = build_missing_output_trajectory(temp_dir, metric_type="规则判分")
            with patch("open_workflowgym.judgers.file_product.download_remote_file") as download:
                result = JudgerAgent().judge(trajectory)

            downloaded_urls = [str(call.args[0]) for call in download.call_args_list]
            self.assertEqual(downloaded_urls, [TASK_FINAL_ANSWER_URL])
            self.assertEqual(result["answer_score"], 0)
            self.assertIn("未生成", result["evidence"])

    def test_judge_file_content_scores_zero_without_student_download(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            trajectory = build_missing_output_trajectory(temp_dir, metric_type="规则判分+LLM-as-judge")
            with patch("open_workflowgym.judgers.file_product.download_remote_file") as download:
                with patch(
                    "open_workflowgym.judgers.file_product.JudgeModelFactory.create"
                ) as create_factory:
                    result = JudgerAgent().judge(trajectory)

            downloaded_urls = [str(call.args[0]) for call in download.call_args_list]
            self.assertEqual(downloaded_urls, [TASK_FINAL_ANSWER_URL])
            create_factory.assert_not_called()
            self.assertEqual(result["answer_score"], 0)
            self.assertIn("未生成", result["evidence"])

    def test_product_text_marks_missing_without_download(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            trajectory = build_missing_output_trajectory(temp_dir, metric_type="Rubrics")
            snapshots = archive_student_products(trajectory)
            with patch("open_workflowgym.judgers.file_product.download_remote_file") as download:
                text = product_text_from_production_snapshots(trajectory, snapshots)

            download.assert_not_called()
            self.assertIn("(文件不存在)", text)

    def test_judge_rubrics_continues_without_student_download(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            trajectory = build_missing_output_trajectory(temp_dir, metric_type="Rubrics")

            def fake_download(url: str, target_path: str) -> None:
                Path(target_path).parent.mkdir(parents=True, exist_ok=True)
                Path(target_path).write_bytes(b"gt-audio")

            with patch("open_workflowgym.judgers.file_product.download_remote_file", side_effect=fake_download) as download:
                with patch(
                    "open_workflowgym.judgers.rubrics.call_judge_model",
                    return_value='{"score": 0, "reason": "no output"}',
                ):
                    result = RubricsJudgerMixin().judge_rubrics(trajectory, "文件产物", "Rubrics")

            downloaded_urls = [str(call.args[0]) for call in download.call_args_list]
            self.assertEqual(downloaded_urls, [TASK_FINAL_ANSWER_URL])
            self.assertEqual(result["status"], "success")
            self.assertEqual(result["answer_score"], 0)
            self.assertEqual(result["hard_item_scores"], [0])
            self.assertEqual(result["production_snapshots"][0]["error"], "产物未生成，跳过下载")


if __name__ == "__main__":
    unittest.main()
