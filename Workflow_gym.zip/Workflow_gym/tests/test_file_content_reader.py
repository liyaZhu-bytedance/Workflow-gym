from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import unittest
import zipfile
from dataclasses import dataclass
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.judgers.file_content_reader import (
    EXCEL_OPENXML_EXTENSIONS,
    _READERS,
    _TEXT_FALLBACK_WHITELIST,
    read_file_content,
    read_xlsx_file,
)


def _has_module(name: str) -> bool:
    return importlib.util.find_spec(name) is not None


@dataclass(frozen=True)
class ExtensionExpectation:
    extension: str
    expect_ok: bool
    note: str = ""


# 仅 plain-text reader；Office/PDF 等见 EXCEL_OPENXML_EXTENSIONS 与 build_extension_fixture。
TEXT_LIKE_EXTENSIONS = {
    ".txt",
    ".md",
    ".markdown",
    ".csv",
    ".log",
    ".json",
    ".xml",
    ".ini",
    ".yaml",
    ".yml",
}

UNSUPPORTED_EXTENSIONS = (".png", ".zip", ".bin")

# Minimal one-page PDF with extractable text "workflowgym".
MINIMAL_PDF_WITH_TEXT = b"""%PDF-1.4
1 0 obj<</Type /Catalog /Pages 2 0 R>>endobj
2 0 obj<</Type /Pages /Kids [3 0 R] /Count 1>>endobj
3 0 obj<</Type /Page /Parent 2 0 R /MediaBox [0 0 300 300] /Contents 4 0 R /Resources <</Font <</F1 5 0 R>>>>>>endobj
4 0 obj<</Length 51>>stream
BT /F1 12 Tf 72 200 Td (workflowgym) Tj ET
endstream
endobj
5 0 obj<</Type /Font /Subtype /Type1 /BaseFont /Helvetica>>endobj
xref
0 6
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000274 00000 n 
0000000375 00000 n 
trailer<</Size 6 /Root 1 0 R>>
startxref
444
%%EOF"""


def _write_text(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def _write_minimal_png(path: Path) -> None:
    try:
        from PIL import Image

        Image.new("RGB", (2, 2), color="red").save(path, format="PNG")
        return
    except Exception:
        path.write_bytes(
            b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01"
            b"\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde"
            b"\x00\x00\x00\x0cIDATx\x9cc\xf8\x0f\x00\x01\x01\x01\x00"
            b"\x18\xdd\x8d\xb4\x00\x00\x00\x00IEND\xaeB`\x82"
        )


def _write_minimal_zip(path: Path) -> None:
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("hello.txt", "zip fixture")


def _write_minimal_pdf(path: Path) -> None:
    path.write_bytes(MINIMAL_PDF_WITH_TEXT)


def _write_minimal_excel(path: Path, extension: str) -> None:
    from openpyxl import Workbook

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Sheet1"
    sheet["A1"] = "workflowgym"
    sheet["B1"] = 42
    if extension in (".xltx", ".xltm"):
        workbook.template = True
    workbook.save(path)


def _write_minimal_pptx(path: Path) -> None:
    from pptx import Presentation

    presentation = Presentation()
    slide = presentation.slides.add_slide(presentation.slide_layouts[5])
    slide.shapes.title.text = "workflowgym"
    presentation.save(str(path))


def _write_minimal_docx(path: Path) -> None:
    from docx import Document

    document = Document()
    document.add_paragraph("workflowgym docx fixture")
    document.save(str(path))


def build_extension_fixture(base_dir: Path, extension: str) -> Path:
    filename = "fixture%s" % (extension or "")
    path = base_dir / filename

    if extension in TEXT_LIKE_EXTENSIONS:
        if extension == ".json":
            _write_text(path, json.dumps({"workflowgym": "fixture"}, ensure_ascii=False))
        elif extension in (".yaml", ".yml"):
            _write_text(path, "workflowgym: fixture\nvalue: 1\n")
        elif extension == ".csv":
            _write_text(path, "name,value\nworkflowgym,1\n")
        elif extension == ".xml":
            _write_text(path, "<root><item>workflowgym</item></root>\n")
        elif extension == ".ini":
            _write_text(path, "[section]\nkey=workflowgym\n")
        else:
            _write_text(path, "workflowgym text fixture\n")
        return path

    if extension in (".html", ".htm"):
        _write_text(path, "<html><body><p>workflowgym html fixture</p></body></html>\n")
        return path

    if extension == ".pdf":
        _write_minimal_pdf(path)
        return path

    if extension in EXCEL_OPENXML_EXTENSIONS:
        if _has_module("openpyxl"):
            _write_minimal_excel(path, extension)
        else:
            path.write_bytes(b"PK\x03\x04invalid-xlsx-fixture")
        return path

    if extension == ".xls":
        path.write_bytes(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1invalid-xls-fixture")
        return path

    if extension == ".pptx":
        if _has_module("pptx"):
            _write_minimal_pptx(path)
        else:
            path.write_bytes(b"PK\x03\x04invalid-pptx-fixture")
        return path

    if extension == ".ppt":
        path.write_bytes(b"invalid-ppt-binary-fixture")
        return path

    if extension == ".docx":
        if _has_module("docx"):
            _write_minimal_docx(path)
        else:
            path.write_bytes(b"PK\x03\x04invalid-docx-fixture")
        return path

    if extension == ".doc":
        path.write_bytes(b"invalid-doc-binary-fixture")
        return path

    if extension in _TEXT_FALLBACK_WHITELIST:
        _write_text(path, "workflowgym whitelist fixture\n")
        return path

    raise ValueError("unsupported fixture extension: %s" % extension)


def expected_results() -> dict[str, ExtensionExpectation]:
    expectations: dict[str, ExtensionExpectation] = {}

    for extension in sorted(_READERS):
        if extension in TEXT_LIKE_EXTENSIONS or extension in (".html", ".htm"):
            expectations[extension] = ExtensionExpectation(extension, True, "text/html reader")
            continue
        if extension == ".pdf":
            expectations[extension] = ExtensionExpectation(
                extension,
                _has_module("pypdf"),
                "requires pypdf",
            )
            continue
        if extension in EXCEL_OPENXML_EXTENSIONS:
            expectations[extension] = ExtensionExpectation(
                extension,
                _has_module("openpyxl"),
                "excel openxml reader (.xlsx/.xlsm/.xltx/.xltm)",
            )
            continue
        if extension == ".xls":
            expectations[extension] = ExtensionExpectation(
                extension,
                False,
                "legacy xls needs valid file + xlrd",
            )
            continue
        if extension == ".pptx":
            expectations[extension] = ExtensionExpectation(
                extension,
                _has_module("pptx"),
                "requires python-pptx",
            )
            continue
        if extension == ".ppt":
            expectations[extension] = ExtensionExpectation(
                extension,
                False,
                "legacy ppt unsupported by design",
            )
            continue
        if extension == ".docx":
            expectations[extension] = ExtensionExpectation(
                extension,
                _has_module("docx"),
                "requires python-docx",
            )
            continue
        if extension == ".doc":
            expectations[extension] = ExtensionExpectation(
                extension,
                False,
                "legacy doc needs antiword/libreoffice or valid docx payload",
            )
            continue
        expectations[extension] = ExtensionExpectation(extension, True, "registered reader")

    for extension in sorted(_TEXT_FALLBACK_WHITELIST):
        expectations[extension] = ExtensionExpectation(extension, True, "text fallback whitelist")

    for extension in UNSUPPORTED_EXTENSIONS:
        expectations[extension] = ExtensionExpectation(
            extension,
            False,
            "unsupported extension",
        )

    expectations[""] = ExtensionExpectation("", False, "missing extension")
    return expectations


class FileContentReaderExtensionTest(unittest.TestCase):
    def test_excel_openxml_extensions_are_registered_and_readable(self):
        self.assertEqual(EXCEL_OPENXML_EXTENSIONS, frozenset({".xlsx", ".xlsm", ".xltx", ".xltm"}))
        for extension in sorted(EXCEL_OPENXML_EXTENSIONS):
            self.assertIs(_READERS.get(extension), read_xlsx_file)

        with tempfile.TemporaryDirectory(prefix="wg_excel_fixtures_") as temp_dir:
            base_dir = Path(temp_dir)
            for extension in sorted(EXCEL_OPENXML_EXTENSIONS):
                with self.subTest(extension=extension):
                    if not _has_module("openpyxl"):
                        self.skipTest("openpyxl not installed")
                    path = build_extension_fixture(base_dir, extension)
                    result = read_file_content(str(path))
                    self.assertTrue(result.ok, msg=result.error)
                    self.assertIn("workflowgym", result.content or "")

    def test_all_extension_read_results(self):
        expectations = expected_results()
        summaries: list[str] = []

        with tempfile.TemporaryDirectory(prefix="wg_reader_fixtures_") as temp_dir:
            base_dir = Path(temp_dir)

            for extension, spec in sorted(expectations.items(), key=lambda item: item[0] or "(none)"):
                with self.subTest(extension=extension or "(none)", note=spec.note):
                    if extension == "":
                        path = base_dir / "no_extension"
                        path.write_text("workflowgym\n", encoding="utf-8")
                    elif extension in UNSUPPORTED_EXTENSIONS:
                        path = base_dir / ("fixture%s" % extension)
                        if extension == ".png":
                            _write_minimal_png(path)
                        elif extension == ".zip":
                            _write_minimal_zip(path)
                        else:
                            path.write_bytes(b"\x00\x01\x02workflowgym")
                    else:
                        path = build_extension_fixture(base_dir, extension)

                    result = read_file_content(str(path))
                    summaries.append(
                        "%s\tok=%s\tcontent_len=%s\terror=%s\texpected_ok=%s\t(%s)"
                        % (
                            extension or "(none)",
                            result.ok,
                            len(result.content or ""),
                            (result.error or "")[:120],
                            spec.expect_ok,
                            spec.note,
                        )
                    )

                    self.assertEqual(
                        result.ok,
                        spec.expect_ok,
                        msg=(
                            "extension=%s expected_ok=%s got_ok=%s error=%r content_preview=%r note=%s"
                            % (
                                extension or "(none)",
                                spec.expect_ok,
                                result.ok,
                                result.error,
                                (result.content or "")[:200],
                                spec.note,
                            )
                        ),
                    )
                    if spec.expect_ok:
                        self.assertTrue(
                            (result.content or "").strip(),
                            msg="extension=%s read ok but content empty" % (extension or "(none)"),
                        )

            print("\n".join(["file_content_reader extension summary:"] + summaries))

    def test_missing_file_returns_error(self):
        result = read_file_content("/tmp/workflowgym-does-not-exist-reader-test.txt")
        self.assertFalse(result.ok)
        self.assertIn("不存在", result.error or "")


if __name__ == "__main__":
    unittest.main()
