from __future__ import annotations

import os
import shlex
import subprocess
import sys
import unittest
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.judgers.common import extract_json_object

SEED21_ZSHRC_ENV_NAMES = (
    "ARK_API_KEY",
    "SEED2P0_API_KEY",
    "SEED21_BASE_URL",
    "SEED21_MODEL",
)
DEFAULT_SEED21_BASE_URL = "https://ark.cn-beijing.volces.com/api/v3"
DEFAULT_SEED21_MODEL = "doubao-seed-2-1-pro-260628"
DEMO_IMAGE_URL = "https://ark-project.tos-cn-beijing.volces.com/doc_image/ark_demo_img_1.png"
JUDGE_PROMPT = '只返回 JSON：{"score":0,"reason":"seed21pro_live_ok"}'


def read_env(name: str, default: str = "") -> str:
    return (os.getenv(name, default) or "").strip()


def load_zshrc_env(names: tuple[str, ...] = SEED21_ZSHRC_ENV_NAMES, zshrc_path: str = "") -> None:
    missing = [name for name in names if not read_env(name)]
    if not missing:
        return
    zshrc = Path(zshrc_path or os.path.expanduser("~/.zshrc"))
    if not zshrc.is_file():
        return
    zshrc_quoted = shlex.quote(str(zshrc))
    for name in missing:
        try:
            completed = subprocess.run(
                ["zsh", "-lc", "source %s >/dev/null 2>&1; print -r -- ${%s:-}" % (zshrc_quoted, name)],
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        value = (completed.stdout or "").strip()
        if value:
            os.environ[name] = value


def resolve_seed21_api_key() -> str:
    # 与示例一致：优先 ARK_API_KEY；兼容 SEED2P0_API_KEY
    for name in ("ARK_API_KEY", "SEED2P0_API_KEY"):
        value = read_env(name)
        if value:
            return value
    return ""


def seed21_base_url() -> str:
    return read_env("SEED21_BASE_URL") or DEFAULT_SEED21_BASE_URL


def seed21_model() -> str:
    return read_env("SEED21_MODEL") or DEFAULT_SEED21_MODEL


def extract_response_text(response: Any) -> str:
    output_text = getattr(response, "output_text", None)
    if isinstance(output_text, str) and output_text.strip():
        return output_text.strip()

    chunks: list[str] = []
    for item in getattr(response, "output", None) or []:
        item_type = getattr(item, "type", None) or (item.get("type") if isinstance(item, dict) else None)
        if item_type != "message":
            continue
        content = getattr(item, "content", None)
        if content is None and isinstance(item, dict):
            content = item.get("content")
        for part in content or []:
            part_type = getattr(part, "type", None) or (part.get("type") if isinstance(part, dict) else None)
            if part_type not in ("output_text", "text"):
                continue
            text = getattr(part, "text", None)
            if text is None and isinstance(part, dict):
                text = part.get("text")
            if text:
                chunks.append(str(text))
    return "\n".join(chunks).strip()


def call_seed21_responses(*, model: str, input_payload: list[dict[str, Any]]) -> Any:
    from openai import OpenAI  # type: ignore[import-not-found]

    api_key = resolve_seed21_api_key()
    if not api_key:
        raise ValueError(
            "缺少 ARK_API_KEY（或 SEED2P0_API_KEY）。"
            "seed2.1pro 必须真实调用火山方舟，请先 export ARK_API_KEY=..."
        )

    client = OpenAI(
        base_url=seed21_base_url(),
        api_key=api_key,
    )
    return client.responses.create(
        model=model,
        input=input_payload,
    )


class JudgeSeed21ProLiveTest(unittest.TestCase):
    """真实调用火山方舟 seed2.1pro，不做 mock / skip。"""

    @classmethod
    def setUpClass(cls) -> None:
        load_zshrc_env()
        api_key = resolve_seed21_api_key()
        if not api_key:
            raise RuntimeError(
                "缺少 ARK_API_KEY（或 SEED2P0_API_KEY）。"
                "seed2.1pro live 测试必须真实调用火山方舟，请先: export ARK_API_KEY=..."
            )

    def test_seed21pro_text_judge_live_call(self) -> None:
        model = seed21_model()
        response = call_seed21_responses(
            model=model,
            input_payload=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "input_text",
                            "text": JUDGE_PROMPT,
                        }
                    ],
                }
            ],
        )
        raw = extract_response_text(response)
        self.assertTrue(raw, "seed2.1pro 返回空内容 (model=%s)" % model)
        parsed = extract_json_object(raw)
        self.assertIsInstance(parsed, dict, "seed2.1pro 返回无法解析为 JSON: %r" % raw)
        self.assertIn("score", parsed)
        print("seed21pro text live judge response (%s): %s" % (model, raw))

    def test_seed21pro_image_live_call(self) -> None:
        model = seed21_model()
        response = call_seed21_responses(
            model=model,
            input_payload=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "input_image",
                            "image_url": DEMO_IMAGE_URL,
                        },
                        {
                            "type": "input_text",
                            "text": "你看见了什么？请用一句话回答。",
                        },
                    ],
                }
            ],
        )
        raw = extract_response_text(response)
        self.assertTrue(raw, "seed2.1pro 图文返回空内容 (model=%s)" % model)
        print("seed21pro image live response (%s): %s" % (model, raw))


if __name__ == "__main__":
    unittest.main()
