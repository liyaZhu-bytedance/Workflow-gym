from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from open_workflowgym.judgers.common import (
    collect_reference_image_paths,
    download_remote_file,
    read_remote_file,
    reference_image_candidates,
)
from open_workflowgym.records import TaskFileResult, TrajectoryResult


class _FakeResponse:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def read(self):
        return b"content"


class JudgerCommonTest(unittest.TestCase):
    def test_read_remote_file_strips_url_query(self):
        with patch("open_workflowgym.judgers.common.urllib.request.urlopen", return_value=_FakeResponse()) as urlopen:
            content = read_remote_file("https://example.com/final.txt?timeout=60s&uploadID=abc")

        self.assertEqual(content, b"content")
        urlopen.assert_called_once_with("https://example.com/final.txt", timeout=60)

    def test_download_remote_file_strips_url_query(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            target = Path(temp_dir) / "final.txt"
            with patch("open_workflowgym.judgers.common.urllib.request.urlopen", return_value=_FakeResponse()) as urlopen:
                download_remote_file("https://example.com/final.txt?timeout=60s&uploadID=abc", str(target))

            self.assertEqual(target.read_bytes(), b"content")
            urlopen.assert_called_once_with("https://example.com/final.txt", timeout=60)

    def test_download_remote_file_rewrites_synthetic_gui_final_answer_url(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            target = Path(temp_dir) / "final.txt"
            with patch("open_workflowgym.judgers.common.urllib.request.urlopen", return_value=_FakeResponse()) as urlopen:
                download_remote_file(
                    "https://data.example.local/base_sheets_output/252/final.txt"
                    "?timeout=60s&uploadID=abc",
                    str(target),
                )

            self.assertEqual(target.read_bytes(), b"content")
            urlopen.assert_called_once_with(
                "https://cdn.example.local/obj/synthetic-gui-data/base_sheets_output/252/final.txt",
                timeout=60,
            )

    def test_reference_image_candidates_from_feishu_sheetshot_dict(self):
        raw_value = [
            {
                "cellPosition": None,
                "link": "https://cdn-icem.example.local/obj/worktime/example-asset-id.png",
                "text": "https://cdn-icem.example.local/obj/worktime/example-asset-id.png",
                "type": "url",
            }
        ]

        self.assertEqual(
            reference_image_candidates(raw_value),
            ["https://cdn-icem.example.local/obj/worktime/example-asset-id.png"],
        )

    def test_reference_image_candidates_from_python_repr_string(self):
        raw_value = (
            "{'cellPosition': None, 'link': 'https://example.com/ref.png', "
            "'text': 'https://example.com/ref.png', 'type': 'url'}"
        )

        self.assertEqual(reference_image_candidates(raw_value), ["https://example.com/ref.png"])

    def test_collect_reference_image_paths_downloads_feishu_sheetshot_url(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            trajectory = TrajectoryResult(
                run_id="run-test",
                task_id="42",
                sample_index=1,
                status="sample_completed",
                sample_dir=temp_dir,
                traj_json_path=str(Path(temp_dir) / "traj.json"),
                traj_md_path=str(Path(temp_dir) / "traj.md"),
                id_json_path=str(Path(temp_dir) / "id.json"),
                sample_status_path=str(Path(temp_dir) / "sample_status.json"),
                task_fields={
                    "sheetshot_url": [
                        {
                            "link": "https://example.com/ref.png",
                            "text": "https://example.com/ref.png",
                            "type": "url",
                        }
                    ],
                    "response_reference": "评估要点",
                },
                task_files=TaskFileResult(),
            )
            with patch("open_workflowgym.judgers.common.urllib.request.urlretrieve") as urlretrieve:
                def fake_download(url, target):
                    Path(target).write_bytes(b"png")

                urlretrieve.side_effect = fake_download
                paths = collect_reference_image_paths(trajectory)

            self.assertEqual(paths, [str(Path(temp_dir) / "gt_sreenshot" / "ref.png")])
            urlretrieve.assert_called_once()


if __name__ == "__main__":
    unittest.main()
