import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))

from export_guangzhou_ubuntu_images_to_tos import (
    build_export_tos_prefix,
    extract_original_image_id,
    local_export_filename,
    normalize_tos_bucket,
    predict_export_object_key,
    predict_export_object_uri,
    strip_image_id_prefix,
)


class TestExportGuangzhouImagesHelpers(unittest.TestCase):
    def test_extract_original_image_id_from_image_name_prefix(self):
        self.assertEqual(
            extract_original_image_id(
                "image-yecwq5rcyrl6wkt5qqye.qcow2_bj",
                "image-yepzrd0gpff9r5r52mon",
            ),
            "image-yecwq5rcyrl6wkt5qqye",
        )

    def test_extract_original_image_id_falls_back_to_guangzhou_id(self):
        self.assertEqual(
            extract_original_image_id(
                "preview-Ubuntu2204_64-Audacity_bj",
                "image-yepznjo25fkhx292gol3",
            ),
            "image-yepznjo25fkhx292gol3",
        )

    def test_build_export_tos_prefix_uses_original_id_without_image_prefix(self):
        self.assertEqual(
            build_export_tos_prefix(
                "image-yecwq5rcyrl6wkt5qqye.qcow2_bj",
                "image-yepzrd0gpff9r5r52mon",
            ),
            "yecwq5rcyrl6wkt5qqye",
        )
        self.assertEqual(
            build_export_tos_prefix(
                "preview-Ubuntu2204_bj",
                "image-yepznjo25fkhx292gol3",
            ),
            "yepznjo25fkhx292gol3",
        )

    def test_strip_image_id_prefix(self):
        self.assertEqual(strip_image_id_prefix("image-abc"), "abc")
        self.assertEqual(strip_image_id_prefix("abc"), "abc")

    def test_predict_export_object_key_matches_volcengine_format(self):
        self.assertEqual(
            predict_export_object_key("yepznjo25fkhx292gol3", "image-yepznjo25fkhx292gol3"),
            "yepznjo25fkhx292gol3_image-yepznjo25fkhx292gol3_system.qcow2",
        )
        self.assertEqual(
            predict_export_object_key("yecwq5rcyrl6wkt5qqye", "image-yepzrd0gpff9r5r52mon"),
            "yecwq5rcyrl6wkt5qqye_image-yepzrd0gpff9r5r52mon_system.qcow2",
        )

    def test_local_export_filename_uses_original_image_name(self):
        self.assertEqual(
            local_export_filename("preview-Ubuntu2204_bj", "image-abc"),
            "preview-Ubuntu2204_bj_system.qcow2",
        )

    def test_normalize_tos_bucket_strips_scheme_and_slashes(self):
        self.assertEqual(normalize_tos_bucket("tos://open-workflowgym-sample/"), "open-workflowgym-sample")

    def test_predict_export_object_uri(self):
        self.assertEqual(
            predict_export_object_uri(
                "open-workflowgym-sample",
                "yepznjo25fkhx292gol3",
                "image-yepznjo25fkhx292gol3",
            ),
            "tos://open-workflowgym-sample/yepznjo25fkhx292gol3_image-yepznjo25fkhx292gol3_system.qcow2",
        )


if __name__ == "__main__":
    unittest.main()
