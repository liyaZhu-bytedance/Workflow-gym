from __future__ import annotations

import os
import shlex
import subprocess
import sys
import time
import unittest
import warnings
from pathlib import Path

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.envs.volcengine_env import (
    VolcengineEnv,
    command_decoded_output,
    windows_login_password,
    windows_login_user,
)


DEFAULT_INSTANCE_ID = "i-yeq4lecmpsnu262idoso"
DEFAULT_WIN_ICON_X = 20
DEFAULT_WIN_ICON_Y = 748
ZSHRC_ENV_NAMES = ("AK", "SK", "WINDOWS_LOGIN_PASSWORD", "INSTANCE_PASSWORD", "VOLCENGINE_REGION", "SOURCE_REGION")


def read_env(name: str, default: str = "") -> str:
    return os.getenv(name, default)


def load_zshrc_env(names: tuple[str, ...] = ZSHRC_ENV_NAMES, zshrc_path: str = "") -> None:
    missing = [name for name in names if not read_env(name)]
    if not missing:
        return
    zshrc = Path(zshrc_path or os.path.expanduser("~/.zshrc"))
    if not zshrc.is_file():
        return
    zshrc_quoted = shlex.quote(str(zshrc))
    for name in missing:
        try:
            completed = subprocess.run(
                ["zsh", "-lc", "source %s >/dev/null 2>&1; print -r -- ${%s:-}" % (zshrc_quoted, name)],
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        value = (completed.stdout or "").strip()
        if value:
            os.environ[name] = value


load_zshrc_env()


def pyautogui_win_r_and_win_icon_as_administrator_command(win_icon_x: int, win_icon_y: int) -> str:
    return r"""$ErrorActionPreference = 'Stop'

$identity = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$sessionId = (Get-Process -Id $PID).SessionId
Write-Output ('WORKFLOWGYM_RUNCOMMAND_IDENTITY identity=' + $identity + ' session=' + $sessionId)

$scriptPath = Join-Path $env:TEMP 'workflowgym_pyautogui_win_r_probe.py'

@"
import time
import pyautogui

pyautogui.FAILSAFE = False

print("PYAUTOGUI_WIN_R_START")
width, height = pyautogui.size()
print("PYAUTOGUI_SIZE", (width, height))
pyautogui.hotkey("winleft", "r")
time.sleep(2)
print("PYAUTOGUI_WIN_R_DONE")

pyautogui.press("esc")
time.sleep(1)

win_icon_x = __WIN_ICON_X__
win_icon_y = __WIN_ICON_Y__
print("PYAUTOGUI_WIN_ICON_START")
print("PYAUTOGUI_WIN_ICON_COORDS", (win_icon_x, win_icon_y))
pyautogui.click(win_icon_x, win_icon_y)
time.sleep(2)
print("PYAUTOGUI_WIN_ICON_DONE")
"@ | Set-Content -LiteralPath $scriptPath -Encoding UTF8

$python = "C:\Program Files\Python312\python.exe"
if (-not (Test-Path -LiteralPath $python)) {
  $pythonCommand = Get-Command python -ErrorAction SilentlyContinue
  if (-not $pythonCommand) {
    throw "python executable not found"
  }
  $python = $pythonCommand.Source
}

& $python $scriptPath
if ($LASTEXITCODE -ne 0) {
  exit $LASTEXITCODE
}
""".replace("__WIN_ICON_X__", str(int(win_icon_x))).replace("__WIN_ICON_Y__", str(int(win_icon_y)))


class WindowsStopStartWinRE2ETest(unittest.TestCase):
    """Manual E2E: stop/start Windows instance, Win+R + Win icon click as Administrator, screenshot."""

    def setUp(self):
        load_zshrc_env()
        self.assertTrue(read_env("AK") and read_env("SK"), "AK/SK missing; set them in ~/.zshrc or the environment")
        self.instance_id = read_env("WORKFLOWGYM_TEST_INSTANCE_ID", DEFAULT_INSTANCE_ID)
        self.region = read_env("VOLCENGINE_REGION", read_env("SOURCE_REGION", "cn-guangzhou"))
        self.output_dir = Path(
            read_env(
                "WORKFLOWGYM_STOP_START_WINR_TEST_OUTPUT_DIR",
                "output/manual_windows_stop_start_winr_test",
            )
        )
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.env = VolcengineEnv(region=self.region)
        self.admin_user = windows_login_user()

    def test_stop_start_pyautogui_win_r_and_screenshot_as_administrator(self):
        password = windows_login_password()
        self.assertTrue(password, "WINDOWS_LOGIN_PASSWORD or INSTANCE_PASSWORD missing; set in ~/.zshrc or the environment")

        stop_timeout = int(read_env("INSTANCE_STOP_TIMEOUT_SECONDS", "600"))
        start_timeout = int(read_env("INSTANCE_START_TIMEOUT_SECONDS", "600"))
        autologin_wait = int(read_env("WINDOWS_AUTO_LOGIN_WAIT_SECONDS", "30"))
        win_icon_x = int(read_env("WORKFLOWGYM_WIN_ICON_X", str(DEFAULT_WIN_ICON_X)))
        win_icon_y = int(read_env("WORKFLOWGYM_WIN_ICON_Y", str(DEFAULT_WIN_ICON_Y)))

        print("WORKFLOWGYM_TEST_INSTANCE", self.instance_id, flush=True)
        print("WORKFLOWGYM_TEST_ADMIN_USER", self.admin_user, flush=True)
        print("WORKFLOWGYM_WIN_ICON_COORDS", win_icon_x, win_icon_y, flush=True)

        before_stop = self.save_screenshot("before_stop.jpg")
        print("WORKFLOWGYM_SCREENSHOT_BEFORE_STOP", before_stop, flush=True)

        print("WORKFLOWGYM_TEST_STOP_INSTANCE_START", flush=True)
        self.env.stop_instance(self.instance_id)
        self.env.wait_for_status(self.instance_id, "STOPPED", timeout_seconds=stop_timeout)
        print("WORKFLOWGYM_TEST_STOP_INSTANCE_DONE", flush=True)

        print("WORKFLOWGYM_TEST_START_INSTANCE_START", flush=True)
        self.env.start_instance(self.instance_id)
        self.env.wait_for_status(self.instance_id, "RUNNING", timeout_seconds=start_timeout)
        self.env.ensure_cloud_assistant_ready(self.instance_id)
        time.sleep(autologin_wait)
        print("WORKFLOWGYM_TEST_START_INSTANCE_DONE", flush=True)

        after_start = self.save_screenshot("after_start_before_win_r.jpg")
        print("WORKFLOWGYM_SCREENSHOT_AFTER_START", after_start, flush=True)

        result = self.env.run_command(
            self.instance_id,
            pyautogui_win_r_and_win_icon_as_administrator_command(win_icon_x, win_icon_y),
            timeout=int(read_env("WORKFLOWGYM_STOP_START_WINR_ACTION_TIMEOUT_SECONDS", "120")),
            command_type="PowerShell",
            username=self.admin_user,
        )
        decoded_output = command_decoded_output(result)
        print("WORKFLOWGYM_ADMIN_PYAUTOGUI_ACTION_RESULT", result, flush=True)
        print("WORKFLOWGYM_ADMIN_PYAUTOGUI_ACTION_OUTPUT", decoded_output, flush=True)

        time.sleep(2)
        after_actions = self.save_screenshot("after_win_r_and_win_icon.jpg")
        print("WORKFLOWGYM_SCREENSHOT_AFTER_ACTIONS", after_actions, flush=True)

        self.assertIn("WORKFLOWGYM_RUNCOMMAND_IDENTITY", decoded_output)
        self.assertIn(self.admin_user, decoded_output)
        self.assertIn("PYAUTOGUI_WIN_R_START", decoded_output)
        self.assertIn("PYAUTOGUI_WIN_R_DONE", decoded_output)
        self.assertIn("PYAUTOGUI_WIN_ICON_START", decoded_output)
        self.assertIn("PYAUTOGUI_WIN_ICON_COORDS (%s, %s)" % (win_icon_x, win_icon_y), decoded_output)
        self.assertIn("PYAUTOGUI_WIN_ICON_DONE", decoded_output)

    def save_screenshot(self, name: str) -> str:
        screenshot = self.env.get_console_screenshot(self.instance_id)
        self.assertTrue(screenshot, "GetConsoleScreenshot returned empty payload")
        path = self.output_dir / name
        path.write_bytes(screenshot)
        return str(path)


if __name__ == "__main__":
    unittest.main()
