from __future__ import print_function

import os
import time
import unittest
import warnings

warnings.filterwarnings(
    "ignore",
    message="urllib3 v2 only supports OpenSSL.*",
)

import volcenginesdkcore
import volcenginesdkecs
from volcenginesdkcore.rest import ApiException

from main import get_result_payload, to_plain_dict


REGION = os.getenv("REGION", "cn-guangzhou")
IMAGE_NAME = os.getenv("IMAGE_NAME", "test_ubuntu2204_x64_guangzhou_eez")
INSTANCE_ID = os.getenv("INSTANCE_ID", "i-yepue3gvswt56onbkl5i")
PROJECT_NAME = os.getenv("PROJECT_NAME", "default")
TASK_POLL_INTERVAL_SECONDS = int(os.getenv("TASK_POLL_INTERVAL_SECONDS", "30"))
TASK_TIMEOUT_SECONDS = int(os.getenv("TASK_TIMEOUT_SECONDS", "1800"))


def create_api_instance():
    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = REGION
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkecs.ECSApi()


def describe_create_tasks(api_instance, image_id):
    request = volcenginesdkecs.DescribeTasksRequest(
        resource_ids=[image_id],
    )
    response = api_instance.describe_tasks(request)
    response_data = to_plain_dict(response)
    result = get_result_payload(response_data)
    return result.get("Tasks") or result.get("tasks") or []


class TestCreateImage(unittest.TestCase):
    def test_create_image_from_instance(self):
        api_instance = create_api_instance()
        request = volcenginesdkecs.CreateImageRequest(
            image_name=IMAGE_NAME,
            instance_id=INSTANCE_ID,
            project_name=PROJECT_NAME,
        )

        try:
            response = api_instance.create_image(request)
        except ApiException as exc:
            self.fail("CreateImage 调用失败: %s" % exc)

        response_data = to_plain_dict(response)
        result = get_result_payload(response_data)
        image_id = result.get("ImageId") or result.get("image_id")

        self.assertTrue(image_id, "CreateImage 响应中没有返回 ImageId")
        print("创建镜像任务已提交，ImageId: %s" % image_id)

        deadline = time.time() + TASK_TIMEOUT_SECONDS
        last_tasks = []
        while time.time() < deadline:
            try:
                tasks = describe_create_tasks(api_instance, image_id)
            except ApiException as exc:
                self.fail("DescribeTasks 调用失败: %s" % exc)

            if tasks:
                last_tasks = tasks
                for task in tasks:
                    task_id = task.get("Id") or task.get("id")
                    task_type = task.get("Type") or task.get("type")
                    status = task.get("Status") or task.get("status")
                    process = task.get("Process")
                    if process is None:
                        process = task.get("process")
                    resource_id = task.get("ResourceId") or task.get("resource_id")
                    print(
                        "创建镜像任务进展: id=%s type=%s status=%s process=%s resource=%s"
                        % (task_id, task_type, status, process, resource_id)
                    )

                    if status in ("Failed", "FAILED", "Error", "ERROR"):
                        self.fail("创建镜像任务失败: %s" % task)
                    if process == 100:
                        self.assertEqual(resource_id, image_id)
                        return

            time.sleep(TASK_POLL_INTERVAL_SECONDS)

        self.fail("等待创建镜像任务完成超时，最后任务信息: %s" % last_tasks)


if __name__ == "__main__":
    unittest.main()
