# fast_mcp_client.py
import asyncio
import os

from mcp import ClientSession
from mcp.client.sse import sse_client


async def main():
    url = os.getenv("WGM_MCP_URL", "http://wgm.example.local:8080/mcp-agent-wgm/mcp")
    token = os.getenv("WGM_TOKEN", "wgm-example-token")
    headers = {"Authorization": token}

    async with sse_client(url, headers=headers) as streams:
        async with ClientSession(streams[0], streams[1]) as session:
            await session.initialize()

            # 获取工具列表
            tools = await session.list_tools()
            print(f"可用工具: {[t.name for t in tools.tools]}")

            # 调用工具
            result = await session.call_tool(
                "tool_name",
                arguments={"param": "value"}
            )
            print(f"结果: {result}")


asyncio.run(main())
