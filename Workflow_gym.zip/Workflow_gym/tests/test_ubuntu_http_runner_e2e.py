from __future__ import annotations

import json
import os
import re
import shlex
import subprocess
import sys
import time
import unittest
import warnings
from pathlib import Path

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.envs.volcengine_env import (
    VolcengineEnv,
    _interactive_flask_runner_python_source,
    build_ubuntu_flask_post_python_action_command,
    build_ubuntu_interactive_flask_runner_setup_command,
    build_ubuntu_probe_flask_runner_command,
    command_decoded_output,
    ubuntu_flask_exec_timeout_seconds,
    ubuntu_flask_runner_port,
    ubuntu_flask_runner_token,
)

DEFAULT_INSTANCE_ID = "i-yeqf508xkwnu262ipptn"
DEFAULT_IMAGE_ID = "image-yepzld5uzdf9r6rwm3g1"
DEFAULT_FLASK_RUNNER_PORT = 80
ZSHRC_ENV_NAMES = (
    "AK",
    "SK",
    "VOLCENGINE_REGION",
    "SOURCE_REGION",
    "WORKFLOWGYM_TEST_INSTANCE_ID",
    "WORKFLOWGYM_UBUNTU_HTTP_RUNNER_IMAGE_ID",
    "WORKFLOWGYM_FLASK_RUNNER_TOKEN",
)


def read_env(name: str, default: str = "") -> str:
    return os.getenv(name, default)


def truthy_env(name: str, default: str = "0") -> bool:
    return read_env(name, default).lower() in ("1", "true", "yes", "on")


def load_zshrc_env(names: tuple[str, ...] = ZSHRC_ENV_NAMES, zshrc_path: str = "") -> None:
    missing = [name for name in names if not read_env(name)]
    if not missing:
        return
    zshrc = Path(zshrc_path or os.path.expanduser("~/.zshrc"))
    if not zshrc.is_file():
        return
    zshrc_quoted = shlex.quote(str(zshrc))
    for name in missing:
        try:
            completed = subprocess.run(
                ["zsh", "-lc", "source %s >/dev/null 2>&1; print -r -- ${%s:-}" % (zshrc_quoted, name)],
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        value = (completed.stdout or "").strip()
        if value:
            os.environ[name] = value


def parse_flask_health_payload(output: str) -> dict:
    marker = "WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_HEALTH"
    for line in output.splitlines():
        if marker not in line:
            continue
        json_part = line.split(marker, 1)[-1].strip()
        match = re.search(r"\{.*\}", json_part)
        if not match:
            continue
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            continue
    return {}


def pyautogui_probe_script() -> str:
    return """import pyautogui

pyautogui.FAILSAFE = False
width, height = pyautogui.size()
print("PYAUTOGUI_UBUNTU_HTTP_RUNNER_SIZE", (int(width), int(height)))
center_x, center_y = int(width // 2), int(height // 2)
pyautogui.moveTo(center_x, center_y, duration=0.1)
print("PYAUTOGUI_UBUNTU_HTTP_RUNNER_MOVE", (center_x, center_y))
print("PYAUTOGUI_UBUNTU_HTTP_RUNNER_DONE")
"""


def headless_python_probe_script() -> str:
    return """print("WORKFLOWGYM_UBUNTU_HTTP_RUNNER_PYTHON_OK")
print("PYAUTOGUI_UBUNTU_HTTP_RUNNER_DONE")
"""


load_zshrc_env()


class UbuntuHttpRunnerHelpersTest(unittest.TestCase):
    def test_parse_flask_health_payload_with_trailing_newline(self):
        output = "\n".join(
            [
                "WORKFLOWGYM_PROBE_FLASK_RUNNER_OK",
                'WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_HEALTH {"ok":true,"runner":"flask"}',
                "",
            ]
        )
        payload = parse_flask_health_payload(output)
        self.assertTrue(payload.get("ok"))
        self.assertEqual(payload.get("runner"), "flask")

    def test_ubuntu_flask_runner_source_lazy_loads_pyautogui(self):
        source = _interactive_flask_runner_python_source("token", 18080, 45)
        self.assertNotIn("\nimport pyautogui\n", source)
        self.assertIn("def load_pyautogui():", source)


class UbuntuHttpRunnerE2ETest(unittest.TestCase):
    """Manual E2E: Ubuntu Flask runner, RunCommand proxies HTTP via curl."""

    def setUp(self):
        load_zshrc_env()
        self.assertTrue(read_env("AK") and read_env("SK"), "AK/SK missing; set them in ~/.zshrc or the environment")
        self.instance_id = read_env("WORKFLOWGYM_TEST_INSTANCE_ID", DEFAULT_INSTANCE_ID)
        self.region = read_env("VOLCENGINE_REGION", read_env("SOURCE_REGION", "cn-guangzhou"))
        self.flask_token = read_env("WORKFLOWGYM_FLASK_RUNNER_TOKEN", ubuntu_flask_runner_token())
        self.flask_port = int(read_env("UBUNTU_FLASK_RUNNER_PORT", str(ubuntu_flask_runner_port() or DEFAULT_FLASK_RUNNER_PORT)))
        self.flask_exec_timeout = ubuntu_flask_exec_timeout_seconds()
        self.flask_http_timeout = max(30, self.flask_exec_timeout + 15)
        self.output_dir = Path(
            read_env(
                "WORKFLOWGYM_UBUNTU_HTTP_RUNNER_TEST_OUTPUT_DIR",
                "output/manual_ubuntu_http_runner_test",
            )
        )
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.env = VolcengineEnv(region=self.region)
        self.desktop_metadata: dict[str, str] = {}
        self.headless_mode = truthy_env("WORKFLOWGYM_UBUNTU_HTTP_RUNNER_HEADLESS")
        self.target_image_id = read_env("WORKFLOWGYM_UBUNTU_HTTP_RUNNER_IMAGE_ID", DEFAULT_IMAGE_ID)

    def ensure_target_image(self) -> dict:
        if not truthy_env("WORKFLOWGYM_UBUNTU_HTTP_RUNNER_ENSURE_IMAGE", "1"):
            return {}
        self.assertTrue(self.target_image_id, "WORKFLOWGYM_UBUNTU_HTTP_RUNNER_IMAGE_ID missing")
        sample_dir = str(self.output_dir / "initialize_for_sample")
        print(
            "WORKFLOWGYM_ENSURE_UBUNTU_IMAGE",
            {"instance_id": self.instance_id, "image_id": self.target_image_id},
            flush=True,
        )
        metadata = self.env.initialize_for_sample(
            self.instance_id,
            self.target_image_id,
            sample_dir=sample_dir,
        )
        if metadata.get("desktop_user") and metadata.get("xauthority"):
            self.desktop_metadata = {
                "desktop_user": str(metadata.get("desktop_user") or "user"),
                "desktop_home": str(metadata.get("desktop_home") or "/home/user"),
                "display": str(metadata.get("display") or ":0"),
                "xauthority": str(metadata.get("xauthority") or ""),
            }
            print("WORKFLOWGYM_UBUNTU_DESKTOP_METADATA", self.desktop_metadata, flush=True)
        print("WORKFLOWGYM_UBUNTU_INIT_METADATA", metadata, flush=True)
        return metadata

    def save_screenshot(self, name: str) -> str:
        screenshot = self.env.get_console_screenshot(self.instance_id)
        self.assertTrue(screenshot, "GetConsoleScreenshot returned empty payload")
        path = self.output_dir / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(screenshot)
        return str(path)

    def resolve_desktop_session(self, *, headless: bool | None = None) -> dict[str, str]:
        use_headless = self.headless_mode if headless is None else headless
        if self.desktop_metadata and not use_headless:
            return self.desktop_metadata
        if use_headless:
            session = {
                "desktop_user": read_env("WORKFLOWGYM_UBUNTU_DESKTOP_USER", "root"),
                "desktop_home": read_env("WORKFLOWGYM_UBUNTU_DESKTOP_HOME", "/root"),
                "display": read_env("WORKFLOWGYM_UBUNTU_DISPLAY", ":0"),
                "xauthority": read_env("WORKFLOWGYM_UBUNTU_XAUTHORITY", "/dev/null"),
            }
            print("WORKFLOWGYM_UBUNTU_HEADLESS_SESSION", session, flush=True)
            self.desktop_metadata = session
            return session
        if all(read_env(key) for key in ("WORKFLOWGYM_UBUNTU_DESKTOP_USER", "WORKFLOWGYM_UBUNTU_DESKTOP_HOME", "WORKFLOWGYM_UBUNTU_XAUTHORITY")):
            session = {
                "desktop_user": read_env("WORKFLOWGYM_UBUNTU_DESKTOP_USER"),
                "desktop_home": read_env("WORKFLOWGYM_UBUNTU_DESKTOP_HOME"),
                "display": read_env("WORKFLOWGYM_UBUNTU_DISPLAY", ":0"),
                "xauthority": read_env("WORKFLOWGYM_UBUNTU_XAUTHORITY"),
            }
            self.desktop_metadata = session
            return session
        sample_dir = str(self.output_dir / "env_probe")
        metadata = self.env.prepare_desktop_for_pyautogui(self.instance_id, sample_dir=sample_dir)
        self.desktop_metadata = {
            "desktop_user": str(metadata.get("desktop_user") or "user"),
            "desktop_home": str(metadata.get("desktop_home") or "/home/user"),
            "display": str(metadata.get("display") or ":0"),
            "xauthority": str(metadata.get("xauthority") or ""),
        }
        self.assertTrue(self.desktop_metadata["xauthority"], "missing xauthority from prepare_desktop_for_pyautogui")
        print("WORKFLOWGYM_UBUNTU_DESKTOP_METADATA", self.desktop_metadata, flush=True)
        return self.desktop_metadata

    def run_flask_setup(self, *, headless: bool | None = None) -> str:
        desktop = self.resolve_desktop_session(headless=headless)
        setup_result = self.env.run_command(
            self.instance_id,
            build_ubuntu_interactive_flask_runner_setup_command(
                desktop["desktop_user"],
                desktop["desktop_home"],
                desktop["display"],
                desktop["xauthority"],
                self.flask_token,
                self.flask_port,
            ),
            timeout=int(read_env("UBUNTU_FLASK_RUNNER_SETUP_TIMEOUT_SECONDS", "300")),
            command_type="Shell",
        )
        setup_output = command_decoded_output(setup_result)
        print("WORKFLOWGYM_UBUNTU_FLASK_RUNNER_SETUP_RESULT", setup_result, flush=True)
        print("WORKFLOWGYM_UBUNTU_FLASK_RUNNER_SETUP_OUTPUT", setup_output, flush=True)
        self.assertIn("WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_STARTED", setup_output)
        self.assertIn("WORKFLOWGYM_PROBE_FLASK_RUNNER_OK", setup_output)
        return setup_output

    def run_flask_probe(self) -> str:
        probe_result = self.env.run_command(
            self.instance_id,
            build_ubuntu_probe_flask_runner_command(self.flask_port, self.flask_token),
            timeout=int(read_env("UBUNTU_FLASK_RUNNER_PROBE_TIMEOUT_SECONDS", "120")),
            command_type="Shell",
        )
        probe_output = command_decoded_output(probe_result)
        print("WORKFLOWGYM_UBUNTU_FLASK_RUNNER_PROBE_OUTPUT", probe_output, flush=True)
        self.assertIn("WORKFLOWGYM_PROBE_FLASK_RUNNER_OK", probe_output)
        return probe_output

    def run_flask_python_action(self, script: str) -> str:
        action_result = self.env.run_command(
            self.instance_id,
            build_ubuntu_flask_post_python_action_command(
                script,
                self.flask_port,
                self.flask_token,
                self.flask_http_timeout,
            ),
            timeout=max(self.flask_http_timeout + 30, 90),
            command_type="Shell",
        )
        action_output = command_decoded_output(action_result)
        print("WORKFLOWGYM_UBUNTU_FLASK_ACTION_OUTPUT", action_output, flush=True)
        self.assertIn("WORKFLOWGYM_RUNCOMMAND_IDENTITY", action_output)
        self.assertIn("WORKFLOWGYM_FLASK_AGENT_RESULT", action_output)
        return action_output

    def assert_flask_health(self, probe_output: str) -> dict:
        health_payload = parse_flask_health_payload(probe_output)
        print("WORKFLOWGYM_UBUNTU_FLASK_HEALTH_PAYLOAD", health_payload, flush=True)
        self.assertTrue(health_payload.get("ok"), health_payload)
        self.assertEqual(health_payload.get("runner"), "flask")
        self.assertEqual(health_payload.get("platform"), "ubuntu")
        return health_payload

    def test_ubuntu_http_runner_headless_api_smoke(self):
        """Gateway/headless: verify RunCommand can start Flask runner and POST /action."""
        print("WORKFLOWGYM_TEST_INSTANCE", self.instance_id, flush=True)
        print("WORKFLOWGYM_UBUNTU_FLASK_PORT", self.flask_port, flush=True)

        self.env.ensure_cloud_assistant_ready(self.instance_id)
        self.run_flask_setup(headless=True)
        time.sleep(int(read_env("UBUNTU_FLASK_RUNNER_SETTLE_SECONDS", "3")))

        probe_output = self.run_flask_probe()
        health_payload = self.assert_flask_health(probe_output)
        self.assertEqual(health_payload.get("screen_size"), [])

        action_output = self.run_flask_python_action(headless_python_probe_script())
        self.assertIn("WORKFLOWGYM_UBUNTU_HTTP_RUNNER_PYTHON_OK", action_output)
        self.assertIn("PYAUTOGUI_UBUNTU_HTTP_RUNNER_DONE", action_output)

    def test_ubuntu_http_runner_health_and_pyautogui_probe(self):
        """Desktop Ubuntu: full pyautogui probe via HTTP runner."""
        if truthy_env("WORKFLOWGYM_UBUNTU_SKIP_DESKTOP_PYAUTOGUI_E2E"):
            self.skipTest("WORKFLOWGYM_UBUNTU_SKIP_DESKTOP_PYAUTOGUI_E2E=1")
        if self.headless_mode:
            self.skipTest("headless mode enabled; use test_ubuntu_http_runner_headless_api_smoke instead")

        print("WORKFLOWGYM_TEST_INSTANCE", self.instance_id, flush=True)
        print("WORKFLOWGYM_UBUNTU_TARGET_IMAGE", self.target_image_id, flush=True)
        print("WORKFLOWGYM_UBUNTU_FLASK_PORT", self.flask_port, flush=True)
        print("WORKFLOWGYM_UBUNTU_FLASK_EXEC_TIMEOUT", self.flask_exec_timeout, flush=True)
        print("WORKFLOWGYM_UBUNTU_FLASK_HTTP_TIMEOUT", self.flask_http_timeout, flush=True)

        self.ensure_target_image()
        before = self.save_screenshot("before_ubuntu_http_runner.jpg")
        print("WORKFLOWGYM_SCREENSHOT_BEFORE", before, flush=True)

        self.run_flask_setup(headless=False)
        time.sleep(int(read_env("UBUNTU_FLASK_RUNNER_SETTLE_SECONDS", "3")))

        probe_output = self.run_flask_probe()
        health_payload = self.assert_flask_health(probe_output)
        screen_size = health_payload.get("screen_size") or []
        self.assertEqual(len(screen_size), 2, "expected desktop screen_size from /health")

        action_output = self.run_flask_python_action(pyautogui_probe_script())
        self.assertIn("PYAUTOGUI_UBUNTU_HTTP_RUNNER_SIZE", action_output)
        self.assertIn("PYAUTOGUI_UBUNTU_HTTP_RUNNER_MOVE", action_output)
        self.assertIn("PYAUTOGUI_UBUNTU_HTTP_RUNNER_DONE", action_output)

        after = self.save_screenshot("after_ubuntu_http_runner_action.jpg")
        print("WORKFLOWGYM_SCREENSHOT_AFTER", after, flush=True)


if __name__ == "__main__":
    unittest.main()
