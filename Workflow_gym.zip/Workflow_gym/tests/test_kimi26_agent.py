from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.agents.base import SampleContext
from open_workflowgym.agents.factory import AgentFactory
from open_workflowgym.agents.kimi26 import (
    Kimi26AgentAdapter,
    KimiNativeAgentAdapter,
    coordinates_are_relative_0_1,
    fix_pyautogui_less_than_bug,
    infer_kimi_platform,
    parse_response_to_cot_and_action,
)
from open_workflowgym.records import TaskRecord


class Kimi26AgentTest(unittest.TestCase):
    def test_factory_registers_kimi(self):
        agent = AgentFactory().create("kimi")
        self.assertIsInstance(agent, KimiNativeAgentAdapter)
        self.assertEqual(agent.name, "kimi")

    def test_factory_registers_kimi_native_alias(self):
        agent = AgentFactory().create("kimi_native")
        self.assertIsInstance(agent, KimiNativeAgentAdapter)
        self.assertEqual(agent.name, "kimi_native")

    def test_factory_registers_kimi26(self):
        agent = AgentFactory().create("kimi2.6")
        self.assertIsInstance(agent, Kimi26AgentAdapter)

    def test_infer_kimi_platform_uses_dataset_system_type(self):
        previous = os.environ.pop("KIMI_NATIVE_PLATFORM", None)

        def restore_platform_env() -> None:
            if previous is None:
                os.environ.pop("KIMI_NATIVE_PLATFORM", None)
            else:
                os.environ["KIMI_NATIVE_PLATFORM"] = previous

        self.addCleanup(restore_platform_env)
        ubuntu_context = SampleContext(
            run_id="run-test",
            task=TaskRecord(run_id="run-test", task_id="task-ubuntu", row_number=1, fields={"系统类型": "Ubuntu"}),
            sample_index=1,
            sample_dir="/tmp/sample",
            metadata={"platform": "windows"},
        )
        windows_context = SampleContext(
            run_id="run-test",
            task=TaskRecord(run_id="run-test", task_id="task-windows", row_number=2, fields={"系统类型": "Windows"}),
            sample_index=1,
            sample_dir="/tmp/sample",
            metadata={"platform": "ubuntu"},
        )

        self.assertEqual(infer_kimi_platform(ubuntu_context), "ubuntu")
        self.assertEqual(infer_kimi_platform(windows_context), "windows")

    def test_parse_code_block_projects_relative_coordinates(self):
        response = {
            "reasoning_content": "Need click target.",
            "content": (
                "## Action:\nClick the target.\n"
                "## Code:\n```python\nimport pyautogui\npyautogui.click(0.5, 0.25)\n```"
            ),
        }
        action, codes, cot = parse_response_to_cot_and_action(response, (1920, 1080))
        self.assertEqual(action, "Click the target.")
        self.assertEqual(codes, ["import pyautogui\npyautogui.click(960, 270)"])
        self.assertEqual(cot["thought"], "Need click target.")
        self.assertEqual(cot["coordinate_conversions"][0]["raw_point"], [0.5, 0.25])
        self.assertEqual(cot["coordinate_conversions"][0]["actual_point"], [960, 270])
        self.assertIn("screen_width", cot["coordinate_conversions"][0]["conversion_formula"])

    def test_coordinates_are_relative_0_1_detection(self):
        self.assertTrue(coordinates_are_relative_0_1(0.5, 0.25))
        self.assertTrue(coordinates_are_relative_0_1(0.196, 0.193))
        self.assertFalse(coordinates_are_relative_0_1(376, 208))
        self.assertFalse(coordinates_are_relative_0_1(196, 193))
        self.assertFalse(coordinates_are_relative_0_1(1, 1))

    def test_parse_preserves_absolute_pixel_coordinates(self):
        response = {
            "content": (
                "## Action:\nClick the target.\n"
                "## Code:\n```python\npyautogui.click(376, 208)\n```"
            )
        }

        action, codes, cot = parse_response_to_cot_and_action(response, (1920, 1080))

        self.assertEqual(action, "Click the target.")
        self.assertEqual(codes, ["pyautogui.click(376, 208)"])
        self.assertEqual(cot["coordinate_conversions"][0]["raw_point"], [376, 208])
        self.assertEqual(cot["coordinate_conversions"][0]["actual_point"], [376, 208])
        self.assertEqual(cot["coordinate_conversions"][0]["source_coordinate_space"], "absolute_pixel")

    def test_parse_repairs_mixed_keyword_and_positional_coordinates(self):
        response = {
            "content": (
                "## Action:\nClick the target.\n"
                "## Code:\n```python\npyautogui.click(x=0.239,0.193)\n```"
            )
        }

        action, codes, cot = parse_response_to_cot_and_action(response, (1920, 1080))

        self.assertEqual(action, "Click the target.")
        self.assertEqual(codes, ["pyautogui.click(459, 208)"])
        self.assertEqual(cot["coordinate_conversions"][0]["raw_point"], [0.239, 0.193])

    def test_parse_code_block_without_action_header(self):
        response = {"content": "## Code:\n```python\npyautogui.click(0.239,0.194)\n```"}

        action, codes, cot = parse_response_to_cot_and_action(response, (1920, 1080))

        self.assertEqual(action, "Execute the provided code block.")
        self.assertEqual(cot["action"], "Execute the provided code block.")
        self.assertEqual(codes, ["pyautogui.click(459, 210)"])

    def test_parse_narrative_code_block_without_action_header(self):
        response = {
            "content": (
                "I notice the menu isn't opening with my clicks. "
                "Let me try clicking slightly more precisely on the hamburger icon.\n"
                "## Code:\n```python\npyautogui.click(0.126,0.132)\n```"
            )
        }

        action, codes, cot = parse_response_to_cot_and_action(response, (1920, 1080))

        self.assertEqual(action, "Execute the provided code block.")
        self.assertEqual(cot["action"], "Execute the provided code block.")
        self.assertEqual(codes, ["pyautogui.click(242, 143)"])

    def test_parse_code_block_from_reasoning_when_content_empty(self):
        response = {
            "reasoning_content": (
                "The next click should open the analysis menu.\n"
                "## Action:\nClick the analysis menu.\n"
                "## Code:\n```python\npyautogui.click(0.25, 0.5)\n```"
            ),
            "content": "",
        }

        action, codes, cot = parse_response_to_cot_and_action(response, (1920, 1080))

        self.assertEqual(action, "Click the analysis menu.")
        self.assertEqual(codes, ["pyautogui.click(480, 540)"])
        self.assertIn("The next click", cot["thought"])

    def test_parse_wait_and_done_sentinels(self):
        wait_response = {"content": "## Action:\nWait.\n## Code:\n```python\ncomputer.wait()\n```"}
        done_response = {"content": "## Action:\nFinish.\n## Code:\n```python\ncomputer.terminate(status='success')\n```"}
        self.assertEqual(parse_response_to_cot_and_action(wait_response, (1920, 1080))[1], ["WAIT"])
        self.assertEqual(parse_response_to_cot_and_action(done_response, (1920, 1080))[1], ["DONE"])

    def test_chinese_typewrite_uses_inline_clipboard_paste(self):
        fixed = fix_pyautogui_less_than_bug('pyautogui.typewrite("""李明""", interval=0.01)')
        self.assertIn("_workflowgym_set_clipboard", fixed)
        self.assertIn("xsel", fixed)
        self.assertIn("xclip", fixed)
        self.assertLess(fixed.index("xsel"), fixed.index("xclip"))
        self.assertIn('pyautogui.hotkey("ctrl", "v")', fixed)
        self.assertNotIn("paste_text(", fixed)

        fixed_write = fix_pyautogui_less_than_bug('pyautogui.write("沃尔玛", interval=0.01)')
        self.assertIn('沃尔玛', fixed_write)
        self.assertIn("_workflowgym_set_clipboard", fixed_write)
        self.assertIn("xsel", fixed_write)
        self.assertNotIn("paste_text(", fixed_write)

    def test_triple_quote_typewrite_normalizes_embedded_quotes(self):
        bad = 'pyautogui.typewrite("""python -c "from PIL import Image" """, interval=0.01)'
        fixed = fix_pyautogui_less_than_bug(bad)
        self.assertNotIn('"""', fixed)
        self.assertIn("pyautogui.typewrite(", fixed)
        self.assertIn("from PIL import Image", fixed)

    def test_pyautogui_sleep_uses_time_sleep(self):
        fixed = fix_pyautogui_less_than_bug("pyautogui.sleep(0.5)")
        self.assertEqual(fixed, "time.sleep(0.5)")

    def test_parse_response_returns_last_native_actions(self):
        context = SampleContext(
            run_id="run-test",
            task=TaskRecord(run_id="run-test", task_id="task-test", row_number=1, fields={"task": "demo"}),
            sample_index=1,
            sample_dir="/tmp/sample",
        )
        adapter = KimiNativeAgentAdapter()
        adapter._last_actions = [{"action": "echo run", "raw_action": {"type": "pyautogui"}, "batch_last": True}]
        parsed = adapter.parse_response("prediction", context)
        self.assertEqual(parsed["function_call"], adapter._last_actions)

    def test_to_pyautogui_wraps_native_python_for_shell_execution(self):
        context = SampleContext(
            run_id="run-test",
            task=TaskRecord(run_id="run-test", task_id="task-test", row_number=1, fields={"task": "demo"}),
            sample_index=1,
            sample_dir="/tmp/sample",
        )
        adapter = KimiNativeAgentAdapter()

        commands = adapter.to_pyautogui(
            [{"action": "pyautogui.click(35, 1036)", "raw_action": {"type": "pyautogui"}}],
            context,
        )

        self.assertEqual(len(commands), 1)
        self.assertIn("#!/bin/bash", commands[0])
        self.assertIn("/usr/bin/python", commands[0])
        self.assertIn("pyautogui.click(35, 1036)", commands[0])
        self.assertNotEqual(commands[0].strip(), "pyautogui.click(35, 1036)")

    def test_done_sentinel_becomes_finished_call(self):
        context = SampleContext(
            run_id="run-test",
            task=TaskRecord(run_id="run-test", task_id="task-test", row_number=1, fields={"task": "demo"}),
            sample_index=1,
            sample_dir="/tmp/sample",
        )
        adapter = KimiNativeAgentAdapter()
        adapter._last_actions = [{"action": "", "terminal": "success", "raw_action": {"type": "done"}}]
        parsed = adapter.parse_response("done", context)
        self.assertEqual(parsed["function_call"]["name"], "finished")


if __name__ == "__main__":
    unittest.main()
