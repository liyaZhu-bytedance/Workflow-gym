from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.tools.match_feishu_image_ids import NOT_FOUND_LABEL
from open_workflowgym.tools.merge_task_sheet_from_ve8a1q import (
    NOT_FOUND_MATCHED_IMAGE_ID_LABEL,
    build_ieoeoe_lookup,
    build_output_rows,
    build_ve8a1q_lookup,
    parse_image_ids,
)


class MergeTaskSheetFromVe8a1qTest(unittest.TestCase):
    def test_parse_image_ids(self):
        self.assertEqual(parse_image_ids("image-a,image-b"), ["image-a", "image-b"])
        self.assertEqual(parse_image_ids("image-a，image-b"), ["image-a", "image-b"])

    def _ve8a1q_row(
        self,
        image_id: str,
        matched_image_id: str = "",
        export_image_id: str = "",
        os_type: str = "Ubuntu",
    ) -> list[str]:
        row = [""] * 10
        row[2] = image_id
        row[4] = matched_image_id
        row[7] = export_image_id
        row[9] = os_type
        return row

    def _ieoeoe_row(self, image_id: str, matched_image_id: str) -> list[str]:
        row = [""] * 5
        row[2] = image_id
        row[4] = matched_image_id
        return row

    def test_build_ve8a1q_lookup(self):
        rows = [
            self._ve8a1q_row("", "", "", ""),
            self._ve8a1q_row("image-a", "e1,e2", "h1", "Ubuntu"),
            self._ve8a1q_row("image-b", "e3", "", "Ubuntu"),
            self._ve8a1q_row("image-win", "win-e1", "", "Windows"),
        ]
        rows[0][2] = "镜像id"
        rows[0][4] = "匹配镜像id"
        rows[0][7] = "导出镜像id"
        rows[0][9] = "系统类型"
        lookup = build_ve8a1q_lookup(rows)
        self.assertEqual(lookup["image-a"], ["e1", "e2"])
        self.assertEqual(lookup["image-b"], ["e3"])
        self.assertEqual(lookup["image-win"], ["win-e1"])

    def test_build_ieoeoe_lookup(self):
        rows = [
            ["", "", "完成后内场镜像ID", "", "镜像id"],
            self._ieoeoe_row("image-a", "ieoeoe-e1"),
            self._ieoeoe_row("image-b", "ieoeoe-e2,ieoeoe-e3"),
        ]
        lookup = build_ieoeoe_lookup(rows)
        self.assertEqual(lookup["image-a"], ["ieoeoe-e1"])
        self.assertEqual(lookup["image-b"], ["ieoeoe-e2", "ieoeoe-e3"])

    def test_build_output_rows_joins_multiple_e_values(self):
        ve8a1q_rows = [
            self._ve8a1q_row("", "", "", ""),
            self._ve8a1q_row("image-a", "e1,e2", "h1,h2", "Ubuntu"),
        ]
        ve8a1q_rows[0][2] = "镜像id"
        ieoeoe_rows = [
            ["", "", "完成后内场镜像ID", "", "镜像id"],
            self._ieoeoe_row("image-a", "ieoeoe-e1"),
        ]
        task_rows = [
            ["id", "AF"],
            ["task-1", "image-a"],
            ["task-2", "image-x"],
        ]
        output_rows, not_found_count, e_not_found_count, _, _ = build_output_rows(
            task_rows, ve8a1q_rows, ieoeoe_rows, task_match_column_index=1
        )
        self.assertEqual(output_rows[0], ["id", "AF", "镜像id", "匹配镜像id"])
        self.assertEqual(output_rows[1], ["task-1", "image-a", "e1,e2", "ieoeoe-e1"])
        self.assertEqual(
            output_rows[2],
            ["task-2", "image-x", NOT_FOUND_MATCHED_IMAGE_ID_LABEL, NOT_FOUND_MATCHED_IMAGE_ID_LABEL],
        )
        self.assertEqual(len(output_rows), 3)
        self.assertEqual(not_found_count, 1)
        self.assertEqual(e_not_found_count, 0)

    def test_build_output_rows_c_matched_e_not_found(self):
        ve8a1q_rows = [
            ["", "", "镜像id", "", "匹配镜像id"],
            ["", "", "image-yeadp1kdx6f9r5zb9e6m", "", NOT_FOUND_LABEL],
        ]
        ieoeoe_rows = [
            ["", "", "完成后内场镜像ID", "", "镜像id"],
            self._ieoeoe_row("image-yeadp1kdx6f9r5zb9e6m", "ieoeoe-e1"),
        ]
        task_rows = [
            ["id", "AF"],
            ["task-1", "image-yeadp1kdx6f9r5zb9e6m"],
        ]
        output_rows, not_found_count, e_not_found_count, _, _ = build_output_rows(
            task_rows, ve8a1q_rows, ieoeoe_rows, task_match_column_index=1
        )
        self.assertEqual(
            output_rows[1],
            ["task-1", "image-yeadp1kdx6f9r5zb9e6m", NOT_FOUND_LABEL, "ieoeoe-e1"],
        )
        self.assertEqual(not_found_count, 0)
        self.assertEqual(e_not_found_count, 1)

    def test_build_output_rows_windows_uses_e_column(self):
        ve8a1q_rows = [
            self._ve8a1q_row("", "", "", ""),
            self._ve8a1q_row("image-win", "win-e1", "", "Windows"),
        ]
        ieoeoe_rows = [
            ["", "", "完成后内场镜像ID", "", "镜像id"],
            self._ieoeoe_row("image-win", "ieoeoe-win"),
        ]
        task_rows = [
            ["id", "AF"],
            ["task-1", "image-win"],
        ]
        output_rows, _, _, _, _ = build_output_rows(
            task_rows, ve8a1q_rows, ieoeoe_rows, task_match_column_index=1
        )
        self.assertEqual(output_rows[1], ["task-1", "image-win", "win-e1", "win-e1"])

    def test_build_output_rows_supports_comma_separated_af(self):
        ve8a1q_rows = [
            self._ve8a1q_row("", "", "", ""),
            self._ve8a1q_row("image-b", "e3", "h3", "Ubuntu"),
        ]
        ieoeoe_rows = [
            ["", "", "完成后内场镜像ID", "", "镜像id"],
            self._ieoeoe_row("image-b", "ieoeoe-e3"),
        ]
        task_rows = [
            ["id", "AF"],
            ["task-1", "image-a,image-b"],
        ]
        output_rows, _, _, _, _ = build_output_rows(
            task_rows, ve8a1q_rows, ieoeoe_rows, task_match_column_index=1
        )
        self.assertEqual(output_rows[1], ["task-1", "image-a,image-b", "e3", "ieoeoe-e3"])

    def test_build_output_rows_non_windows_uses_ve8a1q_e_column(self):
        ve8a1q_rows = [
            self._ve8a1q_row("", "", "", ""),
            self._ve8a1q_row("image-a", "e1", "h1", "Ubuntu"),
        ]
        ve8a1q_rows[0][2] = "镜像id"
        ieoeoe_rows = [
            ["", "", "完成后内场镜像ID", "", "镜像id"],
            self._ieoeoe_row("image-a", "ieoeoe-e1"),
        ]
        task_rows = [
            ["id", "AF"],
            ["task-1", "image-a"],
        ]
        output_rows, _, _, _, _ = build_output_rows(
            task_rows, ve8a1q_rows, ieoeoe_rows, task_match_column_index=1
        )
        self.assertEqual(output_rows[1], ["task-1", "image-a", "e1", "ieoeoe-e1"])


if __name__ == "__main__":
    unittest.main()
