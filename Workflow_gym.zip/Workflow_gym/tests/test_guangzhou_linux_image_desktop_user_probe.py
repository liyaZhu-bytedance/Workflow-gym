from __future__ import annotations

import csv
import json
import os
import sys
import tempfile
import time
import unittest
import warnings
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

warnings.filterwarnings(
    "ignore",
    message="urllib3 v2 only supports OpenSSL.*",
)

import volcenginesdkcore
import volcenginesdkecs

from open_workflowgym.envs.volcengine_env import (
    VolcengineEnv,
    build_probe_desktop_user_command,
    command_decoded_output,
    get_result_payload,
    image_record_field,
    image_record_platform,
    is_linux_os,
    is_windows_os,
    resolve_desktop_user_from_probe,
    to_plain_dict,
)
from open_workflowgym.feishu_client import (
    FeishuClient,
    spreadsheet_token_from_url,
)
from open_workflowgym.local_spreadsheet import feishu_credentials_configured


REGION = os.getenv("VOLCENGINE_REGION", os.getenv("SOURCE_REGION", "cn-guangzhou"))

DEFAULT_IMAGE_PROBE_INSTANCE_NAME_PREFIX = os.getenv(
    "IMAGE_PROBE_INSTANCE_NAME_PREFIX",
    os.getenv("WORKFLOWGYM_INSTANCE_NAME_PREFIX", "open_workflowgym,open_workflow_gym"),
).strip()
IMAGE_PROBE_INSTANCE_DESCRIBE_LIMIT = int(os.getenv("IMAGE_PROBE_INSTANCE_DESCRIBE_LIMIT", "200"))
IMAGE_PROBE_AUTO_DISCOVER = os.getenv("IMAGE_PROBE_AUTO_DISCOVER", "1").lower() not in (
    "0",
    "false",
    "no",
    "off",
)

DEFAULT_IMAGE_PROBE_INSTANCE_IDS = (
    "i-yeql505lhcnu262eh6m9",
    "i-yeql535r7kuo7bu7uwgo",
    "i-yeql543gu8t56onnfxjg",
    "i-yeqlg26kn4f8b8x4yc3b",
    "i-yeqlg3s5xcuo7bu54zac",
    "i-yeqlg4wwe8h2cbem251p",
    "i-yeqlg77rwgobzsyevdoz",
    "i-yeqlg8dwxsuo7budgusa",
    "i-yeqg10p340h2cbena3o8",
    "i-yeq4kys64gnu262h8lqr",
    "i-yeq4l3b400obzsyfqeqs",
    "i-yeq4l7itc0f8b8xd9yfe",
    "i-yeq4la4xdsf8b8xocsc7",
    "i-yeq4lc7dhch2cbesrqlo",
    "i-yeq4lecmpsnu262idoso",
    "i-yeq4lovw1st56onhsg53",
    "i-yeqf508xkwnu262ipptn",
)


def discover_image_probe_instance_ids(region: str = REGION) -> list[str]:
    """List cn-guangzhou ECS instances whose names match the configured prefix."""
    if not IMAGE_PROBE_AUTO_DISCOVER:
        return []
    if not (os.getenv("AK") and os.getenv("SK")):
        return []
    try:
        env = VolcengineEnv(region=region)
        instances = env.describe_instances(
            name_prefix=DEFAULT_IMAGE_PROBE_INSTANCE_NAME_PREFIX,
            limit=IMAGE_PROBE_INSTANCE_DESCRIBE_LIMIT,
        )
    except Exception as exc:
        print(
            "IMAGE_PROBE_AUTO_DISCOVER_FAILED region=%s prefix=%s error=%s"
            % (region, DEFAULT_IMAGE_PROBE_INSTANCE_NAME_PREFIX, exc),
            flush=True,
        )
        return []

    instance_ids: list[str] = []
    seen: set[str] = set()
    for instance in instances:
        instance_id = image_record_field(instance, "InstanceId", "instance_id")
        if not instance_id or instance_id in seen:
            continue
        seen.add(instance_id)
        instance_ids.append(instance_id)
    if instance_ids:
        print(
            "IMAGE_PROBE_AUTO_DISCOVER region=%s prefix=%s count=%s instance_ids=%s"
            % (
                region,
                DEFAULT_IMAGE_PROBE_INSTANCE_NAME_PREFIX,
                len(instance_ids),
                ",".join(instance_ids),
            ),
            flush=True,
        )
    return instance_ids


def parse_probe_instance_ids() -> list[str]:
    """Resolve bake/probe ECS instance IDs from user configuration.

    Priority:
    1. IMAGE_PROBE_INSTANCE_IDS  (comma-separated, GUI 烘焙专用)
    2. IMAGE_PROBE_INSTANCE_ID   (single instance)
    3. INSTANCE_IDS              (same as main.py sampling)
    4. Auto-discover by instance name prefix in cn-guangzhou
    5. DEFAULT_IMAGE_PROBE_INSTANCE_IDS (built-in bake pool fallback)
    """
    multi = os.getenv("IMAGE_PROBE_INSTANCE_IDS", "").strip()
    if multi:
        instance_ids = [item.strip() for item in multi.split(",") if item.strip()]
        if instance_ids:
            return instance_ids
    single = os.getenv("IMAGE_PROBE_INSTANCE_ID", "").strip()
    if single:
        return [single]
    shared = os.getenv("INSTANCE_IDS", "").strip()
    if shared:
        instance_ids = [item.strip() for item in shared.split(",") if item.strip()]
        if instance_ids:
            return instance_ids
    discovered = discover_image_probe_instance_ids()
    if discovered:
        return discovered
    return list(DEFAULT_IMAGE_PROBE_INSTANCE_IDS)


PROBE_INSTANCE_IDS = parse_probe_instance_ids()
PROBE_INSTANCE_ID = PROBE_INSTANCE_IDS[0] if PROBE_INSTANCE_IDS else ""
IMAGE_PROBE_TARGET_IMAGE_ID = os.getenv("IMAGE_PROBE_TARGET_IMAGE_ID", "").strip()
IMAGE_PROBE_MAX_IMAGES = int(os.getenv("IMAGE_PROBE_MAX_IMAGES", "0"))
IMAGE_PROBE_MAX_RESULTS = int(os.getenv("IMAGE_PROBE_MAX_RESULTS", "100"))
IMAGE_PROBE_LIST_LIMIT = int(os.getenv("IMAGE_PROBE_LIST_LIMIT", "1000"))
IMAGE_PROBE_SKIP_EXISTING = os.getenv("IMAGE_PROBE_SKIP_EXISTING", "1").lower() not in ("0", "false", "no", "off")
IMAGE_PROBE_WAIT_SECONDS = int(os.getenv("DESKTOP_PROBE_WAIT_SECONDS", "90"))
IMAGE_PROBE_COMMAND_TIMEOUT_SECONDS = int(os.getenv("DESKTOP_PROBE_COMMAND_TIMEOUT_SECONDS", "180"))
DEFAULT_IMAGE_PROBE_SPREADSHEET_URL = os.getenv(
    "IMAGE_PROBE_SPREADSHEET_URL",
    "https://example.feishu.local/sheets/PLACEHOLDER",
).strip()
IMAGE_PROBE_SPREADSHEET_URL = DEFAULT_IMAGE_PROBE_SPREADSHEET_URL
IMAGE_PROBE_SHEET_TITLE = os.getenv("IMAGE_PROBE_SHEET_TITLE", "linux_desktop_user").strip()
SHEET_HEADERS = ("序号", "镜像名", "镜像id", "用户名")


def create_api_instance(region: str = REGION):
    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = region
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkecs.ECSApi()


def image_display_name(image: dict) -> str:
    return image_record_field(image, "ImageName", "image_name") or image_record_field(image, "ImageId", "image_id")


def image_status_value(image: dict) -> str:
    return image_record_field(image, "Status", "status", "ImageStatus", "image_status")


def is_linux_image(image: dict) -> bool:
    platform = image_record_platform(image)
    if platform == "windows":
        return False
    if platform == "ubuntu":
        return True
    os_type = image_record_field(image, "OsType", "os_type", "OSType")
    if is_windows_os(os_type):
        return False
    return is_linux_os(os_type)


def list_region_images(
    api_instance,
    *,
    region: str = REGION,
    limit: int = IMAGE_PROBE_LIST_LIMIT,
) -> list[dict]:
    images: list[dict] = []
    next_token = ""
    while len(images) < limit:
        request_kwargs: dict = {"max_results": min(IMAGE_PROBE_MAX_RESULTS, limit - len(images))}
        if next_token:
            request_kwargs["next_token"] = next_token
        response = api_instance.describe_images(volcenginesdkecs.DescribeImagesRequest(**request_kwargs))
        result = get_result_payload(to_plain_dict(response))
        page_images = result.get("Images") or result.get("images") or []
        images.extend(page_images)
        next_token = result.get("NextToken") or result.get("next_token") or ""
        if not next_token or not page_images:
            break
    return images[:limit]


def is_excluded_ubuntu_image_name(image_name: str) -> bool:
    normalized = str(image_name or "").strip().lower()
    if normalized.endswith(".qcow2_bj"):
        return True
    if normalized.endswith("_gui"):
        return True
    return False


def is_gui_bake_preview_image_name(image_name: str) -> bool:
    normalized = str(image_name or "").strip().lower()
    return normalized.startswith("preview-")


def is_arm_image(image: dict) -> bool:
    image_name = image_display_name(image)
    padded_name = " %s " % str(image_name or "").strip().lower()
    architecture = image_record_field(
        image,
        "Architecture",
        "architecture",
        "Arch",
        "arch",
    ).lower()
    arm_markers = (" arm ", " arm64", " aarch64")
    for marker in arm_markers:
        if marker in padded_name or marker in architecture:
            return True
    return False


def is_ubuntu_image(image: dict) -> bool:
    image_name = image_display_name(image)
    if is_excluded_ubuntu_image_name(image_name):
        return False
    if is_arm_image(image):
        return False
    name = image_name.lower()
    platform = image_record_field(image, "Platform", "platform").lower()
    os_type = image_record_field(image, "OsType", "os_type", "OSType").lower()
    if is_windows_os(os_type) or is_windows_os(platform) or "windows" in name:
        return False
    for marker in ("centos", "debian", "rocky", "suse", "velinux", "fedora", "almalinux"):
        if marker in name or marker in platform or marker in os_type:
            return False
    return "ubuntu" in name or "ubuntu" in platform or "ubuntu" in os_type


def filter_ubuntu_images(images: list[dict]) -> list[dict]:
    ubuntu_images: list[dict] = []
    for image in images:
        if not is_ubuntu_image(image):
            continue
        if not is_gui_bake_preview_image_name(image_display_name(image)):
            continue
        status = image_status_value(image).lower()
        if status and status not in ("available", "ready"):
            continue
        ubuntu_images.append(image)
    return ubuntu_images


def filter_linux_images(images: list[dict]) -> list[dict]:
    linux_images: list[dict] = []
    for image in images:
        if not is_linux_image(image):
            continue
        status = image_status_value(image).lower()
        if status and status not in ("available", "ready"):
            continue
        linux_images.append(image)
    return linux_images


def replace_image_and_probe_desktop_user(
    env: VolcengineEnv,
    instance_id: str,
    image_id: str,
) -> dict[str, object]:
    env.ensure_stopped(instance_id)
    env.replace_system_volume(instance_id, image_id)
    env.wait_for_replace_system_volume(
        instance_id,
        image_id,
        timeout_seconds=int(os.getenv("REPLACE_SYSTEM_VOLUME_TIMEOUT_SECONDS", "600")),
    )
    env.start_instance(instance_id)
    env.wait_for_status(instance_id, "RUNNING", timeout_seconds=int(os.getenv("INSTANCE_START_TIMEOUT_SECONDS", "600")))
    env.ensure_cloud_assistant_ready(instance_id)
    if IMAGE_PROBE_WAIT_SECONDS > 0:
        time.sleep(IMAGE_PROBE_WAIT_SECONDS)
    run_result = env.run_command(
        instance_id,
        build_probe_desktop_user_command(),
        timeout=IMAGE_PROBE_COMMAND_TIMEOUT_SECONDS,
    )
    output = command_decoded_output(run_result)
    resolved = resolve_desktop_user_from_probe(output)
    return {
        **resolved,
        "probe_output": output,
        "invocation_id": run_result.get("invocation_id", ""),
    }


def records_from_sheet_rows(rows: list[list]) -> list[dict[str, str]]:
    records: list[dict[str, str]] = []
    for row in rows:
        if not row or len(row) < 4:
            continue
        image_name = str(row[1] or "").strip()
        image_id = str(row[2] or "").strip()
        desktop_user = str(row[3] or "").strip()
        if not image_id or image_id == "镜像id":
            continue
        records.append(
            {
                "image_id": image_id,
                "image_name": image_name,
                "desktop_user": desktop_user,
                "desktop_user_source": "",
                "error": "",
            }
        )
    return records


def load_existing_probe_records(client: FeishuClient, sheet_info: dict[str, str]) -> list[dict[str, str]]:
    cell_range = "%s!A:D" % sheet_info["sheet_id"]
    rows = client.read_values(sheet_info["spreadsheet_token"], cell_range)
    return records_from_sheet_rows(rows)


def merge_probe_record(records: list[dict[str, str]], record: dict[str, str]) -> list[dict[str, str]]:
    image_id = record.get("image_id", "")
    merged = [item for item in records if item.get("image_id") != image_id]
    merged.append(record)
    return merged


def sync_probe_records_to_feishu(
    client: FeishuClient,
    sheet_info: dict[str, str],
    records: list[dict[str, str]],
) -> None:
    client.write_values(
        sheet_info["spreadsheet_token"],
        sheet_info["sheet_id"],
        "A1",
        build_probe_rows(records),
    )


def build_probe_rows(records: list[dict[str, str]]) -> list[list[str]]:
    rows = [list(SHEET_HEADERS)]
    for index, record in enumerate(records, start=1):
        rows.append(
            [
                str(index),
                record.get("image_name", ""),
                record.get("image_id", ""),
                record.get("desktop_user", ""),
            ]
        )
    return rows


def write_probe_csv(path: Path, records: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerows(build_probe_rows(records))


def resolve_probe_spreadsheet(client: FeishuClient) -> dict[str, str]:
    spreadsheet_url = IMAGE_PROBE_SPREADSHEET_URL
    spreadsheet_token = spreadsheet_token_from_url(spreadsheet_url)
    if not spreadsheet_token:
        raise ValueError("无法从飞书表格 URL 解析 spreadsheet_token: %s" % spreadsheet_url)
    admin_member_id = os.getenv("FEISHU_SHEET_ADMIN_MEMBER_ID", "").strip()
    if admin_member_id:
        try:
            client.grant_admin_permission(spreadsheet_token, admin_member_id)
            print("飞书电子表格已授予管理员权限: %s" % admin_member_id, flush=True)
        except Exception as exc:
            print("授权飞书电子表格管理员失败，继续写入表格: %s" % exc, flush=True)
    sheet_id = client.get_or_add_sheet(spreadsheet_token, IMAGE_PROBE_SHEET_TITLE)
    return {
        "spreadsheet_token": spreadsheet_token,
        "spreadsheet_url": spreadsheet_url,
        "sheet_id": sheet_id,
    }


def publish_probe_report_to_feishu(records: list[dict[str, str]], *, title: str = "") -> dict[str, str]:
    if not feishu_credentials_configured():
        raise ValueError("缺少 APP_ID 或 APP_SECRET，无法写入线上飞书电子表格")
    client = FeishuClient(dry_run=False)
    sheet_info = resolve_probe_spreadsheet(client)
    sync_probe_records_to_feishu(client, sheet_info, records)
    print("复用飞书探测表格: %s sheet=%s" % (sheet_info["spreadsheet_url"], IMAGE_PROBE_SHEET_TITLE), flush=True)
    if title:
        print("探测批次: %s" % title, flush=True)
    return sheet_info


def print_probe_progress(record: dict[str, str]) -> None:
    print(
        "PROBE_RESULT index=%s image_id=%s image_name=%s desktop_user=%s source=%s error=%s"
        % (
            record.get("index", ""),
            record.get("image_id", ""),
            record.get("image_name", ""),
            record.get("desktop_user", ""),
            record.get("desktop_user_source", ""),
            record.get("error", ""),
        ),
        flush=True,
    )


@unittest.skipUnless(
    os.getenv("WORKFLOWGYM_RUN_IMAGE_DESKTOP_USER_PROBE") == "1",
    "set WORKFLOWGYM_RUN_IMAGE_DESKTOP_USER_PROBE=1 to replace images and probe desktop users",
)
@unittest.skipUnless(os.getenv("AK") and os.getenv("SK"), "set AK and SK to query Volcengine APIs")
@unittest.skipUnless(feishu_credentials_configured(), "set APP_ID and APP_SECRET to publish Feishu spreadsheet")
class TestGuangzhouLinuxImageDesktopUserProbe(unittest.TestCase):
    """Replace a probe instance with each cn-guangzhou Linux image and detect desktop username."""

    def setUp(self):
        self.api = create_api_instance(REGION)
        self.env = VolcengineEnv(region=REGION)
        self.records: list[dict[str, str]] = []
        self.feishu_client = FeishuClient(dry_run=False) if feishu_credentials_configured() else None
        self.feishu_sheet_info: dict[str, str] = {}
        if self.feishu_client:
            self.feishu_sheet_info = resolve_probe_spreadsheet(self.feishu_client)
            self.records = load_existing_probe_records(self.feishu_client, self.feishu_sheet_info)
        self.report_dir = Path(
            os.getenv(
                "IMAGE_PROBE_REPORT_DIR",
                str(Path(tempfile.gettempdir()) / "workflowgym_image_desktop_user_probe"),
            )
        )
        self.report_dir.mkdir(parents=True, exist_ok=True)
        self.csv_path = self.report_dir / "guangzhou_linux_image_desktop_users.csv"

    def _append_record(self, record: dict[str, str]) -> None:
        self.records = merge_probe_record(self.records, record)
        write_probe_csv(self.csv_path, self.records)
        print_probe_progress(record)
        if self.feishu_client and self.feishu_sheet_info:
            sync_probe_records_to_feishu(self.feishu_client, self.feishu_sheet_info, self.records)

    def test_probe_linux_image_desktop_users_and_publish_feishu_sheet(self):
        if IMAGE_PROBE_TARGET_IMAGE_ID:
            target_image = self.env.describe_image(IMAGE_PROBE_TARGET_IMAGE_ID)
            ubuntu_images = [target_image]
        else:
            images = list_region_images(self.api, region=REGION)
            ubuntu_images = filter_ubuntu_images(images)
            if IMAGE_PROBE_MAX_IMAGES > 0:
                ubuntu_images = ubuntu_images[:IMAGE_PROBE_MAX_IMAGES]

        print(
            "开始探测: region=%s instance_id=%s ubuntu_image_count=%s skip_existing=%s"
            % (REGION, PROBE_INSTANCE_ID, len(ubuntu_images), IMAGE_PROBE_SKIP_EXISTING),
            flush=True,
        )
        self.assertTrue(ubuntu_images, "cn-guangzhou 下没有可探测的 Ubuntu 镜像")

        probed_count = 0
        skipped_count = 0
        for index, image in enumerate(ubuntu_images, start=1):
            image_id = image_record_field(image, "ImageId", "image_id")
            image_name = image_display_name(image)
            if IMAGE_PROBE_SKIP_EXISTING:
                existing = next((item for item in self.records if item.get("image_id") == image_id), None)
                if existing and existing.get("desktop_user"):
                    skipped_count += 1
                    print(
                        "SKIP_EXISTING index=%s image_id=%s image_name=%s desktop_user=%s"
                        % (index, image_id, image_name, existing.get("desktop_user")),
                        flush=True,
                    )
                    continue
            record = {
                "index": str(index),
                "image_id": image_id,
                "image_name": image_name,
                "desktop_user": "",
                "desktop_user_source": "",
                "error": "",
            }
            print(
                "PROBE_START index=%s/%s image_id=%s image_name=%s"
                % (index, len(ubuntu_images), image_id, image_name),
                flush=True,
            )
            try:
                probe_result = replace_image_and_probe_desktop_user(self.env, PROBE_INSTANCE_ID, image_id)
                record["desktop_user"] = str(probe_result.get("desktop_user") or "")
                record["desktop_user_source"] = str(probe_result.get("desktop_user_source") or "")
                if not record["desktop_user"]:
                    record["error"] = "probe_empty"
            except Exception as exc:
                record["error"] = str(exc)
                record["desktop_user"] = ""
            self._append_record(record)
            probed_count += 1

        title = "cn-guangzhou Ubuntu 镜像桌面用户探测 %s" % datetime.now().strftime("%Y%m%d_%H%M%S")
        sheet_info = publish_probe_report_to_feishu(self.records, title=title)
        report = {
            "region": REGION,
            "instance_id": PROBE_INSTANCE_ID,
            "ubuntu_image_count": len(ubuntu_images),
            "probed_count": probed_count,
            "skipped_count": skipped_count,
            "records": self.records,
            "csv_path": str(self.csv_path),
            "spreadsheet_url": sheet_info["spreadsheet_url"],
            "sheet_title": IMAGE_PROBE_SHEET_TITLE,
        }
        print("REPORT_JSON", json.dumps(report, ensure_ascii=False), flush=True)
        print("飞书电子表格: %s" % sheet_info["spreadsheet_url"], flush=True)
        print("本地 CSV: %s" % self.csv_path, flush=True)

        self.assertTrue(sheet_info["spreadsheet_url"])
        for image in ubuntu_images:
            image_id = image_record_field(image, "ImageId", "image_id")
            if IMAGE_PROBE_SKIP_EXISTING:
                existing = next((item for item in self.records if item.get("image_id") == image_id), None)
                if existing and existing.get("desktop_user"):
                    continue
            self.assertTrue(
                any(record.get("image_id") == image_id for record in self.records),
                "探测结果未写入记录: %s" % image_id,
            )


class TestGuangzhouLinuxImageDesktopUserProbeHelpers(unittest.TestCase):
    def test_resolve_desktop_user_prefers_graphical_session_user(self):
        output = "\n".join(
            [
                "WORKFLOWGYM_DESKTOP_PROBE auto_user=user",
                "WORKFLOWGYM_DESKTOP_PROBE session_user=ubuntu",
                "WORKFLOWGYM_DESKTOP_PROBE xauth_user=user",
                "WORKFLOWGYM_DESKTOP_PROBE home_users=user ubuntu ",
            ]
        )
        resolved = resolve_desktop_user_from_probe(output)
        self.assertEqual(resolved["desktop_user"], "ubuntu")
        self.assertEqual(resolved["desktop_user_source"], "session_user")

    def test_resolve_desktop_user_prefers_non_root_home_user(self):
        output = "\n".join(
            [
                "WORKFLOWGYM_DESKTOP_PROBE session_user=gdm",
                "WORKFLOWGYM_DESKTOP_PROBE home_users=syslog cups-pk-helper user ",
                "WORKFLOWGYM_DESKTOP_PROBE non_root_users=user ",
            ]
        )
        resolved = resolve_desktop_user_from_probe(output)
        self.assertEqual(resolved["desktop_user"], "user")
        self.assertEqual(resolved["desktop_user_source"], "preferred_user")

    def test_resolve_desktop_user_falls_back_to_single_home_user(self):
        output = "\n".join(
            [
                "WORKFLOWGYM_DESKTOP_PROBE auto_user=",
                "WORKFLOWGYM_DESKTOP_PROBE session_user=",
                "WORKFLOWGYM_DESKTOP_PROBE xauth_user=",
                "WORKFLOWGYM_DESKTOP_PROBE home_users=ubuntu ",
            ]
        )
        resolved = resolve_desktop_user_from_probe(output)
        self.assertEqual(resolved["desktop_user"], "ubuntu")
        self.assertEqual(resolved["desktop_user_source"], "home_users")

    def test_resolve_desktop_user_ignores_invalid_auto_user_from_gdm_config(self):
        output = "\n".join(
            [
                "WORKFLOWGYM_DESKTOP_PROBE auto_user=rot",
                "WORKFLOWGYM_DESKTOP_PROBE session_user=gdm",
                "WORKFLOWGYM_DESKTOP_PROBE xauth_user=",
                "WORKFLOWGYM_DESKTOP_PROBE home_users=syslog cups-pk-helper user ",
                "WORKFLOWGYM_DESKTOP_PROBE non_root_users=user ",
            ]
        )
        resolved = resolve_desktop_user_from_probe(output)
        self.assertEqual(resolved["desktop_user"], "user")
        self.assertEqual(resolved["desktop_user_source"], "preferred_user")

    def test_resolve_desktop_user_ignores_root_when_user_exists(self):
        output = "\n".join(
            [
                "WORKFLOWGYM_DESKTOP_PROBE auto_user=",
                "WORKFLOWGYM_DESKTOP_PROBE session_user=gdm",
                "WORKFLOWGYM_DESKTOP_PROBE xauth_user=",
                "WORKFLOWGYM_DESKTOP_PROBE home_users=syslog cups-pk-helper root roo user ",
                "WORKFLOWGYM_DESKTOP_PROBE non_root_users=root roo user ",
                "WORKFLOWGYM_DESKTOP_PROBE validated_users=user ",
            ]
        )
        resolved = resolve_desktop_user_from_probe(output)
        self.assertEqual(resolved["desktop_user"], "user")
        self.assertEqual(resolved["desktop_user_source"], "preferred_user")

    def test_resolve_desktop_user_requires_validated_home_directory(self):
        output = "\n".join(
            [
                "WORKFLOWGYM_DESKTOP_PROBE auto_user=",
                "WORKFLOWGYM_DESKTOP_PROBE session_user=",
                "WORKFLOWGYM_DESKTOP_PROBE xauth_user=",
                "WORKFLOWGYM_DESKTOP_PROBE home_users=syslog cups-pk-helper user ",
                "WORKFLOWGYM_DESKTOP_PROBE non_root_users=user ",
                "WORKFLOWGYM_DESKTOP_PROBE validated_users=",
            ]
        )
        resolved = resolve_desktop_user_from_probe(output)
        self.assertEqual(resolved["desktop_user"], "")

    def test_build_probe_desktop_user_command_validates_candidates_with_id(self):
        command = build_probe_desktop_user_command()
        self.assertIn("validate_probe_user", command)
        self.assertIn('auto_user="$(validate_probe_user "$auto_user")"', command)
        self.assertIn('session_user="$(validate_probe_user "$session_user")"', command)
        self.assertIn("validated_users=", command)
        self.assertIn('/home/$candidate"', command)

    def test_filter_ubuntu_images_skips_centos(self):
        images = [
            {"ImageId": "image-centos", "OsType": "Linux", "Platform": "CentOS", "ImageName": "CentOS 8", "Status": "Available"},
            {"ImageId": "image-ubuntu", "OsType": "Linux", "Platform": "Ubuntu", "ImageName": "Ubuntu 22.04", "Status": "Available"},
            {"ImageId": "image-preview", "OsType": "Linux", "Platform": "Ubuntu", "ImageName": "preview-Ubuntu2204_64-demo", "Status": "Available"},
        ]
        ubuntu_images = filter_ubuntu_images(images)
        self.assertEqual([item["ImageId"] for item in ubuntu_images], ["image-preview"])

    def test_filter_ubuntu_images_skips_market_images_without_preview_prefix(self):
        images = [
            {
                "ImageId": "image-openclaw",
                "OsType": "Linux",
                "Platform": "Ubuntu",
                "ImageName": "Ubuntu 24.04 with OpenClaw 64 bit",
                "Status": "Available",
            },
            {
                "ImageId": "image-preview",
                "OsType": "Linux",
                "Platform": "Ubuntu",
                "ImageName": "preview-Ubuntu2204_64-demo_bj",
                "Status": "Available",
            },
        ]
        ubuntu_images = filter_ubuntu_images(images)
        self.assertEqual([item["ImageId"] for item in ubuntu_images], ["image-preview"])

    def test_filter_ubuntu_images_skips_qcow2_bj_suffix(self):
        images = [
            {
                "ImageId": "image-stable",
                "OsType": "Linux",
                "Platform": "Ubuntu",
                "ImageName": "stable-Ubuntu22.04-Calibre_v5.37-initv1-20251101-tob.qcow2_bj",
                "Status": "Available",
            },
            {
                "ImageId": "image-preview",
                "OsType": "Linux",
                "Platform": "Ubuntu",
                "ImageName": "preview-Ubuntu2204_64-Blender-demo_bj",
                "Status": "Available",
            },
        ]
        ubuntu_images = filter_ubuntu_images(images)
        self.assertEqual([item["ImageId"] for item in ubuntu_images], ["image-preview"])

    def test_filter_ubuntu_images_skips_gui_suffix(self):
        images = [
            {
                "ImageId": "image-gui",
                "OsType": "Linux",
                "Platform": "Ubuntu",
                "ImageName": "ubuntu-bios-init-20251009-haojun_bj_gui",
                "Status": "Available",
            },
            {
                "ImageId": "image-source",
                "OsType": "Linux",
                "Platform": "Ubuntu",
                "ImageName": "preview-Ubuntu2204_64-demo_bj",
                "Status": "Available",
            },
        ]
        ubuntu_images = filter_ubuntu_images(images)
        self.assertEqual([item["ImageId"] for item in ubuntu_images], ["image-source"])

    def test_filter_ubuntu_images_skips_arm(self):
        images = [
            {
                "ImageId": "image-arm",
                "OsType": "Linux",
                "Platform": "Ubuntu",
                "ImageName": "Ubuntu 24.04 ARM 64 bit",
                "Status": "Available",
            },
            {
                "ImageId": "image-x86",
                "OsType": "Linux",
                "Platform": "Ubuntu",
                "ImageName": "preview-Ubuntu2204_64-demo_bj",
                "Status": "Available",
            },
        ]
        ubuntu_images = filter_ubuntu_images(images)
        self.assertEqual([item["ImageId"] for item in ubuntu_images], ["image-x86"])

    def test_filter_linux_images_skips_windows(self):
        images = [
            {"ImageId": "image-win", "OsType": "Windows", "Platform": "Windows Server 2022", "Status": "Available"},
            {"ImageId": "image-linux", "OsType": "Linux", "Platform": "Ubuntu", "Status": "Available"},
        ]
        linux_images = filter_linux_images(images)
        self.assertEqual([item["ImageId"] for item in linux_images], ["image-linux"])

    def test_build_probe_rows_contains_headers(self):
        rows = build_probe_rows(
            [
                {
                    "image_name": "demo",
                    "image_id": "image-1",
                    "desktop_user": "user",
                }
            ]
        )
        self.assertEqual(rows[0], list(SHEET_HEADERS))
        self.assertEqual(rows[1], ["1", "demo", "image-1", "user"])

    def test_default_probe_spreadsheet_url(self):
        self.assertEqual(
            spreadsheet_token_from_url(DEFAULT_IMAGE_PROBE_SPREADSHEET_URL),
            "PLACEHOLDER",
        )


if __name__ == "__main__":
    unittest.main()
