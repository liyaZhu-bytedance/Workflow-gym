from __future__ import annotations

import base64
import json
import os
import sys
import time
import unittest
import urllib.error
import urllib.request
import warnings
from pathlib import Path

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import volcenginesdkcore
import volcenginesdkecs

from open_workflowgym.envs.volcengine_eip import allocate_and_associate_eip
from open_workflowgym.envs.volcengine_env import (
    get_result_payload,
    maybe_decode_output,
    ps_single_quote,
    to_plain_dict,
    windows_login_password,
)


DEFAULT_INSTANCE_ID = "i-yeq4neypkwuo7budzfbg"


def read_env(name: str, default: str = "") -> str:
    return os.getenv(name, default)


def first_value(data: dict, *keys: str):
    for key in keys:
        value = data.get(key)
        if value:
            return value
    return ""


@unittest.skipUnless(
    os.getenv("WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS") == "1",
    "set WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS=1 to run real Volcengine calls",
)
class WindowsCloudAssistantEipE2ETest(unittest.TestCase):
    """Manual E2E tests that expose an Administrator-session runner through EIP."""

    def setUp(self):
        self.instance_id = read_env("WORKFLOWGYM_TEST_INSTANCE_ID", DEFAULT_INSTANCE_ID)
        self.region = read_env("VOLCENGINE_REGION", read_env("SOURCE_REGION", "cn-guangzhou"))
        self.output_dir = Path(
            read_env("WORKFLOWGYM_CLOUD_ASSISTANT_TEST_OUTPUT_DIR", "output/manual_windows_cloud_assistant_eip_test")
        )
        self.output_dir.mkdir(parents=True, exist_ok=True)
        configuration = volcenginesdkcore.Configuration()
        configuration.ak = read_env("AK")
        configuration.sk = read_env("SK")
        configuration.region = self.region
        volcenginesdkcore.Configuration.set_default(configuration)
        self.api = volcenginesdkecs.ECSApi()

    def test_interactive_flask_runner_click_win_icon_over_eip(self):
        project_name = read_env("VOLCENGINE_EIP_PROJECT_NAME", "default")
        billing_type = int(read_env("VOLCENGINE_EIP_BILLING_TYPE", "2"))
        password = windows_login_password()
        self.assertTrue(password, "set WINDOWS_LOGIN_PASSWORD or INSTANCE_PASSWORD")
        token = read_env("WORKFLOWGYM_FLASK_RUNNER_TOKEN", "workflowgym-test-token")

        print("WORKFLOWGYM_TEST_INSTANCE", self.instance_id, flush=True)
        eip_result = allocate_and_associate_eip(
            instance_id=self.instance_id,
            region=self.region,
            billing_type=billing_type,
            project_name=project_name,
        )
        print("WORKFLOWGYM_TEST_BIND_PUBLIC_IP_RESULT", eip_result, flush=True)
        eip = self.eip_address_from_result(eip_result)
        self.assertTrue(eip, "missing EIP address from binding result")

        print("WORKFLOWGYM_CLOUD_ASSISTANT_STATUS", self.describe_cloud_assistant_status(), flush=True)
        before = self.save_screenshot("before_interactive_flask_runner_click_win_icon.jpg")
        setup_result = self.run_powershell(
            self.interactive_flask_runner_command(password, token),
            timeout=180,
            windows_password=password,
        )
        print("WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_SETUP_RESULT", setup_result, flush=True)
        decoded_output = self.command_decoded_output(setup_result)
        self.assertIn("WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_STARTED", decoded_output)

        base_url = "http://%s:80" % eip
        health = self.http_json("GET", base_url + "/health", token=token, timeout=60)
        print("WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_HEALTH", health, flush=True)
        self.assertTrue(health.get("ok"), health)

        action_result = self.http_json(
            "POST",
            base_url + "/action",
            token=token,
            payload={"action": "click", "x": 20, "y": 748},
            timeout=30,
        )
        print("WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_ACTION_RESULT", action_result, flush=True)
        self.assertTrue(action_result.get("ok"), action_result)

        time.sleep(2)
        after = self.save_screenshot("after_interactive_flask_runner_click_win_icon.jpg")
        print("WORKFLOWGYM_SCREENSHOT_BEFORE", before, flush=True)
        print("WORKFLOWGYM_SCREENSHOT_AFTER", after, flush=True)

    def describe_cloud_assistant_status(self):
        request = volcenginesdkecs.DescribeCloudAssistantStatusRequest(instance_ids=[self.instance_id])
        response = self.api.describe_cloud_assistant_status(request)
        result = get_result_payload(to_plain_dict(response))
        instances = result.get("Instances") or result.get("instances") or []
        for item in instances:
            if first_value(item, "InstanceId", "instance_id") == self.instance_id:
                return item
        return None

    def run_powershell(self, command: str, timeout: int = 60, username: str = "", windows_password: str = ""):
        kwargs = {
            "command_content": command,
            "content_encoding": "PlainText",
            "instance_ids": [self.instance_id],
            "invocation_name": "workflowgym-cloud-assistant-eip-e2e",
            "timeout": timeout,
            "type": "PowerShell",
            "working_dir": "C:\\Users\\Administrator\\Desktop\\",
        }
        if username:
            kwargs["username"] = username
        if windows_password:
            kwargs["windows_password"] = windows_password
        request = volcenginesdkecs.RunCommandRequest(**kwargs)
        response = self.api.run_command(request)
        result = get_result_payload(to_plain_dict(response))
        invocation_id = result.get("InvocationId") or result.get("invocation_id")
        self.assertTrue(invocation_id)
        deadline = time.time() + timeout + 60
        while time.time() < deadline:
            time.sleep(5)
            results_request = volcenginesdkecs.DescribeInvocationResultsRequest(
                invocation_id=invocation_id,
                instance_id=self.instance_id,
                page_number=1,
                page_size=10,
            )
            result_data = get_result_payload(to_plain_dict(self.api.describe_invocation_results(results_request)))
            invocation_results = result_data.get("InvocationResults") or result_data.get("invocation_results") or []
            if not invocation_results:
                continue
            for item in invocation_results:
                output = item.get("Output") or item.get("output")
                if output:
                    item["decoded_output"] = maybe_decode_output(output)
            if any((item.get("InvocationResultStatus") or item.get("invocation_result_status")) in ("Pending", "Running") for item in invocation_results):
                continue
            return {"invocation_id": invocation_id, "results": invocation_results}
        raise TimeoutError("waiting RunCommand timed out: %s" % invocation_id)

    def save_screenshot(self, name: str) -> str:
        request = volcenginesdkecs.GetConsoleScreenshotRequest(instance_id=self.instance_id, wake_up=True)
        response = self.api.get_console_screenshot(request)
        result = get_result_payload(to_plain_dict(response))
        screenshot = result.get("Screenshot") or result.get("screenshot")
        self.assertTrue(screenshot)
        if "," in screenshot:
            screenshot = screenshot.split(",", 1)[1]
        path = self.output_dir / name
        path.write_bytes(base64.b64decode(screenshot))
        return str(path)

    @staticmethod
    def eip_address_from_result(eip_result: dict) -> str:
        for key in ("eip_address", "eip", "ip_address"):
            value = eip_result.get(key)
            if isinstance(value, str) and value:
                return value
        allocate_response = eip_result.get("allocate_response") or {}
        result = allocate_response.get("Result") or allocate_response.get("result") or {}
        for item in result.get("EipAddresses") or result.get("eip_addresses") or []:
            value = item.get("eip_address") or item.get("EipAddress") or item.get("ip_address")
            if value:
                return value
        for item in eip_result.get("pre_disassociated_eips") or []:
            eip = item.get("eip") or {}
            value = eip.get("eip_address") or eip.get("EipAddress") or eip.get("ip_address")
            if value:
                return value
        return ""

    @staticmethod
    def http_json(method: str, url: str, token: str, payload: dict | None = None, timeout: int = 30) -> dict:
        deadline = time.time() + timeout
        last_error = None
        while time.time() < deadline:
            try:
                data = None
                headers = {"X-WorkflowGym-Token": token}
                if payload is not None:
                    data = json.dumps(payload).encode("utf-8")
                    headers["Content-Type"] = "application/json"
                request = urllib.request.Request(url, data=data, headers=headers, method=method)
                with urllib.request.urlopen(request, timeout=5) as response:
                    return json.loads(response.read().decode("utf-8"))
            except (OSError, urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
                last_error = exc
                time.sleep(2)
        raise TimeoutError("waiting HTTP runner failed: %s %s last_error=%r" % (method, url, last_error))

    @staticmethod
    def interactive_flask_runner_command(password: str, token: str) -> str:
        command = r"""$ErrorActionPreference = 'Stop'

$password = __PASSWORD__
$taskName = 'WorkflowGymInteractiveFlaskRunner'
$desktop = 'C:\Users\Administrator\Desktop'
$python = 'C:\Program Files\Python312\python.exe'
$runnerPath = Join-Path $desktop 'workflowgym_interactive_flask_runner.py'
$runnerCmdPath = Join-Path $desktop 'workflowgym_interactive_flask_runner.cmd'
$logPath = Join-Path $desktop 'workflowgym_interactive_flask_runner.log'

if (-not (Test-Path $python)) {
  throw "python executable not found: $python"
}

& $python -m pip install flask | Out-String | Write-Output

@"
import time
import traceback

import pyautogui
from flask import Flask, jsonify, request

TOKEN = __TOKEN_JSON__

app = Flask(__name__)
pyautogui.FAILSAFE = False

def check_token():
    return request.headers.get("X-WorkflowGym-Token") == TOKEN

@app.get("/health")
def health():
    if not check_token():
        return jsonify({"ok": False, "error": "unauthorized"}), 401
    return jsonify({"ok": True, "screen_size": list(pyautogui.size())})

@app.post("/action")
def action():
    if not check_token():
        return jsonify({"ok": False, "error": "unauthorized"}), 401
    data = request.get_json(force=True)
    try:
        kind = data.get("action")
        if kind == "click":
            pyautogui.click(int(data["x"]), int(data["y"]))
        elif kind == "hotkey":
            pyautogui.hotkey(*data["keys"])
        elif kind == "write":
            pyautogui.write(data["text"], interval=float(data.get("interval", 0)))
        elif kind == "press":
            pyautogui.press(data["key"])
        elif kind == "sleep":
            time.sleep(float(data.get("seconds", 1)))
        else:
            return jsonify({"ok": False, "error": "unknown action", "action": kind}), 400
        return jsonify({"ok": True, "screen_size": list(pyautogui.size()), "action": data})
    except Exception as exc:
        return jsonify({"ok": False, "error": repr(exc), "traceback": traceback.format_exc()}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80, threaded=False)
"@ | Set-Content -LiteralPath $runnerPath -Encoding UTF8

('@echo off' + [Environment]::NewLine + '"' + $python + '" "' + $runnerPath + '" > "' + $logPath + '" 2>&1') | Set-Content -LiteralPath $runnerCmdPath -Encoding ASCII

cmd.exe /c "schtasks /Delete /TN $taskName /F >nul 2>nul"
schtasks /Create /F /TN $taskName /SC ONCE /ST 23:59 /TR $runnerCmdPath /RU Administrator /RP $password /RL HIGHEST /IT | Out-Null

netsh advfirewall firewall delete rule name="WorkflowGym Flask Runner 80" 2>$null | Out-Null
netsh advfirewall firewall add rule name="WorkflowGym Flask Runner 80" dir=in action=allow protocol=TCP localport=80 | Out-Null

schtasks /Run /TN $taskName | Out-Null
Start-Sleep -Seconds 5

Write-Output 'WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_STARTED'
Write-Output ('WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_PATH ' + $runnerPath)
Write-Output ('WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_LOG ' + $logPath)
"""
        return (
            command.replace("__PASSWORD__", ps_single_quote(password))
            .replace("__TOKEN_JSON__", json.dumps(token))
        )

    @staticmethod
    def command_decoded_output(response_data: dict) -> str:
        outputs = []
        for item in response_data.get("results") or []:
            output = item.get("decoded_output")
            if output:
                outputs.append(output)
        return "\n".join(outputs)


if __name__ == "__main__":
    unittest.main()
