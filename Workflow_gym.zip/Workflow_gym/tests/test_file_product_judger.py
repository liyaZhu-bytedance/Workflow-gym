from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.judgers.file_product import output_filename, sample_outputs_by_filename


class FileProductJudgerTest(unittest.TestCase):
    def test_sample_outputs_by_filename_uses_relative_path_basename(self):
        output_uploads = [
            {"relative_path": "nested/yyy.csv", "tos_url": "https://example.com/yyy.csv?sig=1"},
            {"relative_path": "xxx.txt", "tos_path": "tos://bucket/output/xxx.txt"},
        ]

        outputs, errors = sample_outputs_by_filename(output_uploads)

        self.assertEqual(errors, [])
        self.assertEqual(outputs["yyy.csv"]["relative_path"], "nested/yyy.csv")
        self.assertEqual(outputs["xxx.txt"]["relative_path"], "xxx.txt")

    def test_output_filename_falls_back_to_url_filename(self):
        self.assertEqual(
            output_filename({"tos_url": "https://example.com/base/answer.pdf?X-Tos-Signature=abc"}),
            "answer.pdf",
        )

    def test_sample_outputs_by_filename_reports_duplicates(self):
        outputs, errors = sample_outputs_by_filename([
            {"relative_path": "a/result.csv", "tos_url": "https://example.com/a/result.csv"},
            {"relative_path": "b/result.csv", "tos_url": "https://example.com/b/result.csv"},
        ])

        self.assertIn("result.csv", outputs)
        self.assertEqual(errors, ["采样输出文件名重复，无法唯一匹配: result.csv"])


if __name__ == "__main__":
    unittest.main()
