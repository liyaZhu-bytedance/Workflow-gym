import os
import sys
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))

from upload_images_to_huggingface import (
    DEFAULT_UPLOAD_CONCURRENCY,
    normalize_upload_workers,
)


class TestUploadWorkers(unittest.TestCase):
    def test_normalize_upload_workers_defaults_to_ten(self):
        with mock.patch.dict(os.environ, {}, clear=True):
            self.assertEqual(normalize_upload_workers(None), DEFAULT_UPLOAD_CONCURRENCY)

    def test_normalize_upload_workers_caps_at_ten(self):
        self.assertEqual(normalize_upload_workers(32), 10)
        self.assertEqual(normalize_upload_workers(3), 3)

    def test_normalize_upload_workers_reads_env(self):
        with mock.patch.dict(os.environ, {"HF_UPLOAD_NUM_WORKERS": "8"}, clear=True):
            self.assertEqual(normalize_upload_workers(None), 8)


if __name__ == "__main__":
    unittest.main()
