from __future__ import annotations

import os
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.agents.base import SampleContext
from open_workflowgym.envs.instance_pool import InstancePool
from open_workflowgym.envs.lease_backend import LocalLeaseBackend, lease_is_expired
from open_workflowgym.envs.volcengine_env import VolcengineEnv
from open_workflowgym.lease_renewal import LeaseRenewContext, renew_active_lease
from open_workflowgym.platform_utils import unknown_platform_reason
from open_workflowgym.records import InstanceLease, RunConfig, SampleJob, TaskRecord, TrajectoryResult
from open_workflowgym.sampler import InitializeForSampleTimeoutError, Sampler, SampleRunState, sample_directory
from open_workflowgym.state_store import StateStore
from open_workflowgym.states import InstanceStatus


class SchedulerSafeguardsTest(unittest.TestCase):
    def test_lease_is_expired(self):
        lease = InstanceLease(
            run_id="run",
            lease_id="lease-1",
            instance_id="i-ubuntu",
            task_id="42",
            sample_index=1,
            status="leased",
            acquired_at="2026-07-12 20:00:00",
            expires_at="2026-07-12 20:30:00",
        )
        self.assertTrue(
            lease_is_expired(lease, now=__import__("datetime").datetime(2026, 7, 12, 20, 30, 0))
        )
        self.assertFalse(
            lease_is_expired(lease, now=__import__("datetime").datetime(2026, 7, 12, 20, 29, 59))
        )

    def test_expire_stale_leases_quarantines_and_blocks_acquire(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            pool = InstancePool(
                ["i-ubuntu"],
                StateStore(str(Path(tmp_dir) / "state.db")),
                {"i-ubuntu": "ubuntu"},
                lease_ttl_seconds=3600,
            )
            store = pool.store
            lease = pool.acquire("run", "42", 1, "ubuntu")
            self.assertIsNotNone(lease)
            lease.expires_at = "2000-01-01 00:00:00"
            pool.lease_backend._leases_by_instance["i-ubuntu"] = lease
            store.upsert_lease(lease)

            expired = pool.expire_stale_leases()
            self.assertEqual(len(expired), 1)
            self.assertEqual(pool.status_by_instance["i-ubuntu"], InstanceStatus.QUARANTINED.value)
            self.assertIsNone(pool.acquire("run", "42", 2, "ubuntu"))
            self.assertEqual(pool.acquire_status("ubuntu"), "unavailable")

            pool.release(expired[0], "sample_finished")
            self.assertEqual(pool.status_by_instance["i-ubuntu"], InstanceStatus.QUARANTINED.value)
            self.assertEqual(pool.acquire_status("ubuntu"), "unavailable")
            pool.mark("i-ubuntu", InstanceStatus.IDLE)
            self.assertIsNotNone(pool.acquire("run", "42", 2, "ubuntu"))

    def test_unknown_platform_reason(self):
        task = TaskRecord(
            run_id="run",
            task_id="42",
            row_number=2,
            fields={"image": "image-unknown"},
        )
        reason = unknown_platform_reason(task, {"image-unknown": ""})
        self.assertIn("42", reason)
        self.assertIn("平台", reason)

    def test_prepare_task_fail_fast_on_unknown_platform(self):
        from open_workflowgym.scheduler import Scheduler

        with tempfile.TemporaryDirectory() as tmp_dir:
            store = StateStore(str(Path(tmp_dir) / "state.db"))
            pool = InstancePool(["i-ubuntu"], store, {"i-ubuntu": "ubuntu"})
            config = RunConfig(
                run_id="run",
                output_root=str(Path(tmp_dir) / "output"),
                state_db_path=str(Path(tmp_dir) / "state.db"),
                fail_on_unknown_platform=True,
                validate=False,
            )
            scheduler = Scheduler(
                config=config,
                store=store,
                instance_pool=pool,
                executor=mock.Mock(supports_async=False),
                writer=mock.Mock(),
                scorer=mock.Mock(),
                agent_factory=mock.Mock(),
                image_platforms={},
            )
            record = TaskRecord(
                run_id="run",
                task_id="42",
                row_number=2,
                fields={"image": "image-unknown"},
            )
            task_status = scheduler.prepare_task_for_sampling(record)
            self.assertIsNone(task_status)
            with store.connect() as conn:
                task_row = conn.execute(
                    "SELECT status FROM tasks WHERE run_id=? AND task_id=?",
                    ("run", "42"),
                ).fetchone()
            self.assertIsNotNone(task_row)
            self.assertEqual(task_row["status"], "validation_failed")

    def test_initialize_for_sample_timeout(self):
        env = mock.Mock()

        def slow_init(*args, **kwargs):
            time.sleep(2)
            return {"dry_run": True}

        env.initialize_for_sample = slow_init
        with tempfile.TemporaryDirectory() as tmp_dir:
            output_root = str(Path(tmp_dir) / "output")
            sampler = Sampler(mock.Mock(), env)
            job = SampleJob(
                run_id="run",
                task_id="42",
                sample_index=1,
                task=TaskRecord(
                    run_id="run",
                    task_id="42",
                    row_number=2,
                    fields={"image": "image-ubuntu", "系统类型": "Ubuntu"},
                ),
                config=RunConfig(
                    run_id="run",
                    output_root=output_root,
                    sample_init_timeout_seconds=1,
                ),
                lease=InstanceLease(
                    run_id="run",
                    lease_id="lease-1",
                    instance_id="i-ubuntu",
                    task_id="42",
                    sample_index=1,
                    status="leased",
                    acquired_at="2026-07-12 20:00:00",
                ),
            )
            sample_dir = sample_directory(job)
            os.makedirs(sample_dir, exist_ok=True)
            context = SampleContext(run_id="run", task=job.task, sample_index=1, sample_dir=sample_dir)
            state = SampleRunState()
            with self.assertRaises(InitializeForSampleTimeoutError):
                sampler.initialize_sample_env(job, sample_dir, context, state)

    def test_renew_active_lease_extends_expiry_from_now(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            db_path = str(Path(tmp_dir) / "state.db")
            store = StateStore(db_path)
            lease = InstanceLease(
                run_id="run",
                lease_id="lease-1",
                instance_id="i-ubuntu",
                task_id="42",
                sample_index=1,
                status="leased",
                acquired_at="2026-07-12 20:00:00",
                expires_at="2026-07-12 20:30:00",
            )
            store.upsert_lease(lease)
            renewed = renew_active_lease(db_path, "lease-1", 3600)
            self.assertIsNotNone(renewed)
            row = store.get_lease("lease-1")
            self.assertEqual(row["expires_at"], renewed)

    def test_run_sample_renews_lease_at_start(self):
        env = mock.Mock()
        env.lease_renew_context = None
        env.renew_lease_now = mock.Mock(return_value="2026-07-12 22:00:00")
        env.dry_run = "local"
        sampler = Sampler(mock.Mock(), env)
        with tempfile.TemporaryDirectory() as tmp_dir:
            output_root = str(Path(tmp_dir) / "output")
            job = SampleJob(
                run_id="run",
                task_id="42",
                sample_index=1,
                task=TaskRecord(
                    run_id="run",
                    task_id="42",
                    row_number=2,
                    fields={"image": "image-ubuntu", "系统类型": "Ubuntu"},
                ),
                config=RunConfig(
                    run_id="run",
                    output_root=output_root,
                    state_db_path=str(Path(tmp_dir) / "state.db"),
                    dry_run="local",
                    lease_ttl_seconds=3600,
                ),
                lease=InstanceLease(
                    run_id="run",
                    lease_id="lease-1",
                    instance_id="i-ubuntu",
                    task_id="42",
                    sample_index=1,
                    status="leased",
                    acquired_at="2026-07-12 20:00:00",
                ),
            )
            with mock.patch.object(sampler, "initialize_sample_env"), mock.patch.object(
                sampler, "prepare_sample"
            ), mock.patch.object(sampler, "run_sampling_steps"), mock.patch.object(
                sampler, "finalize_sample"
            ), mock.patch.object(
                sampler, "write_results", return_value=mock.Mock()
            ):
                sampler.run_sample(job)
            env.renew_lease_now.assert_called()

    def test_volcengine_heartbeat_throttles_renew(self):
        env = VolcengineEnv(dry_run="local", lease_renew_context=mock.Mock())
        with mock.patch(
            "open_workflowgym.envs.volcengine_env.renew_lease_from_context",
            return_value="2026-07-12 22:00:00",
        ) as renew:
            self.assertIsNotNone(env.renew_lease_now())
            self.assertEqual(renew.call_count, 1)
            renew.reset_mock()
            self.assertIsNone(env.maybe_renew_lease_heartbeat(force=False))
            renew.assert_not_called()
            env._lease_heartbeat_last_at = time.monotonic() - 301
            self.assertIsNotNone(env.maybe_renew_lease_heartbeat(force=False))
            renew.assert_called_once()

    def test_expire_rereads_db_per_lease(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            store = StateStore(str(Path(tmp_dir) / "state.db"))
            backend = LocalLeaseBackend(["i-ubuntu"], {"i-ubuntu": "ubuntu"}, 3600)
            lease = backend.acquire("run", "42", 1, "ubuntu")
            self.assertIsNotNone(lease)
            store.upsert_lease(lease)
            lease.expires_at = "2000-01-01 00:00:00"
            backend._leases_by_instance["i-ubuntu"] = lease
            store.renew_lease(lease.lease_id, 3600)
            expired = backend.expire_stale_leases(store=store)
            self.assertEqual(expired, [])

    def test_init_orphan_release_quarantines_instance(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            store = StateStore(str(Path(tmp_dir) / "state.db"))
            pool = InstancePool(["i-ubuntu"], store, {"i-ubuntu": "ubuntu"})
            lease = pool.acquire("run", "42", 1, "ubuntu")
            self.assertIsNotNone(lease)
            store.flag_lease_init_orphan(
                lease.lease_id,
                lease.instance_id,
                "run",
                "42",
                1,
                "init timeout",
            )
            pool.release(lease, "sample_failed")
            self.assertEqual(pool.status_by_instance["i-ubuntu"], InstanceStatus.QUARANTINED.value)
            self.assertEqual(pool.acquire_status("ubuntu"), "unavailable")

    def test_process_tasks_continues_after_single_sample_failure(self):
        from concurrent.futures import Future

        from open_workflowgym.scheduler import Scheduler
        from open_workflowgym.states import SampleStatus, TaskStatus

        with tempfile.TemporaryDirectory() as tmp_dir:
            output_root = str(Path(tmp_dir) / "output")
            store = StateStore(str(Path(tmp_dir) / "state.db"))
            pool = InstancePool(["i-ubuntu"], store, {"i-ubuntu": "ubuntu"})
            config = RunConfig(
                run_id="run",
                output_root=output_root,
                state_db_path=str(Path(tmp_dir) / "state.db"),
                sample_num=3,
                max_workers=3,
                validate=False,
            )
            scheduler = Scheduler(
                config=config,
                store=store,
                instance_pool=pool,
                executor=mock.Mock(supports_async=True),
                writer=mock.Mock(),
                scorer=mock.Mock(),
                agent_factory=mock.Mock(),
                image_platforms={"image-ubuntu": "ubuntu"},
            )
            scheduler.drain_outbox = mock.Mock(return_value=True)
            scheduler.prepare_task_for_sampling = mock.Mock(return_value=TaskStatus.SAMPLING_PENDING.value)
            scheduler.score_sample_payload = mock.Mock(return_value={"status": "scored"})

            lease = InstanceLease(
                run_id="run",
                lease_id="lease-1",
                instance_id="i-ubuntu",
                task_id="42",
                sample_index=1,
                status="leased",
                acquired_at="2026-07-12 20:00:00",
            )
            submitted_indices: list[int] = []

            def fake_submit(record, sample_index):
                submitted_indices.append(sample_index)
                future = Future()
                if sample_index == 1:
                    future.set_exception(RuntimeError("sample 1 failed"))
                else:
                    sample_dir = str(Path(output_root) / record.task_id / ("sample_%s" % sample_index))
                    future.set_result(
                        TrajectoryResult(
                            run_id=record.run_id,
                            task_id=record.task_id,
                            sample_index=sample_index,
                            status=SampleStatus.SAMPLE_MAX_STEPS_REACHED.value,
                            sample_dir=sample_dir,
                            traj_json_path=str(Path(sample_dir) / "traj.json"),
                            traj_md_path=str(Path(sample_dir) / "traj.md"),
                            id_json_path=str(Path(sample_dir) / "sample_metadata.json"),
                            sample_status_path=str(Path(sample_dir) / "sample_status.json"),
                            last_step=0,
                        )
                    )
                return future, lease, SampleStatus.SAMPLING.value

            scheduler.submit_sample_async = fake_submit
            record = TaskRecord(
                run_id="run",
                task_id="42",
                row_number=2,
                fields={"image": "image-ubuntu", "系统类型": "Ubuntu"},
            )
            store.upsert_task("run", "42", 2, TaskStatus.SAMPLING_PENDING.value, record.fields)

            scheduler.process_tasks([record])

            self.assertEqual(submitted_indices, [1, 2, 3])
            with store.connect() as conn:
                task_row = conn.execute(
                    "SELECT status FROM tasks WHERE run_id=? AND task_id=?",
                    ("run", "42"),
                ).fetchone()
            self.assertIsNotNone(task_row)
            self.assertEqual(task_row["status"], TaskStatus.SYNCED.value)


if __name__ == "__main__":
    unittest.main()
