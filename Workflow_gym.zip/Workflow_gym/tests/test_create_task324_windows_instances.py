from __future__ import print_function

import json
import os
import sys
import time
import unittest
import uuid
import warnings
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

warnings.filterwarnings(
    "ignore",
    message="urllib3 v2 only supports OpenSSL.*",
)

import volcenginesdkcore
import volcenginesdkecs
from volcenginesdkcore.rest import ApiException

from open_workflowgym.envs.volcengine_env import get_result_payload, image_os_type, to_plain_dict


# 题目 324 使用的 Windows 镜像
TASK324_IMAGE_ID = os.getenv("TASK324_IMAGE_ID", "image-yepzlwlesi9b4hcmrafd")
INSTANCE_NAME = os.getenv("INSTANCE_NAME", "open_workflow_gym_windows")
INSTANCE_COUNT = int(os.getenv("INSTANCE_COUNT", "3"))
PROJECT_NAME = os.getenv("PROJECT_NAME", "default")
INSTANCE_TYPE_ID = os.getenv("INSTANCE_TYPE_ID", "ecs.g3il.4xlarge")
INSTANCE_TYPE_IDS = tuple(
    item.strip()
    for item in os.getenv(
        "INSTANCE_TYPE_IDS",
        "ecs.r4il.4xlarge,ecs.r4il.2xlarge,ecs.r4il.xlarge,ecs.r4il.large,"
        "ecs.g3il.4xlarge,ecs.g3il.2xlarge,ecs.g3il.xlarge,ecs.g3il.large,%s" % INSTANCE_TYPE_ID,
    ).split(",")
    if item.strip()
)
SECURITY_GROUP_ID = os.getenv("SECURITY_GROUP_ID", "sg-2jxvygwafv9xc7zrx9wf0sqkg")
SUBNET_ID = os.getenv("SUBNET_ID", "subnet-1phsryth6pgqo5sehpn21io2h")
VOLUME_SIZE = int(os.getenv("VOLUME_SIZE", "400"))
ZONE_ID = os.getenv("ZONE_ID", "cn-guangzhou-a")
AVAILABLE_RESOURCE_ZONES = tuple(
    item.strip()
    for item in os.getenv("AVAILABLE_RESOURCE_ZONES", "cn-guangzhou-a,cn-guangzhou-b,cn-guangzhou-c").split(",")
    if item.strip()
)
INSTANCE_PASSWORD = os.getenv("INSTANCE_PASSWORD", "AlwaysDay1-BUPT-01")
INSTANCE_READY_STATUS = os.getenv("INSTANCE_READY_STATUS", "RUNNING")
INSTANCE_CREATE_TIMEOUT_SECONDS = int(os.getenv("INSTANCE_CREATE_TIMEOUT_SECONDS", "900"))
POLL_INTERVAL_SECONDS = int(os.getenv("POLL_INTERVAL_SECONDS", "30"))


def create_api_instance():
    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = os.getenv("VOLCENGINE_REGION", os.getenv("SOURCE_REGION", "cn-guangzhou"))
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkecs.ECSApi()


def describe_image(api_instance, image_id: str) -> dict:
    response = api_instance.describe_images(volcenginesdkecs.DescribeImagesRequest(image_ids=[image_id]))
    result = get_result_payload(to_plain_dict(response))
    images = result.get("Images") or result.get("images") or []
    if not images:
        raise AssertionError("DescribeImages 没有查询到镜像: %s" % image_id)
    return images[0]


def describe_instance(api_instance, instance_id: str) -> dict:
    response = api_instance.describe_instances(volcenginesdkecs.DescribeInstancesRequest(instance_ids=[instance_id]))
    result = get_result_payload(to_plain_dict(response))
    instances = result.get("Instances") or result.get("instances") or []
    if not instances:
        raise AssertionError("DescribeInstances 没有查询到实例: %s" % instance_id)
    return instances[0]


def instance_status(instance: dict) -> str:
    return instance.get("Status") or instance.get("status") or ""


def wait_for_instance_status(api_instance, instance_id: str, expected_status: str):
    deadline = time.time() + INSTANCE_CREATE_TIMEOUT_SECONDS
    last_status = ""
    while time.time() < deadline:
        instance = describe_instance(api_instance, instance_id)
        last_status = instance_status(instance)
        print("实例 %s 当前状态: %s" % (instance_id, last_status))
        if last_status == expected_status:
            return instance
        if last_status in ("ERROR", "FAILED"):
            raise AssertionError("实例创建失败: %s status=%s" % (instance_id, last_status))
        time.sleep(POLL_INTERVAL_SECONDS)
    raise AssertionError(
        "等待实例状态超时: %s expected=%s last_status=%s" % (instance_id, expected_status, last_status)
    )


def build_run_instances_request(instance_type_id: str, zone_id: str = ZONE_ID):
    return volcenginesdkecs.RunInstancesRequest(
        project_name=PROJECT_NAME,
        image_id=TASK324_IMAGE_ID,
        instance_name=INSTANCE_NAME,
        instance_type_id=instance_type_id,
        network_interfaces=[
            volcenginesdkecs.NetworkInterfaceForRunInstancesInput(
                security_group_ids=[SECURITY_GROUP_ID],
                subnet_id=SUBNET_ID,
            )
        ],
        volumes=[
            volcenginesdkecs.VolumeForRunInstancesInput(
                size=VOLUME_SIZE,
            )
        ],
        zone_id=zone_id,
        keep_image_credential=False,
        password=INSTANCE_PASSWORD,
        client_token=str(uuid.uuid4()),
    )


def api_exception_code(exc: ApiException) -> str:
    body = getattr(exc, "body", None)
    if not body:
        return ""
    try:
        data = json.loads(body)
    except (TypeError, ValueError):
        return str(body)
    metadata = data.get("ResponseMetadata") or {}
    error = metadata.get("Error") or data.get("Error") or {}
    return str(error.get("Code") or "")


def is_retryable_capacity_error(exc: ApiException) -> bool:
    return api_exception_code(exc) == "Insufficient.InstanceCapacity"


def describe_available_resource(api_instance, instance_type_id: str, zone_id: str) -> dict:
    request = volcenginesdkecs.DescribeAvailableResourceRequest(
        destination_resource="InstanceType",
        instance_type_id=instance_type_id,
        zone_id=zone_id,
    )
    response = api_instance.describe_available_resource(request)
    return get_result_payload(to_plain_dict(response))


def supported_resource_statuses(result: dict) -> list[str]:
    statuses: list[str] = []
    zones = result.get("AvailableZones") or result.get("available_zones") or []
    if not zones:
        return statuses
    zone = zones[0]
    for available_resource in zone.get("AvailableResources") or zone.get("available_resources") or []:
        for supported_resource in available_resource.get("SupportedResources") or available_resource.get("supported_resources") or []:
            status = str(supported_resource.get("Status") or supported_resource.get("status") or "").strip()
            if status:
                statuses.append(status)
    return statuses


def instance_type_is_available(api_instance, instance_type_id: str, zone_id: str) -> bool:
    try:
        result = describe_available_resource(api_instance, instance_type_id, zone_id)
    except ApiException as exc:
        print(
            "DescribeAvailableResource 失败: zone_id=%s instance_type_id=%s error=%s"
            % (zone_id, instance_type_id, exc),
            flush=True,
        )
        return False
    statuses = supported_resource_statuses(result)
    available = any(status.lower() == "available" for status in statuses)
    print(
        "库存查询: zone_id=%s instance_type_id=%s statuses=%s available=%s"
        % (zone_id, instance_type_id, statuses or ["<empty>"], available),
        flush=True,
    )
    return available


def print_available_resources_for_specs(api_instance, instance_type_ids: tuple[str, ...], zone_id: str) -> None:
    print("查询可用区库存: zone_id=%s" % zone_id, flush=True)
    for instance_type_id in instance_type_ids:
        instance_type_is_available(api_instance, instance_type_id, zone_id)


def ordered_instance_type_ids_by_inventory(api_instance, instance_type_ids: tuple[str, ...], zone_id: str) -> list[str]:
    available_specs: list[str] = []
    unknown_specs: list[str] = []
    for instance_type_id in instance_type_ids:
        if instance_type_is_available(api_instance, instance_type_id, zone_id):
            available_specs.append(instance_type_id)
        else:
            unknown_specs.append(instance_type_id)
    return available_specs + unknown_specs


def run_instances_with_inventory_fallback(api_instance, zone_id: str = ZONE_ID):
    candidate_specs = ordered_instance_type_ids_by_inventory(api_instance, INSTANCE_TYPE_IDS, zone_id)
    if not candidate_specs:
        candidate_specs = list(INSTANCE_TYPE_IDS)
    last_exception: ApiException | None = None
    for instance_type_id in candidate_specs:
        try:
            print("尝试创建实例: zone_id=%s instance_type_id=%s" % (zone_id, instance_type_id), flush=True)
            response = api_instance.run_instances(build_run_instances_request(instance_type_id, zone_id=zone_id))
            return instance_type_id, response
        except ApiException as exc:
            last_exception = exc
            print(
                "RunInstances 失败: zone_id=%s instance_type_id=%s error_code=%s"
                % (zone_id, instance_type_id, api_exception_code(exc) or exc),
                flush=True,
            )
            if is_retryable_capacity_error(exc):
                print_available_resources_for_specs(api_instance, (instance_type_id,), zone_id)
                print("规格库存不足，尝试下一个更低优先级规格", flush=True)
                continue
            raise
    raise AssertionError(
        "所有候选规格都无法创建实例: zone_id=%s specs=%s last_error=%s"
        % (zone_id, ",".join(candidate_specs), last_exception)
    )


@unittest.skipUnless(
    os.getenv("WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS") == "1",
    "set WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS=1 to run real Volcengine calls",
)
class TestCreateTask324WindowsInstances(unittest.TestCase):
    """Create native Windows instances for task 324 image replacement workflow."""

    def setUp(self):
        self.api = create_api_instance()

    def test_describe_available_resource_orders_specs(self):
        ordered = ordered_instance_type_ids_by_inventory(self.api, INSTANCE_TYPE_IDS, ZONE_ID)
        self.assertTrue(ordered)
        print("ORDERED_INSTANCE_TYPE_IDS", ordered, flush=True)

    def test_create_three_windows_instances_for_task324_image(self):
        image = describe_image(self.api, TASK324_IMAGE_ID)
        image_platform = image_os_type(image)
        print("TASK324_IMAGE_ID", TASK324_IMAGE_ID, flush=True)
        print("TASK324_IMAGE_OS_TYPE", image_platform, flush=True)
        print("INSTANCE_NAME", INSTANCE_NAME, flush=True)
        print("INSTANCE_COUNT", INSTANCE_COUNT, flush=True)
        print("ZONE_ID", ZONE_ID, flush=True)
        self.assertIn("windows", image_platform.lower(), "题目 324 镜像应为 Windows 类型")

        print_available_resources_for_specs(self.api, INSTANCE_TYPE_IDS, ZONE_ID)

        created_ids: list[str] = []
        for index in range(1, INSTANCE_COUNT + 1):
            selected_instance_type_id, response = run_instances_with_inventory_fallback(self.api, ZONE_ID)
            print("创建第 %s/%s 个实例成功: instance_type_id=%s" % (index, INSTANCE_COUNT, selected_instance_type_id), flush=True)

            result = get_result_payload(to_plain_dict(response))
            instance_ids = result.get("InstanceIds") or result.get("instance_ids") or []
            self.assertTrue(instance_ids, "RunInstances 响应中没有返回 InstanceIds")
            for instance_id in instance_ids:
                instance = wait_for_instance_status(self.api, instance_id, INSTANCE_READY_STATUS)
                created_ids.append(instance_id)
                print(
                    "实例创建完成: id=%s name=%s os_type=%s image=%s instance_type=%s"
                    % (
                        instance_id,
                        instance.get("InstanceName") or instance.get("instance_name") or "",
                        instance.get("OsType") or instance.get("os_type") or "",
                        instance.get("ImageId") or instance.get("image_id") or "",
                        instance.get("InstanceTypeId") or instance.get("instance_type_id") or selected_instance_type_id,
                    ),
                    flush=True,
                )

        self.assertEqual(len(created_ids), INSTANCE_COUNT)
        print("WORKFLOWGYM_CREATED_WINDOWS_INSTANCES", created_ids, flush=True)


if __name__ == "__main__":
    unittest.main()
