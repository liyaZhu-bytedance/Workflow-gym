from __future__ import annotations

import os
import shlex
import subprocess
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.judgers.common import extract_json_object
from open_workflowgym.judgers.defaults import JUDGE_API_KEY_ENV, judge_base_url, judge_model, resolve_judge_api_key
from open_workflowgym.judgers.factory import JudgeModelClient, JudgeModelConfig

JUDGE_ZSHRC_ENV_NAMES = (
    "JUDGE_API_KEY",
    "JUDGE_BASE_URL",
    "JUDGE_MODEL",
    "GEMINI31_API_KEY",
)
LIVE_JUDGE_MODEL_FALLBACK = "gemini-3-pro-preview-new"
DEFAULT_AZURE_API_VERSION = "2024-03-01-preview"
JUDGE_PROMPT = '只返回 JSON：{"score":0,"reason":"azure_openai_live_ok"}'


def read_env(name: str, default: str = "") -> str:
    return os.getenv(name, default)


def load_zshrc_env(names: tuple[str, ...] = JUDGE_ZSHRC_ENV_NAMES, zshrc_path: str = "") -> None:
    missing = [name for name in names if not read_env(name)]
    if not missing:
        return
    zshrc = Path(zshrc_path or os.path.expanduser("~/.zshrc"))
    if not zshrc.is_file():
        return
    zshrc_quoted = shlex.quote(str(zshrc))
    for name in missing:
        try:
            completed = subprocess.run(
                ["zsh", "-lc", "source %s >/dev/null 2>&1; print -r -- ${%s:-}" % (zshrc_quoted, name)],
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        value = (completed.stdout or "").strip()
        if value:
            os.environ[name] = value


def live_judge_enabled() -> bool:
    return read_env("RUN_LIVE_JUDGE", "1").strip().lower() not in ("0", "false", "no", "off")


def judge_model_permission_error(exc: BaseException) -> bool:
    text = str(exc)
    return "no model permission" in text or '"code":"-1002"' in text


def azure_api_version() -> str:
    return (read_env("JUDGE_API_VERSION") or DEFAULT_AZURE_API_VERSION).strip()


def call_azure_openai_sdk(model_name: str) -> str:
    """Mirror the original azure_openai provider call path."""
    from openai import AzureOpenAI  # type: ignore[import-not-found]

    base_url = judge_base_url()
    api_key = resolve_judge_api_key()
    if not base_url:
        raise ValueError("缺少 JUDGE_BASE_URL")
    if not api_key:
        raise ValueError("缺少 JUDGE_API_KEY")
    if not model_name:
        raise ValueError("缺少 JUDGE_MODEL")

    client = AzureOpenAI(
        azure_endpoint=base_url,
        api_key=api_key,
        api_version=azure_api_version(),
        default_headers={},
    )
    response = client.chat.completions.create(
        model=model_name,
        messages=[{"role": "user", "content": JUDGE_PROMPT}],
        stream=False,
        max_tokens=1024,
    )
    return response.choices[0].message.content or ""


def call_factory_azure_openai(model_name: str) -> str:
    client = JudgeModelClient(
        JudgeModelConfig(
            name="azure_openai_live",
            provider="azure_openai",
            model=model_name,
            base_url=judge_base_url(),
            api_key_env=JUDGE_API_KEY_ENV,
            request_kwargs={
                "stream": False,
                "max_tokens": 1024,
            },
            api_version=azure_api_version(),
            default_headers={},
            retry_count=1,
            delay_seconds=0,
        )
    )
    return client.call_model(
        [{"role": "user", "content": JUDGE_PROMPT}],
        retry_count=1,
        delay_seconds=0,
    )


def assert_live_judge_response(test_case: unittest.TestCase, raw: str, *, used_model: str, label: str) -> None:
    test_case.assertTrue(str(raw).strip(), "%s 返回空内容 (model=%s)" % (label, used_model))
    parsed = extract_json_object(str(raw))
    if parsed is None:
        # gemini-3 reasoning models may truncate under token pressure; non-empty reply
        # is enough to prove the Azure OpenAI call path itself works.
        print("%s live judge raw (unparsed, model=%s): %r" % (label, used_model, raw))
        return
    test_case.assertIn("score", parsed)
    print("%s live judge response (%s): %s" % (label, used_model, raw))


def call_with_model_fallback(call_fn, configured_model: str) -> tuple[str, str]:
    try:
        return call_fn(configured_model), configured_model
    except Exception as exc:
        if judge_model_permission_error(exc) and configured_model != LIVE_JUDGE_MODEL_FALLBACK:
            raw = call_fn(LIVE_JUDGE_MODEL_FALLBACK)
            print(
                "JUDGE_MODEL=%s 无权限，azure live test 已改用 %s；请更新 ~/.zshrc"
                % (configured_model, LIVE_JUDGE_MODEL_FALLBACK)
            )
            return raw, LIVE_JUDGE_MODEL_FALLBACK
        raise


@unittest.skipUnless(live_judge_enabled(), "set RUN_LIVE_JUDGE=1 to run live judge model tests")
class JudgeAzureOpenAILiveTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        load_zshrc_env()

    def test_zshrc_judge_env_loaded(self) -> None:
        self.assertTrue(resolve_judge_api_key(), "缺少 JUDGE_API_KEY")
        self.assertTrue(judge_base_url(), "缺少 JUDGE_BASE_URL")
        self.assertTrue(judge_model(), "缺少 JUDGE_MODEL")

    def test_azure_openai_sdk_live_call(self) -> None:
        configured_model = judge_model()
        raw, used_model = call_with_model_fallback(call_azure_openai_sdk, configured_model)
        assert_live_judge_response(self, raw, used_model=used_model, label="AzureOpenAI SDK")

    def test_factory_azure_openai_live_call(self) -> None:
        configured_model = judge_model()
        raw, used_model = call_with_model_fallback(call_factory_azure_openai, configured_model)
        assert_live_judge_response(self, raw, used_model=used_model, label="factory azure_openai")


if __name__ == "__main__":
    unittest.main()
