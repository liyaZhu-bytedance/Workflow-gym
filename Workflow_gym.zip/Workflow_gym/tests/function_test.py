from __future__ import annotations

import os
import subprocess
import sys
import time
import types
import unittest
import warnings
from pathlib import Path

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
if "PIL" not in sys.modules:
    pil_module = types.ModuleType("PIL")
    pil_image_module = types.ModuleType("PIL.Image")
    pil_module.Image = pil_image_module
    sys.modules["PIL"] = pil_module
    sys.modules["PIL.Image"] = pil_image_module

from open_workflowgym.envs.volcengine_eip import (  # pyright: ignore[reportMissingImports]
    allocate_and_associate_eip,
    create_vpc_api,
    disassociate_eip,
    to_plain_dict,
)
from open_workflowgym.envs.volcengine_env import VolcengineEnv  # pyright: ignore[reportMissingImports]
from open_workflowgym.records import (  # pyright: ignore[reportMissingImports]
    InstanceLease,
    RunConfig,
    SampleJob,
    TaskFileResult,
    TaskRecord,
    TrajectoryResult,
)
from open_workflowgym.sampler import Sampler  # pyright: ignore[reportMissingImports]
from open_workflowgym.scorer import Scorer  # pyright: ignore[reportMissingImports]


DEFAULT_INSTANCE_ID = "i-yeq4neypkwuo7budzfbg"
DEFAULT_OUTPUT_PATH = "/home/user/Desktop/output"
DEFAULT_FINAL_ANSWER_NAME = "KKX.pdf"
DEFAULT_OUTPUT_ROOT = "output/function_test_1746_tos_score"


def read_env(name: str, default: str = "") -> str:
    value = os.getenv(name)
    if value:
        return value
    try:
        return subprocess.check_output(["launchctl", "getenv", name], text=True).strip() or default
    except Exception:
        return default


class CollectOutputsFunctionTest(unittest.TestCase):
    """Manual function test for copying output files to TOS.

    This test intentionally does not stop/start instances or replace images.
    It uses the project's normal Sampler.collect_outputs path on an existing instance.
    """

    def test_collect_outputs_tosutil_cp_and_score(self):
        instance_id = read_env("FUNCTION_TEST_INSTANCE_ID", DEFAULT_INSTANCE_ID)
        region = read_env("VOLCENGINE_REGION") or read_env("SOURCE_REGION") or "cn-guangzhou"
        output_path = read_env("FUNCTION_TEST_OUTPUT_PATH", DEFAULT_OUTPUT_PATH)
        final_answer_name = read_env("FUNCTION_TEST_FINAL_ANSWER_NAME", DEFAULT_FINAL_ANSWER_NAME)
        output_root = read_env("FUNCTION_TEST_OUTPUT_ROOT", DEFAULT_OUTPUT_ROOT)
        bind_public_ip = read_env("FUNCTION_TEST_BIND_EIP", "1").lower() not in {"0", "false", "no"}
        env = VolcengineEnv(region=region)
        allocation_id = ""

        try:
            if bind_public_ip and not instance_has_public_ip(env, instance_id):
                eip = allocate_and_associate_eip(instance_id, region)
                allocation_id = eip["allocation_id"]
                time.sleep(5)

            job = build_sample_job(
                instance_id=instance_id,
                output_path=output_path,
                final_answer_name=final_answer_name,
                output_root=output_root,
            )
            result = Sampler(None, env).collect_outputs(job)

            for upload in result.output_uploads:
                print("collect_outputs upload:", upload)
            for error in result.errors:
                print("collect_outputs error:", error)

            self.assertEqual(result.final_answer_files, [final_answer_name])
            self.assertEqual(len(result.output_uploads), 1)
            upload = result.output_uploads[0]
            self.assertTrue(upload.get("output_file_exists"), upload)
            self.assertEqual(upload.get("status"), "uploaded", upload)
            self.assertTrue((upload.get("tosutil_cp_result") or {}).get("success"), upload)
            self.assertTrue(str(upload.get("tos_url", "")).startswith("https://"), upload)

            score = Scorer().score(build_score_trajectory(output_root, result, upload["tos_url"]))
            print("score result:", score)
            self.assertEqual(score.check.get("answer_score"), 1, score.check)
        finally:
            if allocation_id:
                disassociate_eip(allocation_id, region)
                release_eip_with_retry(allocation_id, region)


def build_sample_job(
    *,
    instance_id: str,
    output_path: str,
    final_answer_name: str,
    output_root: str,
) -> SampleJob:
    return SampleJob(
        run_id="function-test",
        task_id="1746",
        sample_index=1,
        task=TaskRecord(
            run_id="function-test",
            task_id="1746",
            row_number=1,
            fields={
                "输出文件路径": output_path,
                "final_answer文件名": final_answer_name,
            },
        ),
        config=RunConfig(
            run_id="function-test",
            output_root=output_root,
            tosutil_timeout_seconds=180,
        ),
        lease=InstanceLease(
            run_id="function-test",
            lease_id="function-test-lease",
            instance_id=instance_id,
            task_id="1746",
            sample_index=1,
            status="busy",
            acquired_at="2026-01-01 00:00:00",
        ),
    )


def build_score_trajectory(output_root: str, task_files: TaskFileResult, final_answer_url: str) -> TrajectoryResult:
    sample_dir = Path(output_root) / "1746" / "sample_1"
    sample_dir.mkdir(parents=True, exist_ok=True)
    (sample_dir / "traj.json").write_text("[]\n", encoding="utf-8")
    (sample_dir / "traj.md").write_text("# function test\n", encoding="utf-8")
    return TrajectoryResult(
        run_id="function-test",
        task_id="1746",
        sample_index=1,
        status="sample_completed",
        sample_dir=str(sample_dir),
        traj_json_path=str(sample_dir / "traj.json"),
        traj_md_path=str(sample_dir / "traj.md"),
        id_json_path=str(sample_dir / "sample_metadata.json"),
        sample_status_path=str(sample_dir / "sample_status.json"),
        last_step=0,
        error="",
        task_files=task_files,
        task_fields={
            "answer_type": "文件产物",
            "metric_type": "规则判分",
            "final answer 文件": final_answer_url,
        },
    )


def instance_has_public_ip(env: VolcengineEnv, instance_id: str) -> bool:
    for instance in env.describe_instances(name_prefix="", project_name="", limit=100):
        if (instance.get("InstanceId") or instance.get("instance_id")) == instance_id:
            return bool(instance.get("EipAddress") or instance.get("eip_address"))
    return False


def release_eip_with_retry(allocation_id: str, region: str) -> None:
    import volcenginesdkvpc

    api = create_vpc_api(region)
    last_error: Exception | None = None
    for attempt in range(1, 7):
        try:
            response = api.release_eip_address(
                volcenginesdkvpc.ReleaseEipAddressRequest(allocation_id=allocation_id)
            )
            print("release_eip:", to_plain_dict(response))
            return
        except Exception as exc:
            last_error = exc
            print("release_eip retry %s failed: %s" % (attempt, exc))
            if attempt < 6:
                time.sleep(10)
    raise RuntimeError("释放 EIP 失败 allocation_id=%s: %s" % (allocation_id, last_error))


if __name__ == "__main__":
    unittest.main()
