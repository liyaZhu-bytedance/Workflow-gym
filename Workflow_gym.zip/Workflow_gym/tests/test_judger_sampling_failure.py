from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.judgers.agent import JudgerAgent
from open_workflowgym.judgers.common import (
    ERROR_SCORE,
    build_sampling_exception_evidence,
    is_sampling_failure,
)
from open_workflowgym.records import TrajectoryResult


class JudgerSamplingFailureTest(unittest.TestCase):
    def test_is_sampling_failure_detects_status_and_error(self):
        self.assertTrue(
            is_sampling_failure(
                TrajectoryResult(
                    run_id="run-1",
                    task_id="252",
                    sample_index=1,
                    status="sample_failed",
                    sample_dir="/tmp/sample",
                    traj_json_path="/tmp/sample/traj.json",
                    traj_md_path="/tmp/sample/traj.md",
                    id_json_path="/tmp/sample/sample_metadata.json",
                    sample_status_path="/tmp/sample/sample_status.json",
                )
            )
        )
        self.assertTrue(
            is_sampling_failure(
                TrajectoryResult(
                    run_id="run-1",
                    task_id="252",
                    sample_index=1,
                    status="sample_completed",
                    sample_dir="/tmp/sample",
                    traj_json_path="/tmp/sample/traj.json",
                    traj_md_path="/tmp/sample/traj.md",
                    id_json_path="/tmp/sample/sample_metadata.json",
                    sample_status_path="/tmp/sample/sample_status.json",
                    error="RunCommand 执行失败",
                )
            )
        )
        self.assertFalse(
            is_sampling_failure(
                TrajectoryResult(
                    run_id="run-1",
                    task_id="252",
                    sample_index=1,
                    status="sample_completed",
                    sample_dir="/tmp/sample",
                    traj_json_path="/tmp/sample/traj.json",
                    traj_md_path="/tmp/sample/traj.md",
                    id_json_path="/tmp/sample/sample_metadata.json",
                    sample_status_path="/tmp/sample/sample_status.json",
                )
            )
        )

    def test_build_sampling_exception_evidence_includes_exception_json(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            exception_path = Path(tmp_dir) / "exception.json"
            exception_path.write_text(
                json.dumps(
                    [
                        {
                            "stage": "sampling",
                            "exception_type": "ValueError",
                            "step_index": -1,
                            "message": "RunCommand 执行失败: TaskExecutionTimeout",
                        }
                    ]
                ),
                encoding="utf-8",
            )
            trajectory = TrajectoryResult(
                run_id="run-1",
                task_id="252",
                sample_index=1,
                status="sample_failed",
                sample_dir=tmp_dir,
                traj_json_path=str(Path(tmp_dir) / "traj.json"),
                traj_md_path=str(Path(tmp_dir) / "traj.md"),
                id_json_path=str(Path(tmp_dir) / "sample_metadata.json"),
                sample_status_path=str(Path(tmp_dir) / "sample_status.json"),
                last_step=-1,
                error="RunCommand 执行失败: TaskExecutionTimeout",
            )
            evidence = build_sampling_exception_evidence(trajectory)

        self.assertIn("采样异常", evidence)
        self.assertIn("status=sample_failed", evidence)
        self.assertIn("TaskExecutionTimeout", evidence)
        self.assertIn("exception[0] stage=sampling type=ValueError", evidence)
        self.assertIn("answer_score=%s" % ERROR_SCORE, evidence)

    def test_judge_returns_exception_score_for_failed_sample(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            trajectory = TrajectoryResult(
                run_id="run-1",
                task_id="252",
                sample_index=1,
                status="sample_failed",
                sample_dir=tmp_dir,
                traj_json_path=str(Path(tmp_dir) / "traj.json"),
                traj_md_path=str(Path(tmp_dir) / "traj.md"),
                id_json_path=str(Path(tmp_dir) / "sample_metadata.json"),
                sample_status_path=str(Path(tmp_dir) / "sample_status.json"),
                last_step=-1,
                error="RunCommand 执行失败: TaskExecutionTimeout",
                task_fields={"answer_type": "文件产物", "metric_type": "规则判分"},
            )
            result = JudgerAgent().judge(trajectory)

        self.assertEqual(result["answer_score"], ERROR_SCORE)
        self.assertIn("TaskExecutionTimeout", result["evidence"])
        self.assertEqual(result["discard_reason"], "sample_failed")


if __name__ == "__main__":
    unittest.main()
