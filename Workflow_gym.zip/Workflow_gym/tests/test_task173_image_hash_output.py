from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.judgers.common import product_text_from_outputs, read_remote_file_with_content_reader
from open_workflowgym.judgers.file_product import FileProductJudgerMixin
from open_workflowgym.records import TaskFileResult, TrajectoryResult


TASK173_OUTPUT_PATH = "/home/user/Desktop/output/http_with_jpegs,/home/user/Desktop/output"
TASK173_FINAL_ANSWER = "image_hash.txt"
TASK173_IMAGE_HASH_SOURCE = "/home/user/Desktop/output/image_hash.txt"
TASK173_IMAGE_HASH_CONTENT = "e4d909c290d0fb1ca068ffaddf22cbd0  bg2.jpg\n"


def write_image_hash_file(target_dir: Path) -> Path:
    target_dir.mkdir(parents=True, exist_ok=True)
    file_path = target_dir / TASK173_FINAL_ANSWER
    file_path.write_text(TASK173_IMAGE_HASH_CONTENT, encoding="utf-8")
    return file_path


def build_task173_trajectory(sample_dir: str, *, tos_url: str, status: str = "uploaded") -> TrajectoryResult:
    return TrajectoryResult(
        run_id="run-test",
        task_id="173",
        sample_index=1,
        status="sample_completed",
        sample_dir=sample_dir,
        traj_json_path=str(Path(sample_dir) / "traj.json"),
        traj_md_path=str(Path(sample_dir) / "traj.md"),
        id_json_path=str(Path(sample_dir) / "sample_metadata.json"),
        sample_status_path=str(Path(sample_dir) / "sample_status.json"),
        task_files=TaskFileResult(
            final_answer_files=[TASK173_FINAL_ANSWER],
            output_uploads=[
                {
                    "relative_path": TASK173_FINAL_ANSWER,
                    "source_path": TASK173_IMAGE_HASH_SOURCE,
                    "candidate_source_paths": [
                        "/home/user/Desktop/output/http_with_jpegs/image_hash.txt",
                        TASK173_IMAGE_HASH_SOURCE,
                    ],
                    "tos_url": tos_url,
                    "tos_path": "tos://open-workflowgym-sample/output-test/173/sample_1/production/image_hash.txt",
                    "status": status,
                    "output_file_exists": True,
                }
            ],
        ),
        task_fields={
            "answer_type": "文件产物",
            "metric_type": "规则判分+LLM-as-judge",
            "response_reference": "image_hash.txt 应包含 bg2.jpg 的 MD5 哈希值",
        },
    )


class Task173ImageHashOutputTest(unittest.TestCase):
    def test_write_image_hash_file_uses_expected_filename_and_content(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = write_image_hash_file(Path(temp_dir))

            self.assertEqual(file_path.name, TASK173_FINAL_ANSWER)
            self.assertEqual(file_path.read_text(encoding="utf-8"), TASK173_IMAGE_HASH_CONTENT)

    def test_read_remote_file_with_content_reader_reads_image_hash_txt(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = write_image_hash_file(Path(temp_dir))

            def fake_download(url: str, target_path: str) -> None:
                Path(target_path).write_bytes(file_path.read_bytes())

            with patch("open_workflowgym.judgers.common.download_remote_file", side_effect=fake_download):
                content = read_remote_file_with_content_reader(
                    "https://example.com/image_hash.txt",
                    TASK173_FINAL_ANSWER,
                )

            self.assertNotIn("读取失败", content)
            self.assertIn("bg2.jpg", content)

    def test_product_text_from_outputs_reads_image_hash_content(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = write_image_hash_file(Path(temp_dir))
            trajectory = build_task173_trajectory(
                temp_dir,
                tos_url="https://example.com/image_hash.txt",
            )

            def fake_download(url: str, target_path: str) -> None:
                Path(target_path).write_bytes(file_path.read_bytes())

            with patch("open_workflowgym.judgers.common.download_remote_file", side_effect=fake_download):
                product_text = product_text_from_outputs(trajectory)

            self.assertIn("## 文件：image_hash.txt", product_text)
            self.assertIn("bg2.jpg", product_text)
            self.assertNotIn("读取失败", product_text)

    def test_judge_file_content_does_not_report_read_failure_for_image_hash_txt(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = write_image_hash_file(Path(temp_dir))
            trajectory = build_task173_trajectory(
                temp_dir,
                tos_url="https://example.com/image_hash.txt",
            )
            judger = FileProductJudgerMixin()

            def fake_download(url: str, target_path: str) -> None:
                Path(target_path).write_bytes(file_path.read_bytes())

            with patch("open_workflowgym.judgers.file_product.download_remote_file", side_effect=fake_download):
                with patch.object(
                    FileProductJudgerMixin,
                    "judge_file_contents",
                    return_value={"answer_score": 1, "error": "NA", "evidence": "ok", "raw_response": "ok"},
                ) as judge_file_contents:
                    result = judger.judge_file_content(trajectory, "文件产物", "规则判分+LLM-as-judge")

            self.assertEqual(result["answer_score"], 1)
            file_contents = judge_file_contents.call_args.kwargs["file_contents"]
            self.assertEqual(file_contents[0][0], TASK173_FINAL_ANSWER)
            self.assertIn("bg2.jpg", file_contents[0][1])
            self.assertNotIn("读取失败", file_contents[0][1])
            production_path = Path(temp_dir) / "production" / TASK173_FINAL_ANSWER
            self.assertTrue(production_path.is_file())
            self.assertIn("bg2.jpg", production_path.read_text(encoding="utf-8"))
            self.assertTrue(result["production_snapshots"][0]["production_saved"])

    def test_judge_file_content_archives_gt_production_when_final_answer_url_present(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            student_file = write_image_hash_file(Path(temp_dir) / "student")
            gt_file = write_image_hash_file(Path(temp_dir) / "gt")
            trajectory = build_task173_trajectory(
                temp_dir,
                tos_url="https://example.com/student/image_hash.txt",
            )
            trajectory.task_fields["final answer 文件"] = "https://example.com/gt/image_hash.txt"

            def fake_download(url: str, target_path: str) -> None:
                if "gt" in url:
                    Path(target_path).write_bytes(gt_file.read_bytes())
                else:
                    Path(target_path).write_bytes(student_file.read_bytes())

            judger = FileProductJudgerMixin()
            with patch("open_workflowgym.judgers.file_product.download_remote_file", side_effect=fake_download):
                with patch.object(
                    FileProductJudgerMixin,
                    "judge_file_contents",
                    return_value={"answer_score": 1, "error": "NA", "evidence": "ok", "raw_response": "ok"},
                ):
                    result = judger.judge_file_content(trajectory, "文件产物", "规则判分+LLM-as-judge")

            self.assertTrue((Path(temp_dir) / "production" / TASK173_FINAL_ANSWER).is_file())
            self.assertTrue((Path(temp_dir) / "gt_production" / TASK173_FINAL_ANSWER).is_file())
            self.assertTrue(result["production_snapshots"][0]["gt_production_saved"])


if __name__ == "__main__":
    unittest.main()
