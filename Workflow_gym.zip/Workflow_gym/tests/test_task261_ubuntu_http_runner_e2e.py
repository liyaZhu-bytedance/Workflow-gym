from __future__ import annotations

import json
import os
import shlex
import subprocess
import sys
import unittest
import warnings
from pathlib import Path

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.agents.factory import AgentFactory
from open_workflowgym.envs.volcengine_env import VolcengineEnv
from open_workflowgym.records import InstanceLease, RunConfig, SampleJob, TaskRecord
from open_workflowgym.sampler import Sampler

from tests.e2e_reporting import maybe_write_e2e_sample_to_spreadsheet

DEFAULT_INSTANCE_ID = "i-yeqf508xkwnu262ipptn"
TASK_ID = "261"
TASK_IMAGE_ID = "image-yepzmyfy3jlcg9ybmhp6"
TASK_OUTPUT_PATH = "/home/user/Desktop/output"
TASK_FINAL_ANSWER = "budget_report.html"
TASK_STARTUP = "桌面"
STEP_NUM = 10
DEFAULT_E2E_RUN_DIR = "manual_task261_ubuntu_http_runner_e2e_10step"
FIXTURE_PATH = Path(__file__).resolve().parent / "fixtures" / "task261_fields.json"

ZSHRC_ENV_NAMES = (
    "AK",
    "SK",
    "MOONSHOT_API_KEY",
    "KIMI_API_KEY",
    "KIMI_NATIVE_API_KEY",
    "VOLCENGINE_REGION",
    "SOURCE_REGION",
    "WORKFLOWGYM_TEST_INSTANCE_ID",
    "APP_ID",
    "APP_SECRET",
)


def project_output_dir() -> Path:
    return Path(__file__).resolve().parents[1] / "output"


def default_e2e_output_root() -> str:
    return str(project_output_dir() / DEFAULT_E2E_RUN_DIR)


def read_env(name: str, default: str = "") -> str:
    return os.getenv(name, default)


def load_zshrc_env(names: tuple[str, ...] = ZSHRC_ENV_NAMES, zshrc_path: str = "") -> None:
    missing = [name for name in names if not read_env(name)]
    if not missing:
        return
    zshrc = Path(zshrc_path or os.path.expanduser("~/.zshrc"))
    if not zshrc.is_file():
        return
    zshrc_quoted = shlex.quote(str(zshrc))
    for name in missing:
        try:
            completed = subprocess.run(
                ["zsh", "-lc", "source %s >/dev/null 2>&1; print -r -- ${%s:-}" % (zshrc_quoted, name)],
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        value = (completed.stdout or "").strip()
        if value:
            os.environ[name] = value


def load_task261_fixture_fields() -> dict:
    if FIXTURE_PATH.is_file():
        return json.loads(FIXTURE_PATH.read_text(encoding="utf-8"))
    return {}


def load_task261_instruction() -> str:
    fields = load_task261_fixture_fields()
    instruction = str(fields.get("题目") or fields.get("up") or "").strip()
    if instruction:
        return instruction
    return (
        "#软件启动方式: %s\n\n"
        "在 KMyMoney 中完成预算设定与超支交易录入，并导出 budget_report.html 到 /home/user/Desktop/output/。"
        % TASK_STARTUP
    )


def build_task261_fields() -> dict[str, object]:
    fixture = load_task261_fixture_fields()
    instruction = load_task261_instruction()
    return {
        "id": TASK_ID,
        "题目": instruction,
        "up": instruction,
        "镜像ID": TASK_IMAGE_ID,
        "image": TASK_IMAGE_ID,
        "系统类型": fixture.get("系统类型") or "Ubuntu",
        "platform": "ubuntu",
        "启动方式": fixture.get("启动方式") or TASK_STARTUP,
        "tos_url": fixture.get("tos_url") or "[]",
        "输入文件路径": fixture.get("输入文件路径") or "",
        "输出文件路径": fixture.get("输出文件路径") or TASK_OUTPUT_PATH,
        "final_answer文件名": fixture.get("final_answer文件名") or TASK_FINAL_ANSWER,
        "final answer 文件": fixture.get("final answer 文件") or "",
        "answer_type": fixture.get("answer_type") or "文件产物",
        "metric_type": fixture.get("metric_type") or "规则判分",
        "判分类型": fixture.get("metric_type") or "规则判分",
    }


def build_task261_ubuntu_http_runner_sample_job(*, instance_id: str, output_root: str) -> SampleJob:
    return SampleJob(
        run_id="task261-ubuntu-http-runner-e2e",
        task_id=TASK_ID,
        sample_index=1,
        task=TaskRecord(
            run_id="task261-ubuntu-http-runner-e2e",
            task_id=TASK_ID,
            row_number=1,
            fields=build_task261_fields(),
        ),
        config=RunConfig(
            run_id="task261-ubuntu-http-runner-e2e",
            output_root=output_root,
            sample_num=1,
            step_num=STEP_NUM,
            player="kimi",
            judger="gemini3.1",
            enable_real_cloud=True,
            tosutil_timeout_seconds=180,
            write_step_traj=True,
            action_timeout_seconds=120,
        ),
        lease=InstanceLease(
            run_id="task261-ubuntu-http-runner-e2e",
            lease_id="task261-ubuntu-http-runner-e2e-lease",
            instance_id=instance_id,
            task_id=TASK_ID,
            sample_index=1,
            status="busy",
            acquired_at="2026-07-13 00:00:00",
        ),
    )


def ensure_instance_running(env: VolcengineEnv, instance_id: str) -> None:
    instance = env.describe_instance(instance_id)
    status = str(instance.get("Status") or instance.get("status") or "").upper()
    if status == "STOPPING":
        env.wait_for_status(instance_id, "STOPPED", timeout_seconds=600)
        status = "STOPPED"
    if status == "STOPPED":
        env.start_instance(instance_id)
    if status not in ("RUNNING",):
        env.wait_for_status(instance_id, "RUNNING", timeout_seconds=600)


load_zshrc_env()


@unittest.skipUnless(
    os.getenv("WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS") == "1",
    "set WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS=1 to run real Volcengine E2E",
)
class Task261UbuntuHttpRunnerE2ETest(unittest.TestCase):
    """任务 261：Ubuntu HTTP Flask runner 端到端采样 10 步并产出 10 张截图。"""

    def setUp(self):
        os.environ.setdefault("UBUNTU_ACTION_RUNNER", "flask")
        self.instance_id = read_env("WORKFLOWGYM_TEST_INSTANCE_ID", DEFAULT_INSTANCE_ID)
        self.region = read_env("VOLCENGINE_REGION", read_env("SOURCE_REGION", "cn-guangzhou"))
        self.output_root = read_env(
            "WORKFLOWGYM_TASK261_UBUNTU_HTTP_RUNNER_E2E_OUTPUT_ROOT",
            default_e2e_output_root(),
        )
        self.env = VolcengineEnv(region=self.region)

    def tearDown(self):
        return

    def test_task261_ubuntu_http_runner_sample_ten_steps_with_screenshots(self):
        self.assertTrue(read_env("AK") and read_env("SK"), "set AK/SK for Volcengine")
        moonshot_key = read_env("MOONSHOT_API_KEY") or read_env("KIMI_API_KEY") or read_env("KIMI_NATIVE_API_KEY")
        self.assertTrue(moonshot_key, "set MOONSHOT_API_KEY or KIMI_API_KEY for kimi sampling")

        print("WORKFLOWGYM_TEST_INSTANCE", self.instance_id, flush=True)
        print("WORKFLOWGYM_TASK261_IMAGE", TASK_IMAGE_ID, flush=True)
        print("WORKFLOWGYM_TASK261_UBUNTU_HTTP_RUNNER_OUTPUT_ROOT", self.output_root, flush=True)

        ensure_instance_running(self.env, self.instance_id)

        job = build_task261_ubuntu_http_runner_sample_job(
            instance_id=self.instance_id,
            output_root=self.output_root,
        )
        sampler = Sampler(AgentFactory(), self.env)
        trajectory = sampler.run_sample(job)

        print("WORKFLOWGYM_TASK261_UBUNTU_HTTP_RUNNER_SAMPLE_STATUS", trajectory.status, flush=True)
        print("WORKFLOWGYM_TASK261_UBUNTU_HTTP_RUNNER_LAST_STEP", trajectory.last_step, flush=True)

        self.assertNotEqual(trajectory.status, "sample_failed", trajectory.error)
        self.assertEqual(trajectory.last_step, STEP_NUM - 1)

        sample_dir = Path(trajectory.sample_dir)
        self.assertTrue(Path(trajectory.traj_json_path).is_file())

        missing_screenshots = [
            "step_%d.jpg" % step_index
            for step_index in range(STEP_NUM)
            if not (sample_dir / ("step_%d.jpg" % step_index)).is_file()
        ]
        self.assertEqual(missing_screenshots, [], "缺少截图: %s" % missing_screenshots)

        metadata_path = sample_dir / "sample_metadata.json"
        self.assertTrue(metadata_path.is_file(), "应写入 sample_metadata.json")
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        env_meta = metadata.get("env") if isinstance(metadata.get("env"), dict) else metadata
        self.assertEqual(env_meta.get("ubuntu_action_runner"), "flask")
        self.assertEqual(env_meta.get("ubuntu_flask_runner_probe"), "ok")

        traj_payload = json.loads(Path(trajectory.traj_json_path).read_text(encoding="utf-8"))
        executed = [
            str(code)
            for step in traj_payload
            for code in (step.get("executed_code") or [])
        ]
        self.assertTrue(
            any("/action" in code for code in executed),
            "traj.json executed_code 应包含 Flask /action 调用",
        )

        report = maybe_write_e2e_sample_to_spreadsheet(
            output_root=self.output_root,
            trajectory=trajectory,
            score=None,
        )
        if report is not None:
            print("WORKFLOWGYM_TASK261_UBUNTU_HTTP_RUNNER_SPREADSHEET", report, flush=True)


if __name__ == "__main__":
    unittest.main()
