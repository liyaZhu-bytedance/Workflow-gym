from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.tools.sync_ve8a1q_from_zZQpb4 import (
    build_prefix_lookup,
    find_updates,
    resolve_prefix_match,
    should_exclude_source_image_name,
)

class SyncVe8a1qFromZZQpb4Test(unittest.TestCase):
    def test_should_exclude_source_image_name(self):
        self.assertTrue(should_exclude_source_image_name("demo.qcow2_bj"))
        self.assertTrue(should_exclude_source_image_name("demo_bj_gui"))
        self.assertFalse(should_exclude_source_image_name("demo_bj"))
        self.assertFalse(
            should_exclude_source_image_name(
                "preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-ye515ftkhsqc6iktcidr_bj"
            )
        )

    def test_build_prefix_lookup_excludes_suffix_rows(self):
        source_rows = [
            ["序号", "镜像名称", "镜像id", "系统"],
            [
                "1",
                "preview-Ubuntu2204_64-weka-v3.8.6-move-20260112.qcow2_bj",
                "image-skip-qcow2",
                "Ubuntu",
            ],
            [
                "2",
                "preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-ye515ftkhsqc6iktcidr_bj_gui",
                "image-skip-gui",
                "Ubuntu",
            ],
            [
                "3",
                "preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-ye515ftkhsqc6iktcidr_bj",
                "image-bj",
                "Ubuntu",
            ],
        ]
        lookup = build_prefix_lookup(source_rows)
        self.assertEqual(
            lookup["preview-Ubuntu2204_64-weka"],
            [
                (
                    "preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-ye515ftkhsqc6iktcidr_bj",
                    "image-bj",
                )
            ],
        )

    def test_resolve_prefix_match_prefers_exact_name(self):
        target = "preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-ye515ftkhsqc6iktcidr"
        candidates = [
            (target + "_bj", "image-bj"),
            (target, "image-exact"),
        ]
        self.assertEqual(resolve_prefix_match(target, candidates), (target, "image-exact"))

    def test_resolve_prefix_match_windows_prefers_cloud_over_bj(self):
        target = "preview-windows2022-ECS-amQ8-initv1-20251103"
        candidates = [
            ("preview-windows2022-ECS-amQ8-initv1-20251103_bj", "image-bj"),
            ("preview-windows2022-ECS-amQ8-initv1-20251103_cloud", "image-cloud"),
        ]
        self.assertEqual(
            resolve_prefix_match(target, candidates),
            ("preview-windows2022-ECS-amQ8-initv1-20251103_cloud", "image-cloud"),
        )

    def test_resolve_prefix_match_ubuntu_prefers_bj_when_only_bj_left(self):
        target = "preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-ye515ftkhsqc6iktcidr"
        candidates = [
            (
                "preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-ye515ftkhsqc6iktcidr_bj",
                "image-bj",
            ),
        ]
        self.assertEqual(
            resolve_prefix_match(target, candidates),
            (
                "preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-ye515ftkhsqc6iktcidr_bj",
                "image-bj",
            ),
        )

    def test_find_updates_writes_expected_e_and_g(self):
        source_rows = [
            ["序号", "镜像名称", "镜像id", "系统"],
            [
                "1",
                "preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-ye515ftkhsqc6iktcidr_bj",
                "image-bj",
                "Ubuntu",
            ],
        ]
        target_rows = [
            [
                "分组",
                "软件",
                "内场ID",
                "内场镜像名",
                "镜像id",
                "用户名",
                "导出镜像名",
            ],
            [
                "x",
                "weka",
                "image-inner",
                "preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-ye515ftkhsqc6iktcidr",
                "image-old",
                "user",
                "preview-old-gui",
            ],
        ]
        lookup = build_prefix_lookup(source_rows)
        updates = find_updates(target_rows, lookup)
        self.assertEqual(len(updates), 1)
        self.assertEqual(updates[0]["expected_image_id"], "image-bj")
        self.assertEqual(
            updates[0]["expected_export_name"],
            "preview-Ubuntu2204_64-weka-v3.8.6-move-20260112_i-ye515ftkhsqc6iktcidr_bj",
        )


if __name__ == "__main__":
    unittest.main()
