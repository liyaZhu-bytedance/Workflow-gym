from __future__ import annotations

import base64
import json
import os
import re
import sys
import unittest
import unittest.mock
import zlib
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.agents.pyautogui_actions import (
    action_code_needs_clipboard_helpers,
    action_code_needs_subprocess,
    action_script_is_clipboard_paste,
    action_to_pyautogui_command,
    build_inline_clipboard_paste_code,
    build_install_linux_action_helpers_command,
    build_linux_action_helpers_module_source,
    build_pyautogui_python_script,
    compile_pyautogui_action_code_to_xdotool,
    describe_pyautogui_action_script,
    linux_portal_focus_enabled,
    normalize_type_text,
    pyautogui_code_for_action,
    scale_normalized_point,
    should_include_linux_portal_focus_in_script,
    should_retry_interactive_runner_error,
    type_text_code,
    wrap_pyautogui_python,
)
from open_workflowgym.envs.volcengine_env import (
    RUN_COMMAND_MAX_CONTENT_BYTES,
    build_configure_english_desktop_command,
    build_ubuntu_flask_post_python_action_command,
    parse_validated_display_resolution,
    validate_run_command_payload,
)


class PyAutoGuiActionsTest(unittest.TestCase):
    def test_type_text_decodes_escaped_newline(self):
        self.assertEqual(normalize_type_text("/home/user/blender\\n"), "/home/user/blender\n")
        code = type_text_code("/home/user/blender\\n")
        self.assertIn('pyautogui.write("/home/user/blender", interval=0.01)', code)
        self.assertIn("pyautogui.press('enter')", code)
        self.assertNotIn("paste_text(", code)

    def test_type_text_non_ascii_uses_inline_clipboard_paste(self):
        code = type_text_code("张三")
        self.assertIn("_workflowgym_set_clipboard", code)
        self.assertIn("xsel", code)
        self.assertIn("xclip", code)
        self.assertIn("pyperclip.copy", code)
        self.assertLess(code.index("xsel"), code.index("xclip"))
        self.assertLess(code.index("xclip"), code.index("pyperclip.copy"))
        self.assertIn('_clipboard_methods = ["xsel", "xclip", "pyperclip"]', code)
        self.assertIn("WORKFLOWGYM_CLIPBOARD_SET method=", code)
        self.assertIn("WORKFLOWGYM_CLIPBOARD_TRY methods=", code)
        self.assertIn("WORKFLOWGYM_CLIPBOARD_PASTE keys=ctrl+v", code)
        self.assertIn('pyautogui.hotkey("ctrl", "v")', code)
        self.assertNotIn("paste_text(", code)
        script = build_pyautogui_python_script(code, platform="ubuntu", display_size=(1920, 1080))
        self.assertNotIn("def paste_text", script)
        self.assertIn("import subprocess", script)

    def test_scale_normalized_point_uses_validated_resolution(self):
        self.assertEqual(scale_normalized_point("<point>500 500</point>", (1920, 1080)), (960, 540))

    def test_linux_action_code_precomputes_pixel_coordinates(self):
        code = pyautogui_code_for_action(
            "click",
            {"point": "<point>500 300</point>"},
            display_size=(1920, 1080),
            screenshot_size=(1920, 1080),
        )
        self.assertIn("pyautogui.click(960, 324)", code)
        self.assertNotIn("scale_point", code)
        self.assertFalse(action_code_needs_clipboard_helpers(code))

    def test_linux_click_script_omits_english_and_clipboard_helpers(self):
        bundle = describe_pyautogui_action_script(
            'print("WORKFLOWGYM_ACTION_COORD {}")\npyautogui.click(960, 324)',
            platform="ubuntu",
            display_size=(1920, 1080),
        )
        script = bundle["remote_script"]
        self.assertEqual(bundle["backend"], "pyautogui")
        self.assertEqual(bundle["xdotool_code"], "")
        self.assertIn("pyautogui.click(960, 324)", bundle["pyautogui_code"])
        self.assertIn("import pyautogui", script)
        self.assertIn("def prepare_linux_desktop_for_action", script)
        self.assertIn("pyautogui.click(960, 324)\nprepare_linux_desktop_for_action()", script)
        self.assertNotIn("prepare_linux_desktop_for_action()\npyautogui.click", script)
        self.assertIn("xdg-desktop-portal-gtk", script)
        self.assertIn('_linux_search_window_ids("--class", "xdg-desktop-portal-gtk")', script)
        self.assertNotIn('--name", "Open"', script)
        self.assertNotIn("Org.gnome.Nautilus", script)
        self.assertNotIn("_load_linux_action_helpers()", script)
        self.assertNotIn("def ensure_english_input", script)
        self.assertNotIn("def paste_text", script)
        self.assertNotIn("def scale_point", script)
        self.assertNotIn("ensure_english_input()", script)

    def test_linux_click_script_omits_portal_focus_when_disabled(self):
        with unittest.mock.patch.dict(
            os.environ,
            {"UBUNTU_PYAUTOGUI_PORTAL_FOCUS": "0", "UBUNTU_PYAUTOGUI_XDOTOOL_BACKEND": "0"},
            clear=False,
        ):
            bundle = describe_pyautogui_action_script(
                'pyautogui.click(960, 324)',
                platform="ubuntu",
                display_size=(1920, 1080),
            )
        script = bundle["remote_script"]
        self.assertNotIn("def prepare_linux_desktop_for_action", script)
        self.assertNotIn("prepare_linux_desktop_for_action()", script)

    def test_linux_portal_focus_defaults_on_for_pure_pyautogui(self):
        with unittest.mock.patch.dict(
            os.environ,
            {"UBUNTU_PYAUTOGUI_PORTAL_FOCUS": "1", "UBUNTU_PYAUTOGUI_XDOTOOL_BACKEND": "0"},
            clear=False,
        ):
            self.assertTrue(linux_portal_focus_enabled())
            self.assertTrue(should_include_linux_portal_focus_in_script("ubuntu"))

    def test_redis_mode_uses_pyautogui_only_no_xdotool(self):
        context = SimpleNamespace(metadata={"lease_backend": "redis"})
        with unittest.mock.patch.dict(
            os.environ,
            {"UBUNTU_PYAUTOGUI_PORTAL_FOCUS": "1", "UBUNTU_PYAUTOGUI_XDOTOOL_BACKEND": "1"},
            clear=False,
        ):
            bundle = describe_pyautogui_action_script(
                "pyautogui.click(960, 324)",
                platform="ubuntu",
                display_size=(1920, 1080),
                context=context,
            )
        script = bundle["remote_script"]
        self.assertEqual(bundle["backend"], "pyautogui")
        self.assertEqual(bundle["xdotool_code"], "")
        self.assertIn("import pyautogui", script)
        self.assertIn("pyautogui.click(960, 324)", script)
        self.assertNotIn("xdotool", script)
        self.assertNotIn("prepare_linux_desktop_for_action", script)
        self.assertNotIn("xdg-desktop-portal-gtk", script)

    def test_linux_portal_focus_disabled_for_xdotool_backend(self):
        with unittest.mock.patch.dict(
            os.environ,
            {"UBUNTU_PYAUTOGUI_PORTAL_FOCUS": "1", "UBUNTU_PYAUTOGUI_XDOTOOL_BACKEND": "1"},
            clear=False,
        ):
            self.assertFalse(should_include_linux_portal_focus_in_script("ubuntu"))

    def test_linux_paste_script_inlines_clipboard_without_helper_block(self):
        code = build_inline_clipboard_paste_code("演练数据") + '\npyautogui.press("enter")'
        bundle = describe_pyautogui_action_script(
            code,
            platform="ubuntu",
            display_size=(1920, 1080),
        )
        script = bundle["remote_script"]
        self.assertEqual(bundle["backend"], "pyautogui")
        self.assertEqual(bundle["xdotool_code"], "")
        self.assertIn("_workflowgym_set_clipboard", script)
        self.assertIn("xsel", script)
        self.assertIn("xclip", script)
        self.assertLess(script.index("xsel"), script.index("xclip"))
        self.assertIn('pyautogui.hotkey("ctrl", "v")', script)
        self.assertTrue(action_script_is_clipboard_paste(script))
        self.assertNotIn("def paste_text", script)
        self.assertNotIn("def set_clipboard_text", script)
        self.assertFalse(action_code_needs_clipboard_helpers(code))
        self.assertTrue(action_code_needs_subprocess(code))

    def test_clipboard_paste_timeout_skips_interactive_retry(self):
        paste = build_inline_clipboard_paste_code("李明")
        self.assertTrue(action_script_is_clipboard_paste(paste))
        timeout_exc = ValueError("WGM run-action failed: HTTP Error 504: Gateway Timeout")
        self.assertFalse(
            should_retry_interactive_runner_error(timeout_exc, action_script=paste)
        )
        # Non-paste scripts may still retry on timeout/unreachable.
        click = "pyautogui.click(100, 200)"
        self.assertTrue(
            should_retry_interactive_runner_error(
                ValueError("flask /action unreachable timed out"),
                action_script=click,
            )
        )
    def test_linux_click_script_is_smaller_than_before(self):
        bundle = describe_pyautogui_action_script(
            'print("WORKFLOWGYM_ACTION_COORD {}")\npyautogui.click(960, 324)',
            platform="ubuntu",
            display_size=(1920, 1080),
        )
        script = bundle["remote_script"]
        self.assertLess(len(script.encode("utf-8")), 8000)

    def test_linux_click_script_compiles_to_xdotool_when_enabled(self):
        with unittest.mock.patch.dict(os.environ, {"UBUNTU_PYAUTOGUI_XDOTOOL_BACKEND": "1"}, clear=False):
            bundle = describe_pyautogui_action_script(
                'print("WORKFLOWGYM_ACTION_COORD {}")\npyautogui.click(960, 324)',
                platform="ubuntu",
                display_size=(1920, 1080),
            )
        script = bundle["remote_script"]
        self.assertEqual(bundle["backend"], "xdotool")
        self.assertIn("pyautogui.click(960, 324)", bundle["pyautogui_code"])
        self.assertIn('subprocess.run(["xdotool"', bundle["xdotool_code"])
        self.assertNotIn("import pyautogui", script)

    def test_compile_pyautogui_click_to_xdotool(self):
        source = 'pyautogui.click(960, 324)'
        compiled, metadata = compile_pyautogui_action_code_to_xdotool(source)
        self.assertEqual(metadata["backend"], "xdotool")
        self.assertIn('subprocess.run(["xdotool"', compiled)
        self.assertIn('subprocess.run(["xdotool", "click", "1"]', compiled)

    def test_compile_pyautogui_hotkey_to_xdotool(self):
        source = 'pyautogui.hotkey("ctrl", "v")'
        compiled, metadata = compile_pyautogui_action_code_to_xdotool(source)
        self.assertIn('subprocess.run(["xdotool", "key", "ctrl+v"]', compiled)
        self.assertNotIn("[xdotool,", compiled)
        self.assertEqual(len(metadata["conversions"]), 1)

    def test_action_to_pyautogui_command_uses_env_metadata_resolution(self):
        context = SimpleNamespace(
            metadata={
                "env_metadata": {
                    "display_width": 1920,
                    "display_height": 1080,
                }
            },
            current_screenshot="",
            task=SimpleNamespace(fields={}),
        )
        commands = action_to_pyautogui_command(
            {"name": "click", "parameters": {"point": "<point>500 500</point>"}},
            context,
        )
        payload = json.loads(re.search(r"-d '(\{.*\})'", commands[0], re.DOTALL).group(1))
        script = base64.b64decode(payload["script_b64"]).decode("utf-8")
        self.assertIn("pyautogui.click(960, 540)", script)
        self.assertNotIn("def paste_text", script)

    def test_linux_action_helpers_module_contains_xdotool_adapter(self):
        module_source = build_linux_action_helpers_module_source()
        self.assertIn("install_linux_xdotool_adapter()", module_source)

    def test_linux_install_helpers_command_under_run_command_limit(self):
        command = build_install_linux_action_helpers_command("/home/user")
        validate_run_command_payload(command, "Shell")

    def test_linux_flask_action_script_under_run_command_limit(self):
        bundle = describe_pyautogui_action_script(
            'print("WORKFLOWGYM_ACTION_COORD {}")\npyautogui.click(960, 540)',
            platform="ubuntu",
            display_size=(1920, 1080),
        )
        script = bundle["remote_script"]
        command = build_ubuntu_flask_post_python_action_command(
            script,
            port=8080,
            token="workflowgym-flask-token",
            http_timeout=120,
        )
        validate_run_command_payload(command, "Shell")
        self.assertLess(len(command.encode("utf-8")), RUN_COMMAND_MAX_CONTENT_BYTES)

    def test_windows_script_keeps_remote_scale_point_and_english_helpers(self):
        script = build_pyautogui_python_script(
            'x, y = scale_point("<point>500 500</point>")\npyautogui.click(x, y)',
            platform="windows",
        )
        self.assertIn("def scale_point", script)
        self.assertIn("def ensure_english_input", script)
        self.assertIn("ensure_english_input()", script)

    def test_configure_english_desktop_command(self):
        command = build_configure_english_desktop_command("user", "/home/user", ":0", "/home/user/.Xauthority")
        self.assertIn("WORKFLOWGYM_ENGLISH_DESKTOP_CONFIGURED", command)
        self.assertIn("setxkbmap us", command)

    def test_parse_validated_display_resolution(self):
        output = "desktop resolution validated: 1920x1080"
        self.assertEqual(parse_validated_display_resolution(output), (1920, 1080))


def minimal_png(width: int, height: int) -> bytes:
    def chunk(kind: bytes, payload: bytes) -> bytes:
        crc = zlib.crc32(kind + payload) & 0xFFFFFFFF
        return len(payload).to_bytes(4, "big") + kind + payload + crc.to_bytes(4, "big")

    ihdr = width.to_bytes(4, "big") + height.to_bytes(4, "big") + b"\x08\x02\x00\x00\x00"
    raw = b"".join(b"\x00" + b"\x00\x00\x00" * width for _ in range(height))
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")


if __name__ == "__main__":
    unittest.main()
