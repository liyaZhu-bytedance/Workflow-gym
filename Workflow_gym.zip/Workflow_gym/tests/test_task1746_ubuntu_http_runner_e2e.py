from __future__ import annotations

import json
import os
import shlex
import subprocess
import sys
import unittest
import warnings
from pathlib import Path

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.agents.factory import AgentFactory
from open_workflowgym.config import DEFAULT_SOURCE_FEISHU_URL
from open_workflowgym.envs.volcengine_env import VolcengineEnv
from open_workflowgym.feishu_client import FeishuClient
from open_workflowgym.local_spreadsheet import feishu_credentials_configured
from open_workflowgym.records import InstanceLease, RunConfig, SampleJob, TaskRecord
from open_workflowgym.sampler import Sampler
from open_workflowgym.source_reader import SourceReader, normalize_task_id_value

from tests.e2e_reporting import maybe_write_e2e_sample_to_spreadsheet

DEFAULT_INSTANCE_ID = "i-yeqf508xkwnu262ipptn"
TASK_ID = "1746"
TASK_IMAGE_ID = "image-yepzpcv94pkhx198ayjw"
TASK_OUTPUT_PATH = "/home/user/Desktop/output"
TASK_FINAL_ANSWER = "KKX.pdf"
TASK_INPUT_TOS_URL = (
    "https://cdn.example.local/obj/synthetic-gui-data/"
    "base_sheets_input/1746_recv7C2yI5ZfGn/%E6%BC%94%E7%BB%83%E6%95%B0%E6%8D%AE6.xlsx"
)
TASK_INPUT_PATH = "/home/user/Desktop/input"
TASK_STARTUP = "应用菜单搜索jamovi运行"
STEP_NUM_10 = 10
STEP_NUM_20 = 20
STEP_NUM_100 = 100
DEFAULT_E2E_RUN_DIR_10STEP = "manual_task1746_ubuntu_http_runner_e2e_10step"
DEFAULT_E2E_RUN_DIR_20STEP = "manual_task1746_ubuntu_http_runner_e2e_20step"
DEFAULT_E2E_RUN_DIR_100STEP = "manual_task1746_ubuntu_http_runner_e2e_100step"
DEFAULT_SOURCE_SHEET_URL = DEFAULT_SOURCE_FEISHU_URL

ZSHRC_ENV_NAMES = (
    "AK",
    "SK",
    "MOONSHOT_API_KEY",
    "KIMI_API_KEY",
    "KIMI_NATIVE_API_KEY",
    "VOLCENGINE_REGION",
    "SOURCE_REGION",
    "WORKFLOWGYM_TEST_INSTANCE_ID",
    "APP_ID",
    "APP_SECRET",
)


def project_output_dir() -> Path:
    return Path(__file__).resolve().parents[1] / "output"


def default_e2e_output_root(run_dir: str = DEFAULT_E2E_RUN_DIR_10STEP) -> str:
    return str(project_output_dir() / run_dir)


def reference_sample_metadata_paths() -> list[Path]:
    return [
        project_output_dir() / "kimi_native_1746_success/1746/sample_1/sample_metadata.json",
    ]


def read_env(name: str, default: str = "") -> str:
    return os.getenv(name, default)


def load_zshrc_env(names: tuple[str, ...] = ZSHRC_ENV_NAMES, zshrc_path: str = "") -> None:
    missing = [name for name in names if not read_env(name)]
    if not missing:
        return
    zshrc = Path(zshrc_path or os.path.expanduser("~/.zshrc"))
    if not zshrc.is_file():
        return
    zshrc_quoted = shlex.quote(str(zshrc))
    for name in missing:
        try:
            completed = subprocess.run(
                ["zsh", "-lc", "source %s >/dev/null 2>&1; print -r -- ${%s:-}" % (zshrc_quoted, name)],
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        value = (completed.stdout or "").strip()
        if value:
            os.environ[name] = value


def load_task1746_instruction() -> str:
    for metadata_path in reference_sample_metadata_paths():
        if not metadata_path.is_file():
            continue
        payload = json.loads(metadata_path.read_text(encoding="utf-8"))
        up = str(payload.get("up") or "").strip()
        if up:
            return up
    return (
        "#软件启动方式: %s\n\n"
        "在 jamovi 中打开桌面 input/演练数据6.xlsx，完成信度分析并导出 KKX.pdf 到 /home/user/Desktop/output。"
        % TASK_STARTUP
    )


def build_task1746_fields() -> dict[str, str]:
    instruction = load_task1746_instruction()
    return {
        "id": TASK_ID,
        "题目": instruction,
        "up": instruction,
        "镜像ID": TASK_IMAGE_ID,
        "image": TASK_IMAGE_ID,
        "系统类型": "Ubuntu",
        "platform": "ubuntu",
        "启动方式": TASK_STARTUP,
        "tos_url": TASK_INPUT_TOS_URL,
        "输入文件路径": TASK_INPUT_PATH,
        "输出文件路径": TASK_OUTPUT_PATH,
        "final_answer文件名": TASK_FINAL_ANSWER,
        "answer_type": "文件产物",
        "metric_type": "规则判分+LLM-as-judge",
        "判分类型": "规则判分+LLM-as-judge",
    }


def load_task1746_from_feishu(source_url: str = "") -> TaskRecord | None:
    if not feishu_credentials_configured():
        return None
    sheet_url = (source_url or read_env("SOURCE_FEISHU_URL", DEFAULT_SOURCE_SHEET_URL)).strip()
    if not sheet_url:
        return None
    client = FeishuClient(dry_run=False)
    tasks = SourceReader(client, "task1746-ubuntu-http-runner-e2e").read_tasks(
        sheet_url,
        start_row=2,
        limit=int(read_env("WORKFLOWGYM_TARGET_ID_PREFETCH_ROWS", "5000")),
    )
    for task in tasks:
        if normalize_task_id_value(task.task_id) == TASK_ID:
            return task
    return None


def resolve_task1746_record() -> TaskRecord:
    feishu_task = load_task1746_from_feishu()
    if feishu_task is not None:
        print("WORKFLOWGYM_TASK1746_SOURCE feishu row=%s" % feishu_task.row_number, flush=True)
        return feishu_task
    print("WORKFLOWGYM_TASK1746_SOURCE fixture", flush=True)
    return TaskRecord(
        run_id="task1746-ubuntu-http-runner-e2e",
        task_id=TASK_ID,
        row_number=1,
        fields=build_task1746_fields(),
    )


def build_task1746_ubuntu_http_runner_sample_job(
    *,
    instance_id: str,
    output_root: str,
    step_num: int,
    run_id_suffix: str = "",
) -> SampleJob:
    run_id = "task1746-ubuntu-http-runner-e2e%s" % (("-" + run_id_suffix) if run_id_suffix else "")
    task = resolve_task1746_record()
    task = TaskRecord(
        run_id=run_id,
        task_id=task.task_id,
        row_number=task.row_number,
        fields=task.fields,
    )
    return SampleJob(
        run_id=run_id,
        task_id=TASK_ID,
        sample_index=1,
        task=task,
        config=RunConfig(
            run_id=run_id,
            output_root=output_root,
            sample_num=1,
            step_num=step_num,
            player="kimi",
            judger="gemini3.1",
            enable_real_cloud=True,
            tosutil_timeout_seconds=180,
            write_step_traj=True,
            action_timeout_seconds=120,
        ),
        lease=InstanceLease(
            run_id=run_id,
            lease_id="%s-lease" % run_id,
            instance_id=instance_id,
            task_id=TASK_ID,
            sample_index=1,
            status="busy",
            acquired_at="2026-07-12 00:00:00",
        ),
    )


def run_task1746_ubuntu_http_runner_sample(
    *,
    test_case: unittest.TestCase,
    instance_id: str,
    output_root: str,
    step_num: int,
    run_id_suffix: str = "",
) -> None:
    test_case.assertTrue(read_env("AK") and read_env("SK"), "set AK/SK for Volcengine")
    moonshot_key = read_env("MOONSHOT_API_KEY") or read_env("KIMI_API_KEY") or read_env("KIMI_NATIVE_API_KEY")
    test_case.assertTrue(moonshot_key, "set MOONSHOT_API_KEY or KIMI_API_KEY for kimi sampling")

    print("WORKFLOWGYM_TEST_INSTANCE", instance_id, flush=True)
    print("WORKFLOWGYM_TASK1746_IMAGE", TASK_IMAGE_ID, flush=True)
    print("WORKFLOWGYM_TASK1746_UBUNTU_HTTP_RUNNER_OUTPUT_ROOT", output_root, flush=True)
    print("WORKFLOWGYM_TASK1746_SOURCE_SHEET", read_env("SOURCE_FEISHU_URL", DEFAULT_SOURCE_SHEET_URL), flush=True)

    env = VolcengineEnv(region=read_env("VOLCENGINE_REGION", read_env("SOURCE_REGION", "cn-guangzhou")))
    ensure_instance_running(env, instance_id)

    job = build_task1746_ubuntu_http_runner_sample_job(
        instance_id=instance_id,
        output_root=output_root,
        step_num=step_num,
        run_id_suffix=run_id_suffix,
    )
    sampler = Sampler(AgentFactory(), env)
    trajectory = sampler.run_sample(job)

    print("WORKFLOWGYM_TASK1746_UBUNTU_HTTP_RUNNER_SAMPLE_STATUS", trajectory.status, flush=True)
    print("WORKFLOWGYM_TASK1746_UBUNTU_HTTP_RUNNER_LAST_STEP", trajectory.last_step, flush=True)

    test_case.assertNotEqual(trajectory.status, "sample_failed", trajectory.error)
    test_case.assertEqual(trajectory.last_step, step_num - 1)

    sample_dir = Path(trajectory.sample_dir)
    test_case.assertTrue(Path(trajectory.traj_json_path).is_file())

    missing_screenshots = [
        "step_%d.jpg" % step_index
        for step_index in range(step_num)
        if not (sample_dir / ("step_%d.jpg" % step_index)).is_file()
    ]
    test_case.assertEqual(missing_screenshots, [], "缺少截图: %s" % missing_screenshots)

    metadata_path = sample_dir / "sample_metadata.json"
    test_case.assertTrue(metadata_path.is_file(), "应写入 sample_metadata.json")
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    env_meta = metadata.get("env") if isinstance(metadata.get("env"), dict) else metadata
    test_case.assertEqual(env_meta.get("ubuntu_action_runner"), "flask")
    test_case.assertEqual(env_meta.get("ubuntu_flask_runner_probe"), "ok")

    traj_md = sample_dir / "traj.md"
    traj_json = sample_dir / "traj.json"
    flask_evidence = ""
    if traj_json.is_file():
        flask_evidence = traj_json.read_text(encoding="utf-8", errors="replace")
    elif traj_md.is_file():
        flask_evidence = traj_md.read_text(encoding="utf-8", errors="replace")
    if flask_evidence:
        test_case.assertTrue(
            "/action" in flask_evidence or "workflowgym-flask-token" in flask_evidence,
            "轨迹应包含 Flask /action 调用证据",
        )

    report = maybe_write_e2e_sample_to_spreadsheet(
        output_root=output_root,
        trajectory=trajectory,
        score=None,
    )
    if report is not None:
        print("WORKFLOWGYM_TASK1746_UBUNTU_HTTP_RUNNER_SPREADSHEET", report, flush=True)


def ensure_instance_running(env: VolcengineEnv, instance_id: str) -> None:
    instance = env.describe_instance(instance_id)
    status = str(instance.get("Status") or instance.get("status") or "").upper()
    if status == "STOPPING":
        env.wait_for_status(instance_id, "STOPPED", timeout_seconds=600)
        status = "STOPPED"
    if status == "STOPPED":
        env.start_instance(instance_id)
    if status not in ("RUNNING",):
        env.wait_for_status(instance_id, "RUNNING", timeout_seconds=600)


load_zshrc_env()


@unittest.skipUnless(
    os.getenv("WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS") == "1",
    "set WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS=1 to run real Volcengine E2E",
)
class Task1746UbuntuHttpRunnerE2ETest(unittest.TestCase):
    """任务 1746：Ubuntu HTTP Flask runner 端到端采样，支持从飞书题表加载。"""

    def setUp(self):
        os.environ.setdefault("UBUNTU_ACTION_RUNNER", "flask")
        self.instance_id = read_env("WORKFLOWGYM_TEST_INSTANCE_ID", DEFAULT_INSTANCE_ID)

    def tearDown(self):
        return

    def test_task1746_ubuntu_http_runner_sample_ten_steps_with_screenshots(self):
        output_root = read_env(
            "WORKFLOWGYM_TASK1746_UBUNTU_HTTP_RUNNER_E2E_OUTPUT_ROOT",
            default_e2e_output_root(DEFAULT_E2E_RUN_DIR_10STEP),
        )
        run_task1746_ubuntu_http_runner_sample(
            test_case=self,
            instance_id=self.instance_id,
            output_root=output_root,
            step_num=STEP_NUM_10,
        )

    def test_task1746_ubuntu_http_runner_sample_twenty_steps_with_screenshots(self):
        output_root = read_env(
            "WORKFLOWGYM_TASK1746_UBUNTU_HTTP_RUNNER_E2E_20STEP_OUTPUT_ROOT",
            default_e2e_output_root(DEFAULT_E2E_RUN_DIR_20STEP),
        )
        run_task1746_ubuntu_http_runner_sample(
            test_case=self,
            instance_id=self.instance_id,
            output_root=output_root,
            step_num=STEP_NUM_20,
            run_id_suffix="20step",
        )

    def test_task1746_ubuntu_http_runner_sample_hundred_steps_with_screenshots(self):
        output_root = read_env(
            "WORKFLOWGYM_TASK1746_UBUNTU_HTTP_RUNNER_E2E_100STEP_OUTPUT_ROOT",
            default_e2e_output_root(DEFAULT_E2E_RUN_DIR_100STEP),
        )
        run_task1746_ubuntu_http_runner_sample(
            test_case=self,
            instance_id=self.instance_id,
            output_root=output_root,
            step_num=STEP_NUM_100,
            run_id_suffix="100step",
        )


if __name__ == "__main__":
    unittest.main()
