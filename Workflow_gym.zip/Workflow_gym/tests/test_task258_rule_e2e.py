from __future__ import annotations

import json
import os
import shlex
import subprocess
import sys
import unittest
import warnings
from pathlib import Path

warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.agents.factory import AgentFactory
from open_workflowgym.envs.volcengine_env import VolcengineEnv
from open_workflowgym.records import InstanceLease, RunConfig, SampleJob, TaskRecord
from open_workflowgym.sampler import Sampler
from open_workflowgym.scorer import Scorer

from tests.e2e_reporting import maybe_write_e2e_sample_to_spreadsheet

DEFAULT_INSTANCE_ID = "i-yeq4neypkwuo7budzfbg"
TASK_ID = "258"
TASK_IMAGE_ID = "image-yepzmyfy3jlcg9ybmhp6"
TASK_OUTPUT_PATH = "/home/user/Desktop/output"
TASK_FINAL_ANSWER = "expense.csv"
TASK_FINAL_ANSWER_URL = "https://cdn.example.local/obj/synthetic-gui-data/base_sheets_output/258/expense.csv"
TASK_EXPENSE_CSV_CONTENT = """账户类型：活期账户

日期;收款人;金额;Account/Cat;备忘;状态;编号
2025-01-15;;"5000.00";"开户";;;
2025-12-21;"沃尔玛";"-120.00";"食品";;;
"""
STEP_NUM = 10
DEFAULT_E2E_RUN_DIR = "manual_task258_rule_e2e_10step"
FIXTURE_PATH = Path(__file__).resolve().parent / "fixtures" / "task258_fields.json"


def project_output_dir() -> Path:
    return Path(__file__).resolve().parents[1] / "output"


def default_task258_e2e_output_root() -> str:
    return str(project_output_dir() / DEFAULT_E2E_RUN_DIR)


ZSHRC_ENV_NAMES = (
    "AK",
    "SK",
    "MOONSHOT_API_KEY",
    "KIMI_API_KEY",
    "KIMI_NATIVE_API_KEY",
    "VOLCENGINE_REGION",
    "SOURCE_REGION",
    "WORKFLOWGYM_TEST_INSTANCE_ID",
    "APP_ID",
    "APP_SECRET",
)


def read_env(name: str, default: str = "") -> str:
    return os.getenv(name, default)


def load_zshrc_env(names: tuple[str, ...] = ZSHRC_ENV_NAMES, zshrc_path: str = "") -> None:
    missing = [name for name in names if not read_env(name)]
    if not missing:
        return
    zshrc = Path(zshrc_path or os.path.expanduser("~/.zshrc"))
    if not zshrc.is_file():
        return
    zshrc_quoted = shlex.quote(str(zshrc))
    for name in missing:
        try:
            completed = subprocess.run(
                ["zsh", "-lc", "source %s >/dev/null 2>&1; print -r -- ${%s:-}" % (zshrc_quoted, name)],
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        value = (completed.stdout or "").strip()
        if value:
            os.environ[name] = value


def load_task258_fixture_fields() -> dict:
    if FIXTURE_PATH.is_file():
        return json.loads(FIXTURE_PATH.read_text(encoding="utf-8"))
    return {}


def load_task258_instruction() -> str:
    fields = load_task258_fixture_fields()
    instruction = str(fields.get("题目") or fields.get("up") or "").strip()
    if instruction:
        return instruction
    return (
        "在 KMyMoney 中完成账本建立与支出录入，并导出 expense.csv 到 /home/user/Desktop/output/expense.csv。"
    )


def build_task258_fields() -> dict[str, object]:
    fixture = load_task258_fixture_fields()
    instruction = load_task258_instruction()
    return {
        "id": TASK_ID,
        "题目": instruction,
        "up": instruction,
        "镜像ID": TASK_IMAGE_ID,
        "image": TASK_IMAGE_ID,
        "系统类型": fixture.get("系统类型") or "Ubuntu",
        "platform": "ubuntu",
        "启动方式": fixture.get("启动方式") or "桌面",
        "tos_url": fixture.get("tos_url") or "[]",
        "输入文件路径": fixture.get("输入文件路径") or "",
        "输出文件路径": fixture.get("输出文件路径") or TASK_OUTPUT_PATH,
        "final_answer文件名": fixture.get("final_answer文件名") or TASK_FINAL_ANSWER,
        "final answer 文件": fixture.get("final answer 文件") or str([TASK_FINAL_ANSWER_URL]),
        "answer_type": fixture.get("answer_type") or "文件产物",
        "metric_type": fixture.get("metric_type") or "规则判分",
        "判分类型": fixture.get("metric_type") or "规则判分",
        "response_reference": fixture.get("response_reference") or "",
    }


def build_task258_sample_job(*, instance_id: str, output_root: str) -> SampleJob:
    return SampleJob(
        run_id="task258-e2e",
        task_id=TASK_ID,
        sample_index=1,
        task=TaskRecord(
            run_id="task258-e2e",
            task_id=TASK_ID,
            row_number=1,
            fields=build_task258_fields(),
        ),
        config=RunConfig(
            run_id="task258-e2e",
            output_root=output_root,
            sample_num=1,
            step_num=STEP_NUM,
            player="kimi",
            judger="gemini3.1",
            enable_real_cloud=True,
            tosutil_timeout_seconds=180,
            write_step_traj=True,
        ),
        lease=InstanceLease(
            run_id="task258-e2e",
            lease_id="task258-e2e-lease",
            instance_id=instance_id,
            task_id=TASK_ID,
            sample_index=1,
            status="busy",
            acquired_at="2026-07-12 00:00:00",
        ),
    )


def build_seed_expense_csv_command() -> str:
    return "\n".join(
        [
            "#!/bin/bash",
            "set -e",
            "mkdir -p /home/user/Desktop/output",
            "cat > /home/user/Desktop/output/%s <<'EOF'" % shlex.quote(TASK_FINAL_ANSWER),
            TASK_EXPENSE_CSV_CONTENT.rstrip("\n"),
            "EOF",
            "test -s /home/user/Desktop/output/%s" % shlex.quote(TASK_FINAL_ANSWER),
            "echo WORKFLOWGYM_TASK258_PRODUCT_READY",
        ]
    )


def seed_task258_product(env: VolcengineEnv, instance_id: str) -> None:
    result = env.run_command(instance_id, build_seed_expense_csv_command(), timeout=180)
    output = ""
    for item in result.get("results") or []:
        if isinstance(item, dict):
            decoded = item.get("decoded_output")
            if decoded:
                output += str(decoded)
    print("WORKFLOWGYM_TASK258_SEED_OUTPUT", output, flush=True)
    if "WORKFLOWGYM_TASK258_PRODUCT_READY" not in output:
        raise AssertionError("构造 expense.csv 失败: %s" % output[-1000:])


def ensure_instance_running(env: VolcengineEnv, instance_id: str) -> None:
    instance = env.describe_instance(instance_id)
    status = str(instance.get("Status") or instance.get("status") or "").upper()
    if status == "STOPPING":
        env.wait_for_status(instance_id, "STOPPED", timeout_seconds=600)
        status = "STOPPED"
    if status == "STOPPED":
        env.start_instance(instance_id)
    if status not in ("RUNNING",):
        env.wait_for_status(instance_id, "RUNNING", timeout_seconds=600)


class Task258Sampler(Sampler):
    def collect_and_record_outputs(self, job: SampleJob, sample_dir: str, context, state) -> None:
        if job.lease and state.env_metadata.get("desktop_ready_at"):
            seed_task258_product(self.env, job.lease.instance_id)
        else:
            print("WORKFLOWGYM_TASK258_SKIP_SEED reason=env_not_ready", flush=True)
        super().collect_and_record_outputs(job, sample_dir, context, state)


load_zshrc_env()


@unittest.skipUnless(
    os.getenv("WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS") == "1",
    "set WORKFLOWGYM_RUN_REAL_VOLCENGINE_TESTS=1 to run real Volcengine E2E",
)
class Task258RuleE2ETest(unittest.TestCase):
    """任务 258：启动实例 -> 采样 10 步 -> 构造 expense.csv -> collect_outputs -> 规则判分。"""

    def setUp(self):
        self.instance_id = read_env("WORKFLOWGYM_TEST_INSTANCE_ID", DEFAULT_INSTANCE_ID)
        self.region = read_env("VOLCENGINE_REGION", read_env("SOURCE_REGION", "cn-guangzhou"))
        self.output_root = read_env(
            "WORKFLOWGYM_TASK258_E2E_OUTPUT_ROOT",
            default_task258_e2e_output_root(),
        )
        self.env = VolcengineEnv(region=self.region)

    def tearDown(self):
        return

    def test_task258_sample_ten_steps_seed_product_and_score_rule(self):
        self.assertTrue(read_env("AK") and read_env("SK"), "set AK/SK for Volcengine")
        moonshot_key = read_env("MOONSHOT_API_KEY") or read_env("KIMI_API_KEY") or read_env("KIMI_NATIVE_API_KEY")
        self.assertTrue(moonshot_key, "set MOONSHOT_API_KEY or KIMI_API_KEY for kimi sampling")

        print("WORKFLOWGYM_TEST_INSTANCE", self.instance_id, flush=True)
        print("WORKFLOWGYM_TASK258_OUTPUT_ROOT", self.output_root, flush=True)

        ensure_instance_running(self.env, self.instance_id)

        job = build_task258_sample_job(instance_id=self.instance_id, output_root=self.output_root)
        sampler = Task258Sampler(AgentFactory(), self.env)
        trajectory = sampler.run_sample(job)

        print("WORKFLOWGYM_TASK258_SAMPLE_STATUS", trajectory.status, flush=True)
        print("WORKFLOWGYM_TASK258_LAST_STEP", trajectory.last_step, flush=True)
        print("WORKFLOWGYM_TASK258_OUTPUT_UPLOADS", trajectory.task_files.output_uploads, flush=True)

        self.assertEqual(trajectory.last_step, STEP_NUM - 1)
        self.assertNotEqual(trajectory.status, "sample_failed", trajectory.error)
        self.assertTrue(Path(trajectory.traj_json_path).is_file())
        sample_dir = Path(trajectory.sample_dir)
        self.assertTrue(
            (sample_dir / "step_0.jpg").is_file() or (sample_dir / "env_ready.jpg").is_file(),
            "采样目录应至少有一张截图",
        )
        self.assertEqual(trajectory.task_files.final_answer_files, [TASK_FINAL_ANSWER])
        self.assertEqual(len(trajectory.task_files.output_uploads), 1)

        upload = trajectory.task_files.output_uploads[0]
        self.assertTrue(upload.get("output_file_exists"), upload)
        self.assertEqual(upload.get("status"), "uploaded", upload)
        self.assertTrue(str(upload.get("tos_url", "")).startswith("https://"), upload)
        self.assertEqual(upload.get("source_path"), "/home/user/Desktop/output/expense.csv")

        score = Scorer().score(trajectory)

        print("WORKFLOWGYM_TASK258_SCORE", score.check, flush=True)
        score_payload = json.loads(Path(score.score_json_path).read_text(encoding="utf-8"))
        self.assertEqual(score.check.get("answer_score"), 1, score_payload)
        self.assertIn("一致", str(score.check.get("evidence", "")))
        comparisons = score.check.get("comparisons") or []
        self.assertTrue(comparisons)
        self.assertTrue(all(item.get("matched") for item in comparisons), comparisons)
        production_path = sample_dir / "production" / TASK_FINAL_ANSWER
        self.assertTrue(production_path.is_file(), "规则判分应落盘 production/")
        self.assertTrue(score.check.get("production_snapshots", [{}])[0].get("production_saved"))
        gt_production_path = sample_dir / "gt_production" / TASK_FINAL_ANSWER
        self.assertTrue(gt_production_path.is_file(), "应从数据集 final answer 文件 落盘 gt_production/")
        self.assertTrue(score.check.get("production_snapshots", [{}])[0].get("gt_production_saved"))

        report = maybe_write_e2e_sample_to_spreadsheet(
            output_root=self.output_root,
            trajectory=trajectory,
            score=score,
        )
        if report is not None:
            self.assertTrue(Path(report["local_samples_csv"]).is_file())
            print("WORKFLOWGYM_TASK258_SPREADSHEET", report, flush=True)


if __name__ == "__main__":
    unittest.main()
