from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from open_workflowgym.tools.merge_feishu_sheet_columns import (
    build_defg_lookup,
    build_merged_rows,
    parse_image_ids,
)


class MergeFeishuSheetColumnsTest(unittest.TestCase):
    def test_parse_image_ids(self):
        self.assertEqual(parse_image_ids("image-a,image-b"), ["image-a", "image-b"])
        self.assertEqual(parse_image_ids("image-a"), ["image-a"])
        self.assertEqual(parse_image_ids("image-a，image-b"), ["image-a", "image-b"])
        self.assertEqual(parse_image_ids("未找到"), [])

    def test_build_defg_lookup(self):
        lookup_rows = [
            ["", "", "image_id", "D", "E", "F", "G"],
            ["", "", "image-a", "d1", "e1", "f1", "g1"],
            ["", "", "image-b", "d2", "e2", "f2", "g2"],
        ]
        lookup = build_defg_lookup(lookup_rows)
        self.assertEqual(lookup["image-a"], ["d1", "e1", "f1", "g1"])

    def test_build_merged_rows_inserts_after_e_column(self):
        base_rows = [
            ["A", "B", "C", "D", "镜像id", "F"],
            ["1", "x", "y", "z", "image-a,image-c", "tail"],
            ["2", "p", "q", "r", "image-missing", "tail2"],
        ]
        lookup_rows = [
            ["", "", "image_id", "列D", "列E", "列F", "列G"],
            ["", "", "image-a", "d1", "e1", "f1", "g1"],
            ["", "", "image-b", "d2", "e2", "f2", "g2"],
        ]
        output_rows = build_merged_rows(base_rows, lookup_rows)
        self.assertEqual(
            output_rows[0],
            ["A", "B", "C", "D", "镜像id", "列D", "列E", "列F", "列G", "F"],
        )
        self.assertEqual(
            output_rows[1],
            ["1", "x", "y", "z", "image-a,image-c", "d1", "e1", "f1", "g1", "tail"],
        )
        self.assertEqual(
            output_rows[2],
            ["2", "p", "q", "r", "image-missing", "", "", "", "", "tail2"],
        )


if __name__ == "__main__":
    unittest.main()
