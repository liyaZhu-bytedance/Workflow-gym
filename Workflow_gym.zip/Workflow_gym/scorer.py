from __future__ import annotations

import json
import os
from pathlib import Path

from .records import ScoreResult, TaskFileResult, TrajectoryResult, now_text
from .judger_agent import JudgerAgent


class Scorer:
    def __init__(self, judger: JudgerAgent | None = None):
        self.judger = judger or JudgerAgent()

    def score_payload(self, payload: dict) -> ScoreResult:
        task_files = payload.get("task_files") or {}
        trajectory = TrajectoryResult(
            run_id=payload["run_id"],
            task_id=payload["task_id"],
            sample_index=payload["sample_index"],
            status=payload.get("status", ""),
            sample_dir=payload["sample_dir"],
            traj_json_path=payload["traj_json_path"],
            traj_md_path=payload["traj_md_path"],
            id_json_path=payload["id_json_path"],
            sample_status_path=payload["sample_status_path"],
            last_step=payload.get("last_step", -1),
            error=payload.get("error", ""),
            task_files=TaskFileResult(**task_files),
            task_fields=payload.get("task_fields") or {},
        )
        return self.score(trajectory)

    def score(self, trajectory: TrajectoryResult) -> ScoreResult:
        score_path = os.path.join(trajectory.sample_dir, "score.json")
        check = self.judger.judge(trajectory)
        payload = {
            "saved_at": now_text(),
            "check": check,
            "vm_screen_pixel_size": {},
        }
        Path(score_path).parent.mkdir(parents=True, exist_ok=True)
        with open(score_path, "w", encoding="utf-8") as file_obj:
            json.dump(payload, file_obj, ensure_ascii=False, indent=2)
        return ScoreResult(
            run_id=trajectory.run_id,
            task_id=trajectory.task_id,
            sample_index=trajectory.sample_index,
            score_json_path=score_path,
            saved_at=payload["saved_at"],
            check=payload["check"],
            vm_screen_pixel_size=payload["vm_screen_pixel_size"],
            task_fields=trajectory.task_fields,
        )

