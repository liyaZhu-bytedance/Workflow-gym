# Judger（裁判员）运行机制

本文说明采样结束后 **Judger** 如何判分、`JudgeClient` 如何调模型，以及与 `--judger` / `JUDGE_*` 的关系。

---

## 1. 总览

Judger **不单独起进程**。采样完成后，调度器通过 outbox 事件触发判分，结果写入 `score.json`。

```
main.py
  └─ Scheduler(scorer=Scorer())          # Scorer 内默认 JudgerAgent()
       └─ sample_ready_to_score
            └─ Scorer.score() / score_payload()
                 └─ JudgerAgent.judge(trajectory)
                      ├─ 按任务 answer_type + metric_type 分流
                      └─ 需要 LLM 时调用模型客户端
                           └─ 写 output/<run>/<task_id>/sample_<n>/score.json
```

关键文件：

| 路径 | 作用 |
|------|------|
| `scorer.py` | 封装 `JudgerAgent.judge`，落盘 `score.json` |
| `judgers/agent.py` | `JudgerAgent`：按任务字段分流判分策略 |
| `judgers/client.py` | `JudgeClient`：按 `base_url` 选 provider 并请求模型 |
| `judgers/factory.py` | `JudgeModelFactory`：当前 mixin 判分实际调用的 LLM 入口 |
| `judgers/defaults.py` | `JUDGE_*` 读取、`resolve_provider_from_base_url` |

---

## 2. 判分策略如何选择

`JudgerAgent.judge()` 读取任务表字段 `answer_type`、`metric_type`（别名 `判分类型`）：

| 条件 | 方法 | 是否调 LLM |
|------|------|------------|
| 采样失败（`sample_failed` 等） | `error_score` | 否 |
| 数值/文本 + `image-llm` | `judge_image_llm` | 是 |
| 数值/文本 + 其它 | `judge_last_screenshots` | 是 |
| 文件产物 + `规则判分` | `judge_rule_files`（产物比对） | 否 |
| 文件产物 + `规则判分+LLM-as-judge` | `judge_file_content` | 是 |
| `Rubrics` / `rubrics` | `judge_rubrics` | 是 |
| 其它 | `answer_score=-1`（未配置判分方式） | 否 |

纯「规则判分」任务**不必**配置 `JUDGE_*`。

---

## 3. JudgeClient：配置与 Provider

### 3.1 OpenAI 兼容三元组

```bash
JUDGE_API_KEY=你的_Key          # 兼容回退：GEMINI31_API_KEY
JUDGE_BASE_URL=https://.../v1
JUDGE_MODEL=gemini-3-pro-preview-new
```

也可代码显式传入：

```python
from open_workflowgym.judgers.client import JudgeClient

client = JudgeClient(
    api_key="...",
    base_url="https://your-compatible-endpoint/v1",
    model="gemini-3-pro-preview-new",
)
content = client.call_model([{"role": "user", "content": "..."}])
```

未传构造参数时，回退读取上述环境变量。

### 3.2 按 `base_url` 选择 provider

`resolve_provider_from_base_url()`（`judgers/defaults.py`）：

| `base_url` | provider | 实现 |
|------------|----------|------|
| 匹配内部 Azure OpenAI 网关 host | `azure_openai` | `AzureOpenAI` |
| 其它 / 未匹配 | **默认 `openai`** | `OpenAI(base_url=...)` |

`JudgeClient` 与 `JudgeModelFactory` 均使用同一套推断逻辑。

### 3.3 与 `--judger` / `JUDGER` 的关系

CLI `--judger`（默认 `gemini3.1`）只写入采样结果的**元数据标识**，**不**选择 `JudgerAgent` 实现，也**不**切换 `JUDGE_*` 后端。  
真正判分由任务 `metric_type` + `JUDGE_*`（及 provider 推断）决定。

---

## 4. 当前两条 LLM 调用路径

| 路径 | 入口 | 使用场景 |
|------|------|----------|
| **A. JudgeClient** | `JudgeClient.call_model` | 单测 / 直接探测模型；`JudgerAgent` 继承了它 |
| **B. JudgeModelFactory** | `JudgeModelFactory().create("gemini3_pro").call_model` | **生产判分**（screenshot / file_product / rubrics / image_llm mixin） |

两边都会按 `JUDGE_BASE_URL` 推断 provider，行为一致。  
注意：mixin **尚未**统一改成 `self.call_model()`，因此改 `JudgeClient` 时需同步确认 Factory 路径（目前已共用 `resolve_provider_from_base_url`）。

旧名 `GeminiJudgeClient` 仍作为 `JudgeClient` 的别名保留。

---

## 5. 输出产物

判分完成后：

```
output/<run>/<task_id>/sample_<n>/score.json
```

主要字段在 `check` 内，例如 `answer_score`、`evidence`、`error`。  
随后可通过 `score_ready_to_sync` 写入本地 CSV 或飞书报表。

---

## 6. 本地验证 JudgeClient

单元测试（不打真实 API）：

```bash
python -m unittest tests.test_judge_client.JudgeClientConfigTest \
  tests.test_judge_client.JudgeClientProviderTest \
  tests.test_judge_factory_routing -v
```

真实请求（需配置三元组）：

```bash
export RUN_LIVE_JUDGE=1
export JUDGE_API_KEY=...
export JUDGE_BASE_URL=https://your-compatible-endpoint/v1
export JUDGE_MODEL=gemini-3-pro-preview-new

python -m unittest tests.test_judge_client.JudgeClientLiveTest -v
```

也可用 `GEMINI_JUDGE_API_KEY` / `GEMINI_JUDGE_BASE_URL` / `GEMINI_JUDGE_MODEL` 覆盖。

---

## 7. 注意事项

1. **规则判分**不需要 `JUDGE_*`；LLM 类判分缺 Key / Base URL / Model 会报错或得错误分。  
2. `JudgeClient` 构造参数里若显式传 `provider=`，会覆盖 base_url 推断；Factory 路径**只认** base_url。  
3. 快速上手（[quickstart.md](./quickstart.md)）里的离线采样须显式 `SOURCE_FEISHU_URL=`（空值）；未设置时 `config.py` 可能回退到内置飞书 URL。
4. `ENABLE_REAL_CLOUD` 未配置时默认 `true`，会走真实火山云。

环境变量模板见 [`.env.local.example`](../.env.local.example) / [`.env.redis.example`](../.env.redis.example)，本地跑通采样见 [quickstart.md](./quickstart.md)。
