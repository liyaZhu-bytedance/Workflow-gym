# deploy_public_site 一键部署公网站点总结

> 脚本路径：`tools/deploy_public_site.py`  
> 一条命令完成：**建实例 → 配网络 → 绑 EIP → 配防火墙 → 装 Python → 起网站 → curl 验证**

> 说明：下方「关键环境变量」章节仅保留在本地 Markdown；发布飞书 Doc 时从「概述」起导入（见 `tools/publish_deploy_public_site_feishu_doc.py`）。

## 关键环境变量

运行前请先准备以下变量。脚本会通过 `load_shell_env()` 自动从当前环境或 `~/.zshrc` / `~/.bashrc` 读取。

### 必填

| 变量 | 说明 | 申请 / 获取 | 配置方式 |
|------|------|-------------|----------|
| `AK` | 火山引擎 Access Key | [API 访问密钥管理](https://console.volcengine.com/iam/keymanage/) 申请 | `export AK=你的AccessKey`，或写入 `~/.zshrc`：`export AK=...` |
| `SK` | 火山引擎 Secret Key | 同上，创建密钥时一并获得 | `export SK=你的SecretKey`，或写入 `~/.zshrc`：`export SK=...` |

AK/SK 需具备 ECS、VPC（安全组 / ACL / EIP）、云防火墙（fwcenter）相关 API 权限。

### 可选（实例登录）

| 变量 | 说明 | 申请 / 获取 | 配置方式 |
|------|------|-------------|----------|
| `INSTANCE_PASSWORD` | ECS 实例登录密码 | 自行设定，无需单独申请 | `export INSTANCE_PASSWORD=...` 或 `--password`；未设置时默认 `keep_image_credential=true`，复用镜像内置凭据 |
| `KEY_PAIR_NAME` | SSH 密钥对名称 | [密钥对管理](https://console.volcengine.com/ecs/region:ecs+cn-guangzhou/keypair) 创建 | `export KEY_PAIR_NAME=...` 或 `--key-pair-name`；与密码二选一即可 |

### 可选（部署参数）

| 变量 | 说明 | 申请 / 获取 | 配置方式 |
|------|------|-------------|----------|
| `VOLCENGINE_REGION` | 部署区域 | 无需申请，默认广州 | `export VOLCENGINE_REGION=cn-guangzhou` 或 `--region` |
| `DEFAULT_IMAGE_ID` | ECS 镜像 ID | [镜像列表](https://console.volcengine.com/ecs/region:ecs+cn-guangzhou/image) 选用 | `export DEFAULT_IMAGE_ID=image-xxx` 或 `--image-id` |
| `KEEP_IMAGE_CREDENTIAL` | 是否复用镜像登录凭据 | 无需申请 | 默认开启；关闭：`export KEEP_IMAGE_CREDENTIAL=0` 或 `--no-keep-image-credential` |

### 可选（防火墙）

| 变量 | 说明 | 申请 / 获取 | 配置方式 |
|------|------|-------------|----------|
| `INTERNET_FIREWALL_ID` | 互联网边界防火墙 ID | 账号需已开通 [云防火墙](https://www.volcengine.com/docs/6516/162410)；控制台查看实例 ID | 仅多防火墙账号或自动探测失败时设置：`export INTERNET_FIREWALL_ID=...` |
| `FIREWALL_POLICY_TARGET_IP` | 防火墙策略目标 IP | 通常无需手动设置，脚本自动选 EIP | 强制指定时：`export FIREWALL_POLICY_TARGET_IP=101.96.x.x` |
| `FIREWALL_POLICY_DEPLOY_TIMEOUT_SECONDS` | 等待策略云侧下发超时（秒） | 无需申请 | 默认 `300`；可调：`export FIREWALL_POLICY_DEPLOY_TIMEOUT_SECONDS=600` |

### 前置资源说明（非环境变量）

以下资源脚本使用命令行默认值，换账号时需通过参数覆盖，或在控制台预先创建：

| 资源 | 默认值来源 | 申请 / 查看 |
|------|------------|-------------|
| 安全组 ID | `--security-group-id` | [安全组控制台](https://console.volcengine.com/vpc/region:vpc+cn-guangzhou/securityGroup) |
| 子网 ID | `--subnet-id` | [子网控制台](https://console.volcengine.com/vpc/region:vpc+cn-guangzhou/subnet) |
| 公网 EIP 配额 | 脚本自动申请；配额满时复用已有 EIP | [EIP 文档](https://docs.volcengine.com/docs/64064/116980?lang=zh) / [EIP 控制台](https://console.volcengine.com/eip/region:eip+cn-guangzhou/eips) |

**快速配置示例（写入 `~/.zshrc`）：**

```bash
export AK=你的AccessKey
export SK=你的SecretKey
export INSTANCE_PASSWORD=你的实例密码   # 可选
# export VOLCENGINE_REGION=cn-guangzhou
```

**最小运行命令：**

```bash
python tools/deploy_public_site.py \
  --region cn-guangzhou \
  --instance-name my-site \
  --output-json output/result.json
```

---

## 概述

`deploy_public_site.py` 是**单文件、自包含**的火山引擎一键部署脚本，不依赖仓库内其他 Python 脚本。通过火山引擎 SDK 直接调用 ECS / VPC / 互联网防火墙 API，并在实例内通过云助手 RunCommand 安装 Python 并启动 HTTP 服务。

```bash
export AK=xxx SK=xxx   # 或在 ~/.zshrc 中配置
python tools/deploy_public_site.py \
  --region cn-guangzhou \
  --instance-name my-site \
  --output-json output/result.json
```

总入口函数：`deploy_public_site()`

---

## 部署流程与关键函数

| 步骤 | 说明 | 关键函数 | 火山 API / 动作 |
|------|------|----------|-----------------|
| 0 | 加载 AK/SK 等凭据 | `load_shell_env()` | 从环境变量或 ~/.zshrc 读取 |
| 1 | 配置安全组 | `configure_security_group()` | `AuthorizeSecurityGroupIngress` — 开放 ALL/TCP/UDP/ICMP 入站 |
| 2 | 配置 ACL | `configure_acl()` | `UpdateNetworkAclEntries` — 入站/出站全通 |
| 3 | 创建 ECS 实例 | `create_instance()` | `AllocateInstances` → `wait_for_instance_status()` |
| 4 | 申请并绑定 EIP | `allocate_and_bind_eip()` | `AllocateEipAddress` → `AssociateEipAddress` |
| 5 | 配置互联网防火墙 | `configure_firewall_policy()` | 自动探测防火墙 → 下发 in/out 全通策略 |
| 6 | 安装 Python + 起站 | `install_python_and_start_server()` | 云助手 `RunCommand` 执行安装脚本 |
| 7 | 本地 curl 验证 | `test_public_site()` | 本机 `curl http://<EIP>:80` |

> 实际执行顺序：先 SG/ACL → 建实例 → 绑 EIP → 防火墙 → RunCommand → curl。

---

## 各步骤函数详解

### 1. 配置安全组 — `configure_security_group(region, security_group_id)`

- 创建 VPC API 客户端：`create_vpc_api(region)`
- 添加入站规则：ALL / TCP / UDP / ICMP，源 
- 已存在规则（409 Conflict）自动跳过

### 2. 配置 ACL — `configure_acl(region, subnet_id)`

- 通过子网查 ACL ID
- 幂等添加入站、出站 allow-all 规则
- `UpdateNetworkAclEntries` 一次性更新

### 3. 创建实例 — `create_instance(...)`

- `build_allocate_instances_request()` 构造请求
- `AllocateInstances` 创建实例，默认 `keep_image_credential=True`
- `wait_for_instance_status(api, instance_id, "RUNNING")` 等待就绪
- `extract_instance_network_ips()` 提取网卡 IP（含 101.96.x / 192.168.x）

### 4. 绑定 EIP — `allocate_and_bind_eip(region, instance_id)`

- `AllocateEipAddress` 申请公网 IP
- 配额满时回退到已有可用 EIP
- `wait_for_eip_available()` / `wait_for_eip_bound()` 等待绑定完成

### 5. 配置防火墙 — `configure_firewall_policy(region, eip_address, ...)`

| 子函数 | 作用 |
|--------|------|
| `resolve_internet_firewall_id()` | 自动探测互联网防火墙（AssetList → DescribeControlPolicy） |
| `wait_for_firewall_asset()` | 等待实例/EIP 出现在防火墙资产列表 |
| `resolve_firewall_policy_target_ip()` | 选择策略目标 IP（优先 EIP，非 192.168.x 私网） |
| `upsert_control_policy_for_direction()` | in/out 方向添加或修改 accept 策略 |
| `enable_control_policy_switch()` | 开启策略开关 |
| `wait_for_control_policy_deployed()` | 轮询直到云侧下发完成 |
| `ping_public_ip()` | 策略生效后 ping 公网 IP |

防火墙策略目标 IP 优先级：

1. `FIREWALL_POLICY_TARGET_IP` 环境变量
2. AssetList 资产 IP
3. **EIP 公网地址**（如 101.96.245.134）
4. 实例网卡中的 101.96.x
5. 其他私网 IP

### 6. 安装 Python + 启动网站 — `install_python_and_start_server(region, instance_id, port)`

| 子函数 | 作用 |
|--------|------|
| `wait_for_cloud_assistant_ready()` | 等待云助手 Online/Running |
| `RunCommand` | 远程执行安装脚本（安装 Python 3.12、写 demo 页面、`python3 -m http.server 80`） |
| `wait_for_command_result()` | 轮询 DescribeInvocationResults，Success 后返回输出 |
| `print_run_command_output()` | 打印命令执行日志 |

### 7. curl 验证 — `test_public_site(eip_address, port)`

- 最多 10 次重试，每次间隔 5 秒
- `curl -v http://<EIP>:80`，检查 HTTP 200

---

## 辅助 API 工厂

```text
create_ecs_api(region)      → volcenginesdkecs.ECSApi
create_vpc_api(region)      → volcenginesdkvpc.VPCApi
create_fwcenter_api(region) → volcenginesdkfwcenter.FWCENTERApi
```

---

## 部署效果

浏览器访问 `http://<公网EIP>/` 可看到：

- 标题：**Hello from Volcengine ECS!**
- 说明：This is a demo public site deployed automatically.
- 实例 ID：如 `i-yer3mjgvswf8b8x9xvxb`
- 公网 IP 示例：`101.96.245.134`

## 部署效果图

（发布脚本会在文档末尾插入浏览器截图）
