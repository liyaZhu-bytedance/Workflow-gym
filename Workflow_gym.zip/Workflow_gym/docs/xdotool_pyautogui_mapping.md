# xdotool 模式下 PyAutoGUI 动作映射说明

> 源码位置：`agents/pyautogui_actions.py`  
> 编译入口：`compile_pyautogui_action_code_to_xdotool()` → `_compile_pyautogui_call_to_xdotool()`  
> 开关：`UBUNTU_PYAUTOGUI_XDOTOOL_BACKEND`（默认 `0` 关闭，使用纯 pyautogui；设为 `1` 开启 xdotool 编译）

## 总览

| 类别 | 数量 |
|------|------|
| **已实现编译映射的 pyautogui API** | **16 个** |
| 在参数表但未实现编译 | 1 个（`tripleClick`） |
| Agent 动作名 → pyautogui 生成 | 14 种 |
| 不经 pyautogui、直接保留的代码 | 剪贴板内联、`time.sleep`、坐标日志等 |

---

## 一、已实现映射的 16 个 pyautogui API

编译器通过正则匹配 `pyautogui.<func>(...)`，将每个调用替换为内联 `subprocess.run([xdotool, ...])` 代码。

### 1. 鼠标移动与点击（8 个）

| # | pyautogui API | xdotool 映射 | 说明 |
|---|---------------|--------------|------|
| 1 | `moveTo(x, y)` | `mousemove --sync x y` | 可选 `time.sleep(duration)` |
| 2 | `click(x, y, ...)` | `mousemove --sync` + `click [button]` | `button`: left→1, middle→2, right→3；`clicks≥2` 用 `--repeat` |
| 3 | `doubleClick(x, y, ...)` | `mousemove --sync` + `click --repeat 2 [button]` | |
| 4 | `rightClick(x, y, ...)` | `mousemove --sync` + `click 3` | |
| 5 | `middleClick(x, y, ...)` | `mousemove --sync` + `click 2` | |
| 6 | `mouseDown(x, y, button)` | `mousemove --sync` + `mousedown [button]` | |
| 7 | `mouseUp(x, y, button)` | `mousemove --sync` + `mouseup [button]` | |
| 8 | `dragTo(x, y, ...)` | `mousedown` + `mousemove --sync` + `mouseup` | **简化实现**：无逐步插值，不读取当前鼠标位置 |

### 2. 滚轮（2 个）

| # | pyautogui API | xdotool 映射 | 说明 |
|---|---------------|--------------|------|
| 9 | `scroll(clicks, x, y)` | `click 4`（上）/ `click 5`（下） | `clicks>0` 向上，否则向下；按 `abs(clicks)` 重复 |
| 10 | `hscroll(clicks, x, y)` | `click 7`（右）/ `click 6`（左） | 水平滚动 |

### 3. 键盘（6 个）

| # | pyautogui API | xdotool 映射 | 说明 |
|---|---------------|--------------|------|
| 11 | `hotkey(*keys)` | `key key1+key2+...` | 组合键，如 `ctrl+v` → `key ctrl+v` |
| 12 | `press(keys, ...)` | 多次 `key <name>` | 支持 `presses`、`interval` |
| 13 | `keyDown(key)` | `keydown <name>` | 别名 `keydown` 同样支持 |
| 14 | `keyUp(key)` | `keyup <name>` | 别名 `keyup` 同样支持 |
| 15 | `write(message, interval)` | `type --delay <ms> -- <text>` | ASCII 文本逐字输入 |
| 16 | `typewrite(message, interval)` | 同 `write` | `write` 的别名 |

### 按键名别名（`xdotool_key_name`）

| pyautogui / 常用名 | xdotool 名 |
|--------------------|------------|
| enter, return | Return |
| esc, escape | Escape |
| del, delete | Delete |
| ctrl, control | ctrl |
| win, command, super | super |
| up/down/left/right | Up/Down/Left/Right |
| pageup / pagedown | Page_Up / Page_Down |
| space / tab | space / Tab |

---

## 二、参数表中有、但未实现编译（1 个）

| pyautogui API | 状态 |
|---------------|------|
| `tripleClick` | 在 `PYAUTOGUI_FUNCTION_PARAMS` 中声明，但 `_compile_pyautogui_call_to_xdotool` **无对应分支**，调用会原样保留（若含 `pyautogui.` 则仍走 pyautogui 运行时） |

---

## 三、Agent 动作名 → pyautogui 生成 → xdotool 编译链路

`pyautogui_code_for_action()` 将模型 function_call 转为 pyautogui 代码，再由编译器转为 xdotool。

| Agent 动作名 | 生成的 pyautogui 调用 | 是否编译为 xdotool |
|--------------|----------------------|-------------------|
| `click` | `pyautogui.click(x, y)` | ✅ |
| `left_double` | `pyautogui.doubleClick(x, y)` | ✅ |
| `right_single` | `pyautogui.click(x, y, button='right')` | ✅ |
| `move_to` | `pyautogui.moveTo(x, y)` | ✅ |
| `drag` | `pyautogui.moveTo` + `pyautogui.dragTo` | ✅（dragTo 为简化版） |
| `mouse_down` | `pyautogui.mouseDown(...)` | ✅ |
| `mouse_up` | `pyautogui.mouseUp(...)` | ✅ |
| `scroll` | `pyautogui.scroll` / `pyautogui.hscroll` | ✅ |
| `type` | `pyautogui.write`（ASCII）或剪贴板内联 + `hotkey`（非 ASCII） | ✅（write/hotkey 部分） |
| `hotkey` | `pyautogui.hotkey(...)` | ✅ |
| `press` | `pyautogui.press(...)` | ✅ |
| `release` | `pyautogui.keyUp(...)` | ✅ |
| `wait` | `time.sleep(...)` | ➖ 非 pyautogui，原样保留 |
| `open_computer` | `pyautogui.hotkey('win', 'e')` | ✅ |

---

## 四、不经过编译器、原样进入远端脚本的代码

| 类型 | 示例 | 说明 |
|------|------|------|
| 坐标日志 | `print("WORKFLOWGYM_ACTION_COORD " + json.dumps(...))` | Linux 预计算像素坐标时注入 |
| 等待 | `time.sleep(1)` | `wait` 动作 |
| 剪贴板内联（中文输入） | `pyperclip.copy` / `xclip` + 编译后的 `hotkey ctrl+v` | 非 ASCII `type` 动作；`hotkey` 部分会被编译 |
| 未识别的 pyautogui 调用 | 任意未映射 API | 保留 `pyautogui.` 原文，远端脚本会 import pyautogui |

---

## 五、编译限制

1. **仅支持字面量参数**：调用中的参数须为常量（`ast.literal_eval` 可解析），不支持变量、表达式、函数调用。
2. **单步正则匹配**：`pyautogui.\w+\([^\)]*\)`，嵌套括号或复杂多行调用可能匹配失败。
3. **`dragTo` 无平滑拖拽**：旧 runtime adapter 有分步插值，本地编译版仅 `mousedown → mousemove → mouseup`。
4. **非 ASCII 文本**：`write("张三")` 在 Agent 层已改写为剪贴板内联，不走 `xdotool type`。

---

## 六、编译示例

### 输入（pyautogui_code）

```python
print("WORKFLOWGYM_ACTION_COORD {...}")
pyautogui.click(960, 324)
```

### 输出（xdotool_code）

```python
print("WORKFLOWGYM_ACTION_COORD {...}")
subprocess.run([xdotool, "mousemove", "--sync", "960", "324"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
subprocess.run([xdotool, "click", "1"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
```

### 热键示例

```python
# 输入
pyautogui.hotkey("ctrl", "v")

# 输出
subprocess.run([xdotool, "key", "ctrl+v"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(0.05)
```

---

## 七、日志中的记录字段

每步远程执行前，`sampler` 会写入：

- `pyautogui_code`：转换前代码
- `xdotool_code`：转换后代码
- `backend`：`xdotool` 或 `pyautogui`
- `conversions`：逐条 `{function, source, target}` 转换记录

落盘位置：`sample_log.json`（`extra` 字段）、`workflow_events`（`prepare_action_script` 节点）。

---

*文档生成依据源码版本：本地编译 xdotool（A+D1 架构），已移除运行时 `[B]` loader 注入。*
