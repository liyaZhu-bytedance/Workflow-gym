# 快速上手

按模式选择模板：[`.env.local.example`](../.env.local.example)（Local）或 [`.env.redis.example`](../.env.redis.example)（Redis）。以下命令均在仓库根目录（含 `main.py`）执行。

## 0. 安装

```bash
git clone <repo-url> open_workflowgym
cd open_workflowgym
python3.11 -m venv .venv && source .venv/bin/activate   # Python >= 3.10
pip install -r requirements.txt
cp .env.local.example .env
```

编辑 `.env`，然后：

```bash
set -a && source .env && set +a
```

新开终端需重新 `source`。

---

## 1. 环境准备

```bash
# AK / SK 申请：https://console.volcengine.com/iam/keymanage/
AK=你的_Access_Key
SK=你的_Secret_Key
# 默认 cn-guangzhou（广州），一般无需改
VOLCENGINE_REGION=cn-guangzhou
```

---

## 2. 运动员（Player）配置

按 OpenAI 兼容三元组填写（默认 Player 为 `gpt`，无需再设 `PLAYER`）：

```bash
RUNNER_API_KEY=你的_API_Key
RUNNER_BASE_URL=https://api.openai.com/v1
RUNNER_MODEL=gpt-5.4
```

---

## 3. 裁判员（Judger）配置

```bash
JUDGE_API_KEY=你的_Judge_Key
JUDGE_BASE_URL=https://your-compatible-endpoint/v1
JUDGE_MODEL=gemini-3-pro-preview-new
```

仅「规则判分」任务可不填；涉及 LLM 判分时必填。

判分如何运行、provider 如何选择见 [judger.md](./judger.md)。

---

## 4. 离线文件配置

```bash
SOURCE_CSV_PATH=data/tasks.csv
# 离线采样时 SOURCE_FEISHU_URL 须显式留空（非空会优先读飞书；未设置时可能回退到内置飞书 URL）
SOURCE_FEISHU_URL=
```

---

## 5. 运行

```bash
set -a && source .env && set +a
python main.py --max-workers 1
```

结果默认写入 `output/`。指定任务可加 `--id 258`。更多参数见 [README.md](../README.md)。
