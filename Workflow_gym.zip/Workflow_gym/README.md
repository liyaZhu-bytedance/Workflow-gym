<div align="center">

# 🏋️ Open WorkflowGym

**面向桌面 GUI 工作流的 Agent 大规模采样与自动评测框架**

在云桌面（Ubuntu / Windows）上驱动多模态大模型，逐步操作真实桌面应用，自动记录轨迹、收集产物、完成判分。

<br/>

<img src="https://img.shields.io/badge/Python-%3E%3D3.10-3776AB?logo=python&logoColor=white" alt="" />
<img src="https://img.shields.io/badge/License-Apache%202.0-D22128.svg" alt="" />
<img src="https://img.shields.io/badge/Desktop-Ubuntu%20%7C%20Windows-4E9A06.svg" alt="" />
<img src="https://img.shields.io/badge/Modes-Local%20%7C%20Redis-1793D1.svg" alt="" />

<br/>

[快速开始](#-quick-start) · [核心特性](#-核心特性) · [运行模式](#-两种运行模式) · [安装](#-零基础安装) · [Local 模式](#️-local-模式从零到采样) · [Redis 模式](#️-redis-模式快速采样) · [配置参考](#️-配置参考) · [FAQ](#-常见问题)

</div>

---

## ✨ 核心特性

- **双模式采样** —— **Local 模式**自建并管理火山引擎 ECS 实例池；**Redis 模式**经 WGM Session 网关分配共享桌面（**网关需自行部署**，本仓库仅含客户端）。
- **多 Player 适配** —— 内置 GPT、Kimi、Claude、`dummy` 等采样 Agent，统一通过 `RUNNER_*` 三元组配置，切换模型只需改一行。
- **多策略自动判分** —— 支持规则判分（产物文件字节比对）、Rubrics、`image-llm`、`LLM-as-judge` 等，Judger 与 Player 完全解耦。
- **真实桌面操作** —— 通过 `pyautogui` 在云桌面逐步执行点击、输入、快捷键，覆盖真实 GUI 应用工作流。
- **完整轨迹留痕** —— 每次采样输出 `traj.json`（完整轨迹）、`score.json`（判分）、逐步截图与产物文件，便于复盘与二次分析。
- **稳健的工程能力** —— 跨任务并发调度、断点续跑、租约续期、资源看护、产物自动经 `tosutil` 上传至 TOS。
- **本地 CSV 任务表** —— 任务与结果均读写本地 CSV，无需配置线上飞书表格。
- **跨平台中文输入** —— 非 ASCII 文本统一走剪贴板粘贴（Linux `xsel`/`xclip`、Windows `Set-Clipboard`），规避逐字输入乱码。

---

## 🚀 Quick Start

**第一次使用？按下面 3 步判断该走哪条路：**

| 你的情况 | 推荐模式 | 跳转 |
| --- | --- | --- |
| 还没有云桌面，需要从镜像开始搭建 | **Local 模式** | [Local 模式](#️-local-模式从零到采样) |
| 已有团队共享的采样环境，只想直接跑任务 | **Redis 模式**（需已部署 WGM 网关） | [Redis 模式](#️-redis-模式快速采样) |
| 只想验证代码能跑、不连云 | **本地冒烟** | 见下方命令 |

**本地冒烟**（无需云资源、无需模型 Key）：

```bash
git clone <repo-url> open_workflowgym
cd open_workflowgym

python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env                # 编辑后加载
set -a && source .env && set +a

ENABLE_REAL_CLOUD=false python main.py \
  --dry-run local \
  --source-csv-path data/task.csv \
  --player dummy \
  --stepNum 1 \
  --max-workers 1 \
  --output-root output/smoke_run
```

冒烟通过后，再按 [Local](#️-local-模式从零到采样) 或 [Redis](#️-redis-模式快速采样) 章节配置真实采样。

---

## 🧭 项目背景与架构

**Open WorkflowGym** 是一个面向桌面 GUI 工作流的 Agent **大规模采样与自动评测**框架。它在云桌面（Ubuntu / Windows）上驱动多模态大模型，通过 `pyautogui` 逐步操作真实桌面应用，自动记录轨迹、产物文件与判分结果。

整个系统分为三层：

| 层级 | 角色 | 说明 |
| --- | --- | --- |
| **调度层** | 你的电脑（Linux / macOS） | 运行 `main.py`，调度任务、调用模型、收集结果 |
| **云桌面层** | 火山引擎 ECS 或远程 Session | Agent 实际操作的 Ubuntu / Windows 桌面 |
| **模型层** | 外部 API | Player（采样 Agent）、Judger（判分，按需） |

一次采样的完整生命周期：

```
任务表(本地 CSV) → 调度器分发 → 分配云桌面 → 截图 → Player 决策动作
        → 云桌面执行(pyautogui) → 循环至 finished/超步 → 收集产物 → Judger 判分 → 写结果
```

架构示意图见 [`docs/workflowgym_architecture.png`](docs/workflowgym_architecture.png)；Local 模式网络出网（NAT/SNAT）示意见 [`docs/volcengine_nat_gateway_architecture.png`](docs/volcengine_nat_gateway_architecture.png)。

---

## 🔀 两种运行模式

Open WorkflowGym 支持两种云采样方式。**默认是 Local 模式**；使用 `--mode redis`（或 `.env` 里 `SAMPLING_MODE=redis`）进入 Redis 模式。

### 总览：Local vs Redis

| 对比项 | **Local 模式**（默认） | **Redis 模式** |
| --- | --- | --- |
| **适合谁** | 第一次搭建、需要自己管 ECS 实例 | 已部署 WGM 网关、想用共享 Session 池的团队 |
| **云桌面从哪来** | 你自己在火山云创建 ECS 实例池 | WGM 网关背后的共享池（**网关需自行部署**） |
| **镜像准备** | 需从 Hugging Face 获取镜像并导入火山云 | 一般**不需要**，环境已就绪 |
| **本机需要什么** | 火山 `AK` / `SK`、模型 Key、本地 CSV 任务表 | **`WGM_TOKEN`**、模型 Key、本地 CSV 任务表（默认无需本机 AK/SK） |
| **启动参数** | 默认即可（或 `--mode local` / `SAMPLING_MODE=local`） | `--mode redis`（或 `SAMPLING_MODE=redis`） |
| **动作下发** | 本机直连 ECS（Cloud Assistant） | 经 WGM → Cloud Assistant → VM 内 `127.0.0.1` Flask `/action` |
| **截图** | 本机 ECS `GetConsoleScreenshot` | 经网关二进制流（`wgm-direct`）；可选 `WGM_SCREENSHOT_VIA=local` |
| **产物收集** | VM 上 tosutil 上传 | VM 上 tosutil 上传（与 local 一致；可选 `WGM_FILE_COLLECT_VIA=http`） |

**一句话总结：**

- **Local**：自己搭环境 —— 镜像 → 实例 → 数据集 → 采样。
- **Redis**：**先自行部署 WGM 网关** → 配 Token → 数据集 → 直接采样。

### Local 模式在做什么

Local 模式下，你的电脑直接管理火山云 ECS 实例，完整流程分四步：

```
① Hugging Face 获取桌面镜像
        ↓
② 火山云创建 ECS 实例（配置网络出网）
        ↓
③ 准备任务数据集（本地 CSV）
        ↓
④ 运行 main.py 开始采样与判分
```

| 步骤 | 你要做的事 | 关键变量 / 工具 |
| --- | --- | --- |
| ① 镜像 | 查对照表 [`data/image对应huggingface镜像名1.csv`](data/image对应huggingface镜像名1.csv) → 按**镜像名称**从 HF 下载 → 导入火山云 → 把**原始镜像** ID 写入任务 CSV | `HF_TOKEN`、`HF_REPO_ID`；详见 [准备镜像](#1-准备镜像) |
| ② 实例 | 批量创建 ECS，配置 NAT/SNAT 让 VM 能访问公网 | `AK`、`SK`、`VOLCENGINE_REGION`；火山云控制台创建实例 |
| ③ 数据集 | 编辑本地 CSV 任务表 | `SOURCE_CSV_PATH` |
| ④ 采样 | 配置 Player（和按需 Judger），运行 `main.py` | `RUNNER_*`、`PLAYER`、`SAMPLE_NUM`、`STEP_NUM` |

> **小结：** 适合从零搭建。前期步骤多，但实例完全由你控制，不依赖外部 Session 服务。

### Redis 模式在做什么

Redis 模式连接**远程 Session 网关**（WGM）。网关负责 Session 分配、动作转发与截图；其背后的云桌面共享池由网关侧维护，采样端**不需要**在本机 discover ECS 或导入镜像。

> **重要：WGM 网关不在本仓库内。** 本仓库只提供连接 WGM 的**客户端**（`envs/wgm_client.py` 等）。使用前需**自行部署** WGM 服务（含 Redis 租约、实例池、监控门户等），并将 `WGM_API_BASE` 指向你的网关地址。下文中的门户 URL 仅为示例，请替换为实际部署地址。

```
① 自行部署 WGM 网关 + 实例池
        ↓
② 在网关门户注册 → 等待审批 → 创建自己的 Token
        ↓
③ 本机配置 Token + 模型 Key + 本地 CSV 任务表
        ↓
④ python main.py --mode redis
        ↓
⑤ 网关分配 Session → 自动初始化 → 采样 → 释放
```

| 步骤 | 你要做的事 | 关键变量 |
| --- | --- | --- |
| ① 部署网关 | **自行搭建** WGM 服务与实例池（本仓库不包含服务端） | `WGM_API_BASE` |
| ② 获取凭证 | 打开你的网关门户 → **注册** → 等待审批通过 → 登录后**创建自己的 Token** | `WGM_TOKEN` |
| ③ 配置 | 填写 `.env`：Token、Player、`SOURCE_CSV_PATH`（默认无需本机 AK/SK） | `WGM_TOKEN`、`WGM_API_BASE`、`RUNNER_*` |
| ④ 启动 | `--mode redis`（`.env` 已设 `SAMPLING_MODE=redis` 时可省略） | `SAMPLING_MODE=redis`（兼容 `LEASE_BACKEND=redis`） |
| ⑤ 等待 | 程序自动 acquire → prepare → 采样 → release | `LEASE_TTL_SECONDS` |

Redis 模式下：

- **步内动作**经 WGM → Cloud Assistant → VM 内 `127.0.0.1` Flask `/action`（门户操作轨迹里记为 `run_action`）。
- **截图**经网关 `POST .../screenshot/stream`（原始 PNG/JPEG），本机**只需 `WGM_TOKEN`**。仅当显式 `WGM_SCREENSHOT_VIA=local` 时才走本机火山 SDK（此时需要 `AK`/`SK`）。
- **产物收集**与 local 相同：VM 上 tosutil 上传；仅当显式 `WGM_FILE_COLLECT_VIA=http` 时才优先 Flask `/file`。

> **小结：** 适合已部署 WGM 的团队。采样端配置少、开跑快；**前提是 WGM 网关与实例池已由你或团队自行搭建并可用**。

### 怎么选

```
需要从零搭建云桌面、自己管实例？
  └─ 是 → Local 模式（默认）
  └─ 否，想用共享 Session 池？
         └─ 是 → 先自行部署 WGM 网关 → 在门户注册并创建 Token → Redis 模式
         └─ 否 → 先走 Local 模式
```

---

## 📦 零基础安装

以下步骤两种模式**通用**，按顺序做即可。

### 环境要求

- Python >= 3.10
- 推荐 macOS / Linux 作为调度机
- 能访问火山云控制台（Local 模式需要；Redis 模式默认只需 `WGM_TOKEN`，但**需先自行部署 WGM 网关**）

### 安装依赖

```bash
git clone <repo-url> open_workflowgym
cd open_workflowgym

python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env
```

### 编辑并加载配置

用文本编辑器打开 `.env`，把需要的变量填进去（**只填变量名对应的值，不要提交到 Git**）。每次开新终端都要重新加载：

```bash
set -a && source .env && set +a
```

> **提示：** 也可以把常用变量写进 `~/.zshrc` 或 `~/.bashrc`，但 README 不会展示任何具体取值；请自行向管理员或控制台获取。

### 任务来源说明

任务表统一从**本地 CSV** 读取；采样结果也写回本地 CSV（`output/.../report/samples.csv`）。

| 优先级 | 条件 | 行为 |
| --- | --- | --- |
| 1 | `--task-replay-db` 已设 | 从 SQLite 状态库回放 |
| 2 | 默认 | 从本地 `SOURCE_CSV_PATH`（示例 `data/task.csv`）读任务 |

**最小配置：**

```bash
SOURCE_CSV_PATH=data/task.csv
```

也可在命令行显式指定：`--source-csv-path data/task.csv`

---

## 🖥️ Local 模式：从零到采样

### 1. 准备镜像

Local 模式需要带 GUI 的桌面镜像。HF 上按**镜像名称**下载，任务 CSV 的 `image` 列填火山侧 `image-xxx` ID。对照关系见 [`data/image对应huggingface镜像名1.csv`](data/image对应huggingface镜像名1.csv)：

| 列名 | 说明 |
| --- | --- |
| `原始镜像` | 火山镜像 ID（`image-...`），填入任务 CSV 的 `image` 列 |
| `镜像名称` | 可读名称；**在 Hugging Face 上按此列查找并下载** |
| `镜像的大小` | 体积参考（GiB） |
| `huggingface上对应的镜像名和目录` | HF 仓内路径（若已填写可直接定位） |

**推荐流程：**

1. 根据任务所需软件，在对照表中找到对应的 `镜像名称`
2. 在 [Hugging Face](https://huggingface.co/)（`HF_REPO_ID`）按 `镜像名称` 下载镜像文件
3. 在[火山云控制台](https://console.volcengine.com/)导入为自定义镜像
4. 用火山返回的镜像 ID，替换 [`data/task.csv`](data/task.csv) 中 `image` 列的原有值
5. 创建 ECS 时 `--image-id` 使用同一 ID（见 [创建 ECS 实例](#2-创建-ecs-实例)）

若任务 CSV 的 `image` 列已是有效火山镜像 ID，可跳过下载，直接进入 [创建 ECS 实例](#2-创建-ecs-实例)。普通用户流程：**查对照表 → 按镜像名下载 → 导入火山 → 更新任务 CSV**。

### 2. 创建 ECS 实例

1. 在 [IAM 密钥管理](https://console.volcengine.com/iam/keymanage/) 申请 `AK` / `SK`，写入 `.env`
2. 在[火山云控制台](https://console.volcengine.com/)用对照表中的「原始镜像」ID 创建 ECS 实例（数量建议 ≥ `MAX_WORKERS`）；Windows 实例需设置登录密码
3. **配置公网出网（SNAT）**：实例所在子网需能访问互联网（模型 API、TOS 上传等）。控制台路径：EIP → NAT 网关 → SNAT 规则。详见 [火山 SNAT 文档](https://docs.volcengine.com/docs/6404/198717?lang=zh)。
4. 确认实例状态为 **RUNNING**，且已安装 Cloud Assistant。

已有实例可跳过创建，直接指定：

```bash
INSTANCE_IDS=<实例ID1>,<实例ID2>
```

### 3. 准备任务数据集

编辑 [`data/task.csv`](data/task.csv)（或自己的 CSV，通过 `SOURCE_CSV_PATH` 指定）。关键列：

| 列名 | 说明 |
| --- | --- |
| `id` | 任务唯一 ID |
| `题目` | 任务 prompt |
| `image` | ECS 镜像 ID（须为真实 ID，勿用占位符 `image-demo`） |
| `系统类型` / `platform` | `ubuntu` 或 `windows` |
| `输入文件路径` / `输出文件路径` | VM 内目录 |
| `final_answer文件名` | 期望产物文件名 |
| `metric_type` | `规则判分` / `Rubrics` / `image-llm` 等 |

### 4. 配置 `.env`（Local）

主要填写：`AK`、`SK`、`RUNNER_*`、任务来源（`SOURCE_CSV_PATH`）。Windows 任务另需 `WINDOWS_LOGIN_PASSWORD`；LLM 判分另需 `JUDGE_*`。完整变量见 [配置参考](#️-配置参考) 及 [`.env.example`](.env.example)。

### 5. 启动采样（Local）

**推荐首次流程：**

```bash
# 1. 本地冒烟（必做）
ENABLE_REAL_CLOUD=false python main.py \
  --dry-run local --source-csv-path data/task.csv \
  --player dummy --stepNum 1 --max-workers 1

# 2. 单任务试跑
python main.py --id <任务ID> --player kimi --stepNum 40 --max-workers 1

# 3. 确认 output/.../score.json 正常后批量采样
python main.py --player kimi --max-workers 2
```

Local 模式**不需要**加 `--mode`（默认为 `local`）。

### 6. Local 检查清单

- [ ] Python 依赖已安装，`.env` 已加载
- [ ] `AK` / `SK` 有效
- [ ] 已查 [`data/image对应huggingface镜像名1.csv`](data/image对应huggingface镜像名1.csv)，镜像 ID 与任务 CSV `image` 列一致
- [ ] ECS 实例 RUNNING，数量 ≥ `MAX_WORKERS`
- [ ] 子网 SNAT 已配置，VM 可出网
- [ ] 任务 CSV 已准备（`SOURCE_CSV_PATH` 或 `--source-csv-path`）
- [ ] Player Key 已配置；LLM 判分任务已配 `JUDGE_*`
- [ ] Windows 任务已设 `WINDOWS_LOGIN_PASSWORD`
- [ ] 本地冒烟已通过

---

## ☁️ Redis 模式：快速采样

### 1. 前提

- 本机已按 [零基础安装](#-零基础安装) 完成安装
- **你已自行部署 WGM 网关**，且实例池可用（本仓库不包含 WGM 服务端）
- 你已通过网关门户拿到可用的 `WGM_TOKEN`（见下方）

### 2. 注册并创建 Token

Redis 模式访问共享实例，需要先在**你的 WGM 网关门户**完成注册审批，再创建自己的 Token：

1. 打开你的 WGM 门户（示例：`http://118.145.252.36:8080/`，请替换为实际 `WGM_API_BASE`）
2. 点击 **注册**，填写账号信息并提交
3. **等待审批通过**（审批前无法创建 Token）
4. 登录后创建自己的访问 Token
5. 将 Token 写入本机 `.env` 的 `WGM_TOKEN`（**不要**把 Token 提交到 Git）

门户也可查看实例占用情况（总实例数、空闲/占用、占用者等），便于确认池子是否有空闲机。

### 3. 配置 `.env`（Redis）

主要填写：`WGM_TOKEN`、`RUNNER_*`、`SOURCE_CSV_PATH`。完整变量见 [配置参考](#️-配置参考)。**默认不需要本机火山 `AK`/`SK`。**

#### 截图走哪条路（重要）

| 配置 | 截图路径 | 是否需要本机 `AK`/`SK` |
| --- | --- | --- |
| **默认**（不设或 `WGM_SCREENSHOT_VIA=wgm-direct`） | 本机 → WGM → `GetConsoleScreenshot` → **二进制流**返回 | **不需要**（只需 `WGM_TOKEN`） |
| `WGM_SCREENSHOT_VIA=pyautogui` | 本机 → WGM → `run-action`(pyautogui) → PNG base64 回传 | **不需要**（只需 `WGM_TOKEN`） |
| `WGM_SCREENSHOT_VIA=local` | 本机 → 火山 ECS `GetConsoleScreenshot` | 需要 |

WGM 截图默认协议：

```text
POST /api/v1/sessions/{lease_id}/screenshot/stream
Accept: image/png
Body: {"ttl_seconds": N}
→ 200，Content-Type: image/png|jpeg，body = 原始图片字节
```

可选变量：`WGM_SCREENSHOT_FORMAT=stream|base64`、`WGM_SCREENSHOT_STREAM_PATH`、`WGM_SCREENSHOT_FALLBACK_BASE64`（stream 不可用时回退 JSON base64）。

> 门户「实例操作轨迹」里：步内 GUI 动作为 `run_action`；WGM 截图会出现大量 `screenshot`（含稳定检测连拍），可用页面过滤查看 `run_action`。

### 4. 启动采样（Redis）

将 `--wgm-api-base` 换成**你自行部署**的 WGM 网关地址：

```bash
set -a && source .env && set +a

python main.py \
  --mode redis \
  --wgm-api-base http://118.145.252.36:8080 \
  --lease-ttl-seconds 3600 \
  --max-workers 2 \
  --player kimi \
  --sampleNum 3 \
  --stepNum 100 \
  --id 175 176
```

启动日志中应出现类似：

```text
跳过本机 ECS discover（lease_backend=redis） screenshot=wgm-direct
online 模式: api_base=http://118.145.252.36:8080 ... action=wgm-direct screenshot=wgm-direct
```

**注意：**

- Redis 模式**不会**在本机 discover ECS 实例列表；实例由网关分配。
- 并发截图过多可能触发火山 `FlowLimitExceeded`（网关侧 `GetConsoleScreenshot` 限流）；可降 `MAX_WORKERS` 或错开采样。

### 5. 中文输入（Windows / Linux）

非 ASCII 文本（如中文）**不走键盘逐字输入**，统一改为剪贴板粘贴后再 `Ctrl+V`：

| 平台 | 落剪贴板方式 |
| --- | --- |
| **Linux** | 优先 `xsel` → `xclip`，失败再用 `pyperclip` |
| **Windows** | `xsel`/`xclip` 不可用时回退 `pyperclip`；镜像侧 shim 常映射到 PowerShell `Set-Clipboard` |

ASCII 仍用 `pyautogui.write`。粘贴超时一般不自动重试，避免「李明李明」双贴。

### 6. Redis 检查清单

- [ ] **WGM 网关已自行部署**，`WGM_API_BASE` 可访问
- [ ] 已在网关门户注册并完成审批
- [ ] 已创建自己的 Token，并写入 `WGM_TOKEN`
- [ ] Player Key 已配置
- [ ] 任务 CSV 已准备（`SOURCE_CSV_PATH` 或 `--source-csv-path`）
- [ ] 截图走网关时只需 `WGM_TOKEN`（若设了 `WGM_SCREENSHOT_VIA=local` 则另需本机 `AK`/`SK`）
- [ ] 启动命令含 `--mode redis`（或 `.env` 中 `SAMPLING_MODE=redis`）
- [ ] 网关备机已配置 tosutil（产物上传）；仅当使用 `WGM_FILE_COLLECT_VIA=http` 时才需要 Flask `/file`

---

## ⚙️ 配置参考

完整变量模板见 [`.env.example`](.env.example)。以下为常用变量说明（**仅变量名，不含具体取值**）。

### 火山引擎

| 变量 | 说明 |
| --- | --- |
| `AK` / `SK` | 火山 OpenAPI 密钥 |
| `VOLCENGINE_REGION` | 区域，如 `cn-guangzhou` |
| `ENABLE_REAL_CLOUD` | 本地冒烟时设 `false` |
| `WINDOWS_LOGIN_PASSWORD` | Windows 桌面登录密码 |
| `INSTANCE_IDS` | 指定已有实例（Local 模式） |

### Player（采样 Agent）

所有 Player 优先读取统一的 `RUNNER_*` 三元组：

| 变量 | 说明 |
| --- | --- |
| `PLAYER` | 采样 Agent 名称（`gpt` / `kimi` / `claude` / `dummy` 等） |
| `RUNNER_API_KEY` | API Key |
| `RUNNER_BASE_URL` | 接口地址（可选） |
| `RUNNER_MODEL` | 模型名（可选） |

> 内置 Player：`dummy`、`gpt`、`kimi`、`kimi2.6`、`claude` 等。切换 Player 时通常只需改 `PLAYER` 和对应的 Key / 模型名。

### 裁判员（Judger）

涉及 LLM 判分（`规则判分+LLM-as-judge`、`Rubrics`、`image-llm` 等）时需配置，与 Player **独立**：

| 变量 | 说明 |
| --- | --- |
| `JUDGE_API_KEY` | Judger API Key |
| `JUDGE_BASE_URL` | OpenAI 兼容接口地址 |
| `JUDGE_MODEL` | 模型名 |

> 任务全部为「规则判分」（产物文件字节比对）时**无需配置 Judger**。判分策略详情见 [`docs/judger.md`](docs/judger.md)。

### Redis / WGM 网关

> **WGM 网关需自行部署。** 本仓库仅含客户端；`WGM_API_BASE`、门户 URL、Token 审批流程均取决于你的网关部署。

| 变量 | 说明 |
| --- | --- |
| `SAMPLING_MODE` | `local`（默认）或 `redis` / `online`（`online` 等同 `redis`） |
| `LEASE_BACKEND` | 兼容旧名；未设 `SAMPLING_MODE` 时生效，取值同上 |
| `WGM_TOKEN` | Redis 模式必填；在**你的** WGM 网关门户注册审批后自行创建 |
| `WGM_API_BASE` / `WGM_HOST` | **你部署的** WGM 网关 API 地址（示例 `http://118.145.252.36:8080`，请替换） |
| `LEASE_TTL_SECONDS` | Session 租约 TTL（秒） |
| `WGM_SCREENSHOT_VIA` | `wgm-direct`：网关截图流；`pyautogui`：网关 run-action 截图（两者仅需 Token）；`local`：本机 ECS 截图（需 AK/SK） |
| `WGM_SCREENSHOT_FORMAT` | `stream`（原始 PNG/JPEG body）或 `base64`（JSON `screenshot_base64`） |
| `WGM_SCREENSHOT_STREAM_PATH` | 流式截图路径模板，默认 `/api/v1/sessions/{lease_id}/screenshot/stream` |
| `WGM_SCREENSHOT_FALLBACK_BASE64` | stream 返回 404/501 时是否回退 base64 JSON；默认 `true` |

### Hugging Face 镜像（Local 模式）

| 变量 / 文件 | 说明 |
| --- | --- |
| `HF_TOKEN` | Hugging Face 访问 Token |
| `HF_REPO_ID` | 镜像 Dataset 仓库 ID |
| `data/image对应huggingface镜像名1.csv` | 镜像 ID（`原始镜像`）与 HF 镜像名（`镜像名称`）对照表 |

### TOS 产物上传（文件类任务）

Agent 在 VM 上产出的文件，由 VM 侧 tosutil 上传；本地判分通过 HTTPS 下载。

| 变量 | 说明 |
| --- | --- |
| `TOS_UPLOAD_BUCKET` | 上传桶 |
| `TOS_AK` / `TOS_SK` | TOS 凭证（默认可回退 `AK` / `SK`） |
| `TOS_PRESIGN_VALID_PERIOD` | Presign 有效期，默认 `24h` |

> 调度机通常**无需手动安装 tosutil**；仅在 URL 仍为 `tos://` 时会自动下载兜底。

### 采样参数

| 变量 / 参数 | 说明 | 默认 |
| --- | --- | --- |
| `SAMPLE_NUM` / `--sampleNum` | 每任务采样次数 | `1` |
| `STEP_NUM` / `--stepNum` | 每 sample 最大步数 | `400` |
| `MAX_WORKERS` / `--max-workers` | 跨任务并发 | `2` |
| `--id` | 指定任务 ID（可多个） | 全部 |
| `--source-csv-path` | 本地任务 CSV | 示例 `data/task.csv` |
| `--dry-run` | 本地验证 | — |
| `--resume-running-samples` | 断点续跑 | `false` |

### 输出目录

```
output/sample_<player>_<sampleNum>_step_<stepNum>_<时间戳>/
├── report/samples.csv       # 结果汇总
├── workflowgym_state.db     # 断点恢复
├── <任务ID>/
│   └── sample_1/
│       ├── traj.json        # 完整轨迹
│       ├── score.json       # 判分结果
│       ├── screenshot_*.png # 逐步截图
│       ├── production/      # Agent 产物
│       └── gt_production/   # 标准答案
```

> 按一次 `Ctrl+C` 有序退出；连续两次强制中断。

---

## 📁 项目结构

| 路径 | 说明 |
| --- | --- |
| `main.py` | 启动入口 |
| `config.py` | 命令行参数与环境变量解析 |
| `scheduler.py` / `sampler.py` | 任务调度与采样循环 |
| `agents/` | Player 适配器（GPT、Kimi、Claude、dummy 等） |
| `envs/` | 云实例池、租约后端、WGM 网关客户端、远程命令、产物收集 |
| `executors/` | 本地执行器 |
| `judgers/` | 自动判分（规则、Rubrics、image-llm、LLM-as-judge 等） |
| `data/task.csv` | 示例本地任务表（也可通过 `SOURCE_CSV_PATH` 指定其他 CSV） |
| `data/image对应huggingface镜像名1.csv` | **镜像 ID ↔ Hugging Face 镜像名** 对照表（Local 模式必备） |
| `docs/` | 快速上手、判分说明、架构图等文档 |
| `scripts/` | 镜像烘焙等辅助脚本 |
| `.env.example` | 环境变量模板 |

更多上手细节见 [`docs/quickstart.md`](docs/quickstart.md)。

---

## ❓ 常见问题

| 现象 | 可能原因 | 处理 |
| --- | --- | --- |
| 日志显示「从本地 CSV 加载」但任务为空 | `SOURCE_CSV_PATH` 路径错误或 CSV 无有效行 | 检查 `--source-csv-path` 与 CSV 内容 |
| `lease_backend=redis 需要设置 WGM_TOKEN` | 未配置 Token，或 WGM 网关未部署/不可达 | 确认 WGM 已自行部署且 `WGM_API_BASE` 可访问；在网关门户注册 → 等待审批 → 创建 Token 写入 `WGM_TOKEN` |
| `无法解析任务平台` / `image-demo` | 占位镜像 ID 或 CSV 未填对照表中的真实 ID | 查 [`data/image对应huggingface镜像名1.csv`](data/image对应huggingface镜像名1.csv) 填 `原始镜像` 到 `image` 列 |
| `production保存失败: tosutil` | presign 失败 | 检查 VM 出网（SNAT）与 TOS 凭证 |
| `缺少 JUDGE_BASE_URL` | 未配置 Judger | 配置 `JUDGE_*`；或先用「规则判分」任务验证 |
| 采样几步就结束 | Agent 过早 `finished` | 增大 `--stepNum`；换 Player；检查 prompt |
| VM 无法访问公网 | 未配置 SNAT | Local 模式按 [创建 ECS 实例](#2-创建-ecs-实例) 配置 NAT |
| Redis 产物 missing | Agent 未生成文件，或 tosutil 上传失败 | 看 `sample_log.json` / `score.json`；确认备机 tosutil 与 TOS 凭证；可选 `WGM_FILE_COLLECT_VIA=http` |
| Windows 任务无法登录 | 缺桌面密码 | 设置 `WINDOWS_LOGIN_PASSWORD` |
| `FlowLimitExceeded` / 截图限流 | 并发 `GetConsoleScreenshot` 过多 | 降低 `--max-workers`；或错开任务；限流与 Player 无关 |
| 门户操作轨迹几乎只有 `screenshot` | 稳定检测连拍刷屏，或脚本字段过大被跳过 | 用页面过滤看 `run_action`；确认网关已部署最新 ops 日志逻辑；`run_action` 失败（如 lease 不匹配）不会入轨 |
| Windows 中文变成乱码 / 粘贴失败 | 剪贴板路径与 Linux 不同 | Windows 走 PowerShell `Set-Clipboard`；确认网关桌面侧脚本已更新；勿对中文用逐键 `write` |

---

## 🤝 贡献

欢迎各种形式的贡献！提交 PR 前请阅读 [CONTRIBUTING.md](CONTRIBUTING.md)：

- Python >= 3.10，使用 type hints 与 `from __future__ import annotations`
- 云相关逻辑集中在 `envs/`，Agent 逻辑集中在 `agents/`，判分逻辑集中在 `judgers/`
- 新增 Agent：在 `agents/factory.py` 注册，并实现 `BaseAgentAdapter` 接口
- 新增判分策略：在 `judgers/agent.py` 的 `JudgerAgent.judge()` 中扩展分支
- 不要提交 `.env`、API Key、`output/` 运行产物

---

## 📄 License

Apache License 2.0 — 详见 [LICENSE](LICENSE)。
