#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PID_FILE="$ROOT/output/gui_image_bake/gui_bake.pid"

if [[ ! -f "$PID_FILE" ]]; then
  echo "未找到后台 GUI 镜像烘焙任务"
  exit 1
fi

PID="$(cat "$PID_FILE")"
if kill -0 "$PID" 2>/dev/null; then
  kill "$PID"
  echo "已停止后台 GUI 镜像烘焙任务: pid=$PID"
else
  echo "后台任务已不在运行: pid=$PID"
fi

rm -f "$PID_FILE"
