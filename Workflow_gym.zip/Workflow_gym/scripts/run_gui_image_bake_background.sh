#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if [[ -f "$ROOT/.env" ]]; then
  set -a
  # shellcheck disable=SC1091
  source "$ROOT/.env"
  set +a
fi

export WORKFLOWGYM_RUN_GUI_IMAGE_PREPARE=1
export GUI_IMAGE_PREPARE_MAX_WORKERS="${GUI_IMAGE_PREPARE_MAX_WORKERS:-20}"

# 换盘 + 重装 Cloud Assistant + 重启后恢复较慢，默认加长等待（.env 中可覆盖）
export CLOUD_ASSISTANT_WAIT_TIMEOUT_SECONDS="${CLOUD_ASSISTANT_WAIT_TIMEOUT_SECONDS:-900}"
export CLOUD_ASSISTANT_POLL_INTERVAL_SECONDS="${CLOUD_ASSISTANT_POLL_INTERVAL_SECONDS:-15}"
export CLOUD_ASSISTANT_REBOOT_SETTLE_SECONDS="${CLOUD_ASSISTANT_REBOOT_SETTLE_SECONDS:-30}"
export CLOUD_ASSISTANT_MAX_REBOOT_ATTEMPTS="${CLOUD_ASSISTANT_MAX_REBOOT_ATTEMPTS:-2}"
export INSTANCE_START_TIMEOUT_SECONDS="${INSTANCE_START_TIMEOUT_SECONDS:-900}"

LOG_DIR="$ROOT/output/gui_image_bake"
mkdir -p "$LOG_DIR"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
LOG_FILE="$LOG_DIR/gui_bake_${TIMESTAMP}.log"
PID_FILE="$LOG_DIR/gui_bake.pid"
LATEST_LOG_LINK="$LOG_DIR/gui_bake_latest.log"

if [[ -f "$PID_FILE" ]]; then
  OLD_PID="$(cat "$PID_FILE")"
  if kill -0 "$OLD_PID" 2>/dev/null; then
    echo "已有后台 GUI 镜像烘焙任务在运行: pid=$OLD_PID"
    echo "查看日志: tail -f $LATEST_LOG_LINK"
    exit 1
  fi
fi

nohup python3 -m unittest \
  tests.test_guangzhou_ubuntu_gui_image_prepare.TestGuangzhouUbuntuGuiImagePrepare.test_prepare_ubuntu_images_to_gui \
  -v >>"$LOG_FILE" 2>&1 &

NEW_PID=$!
echo "$NEW_PID" >"$PID_FILE"
ln -sf "$LOG_FILE" "$LATEST_LOG_LINK"

echo "后台 GUI 镜像烘焙已启动（关闭终端后仍会继续运行）"
echo "  pid: $NEW_PID"
echo "  log: $LOG_FILE"
echo "  实时查看: tail -f $LATEST_LOG_LINK"
echo "  停止任务: kill $NEW_PID"
