from __future__ import annotations

import concurrent.futures
import datetime as dt
import json
import os
from dataclasses import dataclass
from typing import Any, Callable, TYPE_CHECKING
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from .records import SampleJob, now_text
from .state_store import StateStore

if TYPE_CHECKING:
    from .envs.volcengine_env import VolcengineEnv


@dataclass(frozen=True)
class LeaseRenewContext:
    lease_id: str
    state_db_path: str
    ttl_seconds: int = 3600
    instance_id: str = ""
    lease_backend: str = "local"
    wgm_api_base: str = ""
    wgm_token: str = ""


def lease_heartbeat_interval_seconds() -> int:
    return max(60, int(os.getenv("LEASE_HEARTBEAT_INTERVAL_SECONDS", "300")))


def build_lease_renew_context(job: SampleJob) -> LeaseRenewContext | None:
    if not job.lease or not str(job.config.state_db_path or "").strip():
        return None
    return LeaseRenewContext(
        lease_id=job.lease.lease_id,
        state_db_path=job.config.state_db_path,
        ttl_seconds=max(1, int(job.config.lease_ttl_seconds)),
        instance_id=str(job.lease.instance_id or ""),
        lease_backend=str(getattr(job.config, "lease_backend", "local") or "local"),
        wgm_api_base=str(getattr(job.config, "wgm_api_base", "") or os.getenv("WGM_API_BASE") or os.getenv("WGM_HOST") or ""),
        wgm_token=str(getattr(job.config, "wgm_token", "") or os.getenv("WGM_TOKEN") or ""),
    )


def future_expires_text(seconds: int, now: dt.datetime | None = None) -> str:
    current = now or dt.datetime.now()
    return (current + dt.timedelta(seconds=max(1, int(seconds)))).strftime("%Y-%m-%d %H:%M:%S")


def renew_remote_lease(
    api_base: str,
    api_token: str,
    instance_id: str,
    lease_id: str,
    ttl_seconds: int,
    timeout_seconds: float = 30.0,
) -> str | None:
    """Call redisWebBack session renew API; return new expires_at on success."""
    base = str(api_base or "").rstrip("/")
    token = str(api_token or "").strip()
    if not base or not token or not lease_id:
        return None
    body = {"ttl_seconds": max(1, int(ttl_seconds))}
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    paths = [
        f"/api/v1/sessions/{lease_id}/renew",
        "/api/renew-instance",
    ]
    for path in paths:
        payload = body if path.startswith("/api/v1/sessions/") else {
            "instance_id": instance_id,
            "lease_id": lease_id,
            "ttl_seconds": max(1, int(ttl_seconds)),
        }
        request = Request(
            f"{base}{path}",
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        try:
            with urlopen(request, timeout=timeout_seconds) as response:
                raw = response.read().decode("utf-8")
                data = json.loads(raw) if raw else {}
        except HTTPError as exc:
            try:
                raw = exc.read().decode("utf-8")
                data = json.loads(raw) if raw else {}
            except Exception:
                continue
        except (URLError, TimeoutError, json.JSONDecodeError, OSError):
            continue
        if not isinstance(data, dict):
            continue
        if data.get("success"):
            expires = (
                (data.get("expires_at") or "")
                or ((data.get("instance") or {}).get("expires_at") if isinstance(data.get("instance"), dict) else "")
            )
            return str(expires or "") or future_expires_text(ttl_seconds)
        if data.get("code") in (0, "0") and isinstance(data.get("data"), dict):
            expires = str(data["data"].get("expires_at") or "")
            return expires or future_expires_text(ttl_seconds)
    return None


def renew_active_lease(state_db_path: str, lease_id: str, ttl_seconds: int) -> str | None:
    if not state_db_path or not lease_id:
        return None
    return StateStore(state_db_path).renew_lease(lease_id, ttl_seconds)


def renew_lease_from_context(context: LeaseRenewContext | None) -> str | None:
    if context is None:
        return None
    expires_at = renew_active_lease(context.state_db_path, context.lease_id, context.ttl_seconds)
    backend = str(context.lease_backend or "local").strip().lower()
    if backend in ("redis", "wgm", "remote"):
        remote_expires = renew_remote_lease(
            context.wgm_api_base,
            context.wgm_token,
            context.instance_id,
            context.lease_id,
            context.ttl_seconds,
        )
        if remote_expires:
            expires_at = remote_expires
            # Keep SQLite aligned with remote TTL when remote renew succeeds.
            if context.state_db_path:
                StateStore(context.state_db_path).renew_lease(context.lease_id, context.ttl_seconds)
    return expires_at


def model_lease_heartbeat_enabled(model_call_timeout_seconds: int, threshold_seconds: int) -> bool:
    return int(model_call_timeout_seconds) >= max(1, int(threshold_seconds))


def call_with_lease_heartbeat(
    env: VolcengineEnv,
    func: Callable[[], Any],
    poll_seconds: int | None = None,
) -> Any:
    if env.lease_renew_context is None:
        return func()
    interval = max(15, int(poll_seconds or min(lease_heartbeat_interval_seconds(), 60)))
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(func)
        while True:
            try:
                return future.result(timeout=interval)
            except concurrent.futures.TimeoutError:
                env.maybe_renew_lease_heartbeat(force=False)


def flag_init_orphan_lease(job: SampleJob, reason: str) -> None:
    if not job.lease or not str(job.config.state_db_path or "").strip():
        return
    StateStore(job.config.state_db_path).flag_lease_init_orphan(
        job.lease.lease_id,
        job.lease.instance_id,
        job.run_id,
        job.task_id,
        job.sample_index,
        reason,
    )
