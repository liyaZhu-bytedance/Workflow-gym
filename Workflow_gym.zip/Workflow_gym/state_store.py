from __future__ import annotations

import json
import os
import sqlite3
import uuid
from contextlib import contextmanager
from typing import Any, Iterable

from .records import OutboxEvent, json_dumps, new_id, now_text, to_jsonable


class StateStore:
    """SQLite-backed source of truth and durable work queue."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        parent = os.path.dirname(db_path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        self._init_schema()

    @contextmanager
    def connect(self):
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_schema(self) -> None:
        with self.connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS runs (
                    run_id TEXT PRIMARY KEY,
                    config_json TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS tasks (
                    run_id TEXT NOT NULL,
                    task_id TEXT NOT NULL,
                    row_number INTEGER NOT NULL,
                    status TEXT NOT NULL,
                    fields_json TEXT NOT NULL,
                    validation_json TEXT,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (run_id, task_id)
                );

                CREATE TABLE IF NOT EXISTS samples (
                    run_id TEXT NOT NULL,
                    task_id TEXT NOT NULL,
                    sample_index INTEGER NOT NULL,
                    status TEXT NOT NULL,
                    sample_dir TEXT,
                    lease_id TEXT,
                    instance_id TEXT,
                    last_step INTEGER DEFAULT -1,
                    result_json TEXT,
                    heartbeat_at TEXT,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (run_id, task_id, sample_index)
                );

                CREATE TABLE IF NOT EXISTS instance_leases (
                    run_id TEXT NOT NULL,
                    lease_id TEXT PRIMARY KEY,
                    instance_id TEXT NOT NULL,
                    task_id TEXT NOT NULL,
                    sample_index INTEGER NOT NULL,
                    status TEXT NOT NULL,
                    acquired_at TEXT NOT NULL,
                    expires_at TEXT,
                    released_at TEXT,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS outbox_events (
                    event_id TEXT PRIMARY KEY,
                    run_id TEXT NOT NULL,
                    schema_version INTEGER NOT NULL,
                    event_type TEXT NOT NULL,
                    task_id TEXT,
                    sample_index INTEGER,
                    idempotency_key TEXT UNIQUE,
                    payload_json TEXT NOT NULL,
                    status TEXT NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS inbox_claims (
                    claim_id TEXT PRIMARY KEY,
                    event_id TEXT NOT NULL,
                    worker_id TEXT NOT NULL,
                    status TEXT NOT NULL,
                    claimed_at TEXT NOT NULL,
                    heartbeat_at TEXT NOT NULL,
                    claim_timeout_seconds INTEGER NOT NULL
                );

                CREATE TABLE IF NOT EXISTS event_results (
                    result_id TEXT PRIMARY KEY,
                    event_id TEXT NOT NULL,
                    run_id TEXT NOT NULL,
                    status TEXT NOT NULL,
                    error_category TEXT,
                    error TEXT,
                    result_json TEXT,
                    created_at TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_outbox_status_type
                    ON outbox_events(status, event_type, created_at);
                CREATE INDEX IF NOT EXISTS idx_claim_event
                    ON inbox_claims(event_id, status);
                CREATE INDEX IF NOT EXISTS idx_samples_status
                    ON samples(status, updated_at);
                """
            )

    def create_run(self, run_id: str, config: Any) -> None:
        timestamp = now_text()
        with self.connect() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO runs(run_id, config_json, status, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (run_id, json_dumps(config), "running", timestamp, timestamp),
            )

    def upsert_task(self, run_id: str, task_id: str, row_number: int, status: str, fields: dict[str, Any]) -> None:
        with self.connect() as conn:
            conn.execute(
                """
                INSERT INTO tasks(run_id, task_id, row_number, status, fields_json, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(run_id, task_id) DO UPDATE SET
                    row_number=excluded.row_number,
                    status=excluded.status,
                    fields_json=excluded.fields_json,
                    updated_at=excluded.updated_at
                """,
                (run_id, task_id, row_number, status, json_dumps(fields), now_text()),
            )

    def update_task_status(self, run_id: str, task_id: str, status: str, validation: Any = None) -> None:
        validation_json = json_dumps(validation) if validation is not None else None
        with self.connect() as conn:
            if validation_json is None:
                conn.execute(
                    "UPDATE tasks SET status=?, updated_at=? WHERE run_id=? AND task_id=?",
                    (status, now_text(), run_id, task_id),
                )
            else:
                conn.execute(
                    "UPDATE tasks SET status=?, validation_json=?, updated_at=? WHERE run_id=? AND task_id=?",
                    (status, validation_json, now_text(), run_id, task_id),
                )

    def upsert_sample(self, run_id: str, task_id: str, sample_index: int, status: str, **fields: Any) -> None:
        current = self.get_sample(run_id, task_id, sample_index)
        merged = dict(current or {})
        merged.update(fields)
        with self.connect() as conn:
            conn.execute(
                """
                INSERT INTO samples(
                    run_id, task_id, sample_index, status, sample_dir, lease_id,
                    instance_id, last_step, result_json, heartbeat_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(run_id, task_id, sample_index) DO UPDATE SET
                    status=excluded.status,
                    sample_dir=excluded.sample_dir,
                    lease_id=excluded.lease_id,
                    instance_id=excluded.instance_id,
                    last_step=excluded.last_step,
                    result_json=excluded.result_json,
                    heartbeat_at=excluded.heartbeat_at,
                    updated_at=excluded.updated_at
                """,
                (
                    run_id,
                    task_id,
                    sample_index,
                    status,
                    merged.get("sample_dir"),
                    merged.get("lease_id"),
                    merged.get("instance_id"),
                    parse_int(merged.get("last_step"), -1),
                    json_dumps(merged.get("result")) if merged.get("result") is not None else merged.get("result_json"),
                    merged.get("heartbeat_at"),
                    now_text(),
                ),
            )

    def get_sample(self, run_id: str, task_id: str, sample_index: int) -> dict[str, Any] | None:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT * FROM samples WHERE run_id=? AND task_id=? AND sample_index=?",
                (run_id, task_id, sample_index),
            ).fetchone()
            return dict(row) if row else None

    def upsert_lease(self, lease: Any) -> None:
        data = to_jsonable(lease)
        with self.connect() as conn:
            conn.execute(
                """
                INSERT INTO instance_leases(
                    run_id, lease_id, instance_id, task_id, sample_index, status,
                    acquired_at, expires_at, released_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(lease_id) DO UPDATE SET
                    status=excluded.status,
                    expires_at=excluded.expires_at,
                    released_at=excluded.released_at,
                    updated_at=excluded.updated_at
                """,
                (
                    data["run_id"],
                    data["lease_id"],
                    data["instance_id"],
                    data["task_id"],
                    data["sample_index"],
                    data["status"],
                    data["acquired_at"],
                    data.get("expires_at", ""),
                    data.get("released_at", ""),
                    now_text(),
                ),
            )

    def get_lease(self, lease_id: str) -> dict[str, Any] | None:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT * FROM instance_leases WHERE lease_id=?",
                (lease_id,),
            ).fetchone()
            return dict(row) if row else None

    def renew_lease(self, lease_id: str, ttl_seconds: int) -> str | None:
        from .lease_renewal import future_expires_text

        new_expires_at = future_expires_text(ttl_seconds)
        with self.connect() as conn:
            row = conn.execute(
                "SELECT lease_id, released_at FROM instance_leases WHERE lease_id=?",
                (lease_id,),
            ).fetchone()
            if row is None or str(row["released_at"] or "").strip():
                return None
            conn.execute(
                """
                UPDATE instance_leases
                SET expires_at=?, updated_at=?
                WHERE lease_id=? AND (released_at IS NULL OR released_at='')
                """,
                (new_expires_at, now_text(), lease_id),
            )
        return new_expires_at

    LEASE_STATUS_INIT_ORPHAN = "init_orphan"
    LEASE_STATUS_HUNG_WORKER = "hung_worker"

    def flag_lease_init_orphan(
        self,
        lease_id: str,
        instance_id: str,
        run_id: str,
        task_id: str,
        sample_index: int,
        reason: str,
    ) -> None:
        self._flag_lease_special_status(
            lease_id,
            instance_id,
            run_id,
            task_id,
            sample_index,
            self.LEASE_STATUS_INIT_ORPHAN,
            reason,
        )

    def flag_lease_hung_worker(
        self,
        lease_id: str,
        instance_id: str,
        run_id: str,
        task_id: str,
        sample_index: int,
        reason: str,
    ) -> None:
        self._flag_lease_special_status(
            lease_id,
            instance_id,
            run_id,
            task_id,
            sample_index,
            self.LEASE_STATUS_HUNG_WORKER,
            reason,
        )

    def _flag_lease_special_status(
        self,
        lease_id: str,
        instance_id: str,
        run_id: str,
        task_id: str,
        sample_index: int,
        status: str,
        reason: str,
    ) -> None:
        timestamp = now_text()
        with self.connect() as conn:
            conn.execute(
                """
                UPDATE instance_leases
                SET status=?, updated_at=?
                WHERE lease_id=? AND (released_at IS NULL OR released_at='')
                """,
                (status, timestamp, lease_id),
            )
            conn.execute(
                """
                INSERT INTO event_results(result_id, event_id, run_id, status, error, result_json, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    new_id("lease-flag"),
                    lease_id,
                    run_id,
                    status,
                    reason,
                    json_dumps(
                        {
                            "lease_id": lease_id,
                            "instance_id": instance_id,
                            "task_id": task_id,
                            "sample_index": sample_index,
                            "reason": reason,
                        }
                    ),
                    timestamp,
                ),
            )

    def lease_requires_quarantine(self, lease_id: str) -> bool:
        row = self.get_lease(lease_id)
        if not row:
            return False
        status = str(row.get("status") or "").strip()
        return status in (
            self.LEASE_STATUS_INIT_ORPHAN,
            self.LEASE_STATUS_HUNG_WORKER,
            "quarantined",
        )

    def blocked_instance_ids(self, instance_ids: list[str]) -> set[str]:
        # 快照，避免并发 append instance_ids 导致占位符数量与绑定参数不一致
        ids = [str(x) for x in (instance_ids or []) if str(x or "").strip()]
        if not ids:
            return set()
        placeholders = ",".join("?" for _ in ids)
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT DISTINCT instance_id
                FROM instance_leases
                WHERE instance_id IN (%s)
                  AND status IN (?, ?)
                  AND (released_at IS NULL OR released_at='')
                """
                % placeholders,
                (
                    *ids,
                    self.LEASE_STATUS_INIT_ORPHAN,
                    self.LEASE_STATUS_HUNG_WORKER,
                ),
            ).fetchall()
        return {str(row["instance_id"]) for row in rows}

    def add_outbox_event(self, event: OutboxEvent) -> None:
        idempotency_key = event.idempotency_key or event.event_id
        with self.connect() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO outbox_events(
                    event_id, run_id, schema_version, event_type, task_id, sample_index,
                    idempotency_key, payload_json, status, attempts, created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    event.event_id,
                    event.run_id,
                    event.schema_version,
                    event.event_type,
                    event.task_id,
                    event.sample_index,
                    idempotency_key,
                    json_dumps(event.payload),
                    "pending",
                    0,
                    event.created_at,
                    event.created_at,
                ),
            )

    def list_outbox(self, event_types: Iterable[str] | None = None, limit: int = 100) -> list[dict[str, Any]]:
        with self.connect() as conn:
            if event_types:
                placeholders = ",".join("?" for _ in event_types)
                rows = conn.execute(
                    "SELECT * FROM outbox_events WHERE status='pending' AND event_type IN (%s) ORDER BY created_at LIMIT ?"
                    % placeholders,
                    tuple(event_types) + (limit,),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM outbox_events WHERE status='pending' ORDER BY created_at LIMIT ?",
                    (limit,),
                ).fetchall()
        return [self._row_to_event(row) for row in rows]

    def mark_event_done(self, event_id: str) -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE outbox_events SET status='done', updated_at=? WHERE event_id=?",
                (now_text(), event_id),
            )

    def claim_outbox_event(
        self,
        event_types: Iterable[str],
        worker_id: str,
        run_id: str | None = None,
        claim_timeout_seconds: int = 300,
    ) -> dict[str, Any] | None:
        """Claim one pending event for a worker.

        SQLite serializes this short transaction, which is enough for the first
        single-runner implementation.
        """
        with self.connect() as conn:
            placeholders = ",".join("?" for _ in event_types)
            params = list(event_types)
            run_filter = ""
            if run_id:
                run_filter = " AND run_id=?"
                params.append(run_id)
            row = conn.execute(
                "SELECT * FROM outbox_events WHERE status='pending' AND event_type IN (%s)%s ORDER BY created_at LIMIT 1"
                % (placeholders, run_filter),
                tuple(params),
            ).fetchone()
            if not row:
                return None
            claim_id = "claim-%s" % uuid.uuid4().hex
            timestamp = now_text()
            conn.execute(
                "UPDATE outbox_events SET status='claimed', attempts=attempts + 1, updated_at=? WHERE event_id=?",
                (timestamp, row["event_id"]),
            )
            conn.execute(
                """
                INSERT INTO inbox_claims(
                    claim_id, event_id, worker_id, status, claimed_at,
                    heartbeat_at, claim_timeout_seconds
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    claim_id,
                    row["event_id"],
                    worker_id,
                    "running",
                    timestamp,
                    timestamp,
                    claim_timeout_seconds,
                ),
            )
            data = self._row_to_event(row)
            data["claim_id"] = claim_id
            return data

    def heartbeat_claim(self, claim_id: str) -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE inbox_claims SET heartbeat_at=? WHERE claim_id=? AND status='running'",
                (now_text(), claim_id),
            )

    def complete_claim(self, claim_id: str, event_id: str, result: Any = None) -> None:
        result_id = "result-%s" % uuid.uuid4().hex
        timestamp = now_text()
        with self.connect() as conn:
            conn.execute(
                "UPDATE inbox_claims SET status='done', heartbeat_at=? WHERE claim_id=?",
                (timestamp, claim_id),
            )
            conn.execute(
                "UPDATE outbox_events SET status='done', updated_at=? WHERE event_id=?",
                (timestamp, event_id),
            )
            conn.execute(
                """
                INSERT INTO event_results(
                    result_id, event_id, run_id, status, result_json, created_at
                )
                SELECT ?, event_id, run_id, ?, ?, ? FROM outbox_events WHERE event_id=?
                """,
                (result_id, "done", json_dumps(result) if result is not None else None, timestamp, event_id),
            )

    def fail_claim(
        self,
        claim_id: str,
        event_id: str,
        error: str,
        error_category: str = "retryable",
        max_attempts: int = 3,
    ) -> str:
        result_id = "result-%s" % uuid.uuid4().hex
        timestamp = now_text()
        with self.connect() as conn:
            row = conn.execute("SELECT attempts FROM outbox_events WHERE event_id=?", (event_id,)).fetchone()
            attempts = int(row["attempts"] if row else 0)
            event_status = "failed" if attempts >= max_attempts else "pending"
            conn.execute(
                "UPDATE inbox_claims SET status='failed', heartbeat_at=? WHERE claim_id=?",
                (timestamp, claim_id),
            )
            conn.execute(
                "UPDATE outbox_events SET status=?, updated_at=? WHERE event_id=?",
                (event_status, timestamp, event_id),
            )
            conn.execute(
                """
                INSERT INTO event_results(
                    result_id, event_id, run_id, status, error_category, error, created_at
                )
                SELECT ?, event_id, run_id, ?, ?, ?, ? FROM outbox_events WHERE event_id=?
                """,
                (result_id, "failed", error_category, error, timestamp, event_id),
            )
        return event_status

    @staticmethod
    def _row_to_event(row: sqlite3.Row) -> dict[str, Any]:
        data = dict(row)
        data["payload"] = json.loads(data.pop("payload_json"))
        return data


def parse_int(value: Any, default: int) -> int:
    if value is None or value == "":
        return default
    return int(value)

