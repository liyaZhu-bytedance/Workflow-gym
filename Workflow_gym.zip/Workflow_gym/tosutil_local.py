from __future__ import annotations

import os
import platform
import shutil
import stat
import subprocess
import urllib.request
from pathlib import Path

TOSUTIL_DOWNLOAD_BASE = "https://m645b3e1bb36e-mrap.mrap.accesspoint.tos-global.volces.com"
TOSUTIL_DOWNLOAD_URLS: dict[tuple[str, str], str] = {
    ("linux", "amd64"): f"{TOSUTIL_DOWNLOAD_BASE}/linux/amd64/tosutil",
    ("linux", "arm64"): f"{TOSUTIL_DOWNLOAD_BASE}/linux/arm64/tosutil",
    ("darwin", "amd64"): f"{TOSUTIL_DOWNLOAD_BASE}/darwin/amd64/tosutil",
    ("darwin", "arm64"): f"{TOSUTIL_DOWNLOAD_BASE}/darwin/arm64/tosutil",
    ("windows", "amd64"): f"{TOSUTIL_DOWNLOAD_BASE}/windows/tosutil",
}

_configured_binary: str | None = None


def normalize_arch(machine: str) -> str:
    normalized = (machine or "").lower()
    if normalized in {"x86_64", "amd64"}:
        return "amd64"
    if normalized in {"aarch64", "arm64"}:
        return "arm64"
    return normalized or "amd64"


def local_platform_key() -> tuple[str, str]:
    system = platform.system().lower()
    arch = normalize_arch(platform.machine())
    if system == "windows":
        return "windows", "amd64"
    if system == "darwin":
        return "darwin", arch
    return "linux", arch


def local_tosutil_cache_dir() -> Path:
    override = (os.getenv("LOCAL_TOSUTIL_DIR") or os.getenv("TOSUTIL_CACHE_DIR") or "").strip()
    if override:
        return Path(override).expanduser()
    return Path.home() / ".cache" / "open_workflowgym" / "tosutil"


def cached_tosutil_path(platform_key: tuple[str, str] | None = None) -> Path:
    system, arch = platform_key or local_platform_key()
    cache_dir = local_tosutil_cache_dir() / f"{system}-{arch}"
    if system == "windows":
        return cache_dir / "tosutil.exe"
    return cache_dir / "tosutil"


def tosutil_download_url(platform_key: tuple[str, str] | None = None) -> str:
    key = platform_key or local_platform_key()
    url = TOSUTIL_DOWNLOAD_URLS.get(key)
    if not url:
        system, arch = key
        raise RuntimeError("当前平台暂不支持自动下载 tosutil: %s/%s" % (system, arch))
    override_env = "TOSUTIL_DOWNLOAD_URL"
    if key[0] == "linux":
        override_env = "LINUX_TOSUTIL_DOWNLOAD_URL"
    elif key[0] == "windows":
        override_env = "WINDOWS_TOSUTIL_DOWNLOAD_URL"
    elif key[0] == "darwin":
        override_env = "DARWIN_TOSUTIL_DOWNLOAD_URL"
    return (os.getenv(override_env) or url).strip()


def _binary_is_usable(path: Path) -> bool:
    if not path.is_file() or path.stat().st_size <= 0:
        return False
    if platform.system().lower() != "windows" and not os.access(path, os.X_OK):
        return False
    try:
        subprocess.run(
            [str(path), "version"],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=30,
        )
        return True
    except Exception:
        return False


def _make_executable(path: Path) -> None:
    if platform.system().lower() == "windows":
        return
    mode = path.stat().st_mode
    path.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def download_tosutil(platform_key: tuple[str, str] | None = None) -> Path:
    key = platform_key or local_platform_key()
    target = cached_tosutil_path(key)
    target.parent.mkdir(parents=True, exist_ok=True)
    download_url = tosutil_download_url(key)
    temp_path = target.with_suffix(target.suffix + ".download")
    if temp_path.exists():
        temp_path.unlink()
    with urllib.request.urlopen(download_url, timeout=120) as response:
        temp_path.write_bytes(response.read())
    if platform.system().lower() != "windows":
        _make_executable(temp_path)
    temp_path.replace(target)
    if not _binary_is_usable(target):
        raise RuntimeError("tosutil 下载完成但无法执行: %s" % target)
    return target


def ensure_tosutil_configured(binary: str) -> None:
    global _configured_binary
    if _configured_binary == binary:
        return
    tos_ak = (os.getenv("TOS_AK") or os.getenv("AK") or "").strip()
    tos_sk = (os.getenv("TOS_SK") or os.getenv("SK") or "").strip()
    if not tos_ak or not tos_sk:
        return
    tos_region = (
        os.getenv("TOS_REGION")
        or os.getenv("VOLCENGINE_REGION")
        or os.getenv("SOURCE_REGION")
        or "cn-guangzhou"
    ).strip()
    tos_endpoint = (os.getenv("TOS_ENDPOINT") or "tos-%s.volces.com" % tos_region).strip()
    subprocess.run(
        [binary, "config", "-i", tos_ak, "-k", tos_sk, "-e", tos_endpoint, "-re", tos_region],
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        timeout=60,
    )
    _configured_binary = binary


def resolve_tosutil_binary(*, auto_download: bool = True) -> str:
    override = (os.getenv("TOSUTIL_BINARY") or "").strip()
    if override:
        path = Path(override).expanduser()
        if not path.is_file():
            raise FileNotFoundError("TOSUTIL_BINARY 指向的文件不存在: %s" % path)
        ensure_tosutil_configured(str(path))
        return str(path)

    path_in_path = shutil.which("tosutil")
    if path_in_path:
        ensure_tosutil_configured(path_in_path)
        return path_in_path

    cached = cached_tosutil_path()
    if _binary_is_usable(cached):
        ensure_tosutil_configured(str(cached))
        return str(cached)

    if not auto_download:
        raise FileNotFoundError("未找到可用 tosutil，本地缓存目录: %s" % cached.parent)

    downloaded = download_tosutil()
    ensure_tosutil_configured(str(downloaded))
    return str(downloaded)


def run_tosutil_cp(url: str, target_path: str) -> None:
    binary = resolve_tosutil_binary()
    subprocess.check_call([binary, "cp", url, target_path])


def run_tosutil_ls(url: str) -> str:
    binary = resolve_tosutil_binary()
    completed = subprocess.run(
        [binary, "ls", url],
        check=True,
        capture_output=True,
        text=True,
        timeout=300,
    )
    return completed.stdout or ""


def run_tosutil_cp_recursive(url: str, target_path: str) -> None:
    binary = resolve_tosutil_binary()
    subprocess.check_call([binary, "cp", url, target_path, "-r"])
