from __future__ import annotations

import os
import time
from concurrent.futures import FIRST_COMPLETED, Future, wait
from pathlib import Path
from typing import Callable

from .agents.factory import AgentFactory
from .envs.instance_pool import InstancePool
from .executors.local import LocalExecutorBackend
from .records import InstanceLease, OutboxEvent, RunConfig, SampleJob, TaskRecord, TrajectoryResult, ValidationResult, new_id, now_text, to_jsonable
from .sample_log import append_sample_log
from .scorer import Scorer
from .state_store import StateStore
from .states import SampleStatus, TaskStatus, transition_sample_status, transition_task_status
from .platform_utils import build_image_platform_map, resolve_task_platform, unknown_platform_reason
from .platform_failure import (
    PLATFORM_MATCH_UNAVAILABLE,
    PLATFORM_MISMATCH_EXHAUSTED,
    is_platform_mismatch_failure,
    platform_mismatch_context_from_trajectory,
    write_platform_failure_artifacts,
)
from .validators import validate_task
from .writer_process import WriterProcess


DEMO_TASK_UP = """【任务定义】

# 角色

你是一位掌握 LVGL界面开发 的 嵌入式UI设计 专业的大学生，正在使用 LVGL可视化开发工具 界面设计软件学习并验证UI组件、页面组织结构与样式规则体系。

# 提问场景

你需要在 LVGL可视化开发工具 中创建一个基于LVGL 9.x规则基础的 可视化布局 UI项目，用于验证UI组件资源加载、页面层级结构叠加与基础布局结构的基本规则。实验UI项目采用可视化编辑视图与基础UI组件单元。

# 数据/参数输入

LVGL版本=9.x

项目名称=case007

创建路径=case007

主区域背景色=#fff

Arc组件线条颜色=#F09

Arc组件线条宽度=10

Arc组件透明度=22

左侧Button文本=GO

左侧Button文本颜色=#ff90c3

左侧Button文本字体=MONTSERRAT_30

左侧Button背景色=#219

右侧Button文本颜色=#FF0

右侧Button文本字体=MONTSERRAT_24

右侧Button背景色=#6f3

List组件高度=90px

List组件背景色=#ccc

第一个Label文本=text1

第二个Label文本=text2

第三个Label文本=text3

输出文件路径:/home/user/Desktop/output/

# 任务目标

完成一份具备基础交互功能、明确非自定义扩展区域限制标准以及样式装饰层次标准的UI展示主题UI项目。输出文件：

文件：case007.eez-project



【操作规范】

步骤1        在home页面上方导航栏选择CREATE

步骤2        点击页面中间框架模版选择LVGL模版

步骤3        在PROJECT SETTINGS栏下方LVGL version下拉框点开选取9.x

步骤4        在PROJECT SETTINGS栏下方Name填写case007

步骤5        在PROJECT SETTINGS栏下方Location修改创建路径case007，确认路径为：/home/user/Desktop/output/

步骤6        点击页面右下角Create Pororct创建页面并进入

步骤7        在项目右边pages下方选择Main标签

步骤8        在右侧Properties标签下方找到STYLE标签

步骤9        在STYLE下左侧为默认选取MainPart下边的DEFAULT

步骤10        在STYLE右边点开BACKGROUND标签下边选择第一个属性修改为#fff

步骤11        点击选取工作簿中间Hello,World!预设标签

步骤12        选择下方Delete删除Hello,World!预设标签

步骤13        在页面右下角处Components Palette组件标签下选择Arc组件并拖入中间工作簿中

步骤14        在页面右下角处Components Palette组件标签下选择Button组件并拖入两个到中间工作簿中并排放置

步骤15        在页面右下角处Components Palette组件标签下选择List组件并拖入中间工作簿中放置于并排放置的Button组件下方

步骤16        在右边POSITION AND SIZE中将List组件Height属性改为90px

步骤17        在页面右下角处Components Palette组件标签下选择Label组件并拖入三个到中间List组件上

步骤18        点击选取Arc组件在右侧Properties标签下方找到STYLE标签

步骤19        在STYLE下左侧为默认选取MainPart下边的DEFAULT

步骤20        在STYLE右边点击合上BACKGROUND标签，打开LINE标签

步骤21        在STYLE右边点击打开ARC标签修改Color属性修改成#f09

步骤22        在STYLE右边ARC标签下修改Width属性修改成10

步骤23        在STYLE右边ARC标签下选中并修改Opacity属性修改成22

步骤24        选取左侧button组件中自带的label

步骤25        在右边SPECIFIC下的text栏中内容修改为GO

步骤26        在skyle下方点开TEXT工具栏将Color的属性值修改为#ff90c3

步骤27        TEXT工具栏将font的属性值修改为MONTSERRAT_30

步骤28        选取左侧button组件并合上text工具栏

步骤29        点击展开BACKGROUND工具栏Color的属性值修改为#219

步骤30        选取右侧button组件

步骤31        点击左侧Global上方的label并关闭右侧BACKGROUND工具栏

步骤32        点击展开text工具栏Color的属性值修改为#ff0

步骤33        TEXT工具栏将font的属性值修改为MONTSERRAT_24，点击合上text工具栏

步骤34        选取右侧button组件

步骤35        在右侧展开BACKGROUND工具栏

步骤36        将color属性改为#6f3

步骤37        点击选取List组件中第一个label组件

步骤38        将右侧text属性值更改为Text1

步骤39        点击选取List组件中第二个label组件

步骤40        将右侧text属性值更改为Text2

步骤41        点击选取List组件中第三个label组件

步骤42        将右侧text属性值更改为Text3

步骤43        点击选取中间list组件

步骤44        将右侧BACKGROUND工具栏中的color属性改为#ccc

步骤45        点击上方的RUN测试栏切换到测试页面
"""


class Scheduler:
    def __init__(
        self,
        config: RunConfig,
        store: StateStore,
        instance_pool: InstancePool,
        executor: LocalExecutorBackend,
        writer: WriterProcess,
        scorer: Scorer,
        agent_factory: AgentFactory,
        shutdown_requested: Callable[[], bool] | None = None,
        image_platforms: dict[str, str] | None = None,
    ):
        self.config = config
        self.store = store
        self.instance_pool = instance_pool
        self.executor = executor
        self.writer = writer
        self.scorer = scorer
        self.agent_factory = agent_factory
        self.shutdown_requested = shutdown_requested or (lambda: False)
        self.image_platforms = dict(image_platforms or {})
        self._background_log_last_at: dict[str, float] = {}

    def lease_backend_is_redis(self) -> bool:
        kind = str(getattr(self.config, "lease_backend", "local") or "local").strip().lower()
        return kind in ("redis", "wgm", "remote")

    def required_platform_for_task(self, record: TaskRecord) -> str:
        return resolve_task_platform(record, self.image_platforms)

    def expire_stale_leases(self) -> list[InstanceLease]:
        expired = self.instance_pool.expire_stale_leases()
        for lease in expired:
            self.background_log(
                "租约 TTL 到期，释放并隔离实例: task_id=%s sample_index=%s instance_id=%s lease_id=%s expires_at=%s"
                % (
                    lease.task_id,
                    lease.sample_index,
                    lease.instance_id,
                    lease.lease_id,
                    lease.expires_at,
                ),
                throttle_seconds=60.0,
            )
        return expired

    def check_hung_pending_futures(
        self,
        pending: dict,
        pending_started_at: dict,
    ) -> None:
        max_seconds = max(1, int(self.config.sample_future_max_seconds))
        now = time.monotonic()
        for future in list(pending.keys()):
            if future.done():
                continue
            started_at = pending_started_at.get(future, now)
            if now - started_at <= max_seconds:
                continue
            record, sample_index, lease, _sample_status = pending[future]
            reason = (
                "采样 future 超时: task_id=%s sample_index=%s instance_id=%s lease_id=%s max_seconds=%s"
                % (record.task_id, sample_index, lease.instance_id, lease.lease_id, max_seconds)
            )
            self.store.flag_lease_hung_worker(
                lease.lease_id,
                lease.instance_id,
                record.run_id,
                record.task_id,
                sample_index,
                reason,
            )
            self.background_log(reason, throttle_seconds=60.0)
            future.cancel()

    def try_acquire_lease(
        self,
        record: TaskRecord,
        sample_index: int,
        excluded_instance_ids: set[str] | None = None,
    ) -> InstanceLease | None:
        required_platform = self.required_platform_for_task(record)
        excluded = set(excluded_instance_ids or ())
        if required_platform and self.instance_pool.acquire_status(required_platform, excluded) == "unavailable":
            return None
        return self.instance_pool.acquire(
            record.run_id,
            record.task_id,
            sample_index,
            required_platform,
            excluded,
            image_id=str(getattr(record, "image_id", "") or ""),
        )

    def acquire_lease_waiting(
        self,
        record: TaskRecord,
        sample_index: int,
        pending: dict | None = None,
        wait_callback: Callable[[], None] | None = None,
        excluded_instance_ids: set[str] | None = None,
    ) -> InstanceLease | None:
        required_platform = self.required_platform_for_task(record)
        excluded = set(excluded_instance_ids or ())
        if required_platform and self.instance_pool.acquire_status(required_platform, excluded) == "unavailable":
            self.background_log(
                "任务无匹配环境: task_id=%s sample_index=%s required_platform=%s pool=%s"
                % (
                    record.task_id,
                    sample_index,
                    required_platform,
                    self.instance_pool.platform_summary(),
                )
            )
            return None
        while not self.shutdown_requested():
            self.expire_stale_leases()
            lease = self.instance_pool.acquire(
                record.run_id,
                record.task_id,
                sample_index,
                required_platform,
                excluded,
                image_id=str(getattr(record, "image_id", "") or ""),
            )
            if lease:
                return lease
            if self.instance_pool.acquire_status(required_platform, excluded) == "unavailable":
                return None
            if pending and wait_callback:
                self.background_log(
                    "等待匹配环境释放: task_id=%s sample_index=%s required_platform=%s capacity=%s pending=%s"
                    % (
                        record.task_id,
                        sample_index,
                        required_platform or "<any>",
                        self.instance_pool.platform_capacity(required_platform, excluded),
                        len(pending),
                    )
                )
                wait_callback()
            else:
                self.background_log(
                    "等待匹配环境空闲: task_id=%s sample_index=%s required_platform=%s capacity=%s"
                    % (
                        record.task_id,
                        sample_index,
                        required_platform or "<any>",
                        self.instance_pool.platform_capacity(required_platform, excluded),
                    )
                )
                time.sleep(1.0)
        return None

    def process_task(self, record: TaskRecord) -> None:
        task_status = self.prepare_task_for_sampling(record)
        if not task_status:
            return

        if getattr(self.executor, "supports_async", False):
            task_status = self.run_task_samples_concurrently(record, task_status)
            if task_status in (TaskStatus.FAILED.value, TaskStatus.INTERRUPTED.value):
                self.store.update_task_status(record.run_id, record.task_id, task_status)
                return
            if not self.drain_outbox(("trajectory_ready_to_sync", "sample_ready_to_score", "score_ready_to_sync")):
                task_status = transition_task_status(task_status, TaskStatus.FAILED)
                self.store.update_task_status(record.run_id, record.task_id, task_status)
                return
            task_status = transition_task_status(task_status, TaskStatus.SCORING_PENDING)
            self.store.update_task_status(record.run_id, record.task_id, task_status)
            task_status = transition_task_status(task_status, TaskStatus.SYNCING_FEISHU)
            self.store.update_task_status(record.run_id, record.task_id, task_status)
            task_status = transition_task_status(task_status, TaskStatus.SYNCED)
            self.store.update_task_status(record.run_id, record.task_id, task_status)
            return

        successful_samples = 0
        for sample_index in range(1, self.config.sample_num + 1):
            if self.shutdown_requested():
                task_status = transition_task_status(task_status, TaskStatus.INTERRUPTED)
                self.store.update_task_status(record.run_id, record.task_id, task_status)
                trace("收到退出信号，停止派发新采样: task_id=%s next_sample_index=%s" % (record.task_id, sample_index))
                break
            trace("准备采样: task_id=%s sample_index=%s" % (record.task_id, sample_index))
            if not self.run_sample(record, sample_index):
                if self.shutdown_requested():
                    task_status = transition_task_status(task_status, TaskStatus.INTERRUPTED)
                    self.store.update_task_status(record.run_id, record.task_id, task_status)
                    trace("采样中断: task_id=%s sample_index=%s" % (record.task_id, sample_index))
                    break
                trace("采样失败，继续下一采样: task_id=%s sample_index=%s" % (record.task_id, sample_index))
                continue
            successful_samples += 1
        if successful_samples <= 0 and not self.shutdown_requested():
            task_status = transition_task_status(task_status, TaskStatus.FAILED)
            self.store.update_task_status(record.run_id, record.task_id, task_status)
            trace("全部采样失败: task_id=%s sample_num=%s" % (record.task_id, self.config.sample_num))
            return
        if self.shutdown_requested():
            self.drain_outbox(("trajectory_ready_to_sync", "sample_ready_to_score", "score_ready_to_sync"))
            if task_status != TaskStatus.INTERRUPTED.value:
                task_status = transition_task_status(task_status, TaskStatus.INTERRUPTED)
                self.store.update_task_status(record.run_id, record.task_id, task_status)
            return
        if not self.drain_outbox(("trajectory_ready_to_sync", "sample_ready_to_score", "score_ready_to_sync")):
            task_status = transition_task_status(task_status, TaskStatus.FAILED)
            self.store.update_task_status(record.run_id, record.task_id, task_status)
            return
        task_status = transition_task_status(task_status, TaskStatus.SCORING_PENDING)
        self.store.update_task_status(record.run_id, record.task_id, task_status)
        task_status = transition_task_status(task_status, TaskStatus.SYNCING_FEISHU)
        self.store.update_task_status(record.run_id, record.task_id, task_status)
        task_status = transition_task_status(task_status, TaskStatus.SYNCED)
        self.store.update_task_status(record.run_id, record.task_id, task_status)

    def process_tasks(self, records: list[TaskRecord]) -> None:
        if not getattr(self.executor, "supports_async", False):
            for record in records:
                if self.shutdown_requested():
                    break
                self.process_task(record)
            return

        if self.lease_backend_is_redis():
            self._process_tasks_redis(records)
            return

        pending: dict[Future, tuple[TaskRecord, int, InstanceLease, str]] = {}
        pending_started_at: dict[Future, float] = {}
        task_statuses: dict[str, str] = {}
        tasks_aborted: set[str] = set()
        sample_success_count: dict[str, int] = {}
        sample_failure_count: dict[str, int] = {}
        interrupted_tasks: set[str] = set()
        max_workers = max(1, int(self.config.max_workers))

        def record_sample_outcome(task_id: str, ok: bool) -> None:
            if ok:
                sample_success_count[task_id] = sample_success_count.get(task_id, 0) + 1
            else:
                sample_failure_count[task_id] = sample_failure_count.get(task_id, 0) + 1

        def wait_for_one() -> None:
            self.check_hung_pending_futures(pending, pending_started_at)
            self.expire_stale_leases()
            done, _ = wait(pending.keys(), timeout=1.0, return_when=FIRST_COMPLETED)
            for future in done:
                record, sample_index, lease, sample_status = pending.pop(future)
                pending_started_at.pop(future, None)
                ok = self.finish_sample_future(record, sample_index, lease, sample_status, future)
                record_sample_outcome(record.task_id, ok)

        prepared_records: list[TaskRecord] = []
        for record in records:
            if self.shutdown_requested():
                break
            task_status = self.prepare_task_for_sampling(record)
            if not task_status:
                continue
            task_statuses[record.task_id] = task_status
            prepared_records.append(record)

        sample_queue = [
            (record, sample_index)
            for record in prepared_records
            for sample_index in range(1, self.config.sample_num + 1)
        ]
        for record, sample_index in sample_queue:
            if record.task_id in tasks_aborted or record.task_id in interrupted_tasks:
                continue
            submitted = None
            while submitted is None and not self.shutdown_requested():
                while len(pending) >= max_workers:
                    wait_for_one()
                submitted = self.submit_sample_async(record, sample_index)
                if submitted is None:
                    required_platform = self.required_platform_for_task(record)
                    if self.instance_pool.acquire_status(required_platform) == "unavailable":
                        if self.finish_platform_failure_sample(
                            record,
                            sample_index,
                            reason=PLATFORM_MATCH_UNAVAILABLE,
                            required_platform=required_platform,
                        ):
                            record_sample_outcome(record.task_id, True)
                        break
                    if pending:
                        wait_for_one()
                    elif self.instance_pool.acquire_status(self.required_platform_for_task(record)) == "wait":
                        self.expire_stale_leases()
                        self.background_log(
                            "无 pending 但环境仍被占用，可能存在租约泄漏: task_id=%s sample_index=%s required_platform=%s"
                            % (record.task_id, sample_index, self.required_platform_for_task(record) or "<any>"),
                            throttle_seconds=60.0,
                        )
                        time.sleep(1.0)
                    else:
                        time.sleep(1.0)
            if submitted is None:
                continue
            future, lease, sample_status = submitted
            pending[future] = (record, sample_index, lease, sample_status)
            pending_started_at[future] = time.monotonic()

        if self.shutdown_requested():
            interrupted_tasks.update(task_statuses)
            for future in list(pending):
                future.cancel()

        while pending:
            wait_for_one()

        self.drain_outbox(("trajectory_ready_to_sync", "sample_ready_to_score", "score_ready_to_sync"))

        for record in records:
            task_status = task_statuses.get(record.task_id)
            if not task_status:
                continue
            if record.task_id in interrupted_tasks or self.shutdown_requested():
                final_status = transition_task_status(task_status, TaskStatus.INTERRUPTED)
            elif sample_success_count.get(record.task_id, 0) <= 0:
                final_status = transition_task_status(task_status, TaskStatus.FAILED)
            else:
                final_status = transition_task_status(task_status, TaskStatus.SCORING_PENDING)
                self.store.update_task_status(record.run_id, record.task_id, final_status)
                final_status = transition_task_status(final_status, TaskStatus.SYNCING_FEISHU)
                self.store.update_task_status(record.run_id, record.task_id, final_status)
                final_status = transition_task_status(final_status, TaskStatus.SYNCED)
            self.store.update_task_status(record.run_id, record.task_id, final_status)

    def _process_tasks_redis(self, records: list[TaskRecord]) -> None:
        """Redis 专用：并行 acquire-and-prepare，门闩 preparing+sampling ≤ max_workers。"""
        from concurrent.futures import ThreadPoolExecutor

        max_workers = max(1, int(self.config.max_workers))
        preparing: dict[Future, tuple[TaskRecord, int]] = {}
        sampling: dict[Future, tuple[TaskRecord, int, InstanceLease, str]] = {}
        sampling_started_at: dict[Future, float] = {}
        task_statuses: dict[str, str] = {}
        sample_success_count: dict[str, int] = {}
        interrupted_tasks: set[str] = set()
        retry_queue: list[tuple[TaskRecord, int]] = []

        def record_outcome(task_id: str, ok: bool) -> None:
            if ok:
                sample_success_count[task_id] = sample_success_count.get(task_id, 0) + 1

        def in_flight() -> int:
            return len(preparing) + len(sampling)

        prepared_records: list[TaskRecord] = []
        for record in records:
            if self.shutdown_requested():
                break
            task_status = self.prepare_task_for_sampling(record)
            if not task_status:
                continue
            task_statuses[record.task_id] = task_status
            prepared_records.append(record)

        sample_queue = [
            (record, sample_index)
            for record in prepared_records
            for sample_index in range(1, self.config.sample_num + 1)
        ]
        queue_index = 0

        def next_work_item() -> tuple[TaskRecord, int] | None:
            nonlocal queue_index
            if retry_queue:
                return retry_queue.pop(0)
            if queue_index >= len(sample_queue):
                return None
            item = sample_queue[queue_index]
            queue_index += 1
            return item

        def drain_preparing(prepare_pool_done: set[Future]) -> None:
            for future in prepare_pool_done:
                meta = preparing.pop(future, None)
                if meta is None:
                    continue
                record, sample_index = meta
                lease = None
                try:
                    lease = future.result()
                except Exception as exc:
                    self.background_log(
                        "并行 prepare 异常: task_id=%s sample_index=%s error=%s"
                        % (record.task_id, sample_index, exc),
                        throttle_seconds=30.0,
                    )
                if lease is None:
                    required_platform = self.required_platform_for_task(record)
                    if self.instance_pool.acquire_status(required_platform) == "unavailable":
                        if self.finish_platform_failure_sample(
                            record,
                            sample_index,
                            reason=PLATFORM_MATCH_UNAVAILABLE,
                            required_platform=required_platform,
                        ):
                            record_outcome(record.task_id, True)
                        continue
                    self.background_log(
                        "prepare 未抢到租约，稍后重试: task_id=%s sample_index=%s"
                        % (record.task_id, sample_index),
                        throttle_seconds=30.0,
                    )
                    retry_queue.append((record, sample_index))
                    continue
                submitted = self.submit_sample_with_lease(record, sample_index, lease)
                if submitted is None:
                    retry_queue.append((record, sample_index))
                    continue
                sample_future, bound_lease, sample_status = submitted
                sampling[sample_future] = (record, sample_index, bound_lease, sample_status)
                sampling_started_at[sample_future] = time.monotonic()

        def drain_sampling(done_set: set[Future]) -> None:
            for future in done_set:
                meta = sampling.pop(future, None)
                sampling_started_at.pop(future, None)
                if meta is None:
                    continue
                record, sample_index, lease, sample_status = meta
                ok = self.finish_sample_future(record, sample_index, lease, sample_status, future)
                record_outcome(record.task_id, ok)

        with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="wgm-prepare") as prepare_pool:
            while (
                queue_index < len(sample_queue)
                or retry_queue
                or preparing
                or sampling
            ) and not self.shutdown_requested():
                # 完成的 prepare → 提交采样
                done_prep = {f for f in list(preparing) if f.done()}
                if done_prep:
                    drain_preparing(done_prep)

                # 完成的采样
                if sampling:
                    self.check_hung_pending_futures(sampling, sampling_started_at)
                    done_samp, _ = wait(sampling.keys(), timeout=0.0, return_when=FIRST_COMPLETED)
                    if done_samp:
                        drain_sampling(set(done_samp))

                # 门闩：preparing + sampling < max_workers 才开新 prepare
                while in_flight() < max_workers and not self.shutdown_requested():
                    item = next_work_item()
                    if item is None:
                        break
                    record, sample_index = item
                    self.store.upsert_sample(
                        record.run_id,
                        record.task_id,
                        sample_index,
                        SampleStatus.WAITING_FOR_INSTANCE.value,
                    )
                    self.background_log(
                        "并行 prepare: task_id=%s sample_index=%s in_flight=%s/%s"
                        % (record.task_id, sample_index, in_flight() + 1, max_workers)
                    )
                    future = prepare_pool.submit(self.try_acquire_lease, record, sample_index)
                    preparing[future] = (record, sample_index)

                wait_set = list(preparing.keys()) + list(sampling.keys())
                if not wait_set:
                    if retry_queue:
                        time.sleep(1.0)
                    continue
                wait(wait_set, timeout=1.0, return_when=FIRST_COMPLETED)

            if self.shutdown_requested():
                interrupted_tasks.update(task_statuses)
                for future in list(preparing):
                    future.cancel()
                for future in list(sampling):
                    future.cancel()

            # 收尾 prepare：含已 cancel 失败仍在跑的；拿到的租约直接 release
            while preparing:
                done_prep, _ = wait(list(preparing.keys()), timeout=1.0, return_when=FIRST_COMPLETED)
                if not done_prep:
                    continue
                for future in done_prep:
                    meta = preparing.pop(future, None)
                    if meta is None:
                        continue
                    try:
                        lease = future.result()
                    except Exception:
                        lease = None
                    if lease is not None:
                        try:
                            self.instance_pool.release(lease, "shutdown")
                        except Exception:
                            pass

            # 与 local 一致：仍等待采样 future，由 finish_sample_future 统一 release（勿提前放租）
            while sampling:
                self.check_hung_pending_futures(sampling, sampling_started_at)
                done_samp, _ = wait(sampling.keys(), timeout=1.0, return_when=FIRST_COMPLETED)
                if done_samp:
                    drain_sampling(set(done_samp))

        self.drain_outbox(("trajectory_ready_to_sync", "sample_ready_to_score", "score_ready_to_sync"))

        for record in records:
            task_status = task_statuses.get(record.task_id)
            if not task_status:
                continue
            if record.task_id in interrupted_tasks or self.shutdown_requested():
                final_status = transition_task_status(task_status, TaskStatus.INTERRUPTED)
            elif sample_success_count.get(record.task_id, 0) <= 0:
                final_status = transition_task_status(task_status, TaskStatus.FAILED)
            else:
                final_status = transition_task_status(task_status, TaskStatus.SCORING_PENDING)
                self.store.update_task_status(record.run_id, record.task_id, final_status)
                final_status = transition_task_status(final_status, TaskStatus.SYNCING_FEISHU)
                self.store.update_task_status(record.run_id, record.task_id, final_status)
                final_status = transition_task_status(final_status, TaskStatus.SYNCED)
            self.store.update_task_status(record.run_id, record.task_id, final_status)

    def prepare_task_for_sampling(self, record: TaskRecord) -> str | None:
        task_status = TaskStatus.READ.value
        self.store.upsert_task(record.run_id, record.task_id, record.row_number, task_status, record.fields)
        if self.shutdown_requested():
            task_status = transition_task_status(task_status, TaskStatus.INTERRUPTED)
            self.store.update_task_status(record.run_id, record.task_id, task_status)
            trace("收到退出信号，跳过任务: task_id=%s" % record.task_id)
            return
        validation = validate_task(record) if self.config.validate else None
        if validation and not validation.passed:
            task_status = transition_task_status(task_status, TaskStatus.VALIDATION_FAILED)
            self.store.update_task_status(record.run_id, record.task_id, task_status, validation)
            print_validation_failure(record, validation.reason)
            return
        trace("任务校验通过: task_id=%s row=%s image_id=%s" % (record.task_id, record.row_number, record.image_id))

        if self.config.fail_on_unknown_platform:
            platform_reason = unknown_platform_reason(record, self.image_platforms)
            if platform_reason:
                validation = ValidationResult(
                    run_id=record.run_id,
                    task_id=record.task_id,
                    row_number=record.row_number,
                    passed=False,
                    status="失败",
                    reason=platform_reason,
                )
                task_status = transition_task_status(task_status, TaskStatus.VALIDATION_FAILED)
                self.store.update_task_status(record.run_id, record.task_id, task_status, validation)
                print_validation_failure(record, validation.reason)
                return

        task_status = transition_task_status(task_status, TaskStatus.VALIDATED)
        self.store.update_task_status(
            record.run_id,
            record.task_id,
            task_status,
            validation,
        )
        self.store.add_outbox_event(
            OutboxEvent(
                run_id=record.run_id,
                event_id=new_id("evt"),
                event_type="validation_ready_to_sync",
                task_id=record.task_id,
                payload={"validation": to_jsonable(validation) if validation else {"task_id": record.task_id, "row_number": record.row_number, "status": "未知"}},
                idempotency_key="%s:%s:validation" % (record.run_id, record.task_id),
            )
        )
        if not self.drain_outbox(("validation_ready_to_sync",)):
            task_status = transition_task_status(task_status, TaskStatus.VALIDATION_REPORT_FAILED)
            self.store.update_task_status(record.run_id, record.task_id, task_status)
            trace("任务校验结果写飞书失败，停止采样: task_id=%s" % record.task_id)
            return
        trace("任务校验结果已写入飞书: task_id=%s" % record.task_id)
        task_status = transition_task_status(task_status, TaskStatus.VALIDATION_WRITTEN)
        self.store.update_task_status(record.run_id, record.task_id, task_status)
        task_status = transition_task_status(task_status, TaskStatus.SAMPLING_PENDING)
        self.store.update_task_status(record.run_id, record.task_id, task_status)
        trace("任务进入采样队列: task_id=%s sample_num=%s" % (record.task_id, self.config.sample_num))
        return task_status

    def run_task_samples_concurrently(self, record: TaskRecord, task_status: str) -> str:
        if self.lease_backend_is_redis():
            return self._run_task_samples_redis(record, task_status)

        pending: dict[Future, tuple[int, InstanceLease, str]] = {}
        next_sample_index = 1
        successful_samples = 0
        aborted = False
        interrupted = False

        while next_sample_index <= self.config.sample_num or pending:
            while (
                next_sample_index <= self.config.sample_num
                and len(pending) < max(1, int(self.config.max_workers))
                and not self.shutdown_requested()
                and not aborted
            ):
                submitted = self.submit_sample_async(record, next_sample_index)
                if submitted is None:
                    required_platform = self.required_platform_for_task(record)
                    if self.instance_pool.acquire_status(required_platform) == "unavailable":
                        if self.finish_platform_failure_sample(
                            record,
                            next_sample_index,
                            reason=PLATFORM_MATCH_UNAVAILABLE,
                            required_platform=required_platform,
                        ):
                            successful_samples += 1
                        next_sample_index += 1
                        continue
                    if pending:
                        self.expire_stale_leases()
                        self.background_log(
                            "暂无匹配环境，等待已提交采样释放实例: task_id=%s next_sample_index=%s required_platform=%s pending=%s"
                            % (record.task_id, next_sample_index, required_platform or "<any>", len(pending))
                        )
                        done, _ = wait(pending.keys(), timeout=1.0, return_when=FIRST_COMPLETED)
                        for future in done:
                            sample_index, lease, sample_status = pending.pop(future)
                            if self.finish_sample_future(record, sample_index, lease, sample_status, future):
                                successful_samples += 1
                        continue
                    time.sleep(1.0)
                    continue
                future, lease, sample_status = submitted
                pending[future] = (next_sample_index, lease, sample_status)
                next_sample_index += 1

            if self.shutdown_requested():
                interrupted = True
                trace("收到退出信号，停止派发新采样: task_id=%s pending=%s" % (record.task_id, len(pending)))
                for future in list(pending):
                    future.cancel()

            if not pending:
                break

            self.expire_stale_leases()
            done, _ = wait(pending.keys(), timeout=1.0, return_when=FIRST_COMPLETED)
            if not done:
                continue

            for future in done:
                sample_index, lease, sample_status = pending.pop(future)
                if self.finish_sample_future(record, sample_index, lease, sample_status, future):
                    successful_samples += 1

        if interrupted or self.shutdown_requested():
            return transition_task_status(task_status, TaskStatus.INTERRUPTED)
        if successful_samples <= 0:
            return transition_task_status(task_status, TaskStatus.FAILED)
        return task_status

    def _run_task_samples_redis(self, record: TaskRecord, task_status: str) -> str:
        """单任务 redis 路径：并行 prepare，门闩 in_flight ≤ max_workers。"""
        from concurrent.futures import ThreadPoolExecutor

        max_workers = max(1, int(self.config.max_workers))
        preparing: dict[Future, int] = {}
        sampling: dict[Future, tuple[int, InstanceLease, str]] = {}
        next_sample_index = 1
        successful_samples = 0
        interrupted = False
        retry_indexes: list[int] = []

        def in_flight() -> int:
            return len(preparing) + len(sampling)

        def take_next_index() -> int | None:
            nonlocal next_sample_index
            if retry_indexes:
                return retry_indexes.pop(0)
            if next_sample_index > self.config.sample_num:
                return None
            sample_index = next_sample_index
            next_sample_index += 1
            return sample_index

        with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="wgm-prepare") as prepare_pool:
            while (
                next_sample_index <= self.config.sample_num
                or retry_indexes
                or preparing
                or sampling
            ) and not self.shutdown_requested():
                done_prep = {f for f in list(preparing) if f.done()}
                for future in done_prep:
                    sample_index = preparing.pop(future)
                    lease = None
                    try:
                        lease = future.result()
                    except Exception as exc:
                        self.background_log(
                            "并行 prepare 异常: task_id=%s sample_index=%s error=%s"
                            % (record.task_id, sample_index, exc),
                            throttle_seconds=30.0,
                        )
                    if lease is None:
                        required_platform = self.required_platform_for_task(record)
                        if self.instance_pool.acquire_status(required_platform) == "unavailable":
                            if self.finish_platform_failure_sample(
                                record,
                                sample_index,
                                reason=PLATFORM_MATCH_UNAVAILABLE,
                                required_platform=required_platform,
                            ):
                                successful_samples += 1
                            continue
                        retry_indexes.append(sample_index)
                        continue
                    submitted = self.submit_sample_with_lease(record, sample_index, lease)
                    if submitted is None:
                        retry_indexes.append(sample_index)
                        continue
                    sample_future, bound_lease, sample_status = submitted
                    sampling[sample_future] = (sample_index, bound_lease, sample_status)

                if sampling:
                    done_samp, _ = wait(sampling.keys(), timeout=0.0, return_when=FIRST_COMPLETED)
                    for future in done_samp:
                        sample_index, lease, sample_status = sampling.pop(future)
                        if self.finish_sample_future(record, sample_index, lease, sample_status, future):
                            successful_samples += 1

                while in_flight() < max_workers and not self.shutdown_requested():
                    sample_index = take_next_index()
                    if sample_index is None:
                        break
                    self.store.upsert_sample(
                        record.run_id,
                        record.task_id,
                        sample_index,
                        SampleStatus.WAITING_FOR_INSTANCE.value,
                    )
                    future = prepare_pool.submit(self.try_acquire_lease, record, sample_index)
                    preparing[future] = sample_index

                wait_set = list(preparing.keys()) + list(sampling.keys())
                if not wait_set:
                    if retry_indexes:
                        time.sleep(1.0)
                    continue
                wait(wait_set, timeout=1.0, return_when=FIRST_COMPLETED)

            if self.shutdown_requested():
                interrupted = True
                for future in list(preparing):
                    future.cancel()
                for future in list(sampling):
                    future.cancel()

            while preparing:
                done_prep, _ = wait(list(preparing.keys()), timeout=1.0, return_when=FIRST_COMPLETED)
                if not done_prep:
                    continue
                for future in done_prep:
                    sample_index = preparing.pop(future, None)
                    if sample_index is None:
                        continue
                    try:
                        lease = future.result()
                    except Exception:
                        lease = None
                    if lease is not None:
                        try:
                            self.instance_pool.release(lease, "shutdown")
                        except Exception:
                            pass

            while sampling:
                done_samp, _ = wait(sampling.keys(), timeout=1.0, return_when=FIRST_COMPLETED)
                if not done_samp:
                    continue
                for future in done_samp:
                    sample_index, lease, sample_status = sampling.pop(future)
                    if self.finish_sample_future(record, sample_index, lease, sample_status, future):
                        successful_samples += 1

        if interrupted or self.shutdown_requested():
            return transition_task_status(task_status, TaskStatus.INTERRUPTED)
        if successful_samples <= 0:
            return transition_task_status(task_status, TaskStatus.FAILED)
        return task_status

    def submit_sample_async(self, record: TaskRecord, sample_index: int) -> tuple[Future, InstanceLease, str] | None:
        sample_status = SampleStatus.WAITING_FOR_INSTANCE.value
        self.store.upsert_sample(record.run_id, record.task_id, sample_index, sample_status)
        self.background_log("等待实例: task_id=%s sample_index=%s" % (record.task_id, sample_index))
        required_platform = self.required_platform_for_task(record)
        lease = self.try_acquire_lease(record, sample_index)
        if not lease:
            self.background_log(
                "获取实例失败: task_id=%s sample_index=%s required_platform=%s"
                % (record.task_id, sample_index, required_platform or "<any>")
            )
            return None
        return self.submit_sample_with_lease(record, sample_index, lease)

    def submit_sample_with_lease(
        self,
        record: TaskRecord,
        sample_index: int,
        lease: InstanceLease,
    ) -> tuple[Future, InstanceLease, str] | None:
        sample_status = SampleStatus.WAITING_FOR_INSTANCE.value
        try:
            self.trace_sample(
                record,
                sample_index,
                "获取实例成功: task_id=%s sample_index=%s instance_id=%s lease_id=%s"
                % (record.task_id, sample_index, lease.instance_id, lease.lease_id),
                extra={"instance_id": lease.instance_id, "lease_id": lease.lease_id},
            )
            sample_status = transition_sample_status(sample_status, SampleStatus.INITIALIZING_ENV)
            self.store.upsert_sample(
                record.run_id,
                record.task_id,
                sample_index,
                sample_status,
                lease_id=lease.lease_id,
                instance_id=lease.instance_id,
            )
            job_lease = lease.as_instance_lease() if hasattr(lease, "as_instance_lease") else lease
            job = SampleJob(
                run_id=record.run_id,
                task_id=record.task_id,
                sample_index=sample_index,
                task=record,
                config=self.config,
                lease=job_lease,
            )
            sample_status = transition_sample_status(sample_status, SampleStatus.ENV_READY)
            self.store.upsert_sample(
                record.run_id,
                record.task_id,
                sample_index,
                sample_status,
                lease_id=lease.lease_id,
                instance_id=lease.instance_id,
            )
            sample_status = transition_sample_status(sample_status, SampleStatus.SAMPLING)
            self.store.upsert_sample(
                record.run_id,
                record.task_id,
                sample_index,
                sample_status,
                lease_id=lease.lease_id,
                instance_id=lease.instance_id,
            )
            self.trace_sample(
                record,
                sample_index,
                "提交进程池采样: task_id=%s sample_index=%s instance_id=%s" % (record.task_id, sample_index, lease.instance_id),
                extra={"instance_id": lease.instance_id},
            )
            future = self.executor.submit_sample_async(job)
            return future, lease, sample_status
        except Exception as exc:
            self.background_log(
                "提交采样失败并释放实例: task_id=%s sample_index=%s instance_id=%s error=%s"
                % (record.task_id, sample_index, lease.instance_id, exc),
                throttle_seconds=60.0,
            )
            self.instance_pool.release(lease, "submit_failed")
            return None

    def background_log(self, message: str, throttle_seconds: float = 3600.0) -> None:
        now = time.monotonic()
        last_at = self._background_log_last_at.get(message)
        if last_at is not None and now - last_at < throttle_seconds:
            return
        self._background_log_last_at[message] = now
        log_path = scheduler_log_path(self.config.output_root)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with open(log_path, "a", encoding="utf-8") as file_obj:
            file_obj.write("[%s] %s\n" % (now_text(), message))

    def trace_sample(self, record: TaskRecord, sample_index: int, message: str, extra: dict | None = None) -> None:
        trace(message)
        append_sample_log(
            self.sample_dir(record, sample_index),
            message,
            source="scheduler",
            task_id=record.task_id,
            sample_index=sample_index,
            extra=extra,
        )

    def sample_dir(self, record: TaskRecord, sample_index: int) -> str:
        return str(Path(self.config.output_root) / record.task_id / ("sample_%s" % sample_index))

    def finish_platform_failure_sample(
        self,
        record: TaskRecord,
        sample_index: int,
        *,
        reason: str,
        required_platform: str,
        tried_instance_ids: set[str] | None = None,
        mismatch_context: dict[str, str] | None = None,
    ) -> bool:
        sample_status = SampleStatus.WAITING_FOR_INSTANCE.value
        self.store.upsert_sample(record.run_id, record.task_id, sample_index, sample_status)
        sample_dir = self.sample_dir(record, sample_index)
        trajectory = write_platform_failure_artifacts(
            record=record,
            sample_index=sample_index,
            sample_dir=sample_dir,
            reason=reason,
            required_platform=required_platform,
            tried_instance_ids=sorted(tried_instance_ids or ()),
            mismatch_context=mismatch_context,
        )
        self.trace_sample(
            record,
            sample_index,
            "平台匹配失败，停止采样: task_id=%s reason=%s required_platform=%s error=%s"
            % (record.task_id, reason, required_platform or "<any>", trajectory.error),
            extra={"reason": reason, "required_platform": required_platform},
        )
        return self.finish_trajectory_without_lease(record, sample_index, trajectory)

    def finish_trajectory_without_lease(
        self,
        record: TaskRecord,
        sample_index: int,
        trajectory: TrajectoryResult,
    ) -> bool:
        sample_status = SampleStatus.WAITING_FOR_INSTANCE.value
        sample_status = transition_sample_status(sample_status, SampleStatus.INITIALIZING_ENV)
        sample_status = transition_sample_status(sample_status, SampleStatus.SAMPLE_FAILED)
        self.trace_sample(
            record,
            sample_index,
            "采样终止并判分: task_id=%s sample_index=%s status=%s error=%s"
            % (record.task_id, sample_index, trajectory.status, trajectory.error),
            extra={"status": trajectory.status, "error": trajectory.error},
        )
        self.store.upsert_sample(
            record.run_id,
            record.task_id,
            sample_index,
            sample_status,
            sample_dir=trajectory.sample_dir,
            last_step=trajectory.last_step,
            result=to_jsonable(trajectory),
        )
        sample_status = transition_sample_status(sample_status, SampleStatus.INSTANCE_RELEASING)
        self.store.upsert_sample(
            record.run_id,
            record.task_id,
            sample_index,
            sample_status,
            sample_dir=trajectory.sample_dir,
            last_step=trajectory.last_step,
            result=to_jsonable(trajectory),
        )
        sample_status = transition_sample_status(sample_status, SampleStatus.INSTANCE_RELEASED)
        self.store.upsert_sample(
            record.run_id,
            record.task_id,
            sample_index,
            sample_status,
            sample_dir=trajectory.sample_dir,
            last_step=trajectory.last_step,
            result=to_jsonable(trajectory),
        )
        self.score_sample_payload(
            record.run_id,
            record.task_id,
            sample_index,
            to_jsonable(trajectory),
            sample_status,
        )
        return True

    def handle_platform_mismatch_trajectory(
        self,
        record: TaskRecord,
        sample_index: int,
        lease: InstanceLease,
        sample_status: str,
        trajectory: TrajectoryResult,
        excluded_instance_ids: set[str],
    ) -> bool | None:
        if not is_platform_mismatch_failure(trajectory):
            return None
        excluded_instance_ids.add(lease.instance_id)
        required_platform = self.required_platform_for_task(record)
        mismatch_context = platform_mismatch_context_from_trajectory(trajectory)
        self.trace_sample(
            record,
            sample_index,
            "实例平台与镜像不一致，释放并换实例重试: task_id=%s instance_id=%s excluded=%s"
            % (record.task_id, lease.instance_id, ",".join(sorted(excluded_instance_ids))),
            extra={"instance_id": lease.instance_id},
        )
        self.instance_pool.release(lease, "platform_mismatch")
        if self.instance_pool.acquire_status(required_platform, excluded_instance_ids) == "unavailable":
            return self.finish_platform_failure_sample(
                record,
                sample_index,
                reason=PLATFORM_MISMATCH_EXHAUSTED,
                required_platform=required_platform,
                tried_instance_ids=excluded_instance_ids,
                mismatch_context=mismatch_context,
            )
        new_lease = self.try_acquire_lease(record, sample_index, excluded_instance_ids)
        if not new_lease:
            return self.finish_platform_failure_sample(
                record,
                sample_index,
                reason=PLATFORM_MISMATCH_EXHAUSTED,
                required_platform=required_platform,
                tried_instance_ids=excluded_instance_ids,
                mismatch_context=mismatch_context,
            )
        return self.run_sample_on_lease(record, sample_index, new_lease, sample_status, excluded_instance_ids)

    def run_sample_on_lease(
        self,
        record: TaskRecord,
        sample_index: int,
        lease: InstanceLease,
        sample_status: str,
        excluded_instance_ids: set[str] | None = None,
    ) -> bool:
        excluded = set(excluded_instance_ids or ())
        sample_status = SampleStatus.INITIALIZING_ENV.value
        self.trace_sample(
            record,
            sample_index,
            "获取实例成功: task_id=%s sample_index=%s instance_id=%s lease_id=%s"
            % (record.task_id, sample_index, lease.instance_id, lease.lease_id),
            extra={"instance_id": lease.instance_id, "lease_id": lease.lease_id},
        )
        self.store.upsert_sample(
            record.run_id,
            record.task_id,
            sample_index,
            sample_status,
            lease_id=lease.lease_id,
            instance_id=lease.instance_id,
        )
        job_lease = lease.as_instance_lease() if hasattr(lease, "as_instance_lease") else lease
        job = SampleJob(
            run_id=record.run_id,
            task_id=record.task_id,
            sample_index=sample_index,
            task=record,
            config=self.config,
            lease=job_lease,
        )
        sample_status = transition_sample_status(sample_status, SampleStatus.ENV_READY)
        self.store.upsert_sample(
            record.run_id,
            record.task_id,
            sample_index,
            sample_status,
            lease_id=lease.lease_id,
            instance_id=lease.instance_id,
        )
        sample_status = transition_sample_status(sample_status, SampleStatus.SAMPLING)
        self.store.upsert_sample(
            record.run_id,
            record.task_id,
            sample_index,
            sample_status,
            lease_id=lease.lease_id,
            instance_id=lease.instance_id,
        )
        try:
            self.trace_sample(
                record,
                sample_index,
                "开始执行采样: task_id=%s sample_index=%s instance_id=%s" % (record.task_id, sample_index, lease.instance_id),
                extra={"instance_id": lease.instance_id},
            )
            trajectory = self.executor.submit_sample(job)
        except Exception as exc:
            self.trace_sample(
                record,
                sample_index,
                "采样执行异常: task_id=%s sample_index=%s error=%s" % (record.task_id, sample_index, exc),
                extra={"error": "%s" % exc},
            )
            sample_status = transition_sample_status(sample_status, SampleStatus.SAMPLE_FAILED)
            self.store.upsert_sample(
                record.run_id,
                record.task_id,
                sample_index,
                sample_status,
                lease_id=lease.lease_id,
                instance_id=lease.instance_id,
                result={"error": "%s" % exc},
            )
            self.instance_pool.release(lease, "sample_failed")
            return False
        retry_result = self.handle_platform_mismatch_trajectory(
            record,
            sample_index,
            lease,
            sample_status,
            trajectory,
            excluded,
        )
        if retry_result is not None:
            return retry_result
        return self.finish_trajectory(record, sample_index, lease, sample_status, trajectory)

    def finish_sample_future(self, record: TaskRecord, sample_index: int, lease: InstanceLease, sample_status: str, future: Future) -> bool:
        try:
            self.trace_sample(record, sample_index, "等待进程池采样结果: task_id=%s sample_index=%s" % (record.task_id, sample_index))
            trajectory = future.result()
        except Exception as exc:
            self.trace_sample(
                record,
                sample_index,
                "采样执行异常: task_id=%s sample_index=%s error=%s" % (record.task_id, sample_index, exc),
                extra={"error": "%s" % exc},
            )
            sample_status = transition_sample_status(sample_status, SampleStatus.SAMPLE_FAILED)
            self.store.upsert_sample(
                record.run_id,
                record.task_id,
                sample_index,
                sample_status,
                lease_id=lease.lease_id,
                instance_id=lease.instance_id,
                result={"error": "%s" % exc},
            )
            sample_status = transition_sample_status(sample_status, SampleStatus.INSTANCE_RELEASING)
            self.store.upsert_sample(
                record.run_id,
                record.task_id,
                sample_index,
                sample_status,
                lease_id=lease.lease_id,
                instance_id=lease.instance_id,
                result={"error": "%s" % exc},
            )
            self.instance_pool.release(lease, "sample_failed")
            sample_status = transition_sample_status(sample_status, SampleStatus.INSTANCE_RELEASED)
            self.store.upsert_sample(
                record.run_id,
                record.task_id,
                sample_index,
                sample_status,
                lease_id=lease.lease_id,
                instance_id=lease.instance_id,
                result={"error": "%s" % exc},
            )
            return False
        retry_result = self.handle_platform_mismatch_trajectory(
            record,
            sample_index,
            lease,
            sample_status,
            trajectory,
            set(),
        )
        if retry_result is not None:
            return retry_result
        return self.finish_trajectory(record, sample_index, lease, sample_status, trajectory)

    def run_sample(self, record: TaskRecord, sample_index: int) -> bool:
        sample_status = SampleStatus.WAITING_FOR_INSTANCE.value
        self.store.upsert_sample(
            record.run_id,
            record.task_id,
            sample_index,
            sample_status,
        )
        if self.shutdown_requested():
            sample_status = transition_sample_status(sample_status, SampleStatus.SAMPLE_INTERRUPTED)
            self.store.upsert_sample(
                record.run_id,
                record.task_id,
                sample_index,
                sample_status,
                result={"error": "等待实例前收到退出信号"},
            )
            return False
        self.background_log("等待实例: task_id=%s sample_index=%s" % (record.task_id, sample_index))
        required_platform = self.required_platform_for_task(record)
        if required_platform and self.instance_pool.acquire_status(required_platform) == "unavailable":
            return self.finish_platform_failure_sample(
                record,
                sample_index,
                reason=PLATFORM_MATCH_UNAVAILABLE,
                required_platform=required_platform,
            )
        lease = self.acquire_lease_waiting(record, sample_index)
        if not lease:
            if self.shutdown_requested():
                sample_status = transition_sample_status(sample_status, SampleStatus.SAMPLE_INTERRUPTED)
                self.store.upsert_sample(
                    record.run_id,
                    record.task_id,
                    sample_index,
                    sample_status,
                    result={"error": "等待实例时收到退出信号"},
                )
                return False
            if required_platform and self.instance_pool.acquire_status(required_platform) == "unavailable":
                return self.finish_platform_failure_sample(
                    record,
                    sample_index,
                    reason=PLATFORM_MATCH_UNAVAILABLE,
                    required_platform=required_platform,
                )
            self.background_log(
                "获取实例失败: task_id=%s sample_index=%s required_platform=%s"
                % (record.task_id, sample_index, required_platform or "<any>")
            )
            return False
        return self.run_sample_on_lease(record, sample_index, lease, sample_status)

    def finish_trajectory(
        self,
        record: TaskRecord,
        sample_index: int,
        lease: InstanceLease,
        sample_status: str,
        trajectory: TrajectoryResult,
    ) -> bool:
        sample_status = transition_sample_status(sample_status, trajectory.status)
        self.trace_sample(
            record,
            sample_index,
            "采样执行完成: task_id=%s sample_index=%s status=%s last_step=%s sample_dir=%s"
            % (record.task_id, sample_index, trajectory.status, trajectory.last_step, trajectory.sample_dir),
            extra={"status": trajectory.status, "last_step": trajectory.last_step, "sample_dir": trajectory.sample_dir},
        )
        self.store.upsert_sample(
            record.run_id,
            record.task_id,
            sample_index,
            sample_status,
            sample_dir=trajectory.sample_dir,
            lease_id=lease.lease_id,
            instance_id=lease.instance_id,
            last_step=trajectory.last_step,
            result=to_jsonable(trajectory),
        )
        sample_status = transition_sample_status(sample_status, SampleStatus.INSTANCE_RELEASING)
        self.store.upsert_sample(
            record.run_id,
            record.task_id,
            sample_index,
            sample_status,
            sample_dir=trajectory.sample_dir,
            lease_id=lease.lease_id,
            instance_id=lease.instance_id,
            last_step=trajectory.last_step,
            result=to_jsonable(trajectory),
        )
        self.instance_pool.release(lease, "sample_finished")
        sample_status = transition_sample_status(sample_status, SampleStatus.INSTANCE_RELEASED)
        self.store.upsert_sample(
            record.run_id,
            record.task_id,
            sample_index,
            sample_status,
            sample_dir=trajectory.sample_dir,
            lease_id=lease.lease_id,
            instance_id=lease.instance_id,
            last_step=trajectory.last_step,
            result=to_jsonable(trajectory),
        )
        self.store.add_outbox_event(
            OutboxEvent(
                run_id=record.run_id,
                event_id=new_id("evt"),
                event_type="trajectory_ready_to_sync",
                task_id=record.task_id,
                sample_index=sample_index,
                payload=to_jsonable(trajectory),
                idempotency_key="%s:%s:%s:trajectory_sync" % (record.run_id, record.task_id, sample_index),
            )
        )
        self.score_sample_payload(
            record.run_id,
            record.task_id,
            sample_index,
            to_jsonable(trajectory),
            sample_status,
        )
        return True

    def score_sample_payload(
        self,
        run_id: str,
        task_id: str,
        sample_index: int,
        payload: dict,
        current_status: str,
    ):
        score_path = os.path.join(payload.get("sample_dir") or "", "score.json")
        if score_path and os.path.exists(score_path):
            return {"score_json_path": score_path, "status": "already_scored"}

        scoring_status = transition_sample_status(current_status, SampleStatus.SCORING)
        self.store.upsert_sample(
            run_id,
            task_id,
            sample_index,
            scoring_status,
            sample_dir=payload.get("sample_dir"),
            last_step=payload.get("last_step", -1),
        )
        score = self.scorer.score_payload(payload)
        scored_status = transition_sample_status(scoring_status, SampleStatus.SCORED)
        self.store.upsert_sample(
            run_id,
            task_id,
            sample_index,
            scored_status,
            sample_dir=payload.get("sample_dir"),
            last_step=payload.get("last_step", -1),
            result=to_jsonable(score),
        )
        self.store.add_outbox_event(
            OutboxEvent(
                run_id=run_id,
                event_id=new_id("evt"),
                event_type="score_ready_to_sync",
                task_id=task_id,
                sample_index=sample_index,
                payload={**to_jsonable(score), "task_fields": payload.get("task_fields") or {}},
                idempotency_key="%s:%s:%s:score_sync" % (run_id, task_id, sample_index),
            )
        )
        trace(
            "判分完成: task_id=%s sample_index=%s score_path=%s answer_score=%s"
            % (
                task_id,
                sample_index,
                score.score_json_path,
                (score.check or {}).get("answer_score"),
            )
        )
        return score

    def drain_outbox(self, event_types: tuple[str, ...]) -> bool:
        while True:
            event = self.store.claim_outbox_event(event_types, worker_id="scheduler", run_id=self.config.run_id)
            if not event:
                return True
            trace(
                "开始处理 outbox: event_type=%s task_id=%s sample_index=%s attempts=%s"
                % (event["event_type"], event.get("task_id"), event.get("sample_index"), event.get("attempts"))
            )
            try:
                result = self.handle_event(event)
            except Exception as exc:
                event_status = self.store.fail_claim(event["claim_id"], event["event_id"], "%s" % exc)
                trace(
                    "outbox 处理失败: event_type=%s task_id=%s status=%s error=%s"
                    % (event["event_type"], event.get("task_id"), event_status, exc)
                )
                if event_status == "failed":
                    return False
                continue
            self.store.complete_claim(event["claim_id"], event["event_id"], result)
            trace(
                "outbox 处理完成: event_type=%s task_id=%s result=%s"
                % (event["event_type"], event.get("task_id"), result)
            )

    def handle_event(self, event: dict):
        event_type = event["event_type"]
        payload = event["payload"]
        if event_type == "validation_ready_to_sync":
            self.writer.write_validation_summary(payload)
            return {"status": "validation_synced"}
        if event_type == "trajectory_ready_to_sync":
            self.writer.write_trajectory_payload(payload)
            return {"status": "trajectory_synced"}
        if event_type == "sample_ready_to_score":
            current = self.store.get_sample(event["run_id"], event["task_id"], event["sample_index"])
            current_status = current["status"] if current else SampleStatus.INSTANCE_RELEASED.value
            score = self.score_sample_payload(
                event["run_id"],
                event["task_id"],
                event["sample_index"],
                payload,
                current_status,
            )
            if isinstance(score, dict):
                return {"status": score.get("status", "already_scored"), "score_json_path": score.get("score_json_path", "")}
            return {"status": "scored", "score_json_path": score.score_json_path}
        if event_type == "score_ready_to_sync":
            self.writer.write_score_payload(payload)
            return {"status": "score_synced"}
        raise ValueError("unknown event type: %s" % event_type)


def demo_task(config: RunConfig) -> TaskRecord:
    return TaskRecord(
        run_id=config.run_id,
        task_id="task_demo",
        row_number=config.start_row,
        fields={
            "task": DEMO_TASK_UP,
            "up": DEMO_TASK_UP,
            "image_id": config.demo_image_id,
            "tos_url": [],
            "输入文件路径": "/home/user/Desktop/input",
            "输出文件路径": "/home/user/Desktop/output",
            "final_answer文件名": "",
        },
    )


def trace(message: str) -> None:
    print(message, flush=True)


def scheduler_log_path(output_root: str) -> Path:
    output_path = Path(output_root or "output")
    output_dir = output_path.parent if output_path.parent != Path(".") else Path("output")
    return output_dir / "logs" / "scheduler.log"


def print_validation_failure(record: TaskRecord, reason: str) -> None:
    trace(
        "任务校验失败: task_id=%s row=%s reason=%s"
        % (record.task_id, record.row_number, reason)
    )
    important_keys = (
        "id",
        "image",
        "image_id",
        "镜像ID",
        "题目",
        "启动方式",
        "tos_url",
        "输入文件路径",
        "输出文件路径",
        "final_answer文件名",
        "answer_type",
        "metric_type",
    )
    for key in important_keys:
        if key in record.fields:
            trace("  - %s=%s" % (key, record.fields.get(key)))

