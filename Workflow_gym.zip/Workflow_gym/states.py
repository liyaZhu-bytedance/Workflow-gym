from __future__ import annotations

from enum import Enum


class ErrorCategory(str, Enum):
    RETRYABLE = "retryable"
    NON_RETRYABLE = "non_retryable"
    RESOURCE_QUARANTINE = "resource_quarantine"
    SYNC_PENDING = "sync_pending"
    INTERRUPTED = "interrupted"


class TaskStatus(str, Enum):
    READ = "read"
    VALIDATED = "validated"
    VALIDATION_FAILED = "validation_failed"
    VALIDATION_WRITTEN = "validation_written"
    VALIDATION_REPORT_FAILED = "validation_report_failed"
    SAMPLING_PENDING = "sampling_pending"
    SCORING_PENDING = "scoring_pending"
    SYNCING_FEISHU = "syncing_feishu"
    SYNCED = "synced"
    FAILED = "failed"
    INTERRUPTED = "interrupted"


class SampleStatus(str, Enum):
    WAITING_FOR_INSTANCE = "waiting_for_instance"
    INITIALIZING_ENV = "initializing_env"
    ENV_READY = "env_ready"
    SAMPLING = "sampling"
    SAMPLE_COMPLETED = "sample_completed"
    SAMPLE_FAILED = "sample_failed"
    SAMPLE_INTERRUPTED = "sample_interrupted"
    SAMPLE_MAX_STEPS_REACHED = "sample_max_steps_reached"
    RESUMING = "resuming"
    RESUME_FAILED = "resume_failed"
    INSTANCE_RELEASING = "instance_releasing"
    INSTANCE_RELEASED = "instance_released"
    SCORING = "scoring"
    SCORED = "scored"
    SCORE_FAILED = "score_failed"
    FEISHU_SYNC_FAILED = "feishu_sync_failed"


class InstanceStatus(str, Enum):
    IDLE = "idle"
    LEASED = "leased"
    STOPPING = "stopping"
    STOPPED = "stopped"
    REPLACING_IMAGE = "replacing_image"
    IMAGE_REPLACED = "image_replaced"
    STARTING = "starting"
    READY = "ready"
    RUNNING_SAMPLE = "running_sample"
    RELEASING = "releasing"
    QUARANTINED = "quarantined"


TASK_TRANSITIONS = {
    TaskStatus.READ: {
        TaskStatus.VALIDATED,
        TaskStatus.VALIDATION_FAILED,
        TaskStatus.INTERRUPTED,
    },
    TaskStatus.VALIDATED: {
        TaskStatus.VALIDATION_WRITTEN,
        TaskStatus.VALIDATION_REPORT_FAILED,
    },
    TaskStatus.VALIDATION_WRITTEN: {TaskStatus.SAMPLING_PENDING},
    TaskStatus.SAMPLING_PENDING: {
        TaskStatus.SCORING_PENDING,
        TaskStatus.FAILED,
        TaskStatus.INTERRUPTED,
    },
    TaskStatus.SCORING_PENDING: {
        TaskStatus.SYNCING_FEISHU,
        TaskStatus.FAILED,
        TaskStatus.INTERRUPTED,
    },
    TaskStatus.SYNCING_FEISHU: {
        TaskStatus.SYNCED,
        TaskStatus.FAILED,
        TaskStatus.INTERRUPTED,
    },
}


SAMPLE_TRANSITIONS = {
    SampleStatus.WAITING_FOR_INSTANCE: {
        SampleStatus.INITIALIZING_ENV,
        SampleStatus.SAMPLE_INTERRUPTED,
    },
    SampleStatus.INITIALIZING_ENV: {
        SampleStatus.ENV_READY,
        SampleStatus.SAMPLE_FAILED,
        SampleStatus.SAMPLE_INTERRUPTED,
    },
    SampleStatus.ENV_READY: {SampleStatus.SAMPLING},
    SampleStatus.SAMPLING: {
        SampleStatus.SAMPLE_COMPLETED,
        SampleStatus.SAMPLE_FAILED,
        SampleStatus.SAMPLE_INTERRUPTED,
        SampleStatus.SAMPLE_MAX_STEPS_REACHED,
    },
    SampleStatus.SAMPLE_COMPLETED: {SampleStatus.INSTANCE_RELEASING},
    SampleStatus.SAMPLE_FAILED: {SampleStatus.INSTANCE_RELEASING},
    SampleStatus.SAMPLE_INTERRUPTED: {
        SampleStatus.INSTANCE_RELEASING,
        SampleStatus.RESUMING,
    },
    SampleStatus.SAMPLE_MAX_STEPS_REACHED: {SampleStatus.INSTANCE_RELEASING},
    SampleStatus.RESUMING: {SampleStatus.SAMPLING, SampleStatus.RESUME_FAILED},
    SampleStatus.RESUME_FAILED: {SampleStatus.INSTANCE_RELEASING},
    SampleStatus.INSTANCE_RELEASING: {SampleStatus.INSTANCE_RELEASED},
    SampleStatus.INSTANCE_RELEASED: {SampleStatus.SCORING},
    SampleStatus.SCORING: {SampleStatus.SCORED, SampleStatus.SCORE_FAILED},
    SampleStatus.SCORED: set(),
    SampleStatus.SCORE_FAILED: set(),
}


def transition_state(current: str, new: str, transitions: dict) -> str:
    """Validate and return a legal state transition."""
    current_text = state_value(current)
    new_text = state_value(new)
    if current_text == new_text:
        return new_text
    current_value = _coerce_state(current_text, transitions)
    new_value = _coerce_state(new_text, transitions)
    allowed = transitions.get(current_value, set())
    if new_value not in allowed:
        raise ValueError("invalid state transition: %s -> %s" % (current_text, new_text))
    return new_text


def transition_task_status(current: str, new: TaskStatus | str) -> str:
    return transition_state(current, new, TASK_TRANSITIONS)


def transition_sample_status(current: str, new: SampleStatus | str) -> str:
    return transition_state(current, new, SAMPLE_TRANSITIONS)


def _coerce_state(value: str, transitions: dict):
    for state in transitions:
        if state_value(state) == state_value(value):
            return state
    for allowed in transitions.values():
        for state in allowed:
            if state_value(state) == state_value(value):
                return state
    raise ValueError("unknown state: %s" % value)


def state_value(value) -> str:
    return value.value if isinstance(value, Enum) else str(value)

