from __future__ import annotations

from pathlib import Path

from .records import now_text


CANCEL_FILE_NAME = ".workflowgym_cancel"


def cancel_file_path(output_root: str) -> Path:
    return Path(output_root) / CANCEL_FILE_NAME


def request_cancel(output_root: str, reason: str = "shutdown requested") -> None:
    if not output_root:
        return
    path = cancel_file_path(output_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("%s %s\n" % (now_text(), reason), encoding="utf-8")


def clear_cancel(output_root: str) -> None:
    if not output_root:
        return
    path = cancel_file_path(output_root)
    if path.exists():
        path.unlink()


def is_cancel_requested(output_root: str) -> bool:
    return bool(output_root) and cancel_file_path(output_root).exists()
