from __future__ import annotations

import ast
import json
import posixpath
import re
import ntpath
import urllib.parse
from dataclasses import dataclass
from typing import Iterable

from .records import TaskFileResult, TaskRecord


@dataclass(frozen=True)
class DownloadPlan:
    url: str
    filename: str


URL_RE = re.compile(r"(?:https?|tos)://[^\s'\"\]\),}]+")


def parse_tos_urls(raw_value) -> list[str]:
    if not raw_value:
        return []
    if isinstance(raw_value, (list, tuple)):
        return tos_urls_from_value(raw_value)
    if isinstance(raw_value, dict):
        return tos_urls_from_value(raw_value)
    text = str(raw_value).strip()
    if not text or text in ("[]", "null", "None"):
        return []
    try:
        value = json.loads(text)
    except ValueError:
        try:
            value = ast.literal_eval(text)
        except (ValueError, SyntaxError):
            value = text
    urls = tos_urls_from_value(value)
    if urls:
        return urls
    if isinstance(value, str):
        return [value]
    if not isinstance(value, (list, tuple, dict)):
        raise ValueError("tos_url must be a list, dict, or string")
    return []


def tos_urls_from_value(value) -> list[str]:
    urls: list[str] = []

    def add_url(candidate) -> None:
        if candidate is None:
            return
        text = str(candidate).strip()
        if not text:
            return
        matches = URL_RE.findall(text)
        if matches:
            urls.extend(match.rstrip(".,;") for match in matches)

    def visit(item) -> None:
        if item is None:
            return
        if isinstance(item, dict):
            for key in ("url", "link", "href", "text"):
                add_url(item.get(key))
            return
        if isinstance(item, (list, tuple)):
            for child in item:
                visit(child)
            return
        add_url(item)

    visit(value)
    deduped: list[str] = []
    seen: set[str] = set()
    for url in urls:
        if url not in seen:
            deduped.append(url)
            seen.add(url)
    return deduped


def build_download_plan(urls: Iterable[str]) -> list[DownloadPlan]:
    used: dict[str, int] = {}
    plan = []
    for url in urls:
        filename = filename_from_url(url)
        download_url = download_url_from_url(url)
        count = used.get(filename, 0) + 1
        used[filename] = count
        if count > 1:
            stem, dot, suffix = filename.rpartition(".")
            filename = "%s_%s.%s" % (stem or filename, count, suffix) if dot else "%s_%s" % (filename, count)
        plan.append(DownloadPlan(url=download_url, filename=filename))
    return plan


def download_url_from_url(url: str) -> str:
    normalized = str(url).split("?", 1)[0]
    parsed = urllib.parse.urlparse(normalized)
    if parsed.scheme in ("http", "https") and parsed.netloc.startswith("synthetic-gui-data"):
        path = parsed.path.lstrip("/")
        return "https://lf-gui-file.bytetos.com/obj/synthetic-gui-data/%s" % path
    return normalized


def filename_from_url(url: str) -> str:
    parsed = urllib.parse.urlparse(url)
    name = posixpath.basename(parsed.path)
    name = urllib.parse.unquote(name)
    if not name:
        raise ValueError("cannot infer filename from url: %s" % url)
    return sanitize_filename(name)


def sanitize_filename(name: str) -> str:
    name = name.replace("\\", "_").replace("/", "_").strip()
    if not name or name in (".", ".."):
        raise ValueError("invalid filename: %s" % name)
    return name


def parse_final_answer_names(raw_value: str) -> list[str]:
    if not raw_value:
        return []
    if isinstance(raw_value, list):
        return [
            validate_relative_output_path(final_answer_name_from_item(item))
            for item in raw_value
            if final_answer_name_from_item(item)
        ]
    text = str(raw_value).strip()
    if not text or text in ("[]", "null", "None"):
        return []
    try:
        parsed = json.loads(text)
    except ValueError:
        try:
            parsed = ast.literal_eval(text)
        except (ValueError, SyntaxError):
            parsed = None
    if isinstance(parsed, list):
        return [
            validate_relative_output_path(final_answer_name_from_item(item))
            for item in parsed
            if final_answer_name_from_item(item)
        ]
    if isinstance(parsed, dict):
        name = final_answer_name_from_item(parsed)
        return [validate_relative_output_path(name)] if name else []
    names = []
    for item in text.split(","):
        item = item.strip()
        if item:
            names.append(validate_relative_output_path(item))
    return names


def final_answer_name_from_item(item) -> str:
    if isinstance(item, dict):
        return str(item.get("link") or item.get("text") or item.get("name") or "").strip()
    return str(item).strip()


def validate_relative_output_path(path: str) -> str:
    path = path.strip().replace("\\", "/")
    if not path:
        raise ValueError("empty final answer path")
    if path.startswith("/") or re.match(r"^[a-zA-Z]:/", path):
        raise ValueError("final answer path must be relative: %s" % path)
    normalized = posixpath.normpath(path)
    if normalized.startswith("../") or normalized == "..":
        raise ValueError("final answer path escapes output directory: %s" % path)
    return normalized


def is_windows_path(path: str) -> bool:
    return bool(re.match(r"^[a-zA-Z]:\\", path)) or "\\" in path


def split_output_paths(output_path: str) -> list[str]:
    text = (output_path or "").strip()
    if not text:
        return []
    if "," not in text:
        return [text]
    parts = [item.strip() for item in text.split(",") if item.strip()]
    return parts or [text]


def build_prepare_input_command(input_dir: str, plan: list[DownloadPlan], timeout_seconds: int) -> str:
    if not input_dir or not plan:
        return ""
    if is_windows_path(input_dir):
        return build_windows_prepare_input_command(input_dir, plan, timeout_seconds)
    return build_linux_prepare_input_command(input_dir, plan, timeout_seconds)


def build_linux_prepare_input_command(input_dir: str, plan: list[DownloadPlan], timeout_seconds: int) -> str:
    download_items = [
        {
            "url": item.url,
            "filename": item.filename,
        }
        for item in plan
    ]
    lines = [
        "#!/bin/bash",
        "set -euo pipefail",
        "input_dir=%s" % shell_quote(input_dir),
        "mkdir -p \"$input_dir\"",
        "find \"$input_dir\" -mindepth 1 -maxdepth 1 -exec rm -rf {} +",
        "export WORKFLOWGYM_INPUT_DIR=\"$input_dir\"",
        "python3 - <<'PY'",
        "import json",
        "import os",
        "import pathlib",
        "import subprocess",
        "import time",
        "",
        "input_dir = pathlib.Path(os.environ['WORKFLOWGYM_INPUT_DIR'])",
        "items = json.loads(%s)" % repr(json.dumps(download_items, ensure_ascii=False)),
        "timeout = %s" % int(timeout_seconds),
        "for item in items:",
        "    url = item['url']",
        "    target = input_dir / item['filename']",
        "    last_error = None",
        "    for attempt in range(1, 4):",
        "        try:",
        "            print('download input attempt=%s url=%s target=%s' % (attempt, url, target), flush=True)",
        "            subprocess.run([",
        "                'wget',",
        "                '-q',",
        "                '--timeout=%s' % timeout,",
        "                '--tries=1',",
        "                '--user-agent=WorkflowGym/1.0',",
        "                '-O',",
        "                str(target),",
        "                url,",
        "            ], check=True)",
        "            if target.stat().st_size <= 0:",
        "                raise RuntimeError('downloaded empty file: %s' % target)",
        "            print('download input ok target=%s bytes=%s' % (target, target.stat().st_size), flush=True)",
        "            break",
        "        except Exception as exc:",
        "            last_error = exc",
        "            print('download input failed attempt=%s url=%s error=%s' % (attempt, url, exc), flush=True)",
        "            if attempt < 3:",
        "                time.sleep(2 * attempt)",
        "    else:",
        "        raise RuntimeError('download input exhausted url=%s target=%s last_error=%s' % (url, target, last_error))",
        "PY",
    ]
    return "\n".join(lines)


def build_windows_prepare_input_command(input_dir: str, plan: list[DownloadPlan], timeout_seconds: int) -> str:
    lines = [
        "$ErrorActionPreference = 'Stop'",
        "$inputDir = %s" % ps_quote(input_dir),
        "New-Item -ItemType Directory -Force -Path $inputDir | Out-Null",
        "Get-ChildItem -LiteralPath $inputDir -Force | Remove-Item -Recurse -Force",
    ]
    for item in plan:
        target = ntpath.join(input_dir, item.filename)
        lines.append(
            "Invoke-WebRequest -Uri %s -OutFile %s -TimeoutSec %s"
            % (ps_quote(item.url), ps_quote(target), timeout_seconds)
        )
    return "\n".join(lines)


def sort_output_dirs_for_prepare(output_dirs: list[str]) -> list[str]:
    return sorted(output_dirs, key=lambda path: (path.count("/"), len(path)))


def build_prepare_output_command(output_dir: str) -> str:
    output_dirs = split_output_paths(output_dir)
    if not output_dirs:
        return ""
    if is_windows_path(output_dirs[0]):
        return build_windows_prepare_output_command(output_dirs)
    return build_linux_prepare_output_command(output_dirs)


def build_linux_prepare_output_command(output_dirs: str | list[str]) -> str:
    dirs = sort_output_dirs_for_prepare(
        split_output_paths(output_dirs) if isinstance(output_dirs, str) else list(output_dirs)
    )
    lines = [
        "#!/bin/bash",
        "set -euo pipefail",
    ]
    for output_dir in dirs:
        lines.extend(
            [
                "output_dir=%s" % shell_quote(output_dir),
                "if [ ! -d \"$output_dir\" ]; then",
                "  rm -rf \"$output_dir\"",
                "fi",
                "mkdir -p \"$output_dir\"",
                "find \"$output_dir\" -mindepth 1 -maxdepth 1 -exec rm -rf {} +",
            ]
        )
    return "\n".join(lines)


def build_windows_prepare_output_command(output_dirs: str | list[str]) -> str:
    dirs = sort_output_dirs_for_prepare(
        split_output_paths(output_dirs) if isinstance(output_dirs, str) else list(output_dirs)
    )
    lines = ["$ErrorActionPreference = 'Stop'"]
    for output_dir in dirs:
        lines.extend(
            [
                "$outputDir = %s" % ps_quote(output_dir),
                "if ((Test-Path -LiteralPath $outputDir) -and -not (Test-Path -LiteralPath $outputDir -PathType Container)) {",
                "  Remove-Item -LiteralPath $outputDir -Force",
                "}",
                "New-Item -ItemType Directory -Force -Path $outputDir | Out-Null",
                "Get-ChildItem -LiteralPath $outputDir -Force | Remove-Item -Recurse -Force",
            ]
        )
    return "\n".join(lines)


def build_tosutil_upload_commands(
    output_dir: str,
    final_names: list[str],
    tos_prefix: str,
    presign_valid_period: str = "24h",
) -> list[str]:
    output_dirs = split_output_paths(output_dir)
    if not output_dirs or not final_names:
        return []
    if is_windows_path(output_dirs[0]):
        return [build_windows_tosutil_upload_command(output_dirs, final_names, tos_prefix, presign_valid_period)]
    return [build_linux_tosutil_upload_command(output_dirs, final_names, tos_prefix, presign_valid_period)]


def build_linux_tosutil_upload_command(
    output_dirs: str | list[str],
    final_names: list[str],
    tos_prefix: str,
    presign_valid_period: str = "24h",
) -> str:
    dirs = split_output_paths(output_dirs) if isinstance(output_dirs, str) else list(output_dirs)
    lines = [
        "#!/bin/bash",
        "set -euo pipefail",
        "presign_valid_period=%s" % shell_quote(presign_valid_period or "24h"),
    ]
    for index, relative in enumerate(final_names):
        target = posixpath.join(tos_prefix, relative)
        target_path = tos_target_path(target)
        uploaded_flag = "uploaded_%s" % index
        lines.append("%s=0" % uploaded_flag)
        for output_dir in dirs:
            source = posixpath.join(output_dir, relative)
            lines.extend(
                [
                    "if [ \"${%s}\" -eq 0 ] && [ -f %s ]; then" % (uploaded_flag, shell_quote(source)),
                    "  tosutil cp %s %s" % (shell_quote(source), shell_quote(target_path)),
                    "  presign_output=\"$(tosutil presign %s -vp=\"$presign_valid_period\")\"" % shell_quote(target_path),
                    "  printf '%s\\n' \"$presign_output\"",
                    "  presign_url=\"$(printf '%s\\n' \"$presign_output\" | awk '/^https?:\\/\\// {print; exit}')\"",
                    "  if [ -n \"$presign_url\" ]; then",
                    "    printf 'WORKFLOWGYM_TOS_PRESIGN\\t%s\\t%s\\n' %s \"$presign_url\"" % (
                        "%s",
                        "%s",
                        shell_quote(relative),
                    ),
                    "  fi",
                    "  %s=1" % uploaded_flag,
                    "fi",
                ]
            )
        lines.append("if [ \"${%s}\" -eq 0 ]; then echo 'missing final answer: %s'; fi" % (uploaded_flag, relative))
    return "\n".join(lines)


def build_windows_tosutil_upload_command(
    output_dirs: str | list[str],
    final_names: list[str],
    tos_prefix: str,
    presign_valid_period: str = "24h",
) -> str:
    dirs = split_output_paths(output_dirs) if isinstance(output_dirs, str) else list(output_dirs)
    lines = [
        "$ErrorActionPreference = 'Continue'",
        "$presignValidPeriod = %s" % ps_quote(presign_valid_period or "24h"),
    ]
    for index, relative in enumerate(final_names):
        target = tos_target_path(posixpath.join(tos_prefix, relative))
        uploaded_flag = "$uploaded_%s" % index
        lines.append("%s = 0" % uploaded_flag)
        for output_dir in dirs:
            source = ntpath.join(output_dir, relative.replace("/", "\\"))
            lines.append(
                "if (%s -eq 0 -and (Test-Path -LiteralPath %s)) { "
                "tosutil cp %s %s; "
                "$presignOutput = tosutil presign %s -vp=$presignValidPeriod; "
                "$presignOutput | Write-Output; "
                "$presignUrl = ($presignOutput | Where-Object { $_ -match '^https?://' } | Select-Object -First 1); "
                "if ($presignUrl) { Write-Output (%s -f %s, $presignUrl) }; "
                "%s = 1 "
                "}"
                % (
                    uploaded_flag,
                    ps_quote(source),
                    ps_quote(source),
                    ps_quote(target),
                    ps_quote(target),
                    ps_quote("WORKFLOWGYM_TOS_PRESIGN`t{0}`t{1}"),
                    ps_quote(relative),
                    uploaded_flag,
                )
            )
        lines.append(
            "if (%s -eq 0) { Write-Output %s }"
            % (uploaded_flag, ps_quote("missing final answer: %s" % relative))
        )
    return "\n".join(lines)


def tos_target_path(target: str) -> str:
    return target if target.startswith("tos://") else "tos://" + target


def task_file_result_from_record(record: TaskRecord) -> TaskFileResult:
    urls = parse_tos_urls(record.tos_url)
    final_names = parse_final_answer_names(record.final_answer_names)
    return TaskFileResult(input_urls=urls, final_answer_files=final_names)


def shell_quote(value: str) -> str:
    return "'" + value.replace("'", "'\"'\"'") + "'"


def shell_escape_double(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"').replace("$", "\\$")


def ps_quote(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"

