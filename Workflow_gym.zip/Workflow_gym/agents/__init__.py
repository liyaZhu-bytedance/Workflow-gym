"""Agent adapters and middleware."""

