from __future__ import annotations

from typing import Any

from .base import SampleContext


class Middleware:
    name = "middleware"

    def before_predict(self, context: SampleContext) -> None:
        return None

    def after_parse(self, parsed: dict[str, Any], context: SampleContext) -> dict[str, Any]:
        return parsed


class SafetyCheckMiddleware(Middleware):
    name = "safety_check"

    def validate_code(self, code: str) -> None:
        blocked = ("rm -rf /", "shutdown", "reboot")
        if any(item in code for item in blocked):
            raise ValueError("blocked unsafe code")


class CoordinateTransformMiddleware(Middleware):
    name = "coordinate_transform"

