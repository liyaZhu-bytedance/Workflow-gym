from __future__ import annotations

import base64
import logging
import os
import time
from typing import Any

from ..records import PromptBundle
from .base import BaseAgentAdapter, SampleContext


logger = logging.getLogger(__name__)

OPERATOR_PROMPT = """

You are a GUI agent operating a virtual machine desktop. You will receive screenshots and
must use the computer tool to complete the task described above.

Important guidelines:
- Follow the task description exactly. The task description is the source of truth for
  applications, files, paths, parameters, output requirements, and success criteria.
- In every turn, first provide a concise reasoning / thinking summary in text: describe
  what you see, what you believe the current state is, and why the next action helps.
- Do not stop, return no action, or only ask for another screenshot before the task is
  complete. If the task is not complete, you must continue with at least one meaningful
  computer action based on the current screenshot. It is sctitily to be prohibited that
  you output empty actions before completing all the task.
- The virtual machine environment is already running. Use the application or desktop state
  shown in the screenshot when possible; do not switch to unrelated applications unless the
  task requires it.
- You can act without asking for confirmation.
- If repeated actions leave the screen unchanged, try a different or more specific action.
"""


class GptNativeAgentAdapter(BaseAgentAdapter):
    name = "gpt"
    dynamic_prompts = False
    model = "gpt-5.4"
    base_url = "https://api.openai.com/v1"
    api_version = "responses"
    request_kwargs = {"reasoning_effort": "xhigh", "max_output_tokens": 1500}
    default_headers: dict[str, str] = {}

    def __init__(self):
        self.previous_response_id: str | None = None
        self.pending_input_items: list[dict[str, Any]] = []
        self._last_actions: list[dict[str, Any]] = []
        self._should_stop_after_step = False
        self.screen_width = int(os.getenv("GPT_NATIVE_SCREEN_WIDTH", "1920"))
        self.screen_height = int(os.getenv("GPT_NATIVE_SCREEN_HEIGHT", "1080"))

    def model_name(self) -> str:
        return gpt_model(self.model)

    def base_url_value(self) -> str:
        return gpt_base_url(self.base_url)

    def build_prompts(self, context: SampleContext) -> PromptBundle:
        instruction = self.task_instruction(context)
        return PromptBundle(sp="", up=instruction)

    def predict(self, context: SampleContext) -> str:
        self._should_stop_after_step = False
        if context.metadata.get("dry_run"):
            self._last_actions = []
            self._should_stop_after_step = True
            return "No-op gpt native dry-run response."
        request_input = self.build_request_input(context)
        response = self.create_response(request_input)
        self.previous_response_id = get_field(response, "id")
        self.pending_input_items = []
        predict_info, actions = self.parse_response_output(response)
        self._last_actions = actions
        if not predict_info.get("state_correct", True) and not actions:
            self._should_stop_after_step = True
        return predict_info.get("response", "")

    def build_request_input(self, context: SampleContext) -> list[dict[str, Any]]:
        screenshot_b64 = encode_image_path(context.current_screenshot)
        if not self.previous_response_id:
            return [
                {
                    "role": "user",
                    "content": [
                        {"type": "input_text", "text": (context.prompts.up or self.task_instruction(context)) + OPERATOR_PROMPT},
                        {"type": "input_image", "image_url": f"data:image/png;base64,{screenshot_b64}"},
                    ],
                }
            ]
        if self.pending_input_items:
            return list(self.pending_input_items)
        return [
            {
                "role": "user",
                "content": [
                    {"type": "input_text", "text": "Continue from the latest screenshot."},
                    {"type": "input_image", "image_url": f"data:image/png;base64,{screenshot_b64}"},
                ],
            }
        ]

    def create_response(self, request_input: list[dict[str, Any]]):
        api_key = gpt_api_key()
        if not api_key:
            raise ValueError("缺少 RUNNER_API_KEY / OPENAI_API_KEY / GPT_NATIVE_API_KEY，无法调用 gpt player")
        try:
            import httpx
            from openai import OpenAI
        except ImportError as exc:
            raise RuntimeError("缺少 openai/httpx 依赖，无法调用 gpt native player") from exc
        proxy_url = os.getenv("OPENAI_PROXY") or os.getenv("GPT_NATIVE_PROXY") or ""
        http_client = build_httpx_client(httpx, proxy_url)
        client = OpenAI(api_key=api_key, base_url=self.base_url_value(), http_client=http_client)
        request: dict[str, Any] = {
            "model": self.model_name(),
            "input": request_input,
            "tools": [{"type": "computer"}],
            "reasoning": {
                "effort": self.request_kwargs.get("reasoning_effort", "high"),
                "summary": "concise",
            },
            "truncation": "auto",
            "max_output_tokens": self.request_kwargs.get("max_output_tokens", 1500),
        }
        if self.previous_response_id:
            request["previous_response_id"] = self.previous_response_id
        last_error = None
        for attempt in range(5):
            try:
                return client.responses.create(**request)
            except Exception as exc:
                last_error = exc
                logger.error("OpenAI responses API error attempt=%s: %s", attempt + 1, exc)
                time.sleep(min(5, (attempt + 1) * 2))
        raise RuntimeError(f"OpenAI responses API failed too many times: {last_error}")

    def parse_response_output(self, response: Any) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        raw_output = get_field(response, "output", []) or []
        actions: list[dict[str, Any]] = []
        responses: list[str] = []
        unsupported_action = False
        infeasible_message = False

        for item in raw_output:
            item_type = get_field(item, "type")
            if item_type == "message":
                message_text = message_text_from_item(item)
                if message_text:
                    responses.append(message_text)
                    lower = message_text.lower()
                    if any(token in lower for token in ["infeasible", "unfeasible", "impossible", "cannot be done", "not feasible"]):
                        infeasible_message = True
            elif item_type == "reasoning":
                reasoning_text = reasoning_text_from_item(item)
                if reasoning_text:
                    responses.append(reasoning_text)
            elif item_type == "computer_call":
                raw_actions = get_field(item, "actions")
                if raw_actions is None:
                    single_action = get_field(item, "action")
                    raw_actions = [single_action] if single_action is not None else []
                call_id = get_field(item, "call_id", "")
                pending_checks = model_dump(get_field(item, "pending_safety_checks", []))
                raw_actions = list(raw_actions)
                batch_size = len(raw_actions)
                for index, raw_action in enumerate(raw_actions):
                    action_info = action_to_dict(raw_action)
                    pyautogui_code = convert_action_to_pyautogui(action_info["type"], action_info["args"])
                    if not pyautogui_code:
                        unsupported_action = True
                        responses.append(f"Unsupported computer action from model: {action_info['type']}")
                        continue
                    actions.append(
                        {
                            "action_space": "pyautogui",
                            "action": pyautogui_code,
                            "pending_checks": pending_checks,
                            "call_id": call_id,
                            "batch_index": index,
                            "batch_size": batch_size,
                            "batch_last": index == batch_size - 1,
                            "raw_action": action_info,
                        }
                    )
        state_correct = bool(actions) and not unsupported_action and not infeasible_message
        if unsupported_action:
            actions = []
        usage = get_field(response, "usage", {}) or {}
        return {
            "model_usage": {
                "prompt_tokens": get_field(usage, "input_tokens", 0),
                "completion_tokens": get_field(usage, "output_tokens", 0),
            },
            "messages": model_dump(raw_output),
            "response": "\n".join(item for item in responses if item),
            "state_correct": state_correct,
        }, actions

    def parse_response(self, response: str, context: SampleContext) -> dict[str, Any]:
        return {
            "response": response,
            "function_call": list(self._last_actions),
            "thought": "",
        }

    def transform_function_call(self, call: Any, context: SampleContext) -> Any:
        return call

    def transform_coordinates(self, call: Any, context: SampleContext) -> Any:
        return call

    def to_pyautogui(self, call: Any, context: SampleContext) -> list[str]:
        if not isinstance(call, list):
            return []
        return [item.get("action", "") for item in call if item.get("action")]

    def should_stop_after_step(self, context: SampleContext, step_result: Any) -> bool:
        return self._should_stop_after_step

    def needs_post_action_screenshot(self, context: SampleContext, step_result, action_index: int) -> bool:
        actions = step_result.transformed_function_call or []
        if not isinstance(actions, list) or action_index >= len(actions):
            return False
        return bool(actions[action_index].get("batch_last", True))

    def after_action(self, context: SampleContext, step_result, action_index: int, screenshot_path: str) -> None:
        actions = step_result.transformed_function_call or []
        if not isinstance(actions, list) or action_index >= len(actions):
            return
        action = actions[action_index]
        if not action.get("batch_last", True):
            return
        output_item = {
            "type": "computer_call_output",
            "call_id": action.get("call_id", ""),
            "output": {
                "type": "computer_screenshot",
                "image_url": f"data:image/png;base64,{encode_image_path(screenshot_path)}",
                "detail": "original",
            },
        }
        pending_checks = action.get("pending_checks") or []
        if pending_checks:
            output_item["acknowledged_safety_checks"] = pending_checks
        self.pending_input_items.append(output_item)

    def after_sample(self, context: SampleContext, result: Any) -> None:
        self.previous_response_id = None
        self.pending_input_items = []
        self._last_actions = []
        self._should_stop_after_step = False


class Gpt54MiniNativeAgentAdapter(GptNativeAgentAdapter):
    name = "gpt54-mini-native"
    model = "gpt-5.4-mini"
    request_kwargs = {"reasoning_effort": "high", "max_output_tokens": 1500}


def gpt_api_key() -> str:
    return (
        os.getenv("RUNNER_API_KEY")
        or os.getenv("OPENAI_API_KEY")
        or os.getenv("GPT_NATIVE_API_KEY")
        or ""
    ).strip()


def gpt_base_url(default: str) -> str:
    value = (
        os.getenv("RUNNER_BASE_URL")
        or os.getenv("OPENAI_BASE_URL")
        or os.getenv("GPT_NATIVE_BASE_URL")
        or default
    ).strip().rstrip("/")
    return value or default


def gpt_model(default: str) -> str:
    value = (
        os.getenv("RUNNER_MODEL")
        or os.getenv("OPENAI_MODEL")
        or os.getenv("GPT_NATIVE_MODEL")
        or default
    ).strip()
    return value or default


def build_httpx_client(httpx_module, proxy_url: str):
    if not proxy_url:
        return httpx_module.Client()
    try:
        return httpx_module.Client(proxy=proxy_url)
    except TypeError:
        return httpx_module.Client(proxies=proxy_url)


def encode_image_path(path: str) -> str:
    return base64.b64encode(open(path, "rb").read()).decode("utf-8")


def model_dump(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        return value.model_dump()
    if isinstance(value, list):
        return [model_dump(item) for item in value]
    if isinstance(value, dict):
        return {key: model_dump(item) for key, item in value.items()}
    return value


def get_field(value: Any, field: str, default: Any = None) -> Any:
    if isinstance(value, dict):
        return value.get(field, default)
    return getattr(value, field, default)


def action_to_dict(action: Any) -> dict[str, Any]:
    if isinstance(action, dict):
        action_type = action.get("type")
        action_args = {key: model_dump(value) for key, value in action.items() if key != "type"}
        return {"type": action_type, "args": action_args}
    raw = model_dump(action)
    if isinstance(raw, dict):
        action_type = raw.get("type")
        action_args = {key: value for key, value in raw.items() if key != "type"}
        return {"type": action_type, "args": action_args}
    action_type = getattr(action, "type", None)
    action_args = {}
    for attr in dir(action):
        if attr.startswith("_") or attr == "type":
            continue
        try:
            action_args[attr] = model_dump(getattr(action, attr))
        except Exception:
            continue
    return {"type": action_type, "args": action_args}


def convert_action_to_pyautogui(action_type: str, args: dict[str, Any]) -> str | None:
    if not action_type:
        return None
    key_mapping = {
        "alt": "alt",
        "arrowdown": "down",
        "arrowleft": "left",
        "arrowright": "right",
        "arrowup": "up",
        "backspace": "backspace",
        "capslock": "capslock",
        "cmd": "command",
        "command": "command",
        "ctrl": "ctrl",
        "delete": "delete",
        "end": "end",
        "enter": "enter",
        "esc": "esc",
        "home": "home",
        "insert": "insert",
        "option": "option",
        "pagedown": "pagedown",
        "pageup": "pageup",
        "shift": "shift",
        "space": "space",
        "super": "super",
        "tab": "tab",
        "win": "win",
    }

    try:
        if action_type == "click":
            x = args.get("x")
            y = args.get("y")
            button = args.get("button", "left")
            if x is None or y is None:
                return None
            if button not in ["left", "middle", "right"]:
                button = "left"
            return (
                f"import pyautogui\n"
                f"pyautogui.moveTo({x}, {y})\n"
                f"pyautogui.click(button='{button}')"
            )

        if action_type == "double_click":
            x = args.get("x")
            y = args.get("y")
            if x is None or y is None:
                return None
            return (
                f"import pyautogui\n"
                f"pyautogui.moveTo({x}, {y})\n"
                f"pyautogui.doubleClick()"
            )

        if action_type == "move":
            x = args.get("x")
            y = args.get("y")
            if x is None or y is None:
                return None
            return f"import pyautogui\npyautogui.moveTo({x}, {y})"

        if action_type == "drag":
            return convert_drag_path(args)

        if action_type == "type":
            text = args.get("text", "")
            summary = summarize_type_payload(text)
            logger.info("Type action payload: %s", summary)
            if text == "":
                return "import time\ntime.sleep(0.1)"
            strategy = summary["strategy"]
            if strategy == "multiline_ascii":
                return build_multiline_ascii_type_command(text)
            if strategy == "clipboard":
                return build_clipboard_paste_command(text)
            return f"import pyautogui\npyautogui.typewrite({repr(text)}, interval=0.03)"

        if action_type == "keypress":
            keys = args.get("keys", [])
            if not keys:
                return None
            mapped_keys = []
            for key in keys:
                normalized = key_mapping.get(str(key).lower(), str(key).lower())
                mapped_keys.append(normalized)
            keys_str = ", ".join([repr(key) for key in mapped_keys])
            return f"import pyautogui\npyautogui.hotkey({keys_str})"

        if action_type == "scroll":
            x = args.get("x")
            y = args.get("y")
            scroll_x = int(args.get("scroll_x", 0) or 0)
            scroll_y = int(args.get("scroll_y", 0) or 0)
            position = f", x={x}, y={y}" if x is not None and y is not None else ""
            if scroll_y:
                return f"import pyautogui\npyautogui.scroll({scroll_y * -1}{position})"
            if scroll_x:
                return f"import pyautogui\npyautogui.hscroll({scroll_x * -1}{position})"
            return None

        if action_type == "wait":
            secs = max(0.1, float(args.get("ms", 1000)) / 1000.0)
            return f"import time\ntime.sleep({secs})"

        if action_type == "screenshot":
            return "import time\ntime.sleep(0.1)"
    except Exception:
        logger.exception("Failed to convert GPT-5.4 computer action: %s", action_type)
        return None

    logger.warning("Unsupported GPT-5.4 computer action: %s", action_type)
    return None


def convert_drag_path(args: dict[str, Any]) -> str | None:
    path = args.get("path")
    if not path and args.get("from") and args.get("to"):
        path = [args["from"], args["to"]]
    if not path or len(path) < 2:
        return None

    def point_xy(point: Any):
        if isinstance(point, (list, tuple)) and len(point) == 2:
            return point[0], point[1]
        if isinstance(point, dict):
            return point.get("x"), point.get("y")
        return getattr(point, "x", None), getattr(point, "y", None)

    first_x, first_y = point_xy(path[0])
    if first_x is None or first_y is None:
        return None
    commands = [f"import pyautogui\npyautogui.moveTo({first_x}, {first_y})"]
    for point in path[1:]:
        x, y = point_xy(point)
        if x is None or y is None:
            return None
        commands.append(f"pyautogui.dragTo({x}, {y}, duration=0.2, button='left')")
    return "\n".join(commands)


def typing_strategy(text: str) -> str:
    if text == "":
        return "empty"
    if not text.isascii():
        return "clipboard"
    if "\n" in text:
        return "multiline_ascii"
    if text.isascii():
        return "single_line_ascii"
    return "clipboard"


def preview_text(text: str, limit: int = 120) -> str:
    sanitized = text.replace("\n", "\\n")
    if len(sanitized) <= limit:
        return sanitized
    return sanitized[:limit] + "..."


def summarize_type_payload(text: str) -> dict[str, Any]:
    return {
        "strategy": typing_strategy(text),
        "chars": len(text),
        "lines": len(text.split("\n")) if text else 0,
        "ascii": text.isascii(),
        "trailing_newline": text.endswith("\n"),
        "preview": preview_text(text),
    }


def build_multiline_ascii_type_command(text: str) -> str:
    commands = ["import pyautogui"]
    lines = text.split("\n")
    for index, line in enumerate(lines):
        if line:
            commands.append(f"pyautogui.typewrite({repr(line)}, interval=0.03)")
        if index < len(lines) - 1:
            commands.append("pyautogui.press('enter')")
    return "\n".join(commands)


def build_clipboard_paste_command(text: str, paste_keys: tuple[str, ...] = ("ctrl", "v")) -> str:
    encoded = base64.b64encode(text.encode("utf-8")).decode("ascii")
    keys = ", ".join(repr(key) for key in paste_keys)
    return (
        "import base64, time, pyautogui, pyperclip\n"
        f"_text = base64.b64decode('{encoded}').decode('utf-8')\n"
        "pyperclip.copy(_text)\n"
        "time.sleep(0.1)\n"
        f"pyautogui.hotkey({keys})\n"
        "time.sleep(0.1)"
    )


def message_text_from_item(item: Any) -> str:
    content = get_field(item, "content", [])
    if not content:
        return ""
    if isinstance(content, list):
        parts = []
        for part in content:
            if get_field(part, "type") == "output_text":
                parts.append(get_field(part, "text", ""))
        return "\n".join(part for part in parts if part)
    return str(content)


def reasoning_text_from_item(item: Any) -> str:
    summary = get_field(item, "summary", [])
    if not summary:
        return ""
    if isinstance(summary, list):
        parts = []
        for part in summary:
            text = get_field(part, "text", "")
            if text:
                parts.append(text)
        return "\n".join(parts)
    return str(summary)
