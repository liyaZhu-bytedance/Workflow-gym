from __future__ import annotations

from contextlib import contextmanager
import base64
import io
import json
import logging
import os
import re
import time
from types import SimpleNamespace
from typing import Any

from PIL import Image

from ..records import PromptBundle
from .base import BaseAgentAdapter, SampleContext
from .pyautogui_actions import image_size, platform_from_context, wrap_pyautogui_python


logger = logging.getLogger(__name__)

OPENROUTER_PROXY_URL = ""
OPENROUTER_PROXY_ENV_KEYS = ("HTTP_PROXY", "http_proxy", "HTTPS_PROXY", "https_proxy")

COMPUTER_TOOL_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "computer",
        "description": (
            "Operate the virtual machine GUI. Use exactly one action per response. "
            "Coordinates are based on the screenshot resolution 1280x720."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": [
                        "key",
                        "type",
                        "mouse_move",
                        "left_click",
                        "left_click_drag",
                        "right_click",
                        "middle_click",
                        "double_click",
                        "triple_click",
                        "left_mouse_down",
                        "left_mouse_up",
                        "scroll",
                        "wait",
                        "screenshot",
                        "done",
                        "fail",
                        "call_user",
                    ],
                    "description": "The GUI action to perform.",
                },
                "coordinate": {
                    "type": "array",
                    "items": {"type": "integer"},
                    "minItems": 2,
                    "maxItems": 2,
                    "description": "Target [x, y] in the 1280x720 screenshot coordinate space.",
                },
                "start_coordinate": {
                    "type": "array",
                    "items": {"type": "integer"},
                    "minItems": 2,
                    "maxItems": 2,
                    "description": "Optional drag start [x, y] in the 1280x720 screenshot coordinate space.",
                },
                "text": {
                    "type": "string",
                    "description": "Text to type, key combination like 'ctrl+v', or modifier keys for clicks.",
                },
                "scroll_direction": {
                    "type": "string",
                    "enum": ["up", "down", "left", "right"],
                },
                "scroll_amount": {
                    "type": "integer",
                    "description": "Scroll amount; use 5 if uncertain.",
                },
                "duration": {
                    "type": "number",
                    "description": "Optional mouse movement or drag duration in seconds.",
                },
            },
            "required": ["action"],
        },
    },
}

SYSTEM_PROMPT = """You are a GUI agent operating a virtual machine desktop.

You will receive screenshots resized to 1280x720. Use the `computer` tool to complete
the user's task. Coordinates in tool calls must be integer pixel positions in this
1280x720 screenshot coordinate space.

Output contract:
- Every turn must include both:
  1. A concise reasoning/thought process in message content: what you see, what state the
     task is in, and why the next action is appropriate.
  2. A normal OpenAI tool call to the `computer` function with JSON arguments such as
     {"action": "left_click", "coordinate": [640, 360]}.
- Do not put the action JSON only in text when a tool call is available.
- Fallback only if the tool call channel is unavailable: write exactly one line starting
  with `Action: ` followed by the same JSON arguments.

Rules:
- Use exactly one `computer` tool call per turn until the task is complete.
- Do not output a blank response. If the task is not complete, choose one meaningful action.
- Do not ask for confirmation. Act based on the screenshot.
- Use action `done` only when the task is complete. Use action `fail` only when the task is
  genuinely infeasible in the current VM.
- You do not need to request screenshots; a fresh screenshot will be provided after each action.
"""


class ClaudeAgentAdapter(BaseAgentAdapter):
    name = "claude"
    dynamic_prompts = False
    model = "anthropic/claude-sonnet-4.6"
    base_url = "https://openrouter.ai/api/v1"
    api_version = "chat_completions"
    request_kwargs = {
        "max_tokens": 2048,
        "api_screen_width": 1280,
        "api_screen_height": 720,
        "max_history_messages": 12,
    }
    default_headers: dict[str, str] = {}

    def __init__(self):
        self.messages: list[dict[str, Any]] = []
        self.last_action_summary = ""
        self._last_actions: list[dict[str, Any]] = []
        self._should_stop_after_step = False
        self.screen_size = (
            int(os.getenv("CLAUDE_SCREEN_WIDTH", "1920")),
            int(os.getenv("CLAUDE_SCREEN_HEIGHT", "1080")),
        )
        self.api_screen_size = (
            int(os.getenv("CLAUDE_API_SCREEN_WIDTH", str(self.request_kwargs["api_screen_width"]))),
            int(os.getenv("CLAUDE_API_SCREEN_HEIGHT", str(self.request_kwargs["api_screen_height"]))),
        )
        self.resize_factor = (
            self.screen_size[0] / self.api_screen_size[0],
            self.screen_size[1] / self.api_screen_size[1],
        )
        self.max_tokens = int(os.getenv("CLAUDE_MAX_TOKENS", str(self.request_kwargs["max_tokens"])))
        self.max_history_messages = int(os.getenv("CLAUDE_MAX_HISTORY_MESSAGES", str(self.request_kwargs["max_history_messages"])))

    def build_prompts(self, context: SampleContext) -> PromptBundle:
        return PromptBundle(sp="", up=self.task_instruction(context))

    def before_sample(self, context: SampleContext) -> None:
        self.messages = []
        self.last_action_summary = ""
        self._last_actions = []
        self._should_stop_after_step = False

    def predict(self, context: SampleContext) -> str:
        if context.metadata.get("dry_run"):
            self._last_actions = []
            self._should_stop_after_step = True
            return json.dumps({"content": "No-op claude dry-run response."}, ensure_ascii=False)
        self.update_screen_size(context)
        screenshot = read_binary(context.current_screenshot)
        predict_info, actions = self.predict_step(self.task_instruction(context), {"screenshot": screenshot})
        prediction = predict_info.get("response", "")
        self._last_actions = list(actions or [])[:1]
        if not self._last_actions:
            self._should_stop_after_step = True
        return json.dumps(prediction, ensure_ascii=False) if not isinstance(prediction, str) else prediction

    def predict_step(self, instruction: str, obs: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        screenshot = obs["screenshot"]
        self.messages.append(self.build_user_message(instruction, screenshot))
        if len(self.messages) > self.max_history_messages:
            self.messages = self.messages[-self.max_history_messages:]

        request: dict[str, Any] = {
            "model": self.model_name(),
            "messages": [{"role": "system", "content": SYSTEM_PROMPT}, *self.messages],
            "tools": [COMPUTER_TOOL_SCHEMA],
            "tool_choice": {"type": "function", "function": {"name": "computer"}},
            "max_tokens": self.max_tokens,
        }
        response = self.invoke_chat_completion(request)
        msg = response.choices[0].message
        raw_message = dump_openai_object(msg)
        content = msg.content or ""
        tool_calls = msg.tool_calls or []
        actions: list[dict[str, Any]] = []
        raw_action_summaries: list[str] = []

        for tool_call in tool_calls:
            func = tool_call.function
            if func.name != "computer":
                continue
            tool_input = parse_tool_arguments(func.arguments)
            try:
                command = self.action_to_pyautogui(tool_input)
                action_type = tool_input.get("action")
            except Exception as exc:
                logger.warning("Failed to convert Claude computer action %r: %s", tool_input, exc)
                command = "FAIL"
                action_type = "FAIL"
            raw_action_summaries.append(json.dumps(tool_input, ensure_ascii=False))
            actions.append(
                {
                    "name": "computer",
                    "input": tool_input,
                    "id": tool_call.id,
                    "action_type": action_type,
                    "command": command,
                    "raw_response": content,
                }
            )

        if not actions:
            fallback_input = extract_fallback_action(content)
            if fallback_input:
                try:
                    command = self.action_to_pyautogui(fallback_input)
                    action_type = fallback_input.get("action")
                except Exception as exc:
                    logger.warning("Failed to convert fallback Claude action %r: %s", fallback_input, exc)
                    command = "FAIL"
                    action_type = "FAIL"
                raw_action_summaries.append(json.dumps(fallback_input, ensure_ascii=False))
                actions.append(
                    {
                        "name": "computer",
                        "input": fallback_input,
                        "id": "fallback-text-action",
                        "action_type": action_type,
                        "command": command,
                        "raw_response": content,
                        "fallback": True,
                    }
                )

        if not actions:
            lowered = content.lower()
            if "[infeasible]" in lowered or "infeasible" in lowered or "not feasible" in lowered:
                actions.append({"action_type": "FAIL", "command": "FAIL", "raw_response": content})
            elif "[done]" in lowered or lowered.strip() == "done":
                actions.append({"action_type": "DONE", "command": "DONE", "raw_response": content})

        assistant_summary = content
        if raw_action_summaries:
            assistant_summary = "%s\nAction: %s" % (content, "; ".join(raw_action_summaries))
            assistant_summary = assistant_summary.strip()
        self.messages.append({"role": "assistant", "content": assistant_summary or "No textual response."})
        self.last_action_summary = (
            "Executed action(s): %s" % "; ".join(raw_action_summaries)
            if raw_action_summaries
            else "No tool action was returned."
        )
        return {
            "response": raw_message,
            "history_response": assistant_summary,
            "text_response": content,
            "state_correct": not any(action.get("action_type") == "FAIL" for action in actions),
            "raw_model": getattr(response, "model", self.model),
        }, actions

    def build_user_message(self, instruction: str, screenshot: bytes) -> dict[str, Any]:
        screenshot_api = resize_png(screenshot, self.api_screen_size)
        prompt = instruction
        if self.last_action_summary:
            prompt = (
                "Task instruction:\n%s\n\n"
                "Previous action result:\n%s\n\n"
                "Continue from the current screenshot and choose the next single action."
            ) % (instruction, self.last_action_summary)
        return {
            "role": "user",
            "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": "data:image/png;base64,%s" % encode_image(screenshot_api)}},
            ],
        }

    def invoke_chat_completion(self, request: dict[str, Any]) -> Any:
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise RuntimeError("Missing openai dependency for claude player") from exc
        with openrouter_proxy_env():
            client = OpenAI(api_key=claude_api_key(), base_url=self.base_url_value())
            return client.chat.completions.create(**request)

    def action_to_pyautogui(self, tool_input: dict[str, Any]) -> str:
        action = tool_input.get("action")
        text = tool_input.get("text")
        coordinate = self.scale_coordinate(tool_input.get("coordinate"))
        start_coordinate = self.scale_coordinate(tool_input.get("start_coordinate"))
        scroll_direction = tool_input.get("scroll_direction")
        scroll_amount = int(tool_input.get("scroll_amount") or 5)
        duration = float(tool_input.get("duration") or 0.5)

        code = "import pyautogui\nimport time\npyautogui.FAILSAFE = False\n"
        if action == "mouse_move":
            if coordinate is None:
                raise ValueError("coordinate is required for mouse_move")
            code += "pyautogui.moveTo(%s, %s, duration=%s)\n" % (coordinate[0], coordinate[1], duration)
        elif action == "left_click_drag":
            if coordinate is None:
                raise ValueError("coordinate is required for left_click_drag")
            if start_coordinate is not None:
                code += "pyautogui.moveTo(%s, %s, duration=%s)\n" % (start_coordinate[0], start_coordinate[1], duration)
            code += "pyautogui.dragTo(%s, %s, duration=%s)\n" % (coordinate[0], coordinate[1], duration)
        elif action == "left_click":
            code += "pyautogui.click()\n" if coordinate is None else "pyautogui.click(%s, %s)\n" % coordinate
        elif action == "right_click":
            code += "pyautogui.rightClick()\n" if coordinate is None else "pyautogui.rightClick(%s, %s)\n" % coordinate
        elif action == "double_click":
            code += "pyautogui.doubleClick()\n" if coordinate is None else "pyautogui.doubleClick(%s, %s)\n" % coordinate
        elif action == "middle_click":
            code += "pyautogui.middleClick()\n" if coordinate is None else "pyautogui.middleClick(%s, %s)\n" % coordinate
        elif action == "triple_click":
            code += "pyautogui.tripleClick()\n" if coordinate is None else "pyautogui.tripleClick(%s, %s)\n" % coordinate
        elif action == "left_mouse_down":
            code += "pyautogui.mouseDown()\n" if coordinate is None else "pyautogui.mouseDown(%s, %s)\n" % coordinate
        elif action == "left_mouse_up":
            code += "pyautogui.mouseUp()\n" if coordinate is None else "pyautogui.mouseUp(%s, %s)\n" % coordinate
        elif action == "key":
            if not isinstance(text, str) or not text:
                raise ValueError("text is required for key")
            keys = [key.strip().lower() for key in text.replace(" ", "+").split("+") if key.strip()]
            code += "pyautogui.hotkey(%s)\n" % ", ".join(repr(key) for key in keys)
        elif action == "type":
            if not isinstance(text, str):
                raise ValueError("text is required for type")
            code += "import pyperclip\n"
            code += "pyperclip.copy(%r)\n" % text
            code += "pyautogui.hotkey('ctrl', 'v')\n"
        elif action == "scroll":
            amount = scroll_amount if scroll_direction == "up" else -scroll_amount
            if scroll_direction in ("left", "right"):
                amount = scroll_amount if scroll_direction == "right" else -scroll_amount
                code += "pyautogui.hscroll(%s)\n" % amount if coordinate is None else "pyautogui.hscroll(%s, x=%s, y=%s)\n" % (amount, coordinate[0], coordinate[1])
            else:
                code += "pyautogui.scroll(%s)\n" % amount if coordinate is None else "pyautogui.scroll(%s, x=%s, y=%s)\n" % (amount, coordinate[0], coordinate[1])
        elif action in ("wait", "screenshot"):
            code += "time.sleep(0.5)\n"
        elif action == "done":
            return "DONE"
        elif action == "fail":
            return "FAIL"
        elif action == "call_user":
            return "CALL_USER"
        else:
            raise ValueError("Invalid action: %s" % action)
        return code

    def parse_response(self, response: str, context: SampleContext) -> dict[str, Any]:
        terminal = next((action for action in self._last_actions if action.get("command") in ("DONE", "FAIL", "CALL_USER")), None)
        if terminal:
            self._should_stop_after_step = True
        return {"response": response, "function_call": list(self._last_actions), "thought": ""}

    def transform_function_call(self, call: Any, context: SampleContext) -> Any:
        return call

    def transform_coordinates(self, call: Any, context: SampleContext) -> Any:
        return call

    def to_pyautogui(self, call: Any, context: SampleContext) -> list[str]:
        if not isinstance(call, list):
            return []
        codes: list[str] = []
        for action in call[:1]:
            command = action.get("command", "")
            if command in ("DONE", "FAIL", "CALL_USER"):
                self._should_stop_after_step = True
                break
            if command:
                codes.append(wrap_pyautogui_python(command, platform=platform_from_context(context), context=context))
        return codes

    def should_stop_after_step(self, context: SampleContext, step_result: Any) -> bool:
        return self._should_stop_after_step

    def after_sample(self, context: SampleContext, result: Any) -> None:
        self.messages = []
        self.last_action_summary = ""
        self._last_actions = []
        self._should_stop_after_step = False

    def update_screen_size(self, context: SampleContext) -> None:
        if not context.current_screenshot:
            return
        try:
            size = image_size_path(context.current_screenshot)
        except Exception:
            return
        if not size:
            return
        self.screen_size = size
        self.resize_factor = (
            self.screen_size[0] / self.api_screen_size[0],
            self.screen_size[1] / self.api_screen_size[1],
        )

    def scale_coordinate(self, coordinate: Any) -> tuple[int, int] | None:
        if not isinstance(coordinate, (list, tuple)) or len(coordinate) != 2:
            return None
        x = int(float(coordinate[0]) * self.resize_factor[0])
        y = int(float(coordinate[1]) * self.resize_factor[1])
        return x, y

    def model_name(self) -> str:
        return (os.getenv("CLAUDE_MODEL") or self.model).strip() or self.model

    def base_url_value(self) -> str:
        return (os.getenv("CLAUDE_BASE_URL") or os.getenv("OPENROUTER_BASE_URL") or self.base_url).strip() or self.base_url


def parse_tool_arguments(arguments: Any) -> dict[str, Any]:
    if isinstance(arguments, dict):
        return arguments
    if isinstance(arguments, str) and arguments.strip():
        try:
            parsed = json.loads(arguments)
            return parsed if isinstance(parsed, dict) else {}
        except json.JSONDecodeError:
            logger.warning("Failed to parse OpenRouter computer arguments: %r", arguments)
    return {}


def dump_openai_object(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        try:
            return value.model_dump(mode="json", exclude_none=True)
        except TypeError:
            return value.model_dump(exclude_none=True)
    if hasattr(value, "dict"):
        return value.dict(exclude_none=True)
    if isinstance(value, SimpleNamespace):
        return {key: dump_openai_object(item) for key, item in vars(value).items()}
    if isinstance(value, dict):
        return {key: dump_openai_object(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [dump_openai_object(item) for item in value]
    return value


def extract_fallback_action(content: str) -> dict[str, Any]:
    if not isinstance(content, str) or not content.strip():
        return {}
    decoder = json.JSONDecoder()
    search_offsets: list[int] = []
    marker_idx = content.lower().rfind("action:")
    if marker_idx >= 0:
        brace_idx = content.find("{", marker_idx)
        if brace_idx >= 0:
            search_offsets.append(brace_idx)
    search_offsets.extend(index for index, char in enumerate(content) if char == "{")
    seen = set()
    for index in search_offsets:
        if index in seen:
            continue
        seen.add(index)
        try:
            parsed, _ = decoder.raw_decode(content[index:])
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, dict) and isinstance(parsed.get("action"), str):
            return parsed
    return {}


@contextmanager
def openrouter_proxy_env(proxy_url: str = OPENROUTER_PROXY_URL):
    configured_proxy = (os.getenv("CLAUDE_OPENROUTER_PROXY") or os.getenv("OPENROUTER_PROXY") or proxy_url).strip()
    previous = {key: os.environ.get(key) for key in OPENROUTER_PROXY_ENV_KEYS}
    if configured_proxy:
        for key in OPENROUTER_PROXY_ENV_KEYS:
            os.environ[key] = configured_proxy
    try:
        yield
    finally:
        for key, old_value in previous.items():
            if old_value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = old_value


def claude_api_key() -> str:
    key = (os.getenv("CLAUDE_API_KEY") or os.getenv("OPENROUTER_API_KEY") or "").strip()
    if not key:
        raise RuntimeError("Set CLAUDE_API_KEY or OPENROUTER_API_KEY")
    return key


def resize_png(image_content: bytes, size: tuple[int, int]) -> bytes:
    image = Image.open(io.BytesIO(image_content)).convert("RGB")
    resized = image.resize(size, Image.Resampling.LANCZOS)
    output = io.BytesIO()
    resized.save(output, format="PNG")
    return output.getvalue()


def encode_image(image_content: bytes) -> str:
    return base64.b64encode(image_content).decode("utf-8")


def read_binary(path: str) -> bytes:
    with open(path, "rb") as file_obj:
        return file_obj.read()


def image_size_path(path: str) -> tuple[int, int] | None:
    from pathlib import Path

    return image_size(Path(path))
