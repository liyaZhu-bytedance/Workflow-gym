from __future__ import annotations

import ast
import base64
import json
import os
import re
import shlex
import struct
from pathlib import Path
from typing import Any


_DISALLOWED_PYAUTOGUI_ACTION_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("cat heredoc", re.compile(r"\bcat\b[^\n]*<<", re.IGNORECASE)),
    ("heredoc marker", re.compile(r"<<\s*['\"]?EOF\b", re.IGNORECASE)),
    ("standalone eof marker", re.compile(r"^\s*EOF\s*$", re.MULTILINE)),
    ("python /tmp runner", re.compile(r"\bpython3?\s+/tmp/", re.IGNORECASE)),
    ("bash shebang", re.compile(r"^\s*#!/bin/bash", re.MULTILINE | re.IGNORECASE)),
    ("shell cat redirect", re.compile(r"\bcat\s+>\s+", re.IGNORECASE)),
)

_RUN_COMMAND_FAILURE_MARKERS = (
    "runcommand 执行失败",
    "taskexecutionfailed",
)

_PYTHON_SCRIPT_EXECUTION_ERROR_MARKERS = (
    "syntaxerror",
    "indentationerror",
    "taberror",
    "invalid syntax",
    "unexpected indent",
    "unterminated string literal",
)


def action_to_pyautogui_command(call: Any, context: Any = None) -> list[str]:
    if not call or not isinstance(call, dict):
        return []
    name = call.get("name")
    parameters = call.get("parameters") or {}
    if name in ("finished", "call_user"):
        return []
    platform = platform_from_context(context)
    display_size = display_resolution_from_context(context) if is_linux_platform(platform) else None
    screenshot_size = screenshot_size_from_context(context)
    code = pyautogui_code_for_action(
        str(name),
        parameters,
        display_size=display_size,
        screenshot_size=screenshot_size,
    )
    if not code:
        return []
    return [
        wrap_pyautogui_python(
            code,
            screenshot_size,
            platform=platform,
            context=context,
            display_size=display_size,
        )
    ]


def pyautogui_code_for_action(
    name: str,
    parameters: dict[str, Any],
    display_size: tuple[int, int] | None = None,
    screenshot_size: tuple[int, int] | None = None,
) -> str:
    if name == "click":
        return click_code(required_parameter(name, parameters, "point"), "click", display_size=display_size, screenshot_size=screenshot_size)
    if name == "left_double":
        return click_code(required_parameter(name, parameters, "point"), "doubleClick", display_size=display_size, screenshot_size=screenshot_size)
    if name == "right_single":
        return click_code(
            required_parameter(name, parameters, "point"),
            "click",
            button="right",
            display_size=display_size,
            screenshot_size=screenshot_size,
        )
    if name == "move_to":
        return click_code(required_parameter(name, parameters, "point"), "moveTo", display_size=display_size, screenshot_size=screenshot_size)
    if name == "drag":
        start_point = required_parameter(name, parameters, "start_point")
        end_point = required_parameter(name, parameters, "end_point")
        if display_size:
            sx, sy = scale_normalized_point(start_point, display_size)
            ex, ey = scale_normalized_point(end_point, display_size)
            return "\n".join(
                [
                    action_coord_log_code(start_point, display_size, (sx, sy), screenshot_size),
                    action_coord_log_code(end_point, display_size, (ex, ey), screenshot_size),
                    "pyautogui.moveTo(%s, %s)" % (sx, sy),
                    "pyautogui.dragTo(%s, %s, duration=0.5, button='left')" % (ex, ey),
                ]
            )
        return (
            "sx, sy = scale_point(%s)\n"
            "ex, ey = scale_point(%s)\n"
            "pyautogui.moveTo(sx, sy)\n"
            "pyautogui.dragTo(ex, ey, duration=0.5, button='left')"
        ) % (
            json.dumps(start_point),
            json.dumps(end_point),
        )
    if name == "mouse_down":
        return mouse_button_code("mouseDown", parameters, display_size=display_size, screenshot_size=screenshot_size)
    if name == "mouse_up":
        return mouse_button_code("mouseUp", parameters, display_size=display_size, screenshot_size=screenshot_size)
    if name == "scroll":
        direction = str(required_parameter(name, parameters, "direction"))
        amount = -5 if direction == "down" else 5
        if direction in ("left", "right"):
            amount = -5 if direction == "right" else 5
            return "pyautogui.hscroll(%s)" % amount
        return "pyautogui.scroll(%s)" % amount
    if name == "type":
        return type_text_code(str(required_parameter(name, parameters, "content")))
    if name == "hotkey":
        keys = [normalize_key_name(key) for key in str(required_parameter(name, parameters, "key")).split() if key]
        return "pyautogui.hotkey(*%s)" % json.dumps(keys)
    if name == "press":
        return "pyautogui.press(%s)" % json.dumps(normalize_key_name(str(required_parameter(name, parameters, "key"))))
    if name == "release":
        return "pyautogui.keyUp(%s)" % json.dumps(normalize_key_name(str(required_parameter(name, parameters, "key"))))
    if name == "wait":
        wait_seconds = int(parameters.get("time") or 1)
        return "time.sleep(%s)" % max(0, wait_seconds)
    if name == "open_computer":
        return "pyautogui.hotkey('win', 'e')"
    return ""


def mouse_button_code(
    method: str,
    parameters: dict[str, Any],
    display_size: tuple[int, int] | None = None,
    screenshot_size: tuple[int, int] | None = None,
) -> str:
    point = parameters.get("point")
    button = str(parameters.get("button") or "left")
    if point:
        if display_size:
            x, y = scale_normalized_point(point, display_size)
            return "\n".join(
                [
                    action_coord_log_code(point, display_size, (x, y), screenshot_size),
                    "pyautogui.%s(x=%s, y=%s, button=%s)" % (method, x, y, json.dumps(button)),
                ]
            )
        return (
            "x, y = scale_point(%s)\n"
            "pyautogui.%s(x=x, y=y, button=%s)"
        ) % (json.dumps(point), method, json.dumps(button))
    return "pyautogui.%s(button=%s)" % (method, json.dumps(button))


def click_code(
    point: Any,
    method: str,
    button: str = "left",
    display_size: tuple[int, int] | None = None,
    screenshot_size: tuple[int, int] | None = None,
) -> str:
    if display_size:
        x, y = scale_normalized_point(point, display_size)
        action = "pyautogui.%s(%s, %s" % (method, x, y)
        if method == "click" and button != "left":
            action += ", button=%s" % json.dumps(button)
        action += ")"
        return "\n".join([action_coord_log_code(point, display_size, (x, y), screenshot_size), action])
    if method == "click" and button != "left":
        return "x, y = scale_point(%s)\npyautogui.click(x, y, button=%s)" % (json.dumps(point), json.dumps(button))
    return "x, y = scale_point(%s)\npyautogui.%s(x, y)" % (json.dumps(point), method)


def parse_normalized_point(point_value: Any) -> tuple[int, int]:
    match = re.search(r"<point>\s*(\d+)\s+(\d+)\s*</point>", str(point_value))
    if not match:
        raise ValueError("invalid point: %s" % point_value)
    x_1000 = max(0, min(1000, int(match.group(1))))
    y_1000 = max(0, min(1000, int(match.group(2))))
    return x_1000, y_1000


def scale_normalized_point(point_value: Any, display_size: tuple[int, int]) -> tuple[int, int]:
    x_1000, y_1000 = parse_normalized_point(point_value)
    display_width, display_height = display_size
    return int(display_width * x_1000 / 1000), int(display_height * y_1000 / 1000)


def action_coord_log_code(
    point_value: Any,
    display_size: tuple[int, int],
    actual_point: tuple[int, int],
    screenshot_size: tuple[int, int] | None = None,
) -> str:
    x_1000, y_1000 = parse_normalized_point(point_value)
    display_width, display_height = display_size
    actual_x, actual_y = actual_point
    screenshot_width, screenshot_height = screenshot_size or (0, 0)
    payload = {
        "source_coordinate_space": "1000x1000",
        "normalized_point": [x_1000, y_1000],
        "screen_size": [display_width, display_height],
        "display_size": [display_width, display_height],
        "pyautogui_size": [display_width, display_height],
        "resolution_source": "validated_startup",
        "screenshot_size": [screenshot_width, screenshot_height] if screenshot_width and screenshot_height else None,
        "coordinate_size": [screenshot_width or display_width, screenshot_height or display_height],
        "actual_point": [actual_x, actual_y],
    }
    return 'print("WORKFLOWGYM_ACTION_COORD " + json.dumps(%s, ensure_ascii=False), flush=True)' % json.dumps(payload, ensure_ascii=False)


def display_resolution_from_context(context: Any = None) -> tuple[int, int] | None:
    metadata = getattr(context, "metadata", {}) if context is not None else {}
    if not isinstance(metadata, dict):
        metadata = {}
    env_metadata = metadata.get("env_metadata")
    if not isinstance(env_metadata, dict):
        env_metadata = metadata
    width = env_metadata.get("display_width")
    height = env_metadata.get("display_height")
    if width and height:
        return int(width), int(height)
    configured_width = int(os.getenv("DESKTOP_RESOLUTION_WIDTH", "1920"))
    configured_height = int(os.getenv("DESKTOP_RESOLUTION_HEIGHT", "1080"))
    if configured_width > 0 and configured_height > 0:
        return configured_width, configured_height
    return None


def build_inline_clipboard_paste_code(text: str) -> str:
    """Paste non-ASCII via clipboard without blocking the flask /action worker.

    Prefer xsel then xclip (Popen). Avoid bare ``pyperclip.copy()``: on Linux it often
    blocks until the clipboard is consumed and can hang until Gateway 504, after
    which sampler retries and double-pastes (e.g. 李明李明).

    Prints ``WORKFLOWGYM_CLIPBOARD_SET method=...`` so logs show primary vs fallback.

    Restrict methods for A/B tests via client env ``WORKFLOWGYM_CLIPBOARD_METHODS``
    (comma list: ``xsel``, ``xclip``, ``pyperclip``; default all three, xsel first).
    """
    text_literal = json.dumps(text, ensure_ascii=False)
    allowed = [
        part.strip().lower()
        for part in str(os.getenv("WORKFLOWGYM_CLIPBOARD_METHODS", "xsel,xclip,pyperclip") or "").split(",")
        if part.strip()
    ]
    if not allowed:
        allowed = ["xsel", "xclip", "pyperclip"]
    allowed_literal = json.dumps(allowed, ensure_ascii=False)
    return """# clipboard paste
_paste_text = __PASTE_TEXT__
_clipboard_methods = __CLIPBOARD_METHODS__
def _workflowgym_set_clipboard(text):
    print("WORKFLOWGYM_CLIPBOARD_TRY methods=%s chars=%s" % (",".join(_clipboard_methods), len(text)), flush=True)
    for _name, _cmd in (
        ("xsel", ["xsel", "--clipboard", "--input"]),
        ("xclip", ["xclip", "-selection", "clipboard", "-loops", "1"]),
    ):
        if _name not in _clipboard_methods:
            continue
        try:
            _proc = subprocess.Popen(
                _cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                text=True,
                start_new_session=True,
            )
            assert _proc.stdin is not None
            _proc.stdin.write(text)
            _proc.stdin.close()
            time.sleep(0.15)
            # xclip -loops 1 must stay alive as CLIPBOARD owner.
            if _name == "xclip":
                if _proc.poll() is None:
                    print("WORKFLOWGYM_CLIPBOARD_SET method=xclip chars=%s" % len(text), flush=True)
                    return True
                print("WORKFLOWGYM_CLIPBOARD_FALLBACK method=xclip exited=%s" % _proc.poll(), flush=True)
                continue
            if _proc.poll() in (None, 0):
                print("WORKFLOWGYM_CLIPBOARD_SET method=%s chars=%s" % (_name, len(text)), flush=True)
                return True
            print("WORKFLOWGYM_CLIPBOARD_FALLBACK method=%s exited=%s" % (_name, _proc.poll()), flush=True)
        except FileNotFoundError:
            print("WORKFLOWGYM_CLIPBOARD_FALLBACK missing=%s" % _name, flush=True)
            continue
        except Exception as _exc:
            print("WORKFLOWGYM_CLIPBOARD_FALLBACK method=%s error=%r" % (_name, _exc), flush=True)
            continue
    if "pyperclip" in _clipboard_methods:
        try:
            import threading
            import pyperclip
            _box = {"ok": False, "error": None}
            def _copy():
                try:
                    pyperclip.copy(text)
                    _box["ok"] = True
                except Exception as _exc:
                    _box["error"] = _exc
            _thread = threading.Thread(target=_copy, daemon=True)
            _thread.start()
            _thread.join(2.0)
            if _box["ok"] and not _thread.is_alive():
                print("WORKFLOWGYM_CLIPBOARD_SET method=pyperclip chars=%s" % len(text), flush=True)
                return True
            if _thread.is_alive():
                print("WORKFLOWGYM_CLIPBOARD_FALLBACK method=pyperclip timeout=2.0", flush=True)
            elif _box["error"] is not None:
                print("WORKFLOWGYM_CLIPBOARD_FALLBACK method=pyperclip error=%r" % _box["error"], flush=True)
        except Exception as _exc:
            print("WORKFLOWGYM_CLIPBOARD_FALLBACK method=pyperclip error=%r" % _exc, flush=True)
    else:
        print("WORKFLOWGYM_CLIPBOARD_FALLBACK method=pyperclip skipped", flush=True)
    print("WORKFLOWGYM_CLIPBOARD_SET method=failed chars=%s" % len(text), flush=True)
    return False
if not _workflowgym_set_clipboard(_paste_text):
    raise RuntimeError("clipboard set failed for paste")
time.sleep(0.1)
pyautogui.hotkey("ctrl", "v")
print("WORKFLOWGYM_CLIPBOARD_PASTE keys=ctrl+v chars=%s" % len(_paste_text), flush=True)""".replace(
        "__PASTE_TEXT__", text_literal
    ).replace(
        "__CLIPBOARD_METHODS__", allowed_literal
    )


PYAUTOGUI_FUNCTION_PARAMS: dict[str, list[str]] = {
    "click": ["x", "y", "clicks", "interval", "button", "duration", "pause"],
    "rightClick": ["x", "y", "interval", "duration", "pause"],
    "middleClick": ["x", "y", "duration", "pause"],
    "doubleClick": ["x", "y", "interval", "button", "duration", "pause"],
    "tripleClick": ["x", "y", "interval", "button", "duration", "pause"],
    "moveTo": ["x", "y", "duration", "pause"],
    "dragTo": ["x", "y", "duration", "button", "mouseDownUp", "pause"],
    "mouseDown": ["x", "y", "button", "duration", "pause"],
    "mouseUp": ["x", "y", "button", "duration", "pause"],
    "scroll": ["clicks", "x", "y"],
    "hscroll": ["clicks", "x", "y"],
    "press": ["keys", "interval", "presses", "pause"],
    "keyDown": ["key", "pause"],
    "keyUp": ["key", "pause"],
    "write": ["message", "interval", "pause"],
    "typewrite": ["message", "interval", "pause"],
}


def xdotool_key_name(key: Any) -> str:
    aliases = {
        "enter": "Return",
        "return": "Return",
        "esc": "Escape",
        "escape": "Escape",
        "del": "Delete",
        "delete": "Delete",
        "ctrl": "ctrl",
        "control": "ctrl",
        "alt": "alt",
        "shift": "shift",
        "super": "super",
        "win": "super",
        "command": "super",
        "up": "Up",
        "down": "Down",
        "left": "Left",
        "right": "Right",
        "pageup": "Page_Up",
        "pagedown": "Page_Down",
        "space": "space",
        "tab": "Tab",
    }
    return aliases.get(str(key or "").strip().lower(), str(key))


def inline_xdotool_run_line(*args: Any) -> str:
    rendered = ", ".join([json.dumps("xdotool")] + [json.dumps(str(arg)) for arg in args])
    return "subprocess.run([%s], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)" % rendered


def _literal_arg(node: ast.AST) -> Any:
    return ast.literal_eval(node)


def _parse_pyautogui_call(full_call: str) -> tuple[str, dict[str, Any], list[Any]] | None:
    match = re.match(r"pyautogui\.(\w+)\((.*)\)", full_call, re.DOTALL)
    if not match:
        return None
    func_name = match.group(1)
    args_str = match.group(2).strip()
    try:
        if func_name == "hotkey":
            parsed = ast.parse("func(%s)" % args_str).body[0].value
            positional = [_literal_arg(arg) for arg in getattr(parsed, "args", [])]
            keywords = {keyword.arg: _literal_arg(keyword.value) for keyword in getattr(parsed, "keywords", [])}
            return func_name, keywords, positional
        parsed = ast.parse("func(%s)" % (args_str or "")).body[0].value
    except (SyntaxError, ValueError):
        return None
    param_names = PYAUTOGUI_FUNCTION_PARAMS.get(func_name, [])
    args: dict[str, Any] = {}
    for index, arg in enumerate(getattr(parsed, "args", [])):
        if index < len(param_names):
            try:
                args[param_names[index]] = _literal_arg(arg)
            except ValueError:
                pass
    try:
        for keyword in getattr(parsed, "keywords", []):
            if keyword.arg:
                args[keyword.arg] = _literal_arg(keyword.value)
    except ValueError:
        return None
    return func_name, args, []


def _compile_pyautogui_call_to_xdotool(func_name: str, args: dict[str, Any], positional: list[Any]) -> str | None:
    button_map = {"left": "1", "middle": "2", "right": "3"}
    lines: list[str] = []

    def maybe_move(x: Any, y: Any) -> None:
        if x is not None and y is not None:
            lines.append(inline_xdotool_run_line("mousemove", "--sync", int(x), int(y)))

    if func_name == "hotkey":
        keys = positional or []
        if not keys:
            return None
        combo = "+".join(xdotool_key_name(key) for key in keys)
        lines.append(inline_xdotool_run_line("key", combo))
        interval = float(args.get("interval") or 0.05)
        if interval:
            lines.append("time.sleep(%s)" % interval)
        return "\n".join(lines)

    if func_name in ("keyDown", "keydown"):
        lines.append(inline_xdotool_run_line("keydown", xdotool_key_name(args.get("key"))))
        return "\n".join(lines)

    if func_name in ("keyUp", "keyup"):
        lines.append(inline_xdotool_run_line("keyup", xdotool_key_name(args.get("key"))))
        return "\n".join(lines)

    if func_name == "press":
        keys = args.get("keys")
        key_list = list(keys) if isinstance(keys, (list, tuple)) else [keys]
        presses = max(1, int(args.get("presses") or 1))
        interval = float(args.get("interval") or 0.0)
        for _ in range(presses):
            for key in key_list:
                lines.append(inline_xdotool_run_line("key", xdotool_key_name(key)))
                if interval:
                    lines.append("time.sleep(%s)" % interval)
        return "\n".join(lines)

    if func_name in ("write", "typewrite"):
        text = str(args.get("message") or "")
        if not text:
            return ""
        delay_ms = max(1, int(float(args.get("interval") or 0.01) * 1000))
        lines.append(inline_xdotool_run_line("type", "--delay", delay_ms, "--", text))
        return "\n".join(lines)

    if func_name == "moveTo":
        maybe_move(args.get("x"), args.get("y"))
        duration = float(args.get("duration") or 0.0)
        if duration:
            lines.append("time.sleep(%s)" % duration)
        return "\n".join(lines)

    if func_name == "click":
        maybe_move(args.get("x"), args.get("y"))
        mapped = button_map.get(str(args.get("button") or "left"), "1")
        repeat = max(1, int(args.get("clicks") or 1))
        if repeat >= 2:
            lines.append(inline_xdotool_run_line("click", "--repeat", repeat, mapped))
        else:
            lines.append(inline_xdotool_run_line("click", mapped))
        interval = float(args.get("interval") or 0.0)
        if interval:
            lines.append("time.sleep(%s)" % interval)
        return "\n".join(lines)

    if func_name == "doubleClick":
        maybe_move(args.get("x"), args.get("y"))
        mapped = button_map.get(str(args.get("button") or "left"), "1")
        lines.append(inline_xdotool_run_line("click", "--repeat", 2, mapped))
        interval = float(args.get("interval") or 0.0)
        if interval:
            lines.append("time.sleep(%s)" % interval)
        return "\n".join(lines)

    if func_name == "rightClick":
        maybe_move(args.get("x"), args.get("y"))
        lines.append(inline_xdotool_run_line("click", "3"))
        interval = float(args.get("interval") or 0.0)
        if interval:
            lines.append("time.sleep(%s)" % interval)
        return "\n".join(lines)

    if func_name == "middleClick":
        maybe_move(args.get("x"), args.get("y"))
        lines.append(inline_xdotool_run_line("click", "2"))
        return "\n".join(lines)

    if func_name == "mouseDown":
        maybe_move(args.get("x"), args.get("y"))
        mapped = button_map.get(str(args.get("button") or "left"), "1")
        lines.append(inline_xdotool_run_line("mousedown", mapped))
        return "\n".join(lines)

    if func_name == "mouseUp":
        maybe_move(args.get("x"), args.get("y"))
        mapped = button_map.get(str(args.get("button") or "left"), "1")
        lines.append(inline_xdotool_run_line("mouseup", mapped))
        return "\n".join(lines)

    if func_name == "dragTo":
        maybe_move(args.get("x"), args.get("y"))
        mapped = button_map.get(str(args.get("button") or "left"), "1")
        lines.insert(0, inline_xdotool_run_line("mousedown", mapped))
        lines.append(inline_xdotool_run_line("mouseup", mapped))
        duration = float(args.get("duration") or 0.0)
        if duration:
            lines.append("time.sleep(%s)" % duration)
        return "\n".join(lines)

    if func_name == "scroll":
        maybe_move(args.get("x"), args.get("y"))
        clicks = int(args.get("clicks") or 0)
        button = "4" if clicks > 0 else "5"
        for _ in range(abs(clicks)):
            lines.append(inline_xdotool_run_line("click", button))
        return "\n".join(lines)

    if func_name == "hscroll":
        maybe_move(args.get("x"), args.get("y"))
        clicks = int(args.get("clicks") or 0)
        button = "7" if clicks > 0 else "6"
        for _ in range(abs(clicks)):
            lines.append(inline_xdotool_run_line("click", button))
        return "\n".join(lines)

    return None


def compile_pyautogui_action_code_to_xdotool(action_code: str) -> tuple[str, dict[str, Any]]:
    original = str(action_code or "").strip()
    if not original:
        return original, {
            "backend": "xdotool",
            "pyautogui_code": original,
            "xdotool_code": original,
            "conversions": [],
        }
    updated = original
    conversions: list[dict[str, Any]] = []
    pattern = r"(pyautogui\.\w+\([^\)]*\))"
    for full_call in re.findall(pattern, original):
        parsed_call = _parse_pyautogui_call(full_call)
        if not parsed_call:
            continue
        func_name, args, positional = parsed_call
        replacement = _compile_pyautogui_call_to_xdotool(func_name, args, positional)
        if replacement is None:
            continue
        updated = updated.replace(full_call, replacement, 1)
        conversions.append(
            {
                "function": "pyautogui.%s" % func_name,
                "source": full_call,
                "target": replacement,
            }
        )
    xdotool_code = updated.strip()
    return xdotool_code, {
        "backend": "xdotool",
        "pyautogui_code": original,
        "xdotool_code": xdotool_code,
        "conversions": conversions,
    }


def should_compile_linux_action_to_xdotool(platform: str, *, allow_xdotool: bool = True) -> bool:
    if not allow_xdotool:
        return False
    return is_linux_platform(platform) and linux_xdotool_backend_enabled()


def describe_pyautogui_action_script(
    action_code: str,
    screenshot_size: tuple[int, int] | None = None,
    platform: str = "",
    display_size: tuple[int, int] | None = None,
    *,
    context: Any = None,
    allow_xdotool: bool | None = None,
) -> dict[str, Any]:
    original = str(action_code or "").strip()
    script_action_code = original
    compile_metadata: dict[str, Any] | None = None
    use_xdotool = resolve_allow_linux_xdotool(context=context, allow_xdotool=allow_xdotool)
    if should_compile_linux_action_to_xdotool(platform, allow_xdotool=use_xdotool):
        script_action_code, compile_metadata = compile_pyautogui_action_code_to_xdotool(original)
    remote_script = build_pyautogui_python_script(
        script_action_code,
        screenshot_size,
        platform=platform,
        display_size=display_size,
        allow_xdotool=use_xdotool,
    )
    if compile_metadata:
        return {
            **compile_metadata,
            "remote_script": remote_script,
        }
    return {
        "backend": "pyautogui",
        "pyautogui_code": original,
        "xdotool_code": "",
        "conversions": [],
        "remote_script": remote_script,
    }


def type_text_code(text: str) -> str:
    text = normalize_type_text(text)
    if text == "":
        return "time.sleep(0.1)"
    lines = []
    parts = text.split("\n")
    for index, line in enumerate(parts):
        if line:
            if line.isascii():
                lines.append("pyautogui.write(%s, interval=0.01)" % json.dumps(line))
            else:
                lines.append(build_inline_clipboard_paste_code(line))
        if index < len(parts) - 1:
            lines.append("pyautogui.press('enter')")
    return "\n".join(lines) or "time.sleep(0.1)"


def normalize_type_text(text: str) -> str:
    # Tool calls often carry submit-newline as the two characters "\\n" inside XML.
    return text.replace("\\r\\n", "\n").replace("\\n", "\n").replace("\\t", "\t")


def normalize_key_name(key: str) -> str:
    aliases = {
        "control": "ctrl",
        "cmd": "command",
        "return": "enter",
        "esc": "escape",
        "del": "delete",
        "pgup": "pageup",
        "pgdn": "pagedown",
    }
    return aliases.get(key.strip().lower(), key.strip().lower())


def required_parameter(action_name: str, parameters: dict[str, Any], parameter_name: str) -> Any:
    value = parameters.get(parameter_name)
    if value is None or value == "":
        raise ValueError("tool_call %s 缺少必需参数: %s" % (action_name, parameter_name))
    return value


def screenshot_size_from_context(context: Any = None) -> tuple[int, int] | None:
    screenshot = getattr(context, "current_screenshot", "") if context is not None else ""
    if not screenshot:
        return None
    try:
        return image_size(Path(screenshot))
    except Exception:
        return None


def image_size(path: Path) -> tuple[int, int] | None:
    data = path.read_bytes()
    if data.startswith(b"\x89PNG\r\n\x1a\n") and len(data) >= 24:
        width, height = struct.unpack(">II", data[16:24])
        return int(width), int(height)
    if data.startswith(b"\xff\xd8"):
        offset = 2
        while offset < len(data):
            while offset < len(data) and data[offset] == 0xFF:
                offset += 1
            if offset >= len(data):
                break
            marker = data[offset]
            offset += 1
            if marker in (0xD8, 0xD9):
                continue
            if offset + 2 > len(data):
                break
            length = struct.unpack(">H", data[offset:offset + 2])[0]
            if marker in set(range(0xC0, 0xC4)) | set(range(0xC5, 0xC8)) | set(range(0xC9, 0xCC)) | set(range(0xCD, 0xD0)):
                height, width = struct.unpack(">HH", data[offset + 3:offset + 7])
                return int(width), int(height)
            offset += length
    return None


def platform_from_context(context: Any = None) -> str:
    metadata = getattr(context, "metadata", {}) if context is not None else {}
    for key in ("platform", "computer_platform", "os", "os_type", "system"):
        value = str(metadata.get(key) or "").strip().lower() if isinstance(metadata, dict) else ""
        if value:
            return "windows" if value.startswith("win") or "windows" in value else "ubuntu"
    task = getattr(context, "task", None)
    fields = getattr(task, "fields", {}) if task is not None else {}
    for key in ("系统类型", "platform", "computer_platform", "os", "os_type", "system"):
        value = str(fields.get(key) or "").strip().lower() if isinstance(fields, dict) else ""
        if value:
            return "windows" if value.startswith("win") or "windows" in value else "ubuntu"
    return "ubuntu"


def windows_action_runner_mode_from_env() -> str:
    explicit = os.getenv("WINDOWS_ACTION_RUNNER", "").strip().lower()
    if explicit in ("flask", "file_queue"):
        return explicit
    if os.getenv("WINDOWS_FILE_QUEUE_RUNNER", "0").lower() in ("1", "true", "yes", "on"):
        return "file_queue"
    return "flask"


def windows_file_queue_poll_seconds() -> int:
    return max(5, int(os.getenv("WINDOWS_FILE_QUEUE_POLL_SECONDS", "90")))


def is_windows_file_queue_command(command: str) -> bool:
    return "workflowgym_file_queue_action.json" in str(command or "")


def is_windows_flask_command(command: str) -> bool:
    return "WORKFLOWGYM_FLASK_AGENT_RESULT" in str(command or "")


def ubuntu_action_runner_mode_from_env() -> str:
    explicit = os.getenv("UBUNTU_ACTION_RUNNER", "").strip().lower()
    if explicit in ("flask", "legacy"):
        return explicit
    if os.getenv("UBUNTU_LEGACY_PYAUTOGUI_RUNNER", "0").lower() in ("1", "true", "yes", "on"):
        return "legacy"
    return "flask"


def is_ubuntu_flask_command(command: str) -> bool:
    text = str(command or "")
    return text.startswith("#!/bin/bash") and "WORKFLOWGYM_FLASK_AGENT_RESULT" in text and "/action" in text


def extract_flask_action_python_script(command: str) -> str:
    """从 wrap_* flask 命令或裸 pyautogui 脚本中提取待执行 Python。"""
    text = str(command or "")
    if not text.strip():
        return ""

    win_match = re.search(r"\$script\s*=\s*@'(.*?)'\s*@", text, flags=re.S)
    if win_match:
        return win_match.group(1).lstrip("\n").rstrip("\n")

    b64_match = re.search(r'"script_b64"\s*:\s*"([A-Za-z0-9+/=]+)"', text)
    if b64_match:
        try:
            return base64.b64decode(b64_match.group(1)).decode("utf-8")
        except Exception:
            pass

    stripped = text.lstrip()
    if stripped.startswith("#!/bin/bash") or stripped.startswith("$ErrorActionPreference"):
        return ""
    if "pyautogui" in stripped or "import " in stripped:
        return text
    return ""


def is_windows_interactive_runner_command(command: str) -> bool:
    return is_windows_file_queue_command(command) or is_windows_flask_command(command)


def is_interactive_runner_command(command: str) -> bool:
    return is_windows_interactive_runner_command(command) or is_ubuntu_flask_command(command)


def should_retry_windows_file_queue_error(exc: BaseException) -> bool:
    text = str(exc).lower()
    if is_windows_file_queue_action_execution_error(exc):
        return False
    return any(
        token in text
        for token in (
            "heartbeat missing",
            "heartbeat stale",
            "runner process missing",
            "runner version stale",
            "workflowgym file queue runner heartbeat missing",
            "workflowgym file queue action timed out",
            "unable to inspect python.exe",
        )
    )


def is_windows_file_queue_action_execution_error(exc: BaseException) -> bool:
    text = str(exc).lower()
    if is_remote_action_timeout_error(exc):
        return False
    if any(
        token in text
        for token in (
            "syntaxerror",
            "unterminated string literal",
            '"ok":  false',
            '"ok": false',
            "exit_code=1",
            "status\":  \"error\"",
            'status": "error"',
        )
    ):
        return True
    if "workflowgym file queue action failed" in text:
        # RunCommand failures may embed the full PowerShell wrapper source, which
        # itself contains this throw template. Only treat it as a bad action
        # when the runtime actually raised that error.
        return any(
            marker in text
            for marker in (
                "fullyqualifiederrorid : workflowgym file queue action failed",
                "workflowgym_file_queue_agent_result",
            )
        )
    return False


def should_retry_windows_flask_error(exc: BaseException) -> bool:
    text = str(exc).lower()
    if is_windows_flask_action_execution_error(exc):
        return False
    return any(
        token in text
        for token in (
            "connection refused",
            "unable to connect to the remote server",
            "flask runner probe failed",
            "flask runner health not ready",
            "flask runner script missing",
            "flask runner scheduled task missing",
            "workflowgym_interactive_flask_runner.log",
            "no connection could be made",
            "flask /action unreachable",
            "wgm run-action failed",
            "timed out",
            "urlopen error",
        )
    )


def is_windows_flask_action_execution_error(exc: BaseException) -> bool:
    text = str(exc).lower()
    if is_remote_action_timeout_error(exc):
        return False
    if any(
        token in text
        for token in (
            "syntaxerror",
            "unterminated string literal",
            '"ok":  false',
            '"ok": false',
            "exit_code=1",
            "status\":  \"error\"",
            'status": "error"',
        )
    ):
        return True
    if "workflowgym flask action failed" in text:
        return any(
            marker in text
            for marker in (
                "fullyqualifiederrorid : workflowgym flask action failed",
                "workflowgym_flask_agent_result",
                "via wgm-direct",
            )
        )
    return False


def should_retry_windows_runner_error(exc: BaseException) -> bool:
    if should_retry_windows_file_queue_error(exc):
        return True
    return should_retry_windows_flask_error(exc)


def should_retry_ubuntu_flask_error(exc: BaseException) -> bool:
    text = str(exc).lower()
    if is_windows_flask_action_execution_error(exc):
        return False
    return any(
        token in text
        for token in (
            "connection refused",
            "failed to connect",
            "couldn't connect to server",
            "flask runner health not ready",
            "flask runner probe failed",
            "workflowgym_interactive_flask_runner.log",
            "curl:",
            "flask /action unreachable",
            "wgm run-action failed",
            "timed out",
            "urlopen error",
        )
    )


def should_retry_interactive_runner_error(
    exc: BaseException,
    *,
    action_script: str = "",
) -> bool:
    # Paste already may have landed on the desktop; retrying doubles text (李明李明).
    if action_script_is_clipboard_paste(action_script) and is_remote_action_timeout_error(exc):
        return False
    if should_retry_windows_runner_error(exc):
        return True
    return should_retry_ubuntu_flask_error(exc)


def action_script_is_clipboard_paste(script_or_command: str) -> bool:
    """True when remote payload is (or wraps) a clipboard paste action."""
    text = str(script_or_command or "")
    if not text.strip():
        return False
    markers = (
        "# clipboard paste",
        "_paste_text",
        "_workflowgym_set_clipboard",
        "pyperclip.copy",
        "paste_text(",
    )
    return any(marker in text for marker in markers)


def disallowed_pyautogui_action_reason(action_code: str) -> str | None:
    code = str(action_code or "")
    if not code.strip():
        return "empty action code"
    for label, pattern in _DISALLOWED_PYAUTOGUI_ACTION_PATTERNS:
        if pattern.search(code):
            return "disallowed non-pyautogui snippet: %s" % label
    return None


def is_disallowed_pyautogui_action_code(action_code: str) -> bool:
    return disallowed_pyautogui_action_reason(action_code) is not None


def is_disallowed_pyautogui_action_error(exc: BaseException) -> bool:
    return str(exc).lower().startswith("disallowed non-pyautogui")


def is_runcommand_python_execution_error(exc: BaseException) -> bool:
    text = str(exc).lower()
    if not any(marker in text for marker in _RUN_COMMAND_FAILURE_MARKERS):
        return False
    return any(marker in text for marker in _PYTHON_SCRIPT_EXECUTION_ERROR_MARKERS)


def is_remote_action_execution_error(exc: BaseException) -> bool:
    if is_windows_file_queue_action_execution_error(exc):
        return True
    if is_windows_flask_action_execution_error(exc):
        return True
    return is_runcommand_python_execution_error(exc)


def action_execution_should_continue() -> bool:
    return os.getenv("ACTION_EXECUTION_FAIL_SAMPLE", "0").lower() not in ("1", "true", "yes", "on")


def is_remote_action_timeout_error(exc: BaseException) -> bool:
    if isinstance(exc, TimeoutError):
        return True
    text = str(exc).lower()
    return any(
        token in text
        for token in (
            "taskexecutiontimeout",
            "invocationtimedout",
            "invocation timeout",
            "等待 runcommand 超时",
            "workflowgym file queue action timed out",
            "action_exec_timeout",
            "timed out",
            # wgm-direct / API Gateway: pyperclip clipboard wait can exceed edge timeout
            "504",
            "gateway timeout",
        )
    )


def action_timeout_should_continue() -> bool:
    return os.getenv("ACTION_TIMEOUT_FAIL_SAMPLE", "0").lower() not in ("1", "true", "yes", "on")


def is_remote_screenshot_error(exc: BaseException) -> bool:
    if isinstance(exc, TimeoutError):
        text = str(exc).lower()
        return "getconsolescreenshot" in text or "console screenshot" in text
    text = str(exc).lower()
    return any(
        token in text
        for token in (
            "getconsolescreenshot",
            "invalidtimestamp",
            "signature of the request is expired",
            "consolescreenshot",
            "返回空截图",
            "不是有效图片",
            "apiexception",
        )
    )


def screenshot_failure_should_continue() -> bool:
    return os.getenv("SCREENSHOT_FAIL_SAMPLE", "0").lower() not in ("1", "true", "yes", "on")


def is_linux_platform(platform: str) -> bool:
    normalized = str(platform or "").strip().lower()
    return normalized in ("ubuntu", "linux") or normalized.startswith("ubuntu")


def context_uses_redis_lease(context: Any = None) -> bool:
    """SampleContext / metadata 是否为 redis（WGM）租约模式。"""
    if context is None:
        return False
    metadata = getattr(context, "metadata", None)
    if not isinstance(metadata, dict):
        return False
    sources = [metadata]
    env_metadata = metadata.get("env_metadata")
    if isinstance(env_metadata, dict):
        sources.append(env_metadata)
    for source in sources:
        kind = str(source.get("lease_backend") or "").strip().lower()
        if kind in ("redis", "wgm", "remote"):
            return True
    return False


def resolve_allow_linux_xdotool(*, context: Any = None, allow_xdotool: bool | None = None) -> bool:
    """redis 模式强制只用 pyautogui，不编译/不注入 xdotool。"""
    if allow_xdotool is not None:
        return bool(allow_xdotool)
    if context_uses_redis_lease(context):
        return False
    return True


def linux_xdotool_backend_enabled() -> bool:
    return os.getenv("UBUNTU_PYAUTOGUI_XDOTOOL_BACKEND", "0").lower() not in ("0", "false", "no", "off")


def linux_portal_focus_enabled() -> bool:
    value = os.getenv("UBUNTU_PYAUTOGUI_PORTAL_FOCUS", "1")
    return str(value or "1").strip().lower() not in ("0", "false", "no", "off")


def should_include_linux_portal_focus_in_script(platform: str, *, allow_xdotool: bool = True) -> bool:
    if not allow_xdotool:
        return False
    if not is_linux_platform(platform):
        return False
    if linux_xdotool_backend_enabled():
        return False
    return linux_portal_focus_enabled()


def build_linux_portal_focus_inline_source() -> str:
    return """
def _linux_xdo(*args):
    return subprocess.run(["xdotool", *args], check=False, capture_output=True, text=True)

def _linux_search_window_ids(*search_args):
    result = _linux_xdo("search", *search_args)
    return [line.strip() for line in (result.stdout or "").splitlines() if line.strip()]

def _linux_activate_window_id(window_id):
    if not window_id:
        return False
    result = _linux_xdo("windowactivate", "--sync", str(window_id))
    return result.returncode == 0

def _linux_active_file_dialog_window_ids():
    return _linux_search_window_ids("--class", "xdg-desktop-portal-gtk")

def activate_linux_file_dialog_window():
    window_ids = _linux_active_file_dialog_window_ids()
    if not window_ids:
        return False
    window_id = window_ids[-1]
    if not _linux_activate_window_id(window_id):
        return False
    print("WORKFLOWGYM_LINUX_PORTAL_GTK_ACTIVATE window_id=%s" % window_id, flush=True)
    return True

def prepare_linux_desktop_for_action():
    if not shutil.which("xdotool"):
        print("WORKFLOWGYM_LINUX_PORTAL_FOCUS xdotool_missing", flush=True)
        return False
    try:
        wait_seconds = float(os.getenv("UBUNTU_PORTAL_FOCUS_WAIT_SECONDS", "2"))
    except Exception:
        wait_seconds = 2.0
    try:
        poll_seconds = max(0.05, float(os.getenv("UBUNTU_PORTAL_FOCUS_POLL_MS", "100")) / 1000.0)
    except Exception:
        poll_seconds = 0.1
    deadline = time.time() + max(0.0, wait_seconds)
    while time.time() <= deadline:
        if activate_linux_file_dialog_window():
            print("WORKFLOWGYM_LINUX_FOCUS target=portal_gtk", flush=True)
            return True
        time.sleep(poll_seconds)
    print("WORKFLOWGYM_LINUX_FOCUS target=none", flush=True)
    return False
"""


def linux_action_helpers_path(desktop_home: str = "") -> str:
    home = desktop_home or os.getenv("DESKTOP_HOME", "/home/user")
    return os.path.join(home.rstrip("/"), ".workflowgym/linux_action_helpers.py")


def build_linux_action_helpers_module_source() -> str:
    return build_linux_xdotool_adapter_source().strip() + "\n"


def build_linux_action_helpers_loader_source(helpers_path: str = "") -> str:
    path = helpers_path or linux_action_helpers_path()
    return """
def _load_linux_action_helpers():
    import os
    path = os.environ.get("WORKFLOWGYM_LINUX_HELPERS_PATH", %s)
    if not os.path.isfile(path):
        print("WORKFLOWGYM_LINUX_HELPERS missing path=%%s" %% path, flush=True)
        def prepare_linux_desktop_for_action():
            print("WORKFLOWGYM_LINUX_PURE_PYAUTOGUI mode=1", flush=True)
            return False
        return
    with open(path, encoding="utf-8") as helper_file:
        exec(compile(helper_file.read(), path, "exec"), globals(), globals())

_load_linux_action_helpers()
""" % json.dumps(path)


def build_install_linux_action_helpers_command(desktop_home: str = "") -> str:
    path = linux_action_helpers_path(desktop_home)
    payload_b64 = base64.b64encode(build_linux_action_helpers_module_source().encode("utf-8")).decode("ascii")
    return """#!/bin/bash
set -euo pipefail
/usr/bin/python3 - <<'PY'
import base64
from pathlib import Path

path = Path(%s)
path.parent.mkdir(parents=True, exist_ok=True)
path.write_bytes(base64.b64decode(%s))
path.chmod(0o644)
print("WORKFLOWGYM_LINUX_HELPERS_INSTALLED path=%%s bytes=%%s" %% (path, path.stat().st_size))
PY
""" % (json.dumps(path), json.dumps(payload_b64))


def build_linux_pure_pyautogui_helper_source() -> str:
    return """
def prepare_linux_desktop_for_action():
    print("WORKFLOWGYM_LINUX_PURE_PYAUTOGUI mode=1", flush=True)
    return False
"""


def build_linux_xdotool_adapter_source() -> str:
    return """
def _linux_xdotool_backend_enabled():
    import os
    return os.getenv("UBUNTU_PYAUTOGUI_XDOTOOL_BACKEND", "0").lower() not in ("0", "false", "no", "off")

def _linux_xdotool_available():
    import shutil
    return shutil.which("xdotool") is not None

def _linux_xdo(*args):
    import subprocess
    return subprocess.run(["xdotool", *args], check=False, capture_output=True, text=True)

def _linux_xdotool_key_name(key):
    aliases = {
        "enter": "Return",
        "return": "Return",
        "esc": "Escape",
        "escape": "Escape",
        "del": "Delete",
        "delete": "Delete",
        "ctrl": "ctrl",
        "control": "ctrl",
        "alt": "alt",
        "shift": "shift",
        "super": "super",
        "win": "super",
        "command": "super",
        "up": "Up",
        "down": "Down",
        "left": "Left",
        "right": "Right",
        "pageup": "Page_Up",
        "pagedown": "Page_Down",
        "space": "space",
        "tab": "Tab",
    }
    return aliases.get(str(key or "").strip().lower(), str(key))

def _linux_env_flag(name, default="1"):
    import os
    value = os.getenv(name, default)
    return str(value or default).strip().lower() not in ("0", "false", "no", "off")

def _linux_search_window_ids(*search_args):
    result = _linux_xdo("search", *search_args)
    return [line.strip() for line in (result.stdout or "").splitlines() if line.strip()]

def _linux_activate_window_id(window_id):
    if not window_id:
        return False
    result = _linux_xdo("windowactivate", "--sync", str(window_id))
    return result.returncode == 0

def activate_linux_window(class_name):
    window_ids = _linux_search_window_ids("--class", str(class_name))
    if not window_ids:
        print("WORKFLOWGYM_LINUX_WINDOW_ACTIVATE class=%s window_id=" % class_name, flush=True)
        return False
    window_id = window_ids[-1]
    activated = _linux_activate_window_id(window_id)
    print("WORKFLOWGYM_LINUX_WINDOW_ACTIVATE class=%s window_id=%s" % (class_name, window_id), flush=True)
    return activated

def _linux_active_file_dialog_window_ids():
    return _linux_search_window_ids("--class", "xdg-desktop-portal-gtk")

def _linux_file_dialog_active():
    return bool(_linux_active_file_dialog_window_ids())

def activate_linux_file_dialog_window():
    window_ids = _linux_active_file_dialog_window_ids()
    if not window_ids:
        return False
    window_id = window_ids[-1]
    if not _linux_activate_window_id(window_id):
        return False
    print("WORKFLOWGYM_LINUX_PORTAL_GTK_ACTIVATE window_id=%s" % window_id, flush=True)
    return True

def prepare_linux_desktop_for_action():
    if not _linux_xdotool_backend_enabled():
        print("WORKFLOWGYM_LINUX_PURE_PYAUTOGUI mode=1", flush=True)
        return False
    if not _linux_xdotool_available():
        print("WORKFLOWGYM_LINUX_XDOTOOL_ADAPTER disabled_or_missing", flush=True)
        return False
    if activate_linux_file_dialog_window():
        print("WORKFLOWGYM_LINUX_FOCUS target=portal_gtk", flush=True)
        return True
    focus_class = str(__import__("os").getenv("UBUNTU_WINDOW_ACTIVATE_CLASS", "") or "").strip()
    if focus_class and activate_linux_window(focus_class):
        print("WORKFLOWGYM_LINUX_FOCUS target=app_class class=%s" % focus_class, flush=True)
        return True
    print("WORKFLOWGYM_LINUX_FOCUS target=none", flush=True)
    return False

def _linux_file_dialog_list_click_threshold():
    import os
    try:
        return max(0, int(os.getenv("UBUNTU_FILE_DIALOG_LIST_CLICK_THRESHOLD", "280")))
    except Exception:
        return 280

def _linux_should_use_file_dialog_entry_click(x, clicks):
    if not _linux_env_flag("UBUNTU_FILE_DIALOG_SMART_CLICK", "1"):
        return False
    if x is None or int(clicks or 1) != 1:
        return False
    return _linux_file_dialog_active() and int(x) >= _linux_file_dialog_list_click_threshold()

def linux_select_file_dialog_entry(x, y, confirm=True):
    moveTo(int(x), int(y))
    doubleClick(int(x), int(y))
    if confirm and _linux_env_flag("UBUNTU_FILE_DIALOG_AUTO_CONFIRM", "1"):
        time.sleep(0.35)
        press("enter")
        print("WORKFLOWGYM_LINUX_FILE_DIALOG_SELECT point=%s,%s confirm=1" % (int(x), int(y)), flush=True)
    else:
        print("WORKFLOWGYM_LINUX_FILE_DIALOG_SELECT point=%s,%s confirm=0" % (int(x), int(y)), flush=True)

def install_linux_xdotool_adapter():
    if not _linux_xdotool_backend_enabled():
        print("WORKFLOWGYM_LINUX_PURE_PYAUTOGUI mode=1", flush=True)
        return
    if not _linux_xdotool_available():
        print("WORKFLOWGYM_LINUX_XDOTOOL_ADAPTER disabled_or_missing", flush=True)
        return
    button_map = {"left": "1", "middle": "2", "right": "3"}

    def moveTo(x, y, duration=0, tween=None, _pause=True):
        _linux_xdo("mousemove", "--sync", str(int(x)), str(int(y)))
        if duration:
            time.sleep(float(duration))

    def click(x=None, y=None, clicks=1, interval=0.0, button="left", duration=0, tween=None, logScreenshot=None, _pause=True):
        if x is not None and y is not None and _linux_should_use_file_dialog_entry_click(x, clicks):
            linux_select_file_dialog_entry(x, y, confirm=True)
            return
        if x is not None and y is not None:
            moveTo(x, y, duration=duration)
        mapped = button_map.get(str(button or "left"), "1")
        repeat = max(1, int(clicks or 1))
        if repeat >= 2:
            _linux_xdo("click", "--repeat", str(repeat), mapped)
        else:
            _linux_xdo("click", mapped)
        if interval:
            time.sleep(float(interval))

    def doubleClick(x=None, y=None, interval=0.0, button="left", duration=0, tween=None, logScreenshot=None, _pause=True):
        click(x=x, y=y, clicks=2, interval=interval, button=button, duration=duration, tween=tween, logScreenshot=logScreenshot, _pause=_pause)

    def rightClick(x=None, y=None, interval=0.0, duration=0, tween=None, logScreenshot=None, _pause=True):
        click(x=x, y=y, clicks=1, interval=interval, button="right", duration=duration, tween=tween, logScreenshot=logScreenshot, _pause=_pause)

    def mouseDown(x=None, y=None, button="left", duration=0, tween=None, logScreenshot=None, _pause=True):
        if x is not None and y is not None:
            moveTo(x, y, duration=duration)
        mapped = button_map.get(str(button or "left"), "1")
        _linux_xdo("mousedown", mapped)

    def mouseUp(x=None, y=None, button="left", duration=0, tween=None, logScreenshot=None, _pause=True):
        if x is not None and y is not None:
            moveTo(x, y, duration=duration)
        mapped = button_map.get(str(button or "left"), "1")
        _linux_xdo("mouseup", mapped)

    def dragTo(x, y, duration=0, button="left", tween=None, logScreenshot=None, _pause=True):
        mapped = button_map.get(str(button or "left"), "1")
        _linux_xdo("mousedown", mapped)
        if duration and float(duration) > 0:
            steps = max(2, int(float(duration) / 0.02))
            location = _linux_xdo("getmouselocation", "--shell")
            start_x = start_y = 0
            for line in (location.stdout or "").splitlines():
                if line.startswith("x:"):
                    start_x = int(line.split(":", 1)[1].strip())
                elif line.startswith("y:"):
                    start_y = int(line.split(":", 1)[1].strip())
            target_x = int(x)
            target_y = int(y)
            for step in range(1, steps + 1):
                ratio = step / float(steps)
                moveTo(
                    int(start_x + (target_x - start_x) * ratio),
                    int(start_y + (target_y - start_y) * ratio),
                )
                time.sleep(float(duration) / steps)
        else:
            moveTo(int(x), int(y))
        _linux_xdo("mouseup", mapped)

    def scroll(clicks, x=None, y=None):
        if x is not None and y is not None:
            moveTo(x, y)
        button = "4" if int(clicks) > 0 else "5"
        for _ in range(abs(int(clicks))):
            _linux_xdo("click", button)

    def hscroll(clicks, x=None, y=None):
        if x is not None and y is not None:
            moveTo(x, y)
        button = "7" if int(clicks) > 0 else "6"
        for _ in range(abs(int(clicks))):
            _linux_xdo("click", button)

    def keyDown(key, logScreenshot=None, _pause=True):
        _linux_xdo("keydown", _linux_xdotool_key_name(key))

    def keyUp(key, logScreenshot=None, _pause=True):
        _linux_xdo("keyup", _linux_xdotool_key_name(key))

    def press(keys, interval=0.0, presses=1, _pause=True):
        key_list = list(keys) if isinstance(keys, (list, tuple)) else [keys]
        for _ in range(max(1, int(presses or 1))):
            for key in key_list:
                _linux_xdo("key", _linux_xdotool_key_name(key))
                if interval:
                    time.sleep(float(interval))

    def hotkey(*args, interval=0.05, _pause=True):
        combo = "+".join(_linux_xdotool_key_name(arg) for arg in args)
        _linux_xdo("key", combo)
        if interval:
            time.sleep(float(interval))

    def write(message, interval=0.0, _pause=True):
        text = str(message or "")
        if not text:
            return
        delay_ms = max(1, int(float(interval or 0.0) * 1000))
        _linux_xdo("type", "--delay", str(delay_ms), "--", text)

    pyautogui.click = click
    pyautogui.moveTo = moveTo
    pyautogui.doubleClick = doubleClick
    pyautogui.rightClick = rightClick
    pyautogui.mouseDown = mouseDown
    pyautogui.mouseUp = mouseUp
    pyautogui.dragTo = dragTo
    pyautogui.scroll = scroll
    pyautogui.hscroll = hscroll
    pyautogui.keyDown = keyDown
    pyautogui.keyUp = keyUp
    pyautogui.press = press
    pyautogui.hotkey = hotkey
    pyautogui.write = write
    print("WORKFLOWGYM_LINUX_XDOTOOL_ADAPTER installed", flush=True)

install_linux_xdotool_adapter()
"""


def remote_action_timeout_seconds(command: str, base_timeout: int) -> int:
    if "workflowgym_file_queue_action.json" in str(command or ""):
        return max(int(base_timeout), windows_file_queue_poll_seconds() + 15)
    if "WORKFLOWGYM_FLASK_AGENT_RESULT" in str(command or ""):
        flask_timeout = int(
            os.getenv(
                "WORKFLOWGYM_FLASK_ACTION_HTTP_TIMEOUT_SECONDS",
                os.getenv("WINDOWS_FLASK_ACTION_TIMEOUT_SECONDS", "90"),
            )
        )
        return max(int(base_timeout), flask_timeout)
    return int(base_timeout)


def action_code_needs_subprocess(action_code: str) -> bool:
    text = str(action_code or "")
    return "subprocess.Popen" in text or "subprocess.run" in text


def action_code_needs_clipboard_helpers(action_code: str) -> bool:
    return "paste_text(" in str(action_code or "")


def linux_english_input_configured_at_startup(platform: str) -> bool:
    return is_linux_platform(platform)


def build_english_input_helpers_source() -> str:
    return """
def run_best_effort(command):
    try:
        subprocess.run(command, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

def ensure_english_input():
    run_best_effort(["setxkbmap", "us"])
    run_best_effort(["ibus", "engine", "xkb:us::eng"])
    run_best_effort(["gsettings", "set", "org.gnome.desktop.input-sources", "sources", "[('xkb', 'us')]"])
    run_best_effort(["gsettings", "set", "org.gnome.desktop.input-sources", "current", "uint32", "0"])
"""


def build_clipboard_helpers_source(include_english_prefix_in_paste: bool) -> str:
    paste_prefix = "    ensure_english_input()\n" if include_english_prefix_in_paste else ""
    return """
def set_clipboard_text_with_command(command, text, require_alive=False):
    if not shutil.which(command[0]):
        print("WORKFLOWGYM_CLIPBOARD_FALLBACK missing=%s" % command[0], flush=True)
        return False
    try:
        process = subprocess.Popen(
            command,
            stdin=subprocess.PIPE,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            text=True,
            start_new_session=True,
        )
        assert process.stdin is not None
        process.stdin.write(text)
        process.stdin.close()
        time.sleep(0.15)
        code = process.poll()
        if require_alive:
            if code is not None:
                print("WORKFLOWGYM_CLIPBOARD_FALLBACK method=%s exited=%s" % (command[0], code), flush=True)
                return False
        elif code not in (None, 0):
            print("WORKFLOWGYM_CLIPBOARD_FALLBACK method=%s returncode=%s" % (command[0], code), flush=True)
            return False
        print("WORKFLOWGYM_CLIPBOARD_SET method=%s chars=%s" % (command[0], len(text)), flush=True)
        return True
    except Exception as exc:
        print("WORKFLOWGYM_CLIPBOARD_FALLBACK method=%s error=%r" % (command[0], exc), flush=True)
        return False

def set_clipboard_text(text):
    # Prefer xsel (proven on redis Ubuntu images); xclip -loops 1 often exits 0
    # without holding CLIPBOARD. Bare pyperclip.copy can block until consumed.
    if set_clipboard_text_with_command(["xsel", "--clipboard", "--input"], text):
        return True
    if set_clipboard_text_with_command(["xclip", "-selection", "clipboard", "-loops", "1"], text, require_alive=True):
        return True
    try:
        import threading
        import pyperclip
        box = {"ok": False}
        def _copy():
            try:
                pyperclip.copy(text)
                box["ok"] = True
            except Exception as exc:
                print("WORKFLOWGYM_CLIPBOARD_FALLBACK method=pyperclip error=%r" % exc, flush=True)
        thread = threading.Thread(target=_copy, daemon=True)
        thread.start()
        thread.join(2.0)
        if box["ok"] and not thread.is_alive():
            print("WORKFLOWGYM_CLIPBOARD_SET method=pyperclip chars=%s" % len(text), flush=True)
            return True
        if thread.is_alive():
            print("WORKFLOWGYM_CLIPBOARD_FALLBACK method=pyperclip timeout=2.0", flush=True)
    except Exception as exc:
        print("WORKFLOWGYM_CLIPBOARD_FALLBACK method=pyperclip error=%r" % exc, flush=True)
    try:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        root.clipboard_clear()
        root.clipboard_append(text)
        root.update()
        root.destroy()
        print("WORKFLOWGYM_CLIPBOARD_SET method=tkinter chars=%s" % len(text), flush=True)
        return True
    except Exception as exc:
        print("WORKFLOWGYM_CLIPBOARD_FALLBACK method=tkinter error=%r" % exc, flush=True)
        return False

def paste_text(text):
__PASTE_PREFIX__    if set_clipboard_text(text):
        pyautogui.hotkey("ctrl", "v")
    elif text.isascii():
        print("WORKFLOWGYM_CLIPBOARD_FALLBACK method=pyautogui.write chars=%s" % len(text), flush=True)
        pyautogui.write(text, interval=0.01)
    else:
        raise RuntimeError("unable to paste non-ASCII text without a working clipboard")
""".replace("__PASTE_PREFIX__", paste_prefix)


def build_pyautogui_python_script(
    action_code: str,
    screenshot_size: tuple[int, int] | None = None,
    platform: str = "",
    display_size: tuple[int, int] | None = None,
    *,
    allow_xdotool: bool = True,
) -> str:
    screenshot_width, screenshot_height = screenshot_size or (0, 0)
    remote_action_code = str(action_code or "").strip()
    use_pyautogui_runtime = "pyautogui." in remote_action_code or not should_compile_linux_action_to_xdotool(
        platform, allow_xdotool=allow_xdotool
    )
    include_scale_point = not (is_linux_platform(platform) and display_size)
    scale_point_block = ""
    if include_scale_point:
        scale_point_block = """
def parse_size(value):
    match = re.search(r"(\\d+)x(\\d+)", str(value or ""))
    if not match:
        return None
    return int(match.group(1)), int(match.group(2))

def shell_display_size():
    commands = (
        ["xdpyinfo"],
        ["xrandr", "--current"],
    )
    for command in commands:
        try:
            output = subprocess.check_output(command, text=True, stderr=subprocess.DEVNULL)
        except Exception:
            continue
        if command[0] == "xdpyinfo":
            for line in output.splitlines():
                if "dimensions:" in line:
                    size = parse_size(line)
                    if size:
                        return size
        else:
            for line in output.splitlines():
                if "*" in line:
                    size = parse_size(line)
                    if size:
                        return size
    return None

def scale_point(value):
    match = re.search(r"<point>\\s*(\\d+)\\s+(\\d+)\\s*</point>", str(value))
    if not match:
        raise ValueError("invalid point: %s" % value)
    x_1000 = max(0, min(1000, int(match.group(1))))
    y_1000 = max(0, min(1000, int(match.group(2))))
    pyautogui_width, pyautogui_height = pyautogui.size()
    shell_size = shell_display_size()
    if shell_size:
        display_width, display_height = shell_size
        resolution_source = "shell"
    else:
        display_width, display_height = int(pyautogui_width), int(pyautogui_height)
        resolution_source = "pyautogui"
    screenshot_width = __SCREENSHOT_WIDTH__
    screenshot_height = __SCREENSHOT_HEIGHT__
    coordinate_width = screenshot_width or int(display_width)
    coordinate_height = screenshot_height or int(display_height)
    actual_x = int(display_width * x_1000 / 1000)
    actual_y = int(display_height * y_1000 / 1000)
    print("WORKFLOWGYM_ACTION_COORD " + json.dumps({
        "source_coordinate_space": "1000x1000",
        "normalized_point": [x_1000, y_1000],
        "screen_size": [int(display_width), int(display_height)],
        "display_size": [int(display_width), int(display_height)],
        "pyautogui_size": [int(pyautogui_width), int(pyautogui_height)],
        "resolution_source": resolution_source,
        "screenshot_size": [int(screenshot_width), int(screenshot_height)] if screenshot_width and screenshot_height else None,
        "coordinate_size": [int(coordinate_width), int(coordinate_height)],
        "actual_point": [actual_x, actual_y],
    }, ensure_ascii=False), flush=True)
    return actual_x, actual_y
"""

    include_english_input = not linux_english_input_configured_at_startup(platform)
    include_clipboard_helpers = action_code_needs_clipboard_helpers(remote_action_code)
    english_input_block = build_english_input_helpers_source() if include_english_input else ""
    clipboard_block = ""
    if include_clipboard_helpers:
        clipboard_block = build_clipboard_helpers_source(include_english_prefix_in_paste=include_english_input)
        if include_english_input and not english_input_block:
            english_input_block = build_english_input_helpers_source()

    include_portal_focus = should_include_linux_portal_focus_in_script(platform, allow_xdotool=allow_xdotool)
    portal_focus_block = build_linux_portal_focus_inline_source() if include_portal_focus else ""

    action_prefix = ""
    if include_english_input:
        action_prefix += "ensure_english_input()\n"

    action_suffix = ""
    if include_portal_focus:
        # Post-action focus: next step screenshots after portal opens (e.g. Browse).
        action_suffix += "\nprepare_linux_desktop_for_action()"

    imports = ["import json", "import time"]
    if action_code_needs_subprocess(remote_action_code) or include_scale_point or include_portal_focus:
        imports.append("import subprocess")
    if include_clipboard_helpers or include_scale_point or include_portal_focus:
        imports.append("import shutil")
    if include_portal_focus:
        imports.append("import os")

    pyautogui_block = ""
    if use_pyautogui_runtime:
        pyautogui_block = """
try:
    import pyautogui
except ModuleNotFoundError:
    raise RuntimeError("pyautogui is not installed in the instance environment") from None

pyautogui.FAILSAFE = False
pyautogui.sleep = time.sleep
"""

    script = """#!/usr/bin/env python3
__IMPORTS__
__PYAUTOGUI_BLOCK__
__PORTAL_FOCUS_BLOCK__
__ENGLISH_INPUT_BLOCK__
__CLIPBOARD_BLOCK__
__SCALE_POINT_BLOCK__
__ACTION_CODE__
""".replace("__IMPORTS__", "\n".join(imports)).replace(
        "__ACTION_CODE__", action_prefix + remote_action_code + action_suffix
    ).replace("__PYAUTOGUI_BLOCK__", pyautogui_block).replace(
        "__PORTAL_FOCUS_BLOCK__", portal_focus_block
    ).replace("__ENGLISH_INPUT_BLOCK__", english_input_block).replace(
        "__CLIPBOARD_BLOCK__", clipboard_block
    ).replace("__SCALE_POINT_BLOCK__", scale_point_block)
    if include_scale_point:
        return script.replace("__SCREENSHOT_WIDTH__", str(int(screenshot_width))).replace(
            "__SCREENSHOT_HEIGHT__", str(int(screenshot_height))
        )
    return script


def ubuntu_desktop_session_from_context(context: Any = None) -> dict[str, str]:
    metadata = getattr(context, "metadata", {}) if context is not None else {}
    if not isinstance(metadata, dict):
        return {}
    env_metadata = metadata.get("env_metadata")
    if not isinstance(env_metadata, dict):
        env_metadata = metadata
    session: dict[str, str] = {}
    for key in ("desktop_user", "desktop_home", "display", "xauthority"):
        value = str(env_metadata.get(key) or "").strip()
        if value:
            session[key] = value
    return session


def _ubuntu_pyautogui_bash_session_block(session: dict[str, str]) -> str:
    session = {key: str(value).strip() for key, value in session.items() if str(value or "").strip()}

    def assignment(name: str, key: str, fallback: str) -> str:
        value = session.get(key)
        if value:
            return "%s=%s" % (name, shlex.quote(value))
        return '%s=%s' % (name, fallback)

    lines = [
        assignment("desktop_user", "desktop_user", '"${DESKTOP_USER:-user}"'),
        assignment("desktop_home", "desktop_home", '"${DESKTOP_HOME:-/home/$desktop_user}"'),
        assignment("display", "display", '"${DISPLAY:-:0}"'),
        assignment("xauthority", "xauthority", '"${XAUTHORITY:-$desktop_home/.Xauthority}"'),
    ]
    if session.get("xauthority"):
        return "\n".join(lines)
    lines.extend(
        [
            'if [ ! -f "$xauthority" ]; then',
            '  found_xauthority="$(find /home /run/user -name ".Xauthority" -o -name "Xauthority" 2>/dev/null | head -n 1 || true)"',
            '  if [ -n "$found_xauthority" ]; then',
            '    xauthority="$found_xauthority"',
            "  fi",
            "fi",
        ]
    )
    return "\n".join(lines)


def wrap_pyautogui_python(
    action_code: str,
    screenshot_size: tuple[int, int] | None = None,
    platform: str = "ubuntu",
    windows_runner_mode: str = "",
    ubuntu_runner_mode: str = "",
    context: Any = None,
    display_size: tuple[int, int] | None = None,
    prebuilt_script: str = "",
) -> str:
    disallowed_reason = disallowed_pyautogui_action_reason(action_code)
    if disallowed_reason:
        raise ValueError(disallowed_reason)
    resolved_display_size = display_size
    if resolved_display_size is None and is_linux_platform(platform):
        resolved_display_size = display_resolution_from_context(context)
    if prebuilt_script:
        script = str(prebuilt_script)
    else:
        use_xdotool = resolve_allow_linux_xdotool(context=context)
        action_bundle = describe_pyautogui_action_script(
            action_code,
            screenshot_size,
            platform=platform,
            display_size=resolved_display_size,
            context=context,
            allow_xdotool=use_xdotool,
        )
        script = str(action_bundle.get("remote_script") or "")
    if str(platform or "").lower().startswith("win"):
        mode = str(windows_runner_mode or windows_action_runner_mode_from_env()).strip().lower()
        if mode == "file_queue":
            return wrap_windows_pyautogui_python(script)
        return wrap_windows_flask_local_python(
            script,
            token=os.getenv("WORKFLOWGYM_FLASK_RUNNER_TOKEN", "workflowgym-flask-token"),
            port=int(os.getenv("WORKFLOWGYM_FLASK_RUNNER_PORT", "8080")),
        )
    ubuntu_mode = str(ubuntu_runner_mode or ubuntu_action_runner_mode_from_env()).strip().lower()
    if ubuntu_mode == "flask":
        metadata = getattr(context, "metadata", {}) if context is not None else {}
        env_metadata = metadata.get("env_metadata") if isinstance(metadata, dict) else {}
        if not isinstance(env_metadata, dict):
            env_metadata = {}
        token = str(
            metadata.get("ubuntu_flask_token")
            or env_metadata.get("ubuntu_flask_token")
            or os.getenv("WORKFLOWGYM_FLASK_RUNNER_TOKEN", "workflowgym-flask-token")
        )
        port = int(
            metadata.get("ubuntu_flask_port")
            or env_metadata.get("ubuntu_flask_port")
            or os.getenv("UBUNTU_FLASK_RUNNER_PORT", os.getenv("WORKFLOWGYM_UBUNTU_FLASK_RUNNER_PORT", "80"))
        )
        return wrap_ubuntu_flask_local_python(script, token=token, port=port, context=context)
    session_block = _ubuntu_pyautogui_bash_session_block(ubuntu_desktop_session_from_context(context))
    command = """#!/bin/bash
set -euo pipefail
__SESSION_BLOCK__
sudo rm -f /tmp/workflowgym_pyautogui.py
sudo tee /tmp/workflowgym_pyautogui.py >/dev/null <<'PY'
__PYTHON_SCRIPT__
PY
sudo chown "$desktop_user:$desktop_user" /tmp/workflowgym_pyautogui.py
sudo chmod 644 /tmp/workflowgym_pyautogui.py
sudo -H -u "$desktop_user" env DISPLAY="$display" HOME="$desktop_home" XAUTHORITY="$xauthority" /usr/bin/python /tmp/workflowgym_pyautogui.py
"""
    return command.replace("__SESSION_BLOCK__", session_block).replace("__PYTHON_SCRIPT__", script)


def wrap_windows_pyautogui_python(script: str) -> str:
    return """$ErrorActionPreference = 'Stop'
$desktop = 'C:\\Users\\Administrator\\Desktop'
$actionPath = Join-Path $desktop 'workflowgym_file_queue_action.json'
$resultPath = Join-Path $desktop 'workflowgym_file_queue_result.json'
$heartbeatPath = Join-Path $desktop 'workflowgym_file_queue_heartbeat.json'
$runnerLogPath = Join-Path $desktop 'workflowgym_file_queue_runner.log'
$script = @'
__PYTHON_SCRIPT__
'@
$actionId = [guid]::NewGuid().ToString()
$payload = [ordered]@{
  action = 'python'
  id = $actionId
  source = 'workflowgym_pyautogui_wrapper'
  script_b64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($script))
}
if (-not (Test-Path $heartbeatPath)) {
  if (Test-Path $runnerLogPath) {
    Write-Output 'WORKFLOWGYM_FILE_QUEUE_RUNNER_LOG'
    Get-Content -LiteralPath $runnerLogPath -Tail 40
  }
  throw "workflowgym file queue runner heartbeat missing: $heartbeatPath"
}
Remove-Item -LiteralPath $resultPath -Force -ErrorAction SilentlyContinue
$payload | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $actionPath -Encoding UTF8
for ($i = 0; $i -lt __POLL_SECONDS__; $i++) {
  if (Test-Path $resultPath) {
    $result = Get-Content -LiteralPath $resultPath -Raw | ConvertFrom-Json
    if ($result.id -eq $actionId) {
      Write-Output 'WORKFLOWGYM_FILE_QUEUE_AGENT_RESULT'
      $result | ConvertTo-Json -Depth 12
      if ($result.output) {
        Write-Output $result.output
      }
      if ($result.stderr) {
        Write-Output $result.stderr
      }
      if (-not $result.ok) {
        throw ("workflowgym file queue action failed: " + ($result | ConvertTo-Json -Depth 12 -Compress))
      }
      exit 0
    }
  }
  Start-Sleep -Seconds 1
}
if (Test-Path $runnerLogPath) {
  Write-Output 'WORKFLOWGYM_FILE_QUEUE_RUNNER_LOG'
  Get-Content -LiteralPath $runnerLogPath -Tail 40
}
throw "workflowgym file queue action timed out: $actionId"
""".replace("__PYTHON_SCRIPT__", script).replace("__POLL_SECONDS__", str(windows_file_queue_poll_seconds()))


def wrap_windows_flask_local_python(script: str, token: str = "workflowgym-flask-token", port: int = 8080) -> str:
    token_literal = json.dumps(str(token))
    http_timeout = max(30, int(os.getenv("WORKFLOWGYM_FLASK_ACTION_HTTP_TIMEOUT_SECONDS", "120")))
    return """$ErrorActionPreference = 'Stop'
$port = __PORT__
$token = __TOKEN__
$logPath = 'C:\\Users\\Administrator\\Desktop\\workflowgym_interactive_flask_runner.log'
$script = @'
__PYTHON_SCRIPT__
'@
$actionId = [guid]::NewGuid().ToString()
$payload = [ordered]@{
  action = 'python'
  id = $actionId
  source = 'workflowgym_pyautogui_wrapper'
  script_b64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($script))
}
$headers = @{
  'X-WorkflowGym-Token' = $token
  'Content-Type' = 'application/json'
}
try {
  $result = Invoke-RestMethod -Uri ('http://127.0.0.1:' + $port + '/action') -Method Post -Headers $headers -Body ($payload | ConvertTo-Json -Depth 8 -Compress) -TimeoutSec __HTTP_TIMEOUT__
} catch {
  if (Test-Path -LiteralPath $logPath) {
    Write-Output 'WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_LOG'
    Get-Content -LiteralPath $logPath -Tail 40
  }
  throw $_
}
Write-Output 'WORKFLOWGYM_FLASK_AGENT_RESULT'
$result | ConvertTo-Json -Depth 12
if ($result.output) {
  Write-Output $result.output
}
if ($result.stderr) {
  Write-Output $result.stderr
}
if (-not $result.ok) {
  throw ("workflowgym flask action failed: " + ($result | ConvertTo-Json -Depth 12 -Compress))
}
""".replace("__PYTHON_SCRIPT__", script).replace("__PORT__", str(int(port))).replace("__TOKEN__", token_literal).replace("__HTTP_TIMEOUT__", str(http_timeout))


def wrap_ubuntu_flask_local_python(script: str, token: str, port: int, context: Any = None) -> str:
    from open_workflowgym.envs.volcengine_env import (
        build_ubuntu_flask_post_python_action_command,
        ubuntu_flask_exec_timeout_seconds,
    )

    session = ubuntu_desktop_session_from_context(context)
    desktop_home = str(session.get("desktop_home") or "/home/user").rstrip("/")
    log_path = "%s/.workflowgym/workflowgym_interactive_flask_runner.log" % desktop_home
    http_timeout = max(
        30,
        int(
            os.getenv(
                "WORKFLOWGYM_FLASK_ACTION_HTTP_TIMEOUT_SECONDS",
                str(ubuntu_flask_exec_timeout_seconds() + 15),
            )
        ),
    )
    return build_ubuntu_flask_post_python_action_command(
        script,
        port,
        token,
        http_timeout,
        source="workflowgym_pyautogui_wrapper",
        log_path=log_path,
    )
