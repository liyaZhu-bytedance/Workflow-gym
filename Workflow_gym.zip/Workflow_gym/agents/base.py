from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol

from ..records import PromptBundle, StepTrace, TaskRecord


@dataclass
class SampleContext:
    run_id: str
    task: TaskRecord
    sample_index: int
    sample_dir: str
    prompts: PromptBundle = field(default_factory=PromptBundle)
    history: list[StepTrace] = field(default_factory=list)
    current_screenshot: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


class AgentAdapter(Protocol):
    name: str
    dynamic_prompts: bool

    def build_prompts(self, context: SampleContext) -> PromptBundle:
        ...

    def before_sample(self, context: SampleContext) -> None:
        ...

    def before_step(self, context: SampleContext) -> None:
        ...

    def build_step_prompts(self, context: SampleContext) -> PromptBundle:
        ...

    def predict(self, context: SampleContext) -> str:
        ...

    def parse_response(self, response: str, context: SampleContext) -> dict[str, Any]:
        ...

    def transform_function_call(self, call: Any, context: SampleContext) -> Any:
        ...

    def transform_coordinates(self, call: Any, context: SampleContext) -> Any:
        ...

    def to_pyautogui(self, call: Any, context: SampleContext) -> list[str]:
        ...

    def after_step(self, context: SampleContext, step_result: StepTrace) -> None:
        ...

    def after_sample(self, context: SampleContext, result: Any) -> None:
        ...


class BaseAgentAdapter:
    name = "base"
    dynamic_prompts = False

    def build_prompts(self, context: SampleContext) -> PromptBundle:
        task_text = self.task_instruction(context)
        return PromptBundle(sp="You are a desktop automation agent.", up=task_text)

    def task_instruction(self, context: SampleContext) -> str:
        return build_task_instruction(context.task.fields)

    def before_sample(self, context: SampleContext) -> None:
        return None

    def before_step(self, context: SampleContext) -> None:
        return None

    def build_step_prompts(self, context: SampleContext) -> PromptBundle:
        return context.prompts

    def predict(self, context: SampleContext) -> str:
        return "No-op dummy response."

    def parse_response(self, response: str, context: SampleContext) -> dict[str, Any]:
        return {"response": response, "function_call": None, "thought": ""}

    def transform_function_call(self, call: Any, context: SampleContext) -> Any:
        return call

    def transform_coordinates(self, call: Any, context: SampleContext) -> Any:
        return call

    def to_pyautogui(self, call: Any, context: SampleContext) -> list[str]:
        if not call:
            return []
        if isinstance(call, str) and "pyautogui" in call:
            return [call]
        return []

    def after_step(self, context: SampleContext, step_result: StepTrace) -> None:
        context.history.append(step_result)

    def after_sample(self, context: SampleContext, result: Any) -> None:
        return None


class DummyAgentAdapter(BaseAgentAdapter):
    name = "dummy"


def build_task_instruction(fields: dict[str, Any]) -> str:
    instruction = first_text(fields, "up", "UP", "题目", "任务", "task")
    launch_mode = first_text(fields, "启动方式", "launch_mode", "launchMode")
    if launch_mode:
        return f"#软件启动方式: {launch_mode}\n\n{instruction}"
    return instruction


def first_text(fields: dict[str, Any], *keys: str) -> str:
    for key in keys:
        value = fields.get(key)
        if value not in (None, ""):
            return str(value).strip()
    return ""

