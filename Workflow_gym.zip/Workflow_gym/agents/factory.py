from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any
from typing import Type

from .base import AgentAdapter, BaseAgentAdapter, DummyAgentAdapter
from .claude import ClaudeAgentAdapter
from .gpt_native import Gpt54MiniNativeAgentAdapter, GptNativeAgentAdapter
from .kimi26 import Kimi26AgentAdapter, KimiNativeAgentAdapter


@dataclass(frozen=True)
class AgentRegistration:
    agent_name: str
    adapter_class: str
    enabled_hooks: tuple[str, ...]
    middlewares: tuple[str, ...] = ()
    sp_builder: str = "build_prompts"
    up_builder: str = "build_prompts"
    dynamic_prompts: bool = False
    tool_calls_schema: str = ""
    function_call_converter: str = "transform_function_call"
    coordinate_transformer: str = "transform_coordinates"
    needs_coordinate_transform: bool = False
    reference_history_image_count: int = 1
    default_keep_history_image_count: int = 5
    model: str = ""
    base_url: str = ""
    api_version: str = ""
    request_kwargs: dict[str, Any] | None = None
    default_headers: dict[str, str] | None = None
    predictor_class: str = ""
    function_call_parser: str = "parse_response"
    needs_conversion: bool = True


class AgentFactory:
    def __init__(self):
        self._classes: dict[str, Type[BaseAgentAdapter]] = {}
        self.register("dummy", DummyAgentAdapter)
        self.register("chatgpt5.5", DummyAgentAdapter)
        self.register("claude", ClaudeAgentAdapter)
        self.register("kimi", KimiNativeAgentAdapter)
        self.register("kimi_native", KimiNativeAgentAdapter)
        self.register("kimi2.6", Kimi26AgentAdapter)
        self.register("gpt", GptNativeAgentAdapter)
        self.register("gpt54-mini-native", Gpt54MiniNativeAgentAdapter)

    def register(self, name: str, cls: Type[BaseAgentAdapter]) -> None:
        self._classes[name] = cls

    def create(self, name: str) -> AgentAdapter:
        cls = self._classes.get(name)
        if not cls:
            raise ValueError("unknown agent: %s" % name)
        adapter = cls()
        adapter.name = name
        return adapter

    def registrations(self) -> list[dict]:
        return [asdict(self.registration_for(name)) for name in sorted(self._classes)]

    def registration_for(self, name: str) -> AgentRegistration:
        cls = self._classes[name]
        hooks = (
            "build_prompts",
            "before_sample",
            "before_step",
            "predict",
            "parse_response",
            "transform_function_call",
            "transform_coordinates",
            "to_pyautogui",
            "after_step",
            "after_sample",
        )
        return AgentRegistration(
            agent_name=name,
            adapter_class="%s.%s" % (cls.__module__, cls.__name__),
            enabled_hooks=hooks,
            dynamic_prompts=getattr(cls, "dynamic_prompts", False),
            model=getattr(cls, "model", name),
            base_url=getattr(cls, "base_url", ""),
            api_version=getattr(cls, "api_version", ""),
            request_kwargs=getattr(cls, "request_kwargs", None),
            default_headers=getattr(cls, "default_headers", None),
            predictor_class=cls.__name__,
        )
