"""Prompt templates for agent adapters."""
