from __future__ import annotations

import ast
import base64
import json
import logging
import os
import re
import time
from typing import Any

from ..records import PromptBundle
from .base import BaseAgentAdapter, SampleContext
from .pyautogui_actions import (
    build_inline_clipboard_paste_code,
    disallowed_pyautogui_action_reason,
    image_size,
    platform_from_context,
    screenshot_size_from_context,
    wrap_pyautogui_python,
)


logger = logging.getLogger(__name__)

INSTRUCTION_TEMPLATE = (
    "# Task Instruction:\n{instruction}\n\n"
    "Please generate the next move according to the screenshot, task instruction and previous steps (if provided).\n"
)
STEP_TEMPLATE = "# Step {step_num}:\n"
THOUGHT_HISTORY_TEMPLATE = "\u25c1think\u25b7{thought}\u25c1/think\u25b7## Action:\n{action}\n"

SYSTEM_PROMPT_THINKING = """
You are a GUI agent. You are given an instruction, a screenshot of the screen and your previous interactions with the computer. You need to perform a series of actions to complete the task. The passoword of the computer is {password}.

Step output policy (strict — counts must be 1:1:1, headers are mandatory literals):
- **Exactly one** thought for this step: put all reasoning in the single thinking segment (before ## Action). Do not add a second thought block, duplicate headings, or “Thought 2 / Part B”.
- **Exactly one** ## Action section: you MUST include the exact literal heading `## Action:` once, followed by one contiguous action description (no bullet list of multiple operations, no “Step 1/2/3” plan for future steps).
- **Exactly one** ## Code section: you MUST include the exact literal heading `## Code:` once, followed by **one** fenced ```python … ``` block only. No second code fence, no extra ```python blocks, no mixing languages.
- Inside that single code block: one GUI operation — at most one primary pyautogui call, except dragging may use `moveTo` then `dragTo` in the same block. Or use exactly one `computer.wait` / `computer.terminate` as specified below.
- Do not output multiple unrelated operations in one step; the environment will screenshot again after this step.
- Forbidden output: any `# Step <n>` section, multiple `## Action` headers, or multiple `## Code` headers.

For this turn only, provide your response in this format:
{thought}
## Action:
{action}
## Code:
{code}

In the code section, the code should be either pyautogui code or one of the following functions wrapped in the code block:
- {"name": "computer.wait", "description": "Make the computer wait for 20 seconds for installation, running code, etc.", "parameters": {"type": "object", "properties": {}, "required": []}}
- {"name": "computer.terminate", "description": "Terminate the current task and report its completion status", "parameters": {"type": "object", "properties": {"status": {"type": "string", "enum": ["success", "failure"], "description": "The status of the task"}, "answer": {"type": "string", "description": "The answer of the task"}}, "required": ["status"]}}
""".strip()

STEP_HEADER_RE = re.compile(r"^\s*#\s*Step\s+\d+\b", re.IGNORECASE | re.MULTILINE)
ACTION_HEADER_RE = re.compile(r"^\s*##\s*Action\s*:?\s*$", re.IGNORECASE | re.MULTILINE)
CODE_HEADER_RE = re.compile(r"^\s*##\s*Code\s*:?\s*$", re.IGNORECASE | re.MULTILINE)
FENCED_CODE_RE = re.compile(r"```.*?```", re.DOTALL)


class KimiNativeAgentAdapter(BaseAgentAdapter):
    name = "kimi"
    dynamic_prompts = False
    model = "kimi-k2.6"
    base_url = "https://api.moonshot.cn/v1"
    api_version = "chat_completions"
    request_kwargs = {
        "max_tokens": 8192,
        "top_p": 0.95,
        "temperature": 1,
        "thinking": True,
        "max_image_history_length": 6,
    }
    default_headers: dict[str, str] = {}

    def __init__(self):
        self.actions: list[str] = []
        self.observations: list[dict[str, bytes]] = []
        self.cots: list[dict[str, Any]] = []
        self._last_actions: list[dict[str, Any]] = []
        self.screen_size = (
            int(os.getenv("KIMI_NATIVE_SCREEN_WIDTH", "1920")),
            int(os.getenv("KIMI_NATIVE_SCREEN_HEIGHT", "1080")),
        )
        self.max_steps = int(os.getenv("STEP_NUM", "400"))
        self.max_tokens = int(os.getenv("KIMI_NATIVE_MAX_TOKENS", str(self.request_kwargs["max_tokens"])))
        self.max_image_history_length = max(
            3,
            int(os.getenv("KIMI_NATIVE_IMAGE_HISTORY", str(self.request_kwargs["max_image_history_length"]))),
        )
        self.top_p = float(os.getenv("KIMI_NATIVE_TOP_P", str(self.request_kwargs["top_p"])))
        self.temperature = float(os.getenv("KIMI_NATIVE_TEMPERATURE", str(self.request_kwargs["temperature"])))
        self.platform = os.getenv("KIMI_NATIVE_PLATFORM", "ubuntu").lower()

    def build_prompts(self, context: SampleContext) -> PromptBundle:
        # Must match build_messages(): traj.md / sample_metadata.sp come from here.
        return PromptBundle(sp=SYSTEM_PROMPT_THINKING, up=self.task_instruction(context))

    def before_sample(self, context: SampleContext) -> None:
        self.actions = []
        self.observations = []
        self.cots = []
        self._last_actions = []
        self.max_steps = int(context.metadata.get("step_num") or self.max_steps)
        self.platform = infer_kimi_platform(context)

    def predict(self, context: SampleContext) -> str:
        if context.metadata.get("dry_run"):
            self._last_actions = []
            return "No-op kimi native dry-run response."
        self.update_screen_size(context)
        screenshot = read_binary(context.current_screenshot)
        response_msg, actions, cot = self.predict_step(
            self.task_instruction(context),
            {"screenshot": screenshot},
            len(self.actions),
        )
        prediction = response_to_prediction_text(response_msg)
        self._last_actions = self.build_native_actions(actions, prediction, cot)
        self.observations.append({"screenshot": screenshot})
        self.actions.append(cot.get("action") or "")
        self.cots.append(cot)
        return prediction

    def predict_step(self, instruction: str, obs: dict[str, bytes], step_idx: int) -> tuple[Any, list[str], dict[str, Any]]:
        messages = self.build_messages(instruction, obs)
        retry_count = 0
        max_retry = int(os.getenv("KIMI_NATIVE_PARSE_RETRY", "8"))
        format_repair_used = False
        last_cot: dict[str, Any] = {}

        while retry_count < max_retry:
            try:
                response = self.call_llm(
                    {
                        "model": self.model_name(),
                        "messages": messages,
                        "max_tokens": max(256, self.max_tokens),
                        "top_p": self.top_p,
                        "temperature": self.temperature if retry_count == 0 else max(0.2, self.temperature),
                    }
                )
                response_text = response_content_text(response)
                violation = detect_response_structure_violation(response_text)
                if violation:
                    if format_repair_used:
                        raise ValueError("format violation after repair: %s" % violation)
                    format_repair_used = True
                    messages.append({"role": "assistant", "content": response_text})
                    messages.append(
                        {
                            "role": "user",
                            "content": [{"type": "text", "text": format_repair_message(violation, response_text)}],
                        }
                    )
                    continue

                low_level_instruction, pyautogui_actions, cot = parse_response_to_cot_and_action(
                    response,
                    self.screen_size,
                )
                last_cot = cot
                if "<Error>" in low_level_instruction or not pyautogui_actions:
                    raise ValueError(low_level_instruction)

                pyautogui_actions = [scale_scroll_for_windows(code, self.platform) for code in pyautogui_actions]
                current_step = len(self.actions) + 1
                first_code = (pyautogui_actions[0] if pyautogui_actions else "") or ""
                if current_step >= self.max_steps and "computer.terminate" not in str(first_code).lower():
                    cot["code"] = "FAIL"
                    return response, ["FAIL"], cot
                return response, pyautogui_actions, cot
            except Exception as exc:
                retry_count += 1
                logger.error("Kimi native step=%s attempt=%s failed: %s", step_idx, retry_count, exc)
                if retry_count >= max_retry:
                    return str(exc), ["FAIL"], last_cot
                time.sleep(min(5, retry_count))

        return "", ["FAIL"], last_cot

    def build_messages(self, instruction: str, obs: dict[str, bytes]) -> list[dict[str, Any]]:
        messages: list[dict[str, Any]] = [{"role": "system", "content": SYSTEM_PROMPT_THINKING}]
        history_texts: list[str] = []
        history_count = len(self.actions)
        for index in range(history_count):
            history_content = STEP_TEMPLATE.format(step_num=index + 1) + THOUGHT_HISTORY_TEMPLATE.format(
                thought=self.cots[index].get("thought") or "",
                action=self.cots[index].get("action") or self.actions[index],
            )
            if index >= history_count - self.max_image_history_length:
                messages.append(
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": "data:image/png;base64,%s" % encode_image(self.observations[index]["screenshot"])
                                },
                            }
                        ],
                    }
                )
                messages.append({"role": "assistant", "content": history_content})
            else:
                history_texts.append(history_content)
                if history_count > self.max_image_history_length and index == history_count - self.max_image_history_length - 1:
                    messages.append({"role": "assistant", "content": "\n".join(history_texts)})

        messages.append(
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {"url": "data:image/png;base64,%s" % encode_image(obs["screenshot"])},
                    },
                    {"type": "text", "text": INSTRUCTION_TEMPLATE.format(instruction=instruction)},
                ],
            }
        )
        return messages

    def call_llm(self, payload: dict[str, Any]) -> dict[str, Any]:
        try:
            import httpx
            from openai import APIConnectionError, APIStatusError, APITimeoutError, OpenAI
        except ImportError as exc:
            raise RuntimeError("Missing openai/httpx dependencies for kimi") from exc

        api_key = kimi_api_key()
        proxy_url = kimi_http_proxy()
        timeout_s = float(os.getenv("KIMI_MOONSHOT_TIMEOUT", "1200"))
        if proxy_url:
            try:
                http_client = httpx.Client(proxy=proxy_url, timeout=timeout_s, verify=False)
            except TypeError:
                http_client = httpx.Client(proxies=proxy_url, timeout=timeout_s, verify=False)
            client = OpenAI(api_key=api_key, base_url=moonshot_base_url(), http_client=http_client)
        else:
            client = OpenAI(api_key=api_key, base_url=moonshot_base_url(), timeout=timeout_s)

        last_error = None
        for _ in range(int(os.getenv("KIMI_NATIVE_REQUEST_RETRY", "20"))):
            try:
                completion = client.chat.completions.create(**payload)
                choice = completion.choices[0]
                message = message_to_dict(choice.message)
                content, reasoning = message_text_bodies(message)
                finish_reason = normalize_finish_reason(choice)
                if content or reasoning or finish_reason in ("stop", "length", "end_turn", None):
                    return message
                last_error = "empty completion with finish_reason=%r" % finish_reason
            except (APIConnectionError, APITimeoutError, APIStatusError) as exc:
                last_error = str(exc)
                if hasattr(exc, "response") and exc.response is not None:
                    try:
                        last_error = exc.response.text
                    except Exception:
                        pass
            except Exception as exc:
                last_error = str(exc)
            logger.error("Moonshot request failed: %s", last_error)
            time.sleep(5)
        raise RuntimeError("Moonshot chat/completions failed after retries: %s" % last_error)

    def build_native_actions(self, actions: list[str], prediction: str, cot: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        native_actions: list[dict[str, Any]] = []
        coordinate_conversions = (cot or {}).get("coordinate_conversions") or []
        for action in actions:
            action_text = str(action or "").strip()
            if not action_text:
                continue
            if action_text == "WAIT":
                code = "import time\ntime.sleep(20)\n"
                native_actions.append({"action": code, "raw_action": {"type": "wait"}, "batch_last": True})
                continue
            if action_text == "SKIP":
                native_actions.append(
                    {
                        "action": "",
                        "raw_action": {
                            "type": "skip",
                            "reason": (cot or {}).get("rejected_code_reason") or "disallowed non-pyautogui action code",
                        },
                        "batch_last": True,
                    }
                )
                continue
            if action_text == "DONE":
                native_actions.append({"action": "", "raw_action": {"type": "done"}, "batch_last": True, "terminal": "success"})
                continue
            if action_text == "FAIL":
                native_actions.append(
                    {
                        "action": "",
                        "raw_action": {"type": "fail", "message": prediction},
                        "batch_last": True,
                        "terminal": "failure",
                    }
                )
                continue
            fixed = fix_pyautogui_less_than_bug(action_text)
            disallowed_reason = disallowed_pyautogui_action_reason(fixed)
            if disallowed_reason:
                native_actions.append(
                    {
                        "action": "",
                        "raw_action": {"type": "skip", "reason": disallowed_reason, "code": fixed},
                        "batch_last": True,
                    }
                )
                continue
            native_actions.append(
                {
                    "action": fixed,
                    "raw_action": {"type": "pyautogui", "code": fixed, "coordinate_conversions": coordinate_conversions},
                    "batch_last": True,
                }
            )
        return native_actions

    def parse_response(self, response: str, context: SampleContext) -> dict[str, Any]:
        terminal = next((item for item in self._last_actions if item.get("terminal")), None)
        if terminal:
            return {
                "response": response,
                "function_call": {"name": "finished", "parameters": {"status": terminal.get("terminal"), "content": response}},
                "thought": "",
            }
        return {"response": response, "function_call": list(self._last_actions), "thought": ""}

    def transform_function_call(self, call: Any, context: SampleContext) -> Any:
        return call

    def transform_coordinates(self, call: Any, context: SampleContext) -> Any:
        return call

    def to_pyautogui(self, call: Any, context: SampleContext) -> list[str]:
        if not isinstance(call, list):
            return []
        screenshot_size = screenshot_size_from_context(context)
        executed_code: list[str] = []
        for item in call:
            action = str(item.get("action") or "")
            if not action or disallowed_pyautogui_action_reason(action):
                continue
            executed_code.append(
                wrap_pyautogui_python(action, screenshot_size, platform_from_context(context), context=context)
            )
        return executed_code

    def rollback_last_step_history(self) -> None:
        if self.actions:
            self.actions.pop()
        if self.cots:
            self.cots.pop()
        if self.observations:
            self.observations.pop()

    def after_sample(self, context: SampleContext, result: Any) -> None:
        self.actions = []
        self.observations = []
        self.cots = []
        self._last_actions = []

    def update_screen_size(self, context: SampleContext) -> None:
        if not context.current_screenshot:
            return
        try:
            self.screen_size = image_size_path(context.current_screenshot) or self.screen_size
        except Exception:
            return

    def model_name(self) -> str:
        return (
            os.getenv("RUNNER_MODEL")
            or os.getenv("KIMI_NATIVE_MODEL")
            or self.model
        ).strip() or self.model


class Kimi26AgentAdapter(KimiNativeAgentAdapter):
    name = "kimi2.6"


def parse_response_to_cot_and_action(response: Any, screen_size: tuple[int, int]) -> tuple[str, list[str], dict[str, Any]]:
    input_string = response_to_prediction_text(response).lstrip()
    sections: dict[str, Any] = {}
    try:
        thought = response.get("reasoning_content", "") if isinstance(response, dict) else ""
        sections["thought"] = thought.strip() if isinstance(thought, str) else ""
        action_header = re.search(r"^##\s*Action\b", input_string, flags=re.MULTILINE)
        if action_header:
            input_string = input_string[action_header.start():]
        action_match = re.search(r"^\s*##\s*Action\s*:?\s*[\n\r]+(.*?)(?=^\s*##|\Z)", input_string, re.DOTALL | re.MULTILINE)
        if action_match:
            sections["action"] = action_match.group(1).strip()

        code_blocks = re.findall(r"```(?:code|python)?\s*(.*?)\s*```", input_string, re.DOTALL | re.IGNORECASE)
        if not code_blocks:
            return "<Error>: no code blocks found in the input string: %s" % input_string, ["FAIL"], sections

        code_block = code_blocks[-1].strip()
        sections["original_code"] = code_block
        action_text = sections.get("action") or "Execute the provided code block."
        sections["action"] = action_text
        lower_code = code_block.lower()
        if "computer.wait" in lower_code:
            sections["code"] = "WAIT"
            return action_text, ["WAIT"], sections
        if "computer.terminate" in lower_code:
            if "failure" in lower_code or "fail" in lower_code:
                sections["code"] = "FAIL"
                return code_block, ["FAIL"], sections
            if "success" in lower_code:
                sections["code"] = "DONE"
                return code_block, ["DONE"], sections
            return "<Error>: terminate action found but no status: %s" % input_string, ["FAIL"], sections

        projected_code, coordinate_conversions = project_coordinate_to_absolute_scale_with_metadata(
            code_block,
            screen_size[0],
            screen_size[1],
        )
        sections["code"] = projected_code
        sections["coordinate_conversions"] = coordinate_conversions
        if not projected_code:
            return "<Error>: no code parsed: %s" % input_string, ["FAIL"], sections
        disallowed_reason = disallowed_pyautogui_action_reason(projected_code)
        if disallowed_reason:
            sections["rejected_code_reason"] = disallowed_reason
            return action_text, ["SKIP"], sections
        return action_text, [projected_code], sections
    except Exception as exc:
        return "<Error>: parsing response: %s Input string: %s" % (exc, input_string), ["FAIL"], sections


def project_coordinate_to_absolute_scale(code: str, screen_width: int, screen_height: int) -> str:
    return project_coordinate_to_absolute_scale_with_metadata(code, screen_width, screen_height)[0]


def coordinates_are_relative_0_1(x: float, y: float) -> bool:
    """Return True only for normalized 0-1 fractions; absolute pixels are left unchanged."""
    if x < 0 or y < 0:
        return False
    if x > 1.0 or y > 1.0:
        return False
    # Integer pairs in [0, 1] are pixel coordinates (e.g. origin), not normalized fractions.
    if float(int(x)) == x and float(int(y)) == y:
        return False
    return True


def project_coordinate_to_absolute_scale_with_metadata(code: str, screen_width: int, screen_height: int) -> tuple[str, list[dict[str, Any]]]:
    def coordinate_projection(x: float, y: float) -> tuple[int, int]:
        if coordinates_are_relative_0_1(x, y):
            return int(round(x * screen_width)), int(round(y * screen_height))
        return int(round(x)), int(round(y))

    pattern = r"(pyautogui\.\w+\([^\)]*\))"
    updated_code = code
    coordinate_conversions: list[dict[str, Any]] = []
    for full_call in re.findall(pattern, code):
        func_match = re.match(r"(pyautogui\.\w+)\((.*)\)", full_call, re.DOTALL)
        if not func_match:
            continue
        func_name = func_match.group(1)
        args_str = normalize_mixed_coordinate_arguments(func_match.group(2))
        try:
            parsed = ast.parse("func(%s)" % args_str).body[0].value
        except SyntaxError:
            continue
        function_parameters = {
            "click": ["x", "y", "clicks", "interval", "button", "duration", "pause"],
            "rightClick": ["x", "y", "duration", "tween", "pause"],
            "middleClick": ["x", "y", "duration", "tween", "pause"],
            "doubleClick": ["x", "y", "interval", "button", "duration", "pause"],
            "tripleClick": ["x", "y", "interval", "button", "duration", "pause"],
            "moveTo": ["x", "y", "duration", "tween", "pause"],
            "dragTo": ["x", "y", "duration", "button", "mouseDownUp", "pause"],
        }
        param_names = function_parameters.get(func_name.split(".")[-1], [])
        args: dict[str, Any] = {}
        for index, arg in enumerate(getattr(parsed, "args", [])):
            if index < len(param_names):
                try:
                    args[param_names[index]] = ast.literal_eval(arg)
                except Exception:
                    pass
        try:
            for keyword in getattr(parsed, "keywords", []):
                args[keyword.arg] = ast.literal_eval(keyword.value)
        except Exception:
            continue
        if "x" not in args or "y" not in args:
            continue
        try:
            original_x = float(args["x"])
            original_y = float(args["y"])
            projected_x, projected_y = coordinate_projection(original_x, original_y)
            is_relative = coordinates_are_relative_0_1(original_x, original_y)
            coordinate_conversions.append(
                {
                    "source": "kimi",
                    "function": func_name,
                    "source_coordinate_space": "relative_0_1" if is_relative else "absolute_pixel",
                    "raw_point": [original_x, original_y],
                    "screen_size": [int(screen_width), int(screen_height)],
                    "conversion_formula": (
                        "actual_x = round(raw_x * screen_width), actual_y = round(raw_y * screen_height)"
                        if is_relative
                        else "actual_x = round(raw_x), actual_y = round(raw_y)"
                    ),
                    "actual_point": [projected_x, projected_y],
                    "converted_point": [projected_x, projected_y],
                }
            )
            args["x"], args["y"] = projected_x, projected_y
        except (TypeError, ValueError):
            continue
        reconstructed: list[str] = []
        for param_name in param_names:
            if param_name in args:
                reconstructed.append(argument_repr(args[param_name]))
            else:
                break
        used_params = set(param_names[: len(reconstructed)])
        for keyword in getattr(parsed, "keywords", []):
            if keyword.arg not in used_params:
                reconstructed.append("%s=%s" % (keyword.arg, argument_repr(args[keyword.arg])))
        updated_code = updated_code.replace(full_call, "%s(%s)" % (func_name, ", ".join(reconstructed)))
    return updated_code, coordinate_conversions


def normalize_mixed_coordinate_arguments(args_str: str) -> str:
    """Repair common model output like ``x=0.2,0.3`` before AST parsing."""
    match = re.match(
        r"^(\s*x\s*=\s*[-+]?\d+(?:\.\d+)?\s*,\s*)([-+]?\d+(?:\.\d+)?)(\s*(?:,.*)?\s*)$",
        args_str,
        re.DOTALL,
    )
    if match and not re.search(r"\by\s*=", match.group(3)):
        return "%sy=%s%s" % (match.group(1), match.group(2), match.group(3))
    return args_str


def normalize_pyautogui_typewrite_quotes(command: str) -> str:
    pattern = r'pyautogui\.(?:typewrite|write)\(\s*"""(.*?)"""\s*(,\s*interval\s*=\s*[^)]+)?\)'

    def replacer(match: re.Match[str]) -> str:
        content = match.group(1)
        interval = match.group(2) or ""
        return "pyautogui.typewrite(%s%s)" % (repr(content), interval)

    return re.sub(pattern, replacer, command, flags=re.DOTALL)


def fix_pyautogui_less_than_bug(command: str) -> str:
    command = normalize_pyautogui_typewrite_quotes(command)
    press_pattern = r"pyautogui\.press\([\"'](?:<|\\u003c)[\"']\)"
    command = re.sub(press_pattern, 'pyautogui.hotkey("shift", ",")', command)
    command = re.sub(r"\bpyautogui\.sleep\(", "time.sleep(", command)
    command = rewrite_text_entry_calls(command)
    typewrite_pattern = r"pyautogui\.(?:typewrite|write)\(([\"'])(.*?)\1\)"

    def replace_typewrite(match: re.Match[str]) -> str:
        quote = match.group(1)
        content = match.group(2)
        try:
            content = content.encode("utf-8").decode("unicode_escape")
        except UnicodeDecodeError:
            pass
        if "<" not in content:
            return match.group(0)
        parts = content.split("<")
        result: list[str] = []
        for index, part in enumerate(parts):
            if index == 0:
                if part:
                    result.append("pyautogui.typewrite(%s%s%s)" % (quote, part, quote))
            else:
                result.append('pyautogui.hotkey("shift", ",")')
                if part:
                    result.append("pyautogui.typewrite(%s%s%s)" % (quote, part, quote))
        return "; ".join(result)

    return re.sub(typewrite_pattern, replace_typewrite, command)


def rewrite_text_entry_calls(command: str) -> str:
    pattern = r"(pyautogui\.(?:typewrite|write)\([^\)]*\))"
    updated = command
    for full_call in re.findall(pattern, command):
        func_match = re.match(r"pyautogui\.(?:typewrite|write)\((.*)\)", full_call, re.DOTALL)
        if not func_match:
            continue
        try:
            parsed = ast.parse("func(%s)" % func_match.group(1)).body[0].value
        except SyntaxError:
            continue
        args = getattr(parsed, "args", [])
        if not args:
            continue
        try:
            text = ast.literal_eval(args[0])
        except Exception:
            continue
        if not isinstance(text, str) or text.isascii():
            continue
        updated = updated.replace(full_call, build_inline_clipboard_paste_code(text))
    return updated


def response_to_prediction_text(response: Any) -> str:
    if isinstance(response, dict):
        content = response_content_text(response)
        reasoning = response.get("reasoning_content")
        if isinstance(reasoning, str) and reasoning.strip():
            return ("%s\n%s" % (reasoning.strip(), content)).strip()
        return content
    return str(response)


def response_content_text(response: Any) -> str:
    raw = response.get("content") if isinstance(response, dict) else response
    if isinstance(raw, str):
        return raw
    if isinstance(raw, list):
        parts = []
        for item in raw:
            if isinstance(item, dict):
                parts.append(str(item.get("text") or ""))
            else:
                parts.append(str(item))
        return "\n".join(part for part in parts if part)
    if raw is None:
        return ""
    return str(raw)


def detect_response_structure_violation(response_text: str) -> str | None:
    if not response_text:
        return None
    text_for_check = FENCED_CODE_RE.sub("", response_text)
    if STEP_HEADER_RE.search(text_for_check):
        return "forbidden '# Step <n>' block detected"
    action_count = len(ACTION_HEADER_RE.findall(text_for_check))
    if action_count > 1:
        return "multiple ## Action headers detected: %s" % action_count
    code_count = len(CODE_HEADER_RE.findall(text_for_check))
    if code_count > 1:
        return "multiple ## Code headers detected: %s" % code_count
    return None


def format_repair_message(reason: str, bad_response_text: str) -> str:
    preview = (bad_response_text or "").strip()
    if len(preview) > 2000:
        preview = preview[:2000] + "\n...(truncated)"
    return (
        "FORMAT ERROR. Rewrite your previous reply for THIS TURN ONLY.\n"
        "Reason: %s\n\n"
        "Hard constraints (must all be satisfied):\n"
        "1) Do NOT output any '# Step' header.\n"
        "2) Include exactly one '## Action:' header.\n"
        "3) Include exactly one '## Code:' header.\n"
        "4) Return exactly one code fence under ## Code.\n"
        "5) Keep a single-turn response only; no future-step plan.\n\n"
        "Your previous invalid response was:\n%s"
    ) % (reason, preview)


def kimi_api_key() -> str:
    key = (
        os.getenv("RUNNER_API_KEY")
        or os.getenv("MOONSHOT_API_KEY")
        or os.getenv("KIMI_API_KEY")
        or os.getenv("KIMI_NATIVE_API_KEY")
        or ""
    ).strip()
    if not key:
        raise RuntimeError("Set RUNNER_API_KEY, MOONSHOT_API_KEY, KIMI_API_KEY, or KIMI_NATIVE_API_KEY")
    return key


def moonshot_base_url() -> str:
    raw = (
        os.getenv("RUNNER_BASE_URL")
        or os.getenv("MOONSHOT_BASE_URL")
        or os.getenv("KIMI_MOONSHOT_BASE_URL")
        or "https://api.moonshot.cn/v1"
    ).strip().rstrip("/")
    return raw if raw.endswith("/v1") else "%s/v1" % raw


def kimi_http_proxy() -> str:
    use_proxy = (os.getenv("KIMI_NATIVE_USE_PROXY") or "0").strip().lower() not in ("0", "false", "no", "")
    proxy_url = (os.getenv("KIMI_NATIVE_PROXY_URL") or os.getenv("OPENAI_PROXY") or "").strip()
    return proxy_url if use_proxy else ""


def infer_kimi_platform(context: SampleContext) -> str:
    explicit = os.getenv("KIMI_NATIVE_PLATFORM")
    if explicit:
        return explicit.strip().lower()
    task_fields = getattr(getattr(context, "task", None), "fields", {}) or {}
    for key in ("系统类型", "system_type", "platform", "computer_platform", "os", "os_type", "system"):
        value = str(task_fields.get(key) or "").strip().lower()
        if value:
            return "windows" if value.startswith("win") else "ubuntu"
    metadata = context.metadata or {}
    for key in ("platform", "computer_platform", "os", "os_type", "system"):
        value = str(metadata.get(key) or "").strip().lower()
        if value:
            return "windows" if value.startswith("win") else "ubuntu"
    env_metadata = metadata.get("env_metadata")
    if isinstance(env_metadata, dict):
        for key in ("platform", "computer_platform", "os", "os_type", "system"):
            value = str(env_metadata.get(key) or "").strip().lower()
            if value:
                return "windows" if value.startswith("win") else "ubuntu"
    return "ubuntu"


def message_to_dict(message: Any) -> dict[str, Any]:
    if hasattr(message, "model_dump"):
        return message.model_dump()
    if hasattr(message, "dict"):
        return message.dict()
    result = {"role": getattr(message, "role", None), "content": getattr(message, "content", None)}
    reasoning = getattr(message, "reasoning_content", None)
    if reasoning is not None:
        result["reasoning_content"] = reasoning
    return result


def message_text_bodies(message: dict[str, Any]) -> tuple[str, str]:
    content = response_content_text(message).strip()
    reasoning = message.get("reasoning_content")
    return content, reasoning.strip() if isinstance(reasoning, str) else ""


def normalize_finish_reason(choice: Any) -> str | None:
    finish_reason = getattr(choice, "finish_reason", None)
    if finish_reason is None:
        return None
    if hasattr(finish_reason, "value"):
        return str(finish_reason.value)
    return str(finish_reason)


def encode_image(image_content: bytes) -> str:
    return base64.b64encode(image_content).decode("utf-8")


def read_binary(path: str) -> bytes:
    with open(path, "rb") as file_obj:
        return file_obj.read()


def image_size_path(path: str) -> tuple[int, int] | None:
    from pathlib import Path

    return image_size(Path(path))


def scale_scroll_for_windows(code: str, platform: str, factor: int = 50) -> str:
    if platform.lower() != "windows":
        return code
    pattern = re.compile(r"(pyautogui\.scroll\()\s*([-+]?\d+)\s*\)")
    return pattern.sub(lambda match: "%s%s)" % (match.group(1), int(match.group(2)) * factor), code)


def argument_repr(value: Any) -> str:
    if isinstance(value, str):
        return repr(value)
    return str(value)
