from __future__ import annotations

import re
from typing import Any


def parse_thought(response: str) -> str:
    match = re.search(r"<think>(.*?)</think>", response, flags=re.DOTALL)
    if not match:
        return ""
    return match.group(1).strip()


def parse_tool_call(response: str) -> dict[str, Any] | None:
    function_call = parse_function_tool_call(response)
    if function_call:
        return function_call
    return parse_tool_code_call(response)


def parse_function_tool_call(response: str) -> dict[str, Any] | None:
    function_match = re.search(
        r"<function=([A-Za-z_][A-Za-z0-9_]*)>(.*?)</function>",
        response,
        flags=re.DOTALL,
    )
    if not function_match:
        return None

    name = function_match.group(1)
    body = function_match.group(2)
    parameters = {}
    for parameter_match in re.finditer(
        r"<parameter=([A-Za-z_][A-Za-z0-9_]*)>(.*?)</parameter>",
        body,
        flags=re.DOTALL,
    ):
        parameter_name = parameter_match.group(1)
        parameters[parameter_name] = normalize_tool_code_parameter(parameter_name, parameter_match.group(2).strip())
    if not parameters:
        for parameter_match in re.finditer(
            r"<([A-Za-z_][A-Za-z0-9_]*)>(.*?)</\1>",
            body,
            flags=re.DOTALL,
        ):
            parameter_name = parameter_match.group(1)
            parameters[parameter_name] = normalize_tool_code_parameter(parameter_name, parameter_match.group(2).strip())
    return {"name": name, "parameters": parameters}


def parse_tool_code_call(response: str) -> dict[str, Any] | None:
    tool_code_match = re.search(r"<tool_code>(.*?)</tool_code>", response, flags=re.DOTALL)
    if not tool_code_match:
        return None

    body = tool_code_match.group(1).strip()
    action_match = re.search(r"<([A-Za-z_][A-Za-z0-9_]*)>(.*?)</\1>", body, flags=re.DOTALL)
    if not action_match:
        return None

    name = action_match.group(1)
    action_body = action_match.group(2)
    parameters = {}
    for parameter_match in re.finditer(
        r"<([A-Za-z_][A-Za-z0-9_]*)>(.*?)</\1>",
        action_body,
        flags=re.DOTALL,
    ):
        parameters[parameter_match.group(1)] = normalize_tool_code_parameter(parameter_match.group(1), parameter_match.group(2).strip())
    return {"name": name, "parameters": parameters}


def normalize_tool_code_parameter(name: str, value: str) -> str:
    if name.endswith("point") or name == "point":
        if value.startswith("<point>"):
            return value
        return "<point>%s</point>" % value
    return value
