from __future__ import annotations

import json
import os
import signal
import sqlite3
import sys
import types
import warnings
from pathlib import Path

if __package__ in (None, ""):
    # 仓库目录名是 open_workflowgym_redis，但代码以 open_workflowgym 包名相对导入。
    # 用内存注册包路径，避免 /tmp symlink，也避免 ProcessPool spawn 多进程抢链。
    _repo_root = Path(__file__).resolve().parent
    _pkg_name = "open_workflowgym"
    _existing = sys.modules.get(_pkg_name)
    _existing_paths = list(getattr(_existing, "__path__", []) or []) if _existing is not None else []
    _already_this_repo = any(Path(p).resolve() == _repo_root for p in _existing_paths)
    if not _already_this_repo:
        _pkg = types.ModuleType(_pkg_name)
        _pkg.__file__ = str(_repo_root / "__init__.py")
        _pkg.__package__ = _pkg_name
        _pkg.__path__ = [str(_repo_root)]  # type: ignore[attr-defined]
        sys.modules[_pkg_name] = _pkg
    __package__ = _pkg_name

# urllib3 v2 在 macOS 系统 Python 的 LibreSSL 环境下会输出兼容性 warning；
# 这里仅屏蔽这条已知噪声，保留其他 warning 正常展示。
warnings.filterwarnings("ignore", message=r"urllib3 v2 only supports OpenSSL.*")

from .agents.factory import AgentFactory
from .attachment_uploader import AttachmentUploader
from .cancellation import clear_cancel, request_cancel
from .config import build_run_config, parse_args
from .envs.instance_pool import InstancePool
from .envs.instance_validation import (
    env_exception_log_path,
    summarize_validated_pool,
    validate_discovered_instances,
)
from .envs.volcengine_env import VolcengineEnv, instance_platform_from_name
from .envs.gateway_volcengine_env import GatewayVolcengineEnv
from .executors.local import LocalExecutorBackend, ProcessPoolExecutorBackend
from .feishu_client import FeishuClient
from .local_spreadsheet import (
    LocalSpreadsheetClient,
    MirroringSpreadsheetClient,
    feishu_credentials_configured,
    local_spreadsheet_reason,
    resolve_report_csv_dir,
    resolve_source_csv_path,
    resolve_local_samples_csv_path,
    should_load_tasks_from_feishu,
    should_use_local_spreadsheet,
)
from .platform_utils import build_image_platform_map, resolve_task_platform
from .records import TaskRecord, now_text
from .resource_watchdog import ResourceWatchdog
from .sampler import Sampler
from .scheduler import Scheduler, demo_task
from .scorer import Scorer
from .source_reader import SourceReader, normalize_task_id_value, read_tasks_from_csv
from .state_store import StateStore
from .task_files import is_windows_path
from .writer_process import WriterProcess


SHUTDOWN_REQUESTED = False
SHUTDOWN_SIGNAL_COUNT = 0
CANCEL_OUTPUT_ROOT = ""


def request_shutdown(signum, frame):
    global SHUTDOWN_REQUESTED, SHUTDOWN_SIGNAL_COUNT
    SHUTDOWN_SIGNAL_COUNT += 1
    if CANCEL_OUTPUT_ROOT:
        request_cancel(CANCEL_OUTPUT_ROOT, "signal=%s" % signum)
    if SHUTDOWN_SIGNAL_COUNT >= 2:
        raise KeyboardInterrupt("再次收到退出信号，强制中断")
    SHUTDOWN_REQUESTED = True
    print("[%s] 收到退出信号: %s，准备有序退出" % (now_text(), signum))


def shutdown_requested() -> bool:
    return SHUTDOWN_REQUESTED


def install_signal_handlers() -> None:
    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, request_shutdown)
    if hasattr(signal, "SIGHUP"):
        signal.signal(signal.SIGHUP, request_shutdown)


def main(argv: list[str] | None = None) -> int:
    global CANCEL_OUTPUT_ROOT
    install_signal_handlers()
    args = parse_args(argv)
    config = build_run_config(args)
    Path(config.output_root).mkdir(parents=True, exist_ok=True)
    CANCEL_OUTPUT_ROOT = config.output_root
    clear_cancel(config.output_root)

    store = StateStore(config.state_db_path)
    store.create_run(config.run_id, config)

    agent_factory = AgentFactory()
    cloud_dry_run = "" if config.enable_real_cloud else (config.dry_run or "local")
    lease_backend_kind = str(getattr(config, "lease_backend", "local") or "local").strip().lower()
    if lease_backend_kind in ("redis", "wgm", "remote"):
        env = GatewayVolcengineEnv(
            dry_run=cloud_dry_run,
            region=config.region,
            wgm_api_base=getattr(config, "wgm_api_base", "") or None,
            wgm_token=getattr(config, "wgm_token", "") or None,
            ttl_seconds=max(60, int(config.lease_ttl_seconds or 1800)),
        )
    else:
        env = VolcengineEnv(dry_run=cloud_dry_run, region=config.region)
    instance_ids = list(config.instance_ids)
    platform_by_instance: dict[str, str] = {}
    target_ids = target_ids_from_text(config.target_id)
    discovered_instances: list[dict] = []
    if lease_backend_kind in ("redis", "wgm", "remote"):
        # 实例发现/换盘/RunCommand 由 WGM 胖网关负责，跳过本机 ECS discover。
        from .envs.gateway_volcengine_env import screenshot_delivery

        print(
            "[%s] 跳过本机 ECS discover（lease_backend=%s） screenshot=%s"
            % (now_text(), lease_backend_kind, screenshot_delivery())
        )
    elif config.enable_real_cloud:
        invalid_instance_ids = [item for item in instance_ids if "debug" in item or "dryrun" in item]
        if invalid_instance_ids:
            print("[%s] 忽略真实云模式下的调试实例 ID: %s" % (now_text(), ",".join(invalid_instance_ids)))
            instance_ids = [item for item in instance_ids if item not in invalid_instance_ids]
        if instance_ids:
            discovered_instances = [env.describe_instance(instance_id) for instance_id in instance_ids]
        else:
            feishu_for_discover = build_spreadsheet_client(config)
            preview_tasks = load_tasks_for_run(config, target_ids, feishu_for_discover)
            print("[%s] 发现实例后将先启动 STOPPED 实例，再按 InstanceName + RunCommand 并行校验环境并写入 env_exception.log" % now_text(), flush=True)
            discovered_instances = env.discover_reusable_instances(
                name_prefix=config.discover_instance_name_prefix,
                project_name=config.discover_project_name,
                limit=config.discover_instance_limit,
            )
            print(
                "[%s] 候选实例: region=%s prefix=%s project=%s count=%s"
                % (
                    now_text(),
                    config.region,
                    config.discover_instance_name_prefix or "<不限>",
                    config.discover_project_name or "<不限>",
                    len(discovered_instances),
                )
            )
        env_log_path = env_exception_log_path(config.output_root)
        instance_ids, platform_by_instance = validate_discovered_instances(
            env,
            discovered_instances,
            env_log_path,
            max_workers=config.discover_probe_max_workers,
        )
        pool_summary = summarize_validated_pool(platform_by_instance)
        print(
            "[%s] 环境池校验完成: ubuntu=%s windows=%s validated=%s probe_workers=%s log=%s"
            % (
                now_text(),
                pool_summary["ubuntu"],
                pool_summary["windows"],
                len(instance_ids),
                min(config.discover_probe_max_workers, max(1, len(discovered_instances))),
                env_log_path,
            ),
            flush=True,
        )
        for item in discovered_instances:
            instance_id = str(item.get("InstanceId") or item.get("instance_id") or "")
            if instance_id not in platform_by_instance:
                continue
            try:
                instance_platform_label = instance_platform_from_name(item)
            except ValueError:
                instance_platform_label = platform_by_instance.get(instance_id, "<unknown>")
            print(
                "  - %s name=%s status=%s image=%s instance_platform=%s zone=%s validated=1"
                % (
                    instance_id,
                    item.get("InstanceName") or item.get("instance_name") or "",
                    item.get("Status") or item.get("status") or "",
                    item.get("ImageId") or item.get("image_id") or "",
                    instance_platform_label,
                    item.get("ZoneId") or item.get("zone_id") or "",
                )
            )
        if not instance_ids:
            raise ValueError(
                "真实云模式在 %s 没有通过校验的 ECS 实例。失败详情见 %s；请修复实例命名/云助手后重试。"
                % (config.region, env_log_path)
            )

    sampler = Sampler(agent_factory, env, shutdown_requested=shutdown_requested)
    if int(config.max_workers) > 1:
        executor = ProcessPoolExecutorBackend(config.max_workers)
        print("[%s] 采样进程池已启用: max_workers=%s" % (now_text(), config.max_workers))
    else:
        executor = LocalExecutorBackend(sampler.run_sample)
    lease_backend_kind = str(getattr(config, "lease_backend", "local") or "local").strip().lower()
    if lease_backend_kind in ("redis", "wgm", "remote"):
        # online 模式：实例来自 WGM 共享池，可不依赖本机 discover 列表。
        instance_ids = list(instance_ids or [])
        if not getattr(config, "wgm_token", "") and not os.getenv("WGM_TOKEN"):
            raise ValueError("lease_backend=redis 需要设置 WGM_TOKEN / --wgm-token（或改用 --mode redis 并配置 .env）")
        from .envs.gateway_volcengine_env import screenshot_delivery

        print(
            "[%s] online 模式: api_base=%s ttl=%ss pool_ids=%s action=wgm-direct screenshot=%s"
            % (
                now_text(),
                getattr(config, "wgm_api_base", "") or os.getenv("WGM_HOST") or "<default>",
                config.lease_ttl_seconds,
                len(instance_ids),
                screenshot_delivery(),
            )
        )
    else:
        instance_ids = instance_ids or ["dry-run-instance-1"]
        if not platform_by_instance and not config.enable_real_cloud:
            platform_by_instance = {"dry-run-instance-1": "ubuntu"}
    instance_pool = InstancePool(
        instance_ids,
        store,
        platform_by_instance,
        config.lease_ttl_seconds,
        lease_backend_kind=lease_backend_kind,
        wgm_api_base=getattr(config, "wgm_api_base", "") or None,
        wgm_token=getattr(config, "wgm_token", "") or None,
    )
    if hasattr(instance_pool.lease_backend, "set_abort_checker"):
        instance_pool.lease_backend.set_abort_checker(shutdown_requested)
    if config.recover_instances:
        recovery = instance_pool.recover(
            force_reset=config.force_reset_instances,
            auto_reset_unknown=config.auto_reset_unknown_instances,
        )
        print("[%s] 实例池恢复完成: idle=%s quarantined=%s" % (
            now_text(),
            recovery.idle,
            recovery.quarantined,
        ))

    spreadsheet_client = build_spreadsheet_client(config)
    writer = WriterProcess(spreadsheet_client, AttachmentUploader(spreadsheet_client), agent_factory)
    report_url = writer.report.get("spreadsheet_url", "")
    local_samples_csv = resolve_local_samples_csv_path(config.report_csv_dir, config.output_root)
    if should_use_local_spreadsheet(config.enable_real_feishu):
        reason = local_spreadsheet_reason(config.enable_real_feishu)
        print(
            "[%s] 使用本地 CSV 报表: dir=%s samples=%s%s"
            % (
                now_text(),
                resolve_report_csv_dir(config.report_csv_dir, config.output_root),
                local_samples_csv,
                ("（%s）" % reason) if reason else "",
            )
        )
    elif config.enable_real_feishu:
        print("[%s] 飞书报表已创建: %s" % (now_text(), report_url))
        print("[%s] 本地 CSV 报表同步写入: %s" % (now_text(), local_samples_csv))
    else:
        print("[%s] 飞书报表为 dry-run，未创建线上电子表格。需要线上表请加 --enable-real-feishu" % now_text())
        print("[%s] 本地 CSV 报表: %s" % (now_text(), local_samples_csv))
    writer.write_agent_config()

    target_ids = target_ids_from_text(config.target_id)
    tasks, missing_ids = filter_tasks_by_target_ids(load_tasks_for_run(config, target_ids, spreadsheet_client), target_ids)
    if missing_ids:
        print("[%s] 未找到指定任务 id: %s" % (now_text(), " ".join(missing_ids)))
        return 1
    for task in tasks:
        if not task.image_id and config.demo_image_id and config.demo_image_id != "image-demo":
            task.fields["image_id"] = config.demo_image_id
            print("[%s] 任务 %s 使用默认镜像 ID: %s" % (now_text(), task.task_id, config.demo_image_id))
    image_platforms = build_image_platform_map(env, tasks)
    print_task_platform_demand(tasks, image_platforms, instance_pool.platform_summary())

    scheduler = Scheduler(
        config=config,
        store=store,
        instance_pool=instance_pool,
        executor=executor,
        writer=writer,
        scorer=Scorer(),
        agent_factory=agent_factory,
        shutdown_requested=shutdown_requested,
        image_platforms=image_platforms,
    )
    watchdog = ResourceWatchdog(config)
    decision = watchdog.decide()
    if not decision.can_dispatch:
        print("[%s] 资源水位阻止派发任务: %s" % (now_text(), decision.reason))
        return 2 if decision.should_shutdown else 0

    try:
        if getattr(executor, "supports_async", False):
            print("[%s] 进入跨任务并发采样: task_count=%s max_workers=%s" % (now_text(), len(tasks), config.max_workers))
            scheduler.process_tasks(tasks)
        else:
            for task in tasks:
                if SHUTDOWN_REQUESTED:
                    break
                print("[%s] 开始处理任务: %s run_id=%s" % (now_text(), task.task_id, config.run_id))
                scheduler.process_task(task)
        if SHUTDOWN_REQUESTED:
            print("[%s] 已完成信号后的安全收尾" % now_text())
        print("[%s] 运行结束，状态库: %s" % (now_text(), config.state_db_path))
        return 0
    except KeyboardInterrupt:
        print("[%s] KeyboardInterrupt，释放本进程租约后退出" % now_text())
        return 130
    finally:
        try:
            if SHUTDOWN_REQUESTED or SHUTDOWN_SIGNAL_COUNT > 0:
                print("[%s] 释放本进程持有的网关租约（不影响同用户其他终端）..." % now_text())
                result = instance_pool.release_all(reason="shutdown")
                print(
                    "[%s] 本进程租约释放完成: released=%s scope=%s errors=%s"
                    % (
                        now_text(),
                        (result or {}).get("released_count"),
                        (result or {}).get("scope") or "process_held",
                        len((result or {}).get("errors") or []),
                    )
                )
        except Exception as release_exc:
            print("[%s] 本进程租约释放失败: %s" % (now_text(), release_exc))
        executor.shutdown(cancel_futures=SHUTDOWN_REQUESTED)


def target_ids_from_text(value: str) -> tuple[str, ...]:
    target_ids = []
    seen = set()
    for item in str(value or "").split():
        target_id = normalize_task_id_value(item)
        if target_id and target_id not in seen:
            target_ids.append(target_id)
            seen.add(target_id)
    return tuple(target_ids)


def infer_tasks_platform(tasks: list[TaskRecord]) -> str:
    platforms: set[str] = set()
    for task in tasks:
        for key in ("系统类型", "platform", "computer_platform", "os", "os_type", "system"):
            value = str(task.fields.get(key) or "").strip().lower()
            if value:
                platforms.add("windows" if value.startswith("win") or "windows" in value else "ubuntu")
                break
        else:
            if is_windows_path(task.input_path) or is_windows_path(task.output_path):
                platforms.add("windows")
    if platforms == {"windows"}:
        return "windows"
    if platforms == {"ubuntu"}:
        return "ubuntu"
    return ""


def infer_tasks_target_image_id(tasks: list[TaskRecord]) -> str:
    image_ids: list[str] = []
    seen: set[str] = set()
    for task in tasks:
        image_id = str(task.image_id or "").strip()
        if image_id and image_id not in seen:
            image_ids.append(image_id)
            seen.add(image_id)
    if len(image_ids) == 1:
        return image_ids[0]
    return ""


def build_spreadsheet_client(config):
    local_client = LocalSpreadsheetClient(resolve_report_csv_dir(config.report_csv_dir, config.output_root))
    if should_use_local_spreadsheet(config.enable_real_feishu):
        return local_client
    primary = FeishuClient(dry_run=False)
    return MirroringSpreadsheetClient(primary, local_client)


def build_feishu_source_client() -> FeishuClient:
    if not feishu_credentials_configured():
        raise ValueError(
            "已配置 SOURCE_FEISHU_URL / --source-feishu-url，但未设置 APP_ID / APP_SECRET，无法从飞书读取任务。"
            "请补齐飞书凭证，或清空 SOURCE_FEISHU_URL 改用本地 CSV。"
        )
    return FeishuClient(dry_run=False)


def load_tasks_for_run(config, target_ids: tuple[str, ...], spreadsheet_client) -> list[TaskRecord]:
    tasks: list[TaskRecord] = []
    if config.task_replay_db:
        if not target_ids:
            raise ValueError("--task-replay-db 需要同时指定 --id")
        tasks = load_tasks_from_replay_db(config.task_replay_db, config.run_id, target_ids)
        print(
            "[%s] 从本地状态库回放任务: db=%s task_ids=%s"
            % (now_text(), config.task_replay_db, " ".join(task.task_id for task in tasks))
        )
    elif should_load_tasks_from_feishu(config.source_feishu_url):
        read_limit = config.prefetch_rows
        if target_ids:
            read_limit = max(read_limit, int(os.getenv("WORKFLOWGYM_TARGET_ID_PREFETCH_ROWS", "5000")))
        source_client = build_feishu_source_client()
        tasks = SourceReader(source_client, config.run_id).read_tasks(
            config.source_feishu_url,
            config.source_range,
            config.start_row,
            read_limit,
        )
        print(
            "[%s] 从飞书加载任务: url=%s count=%s"
            % (now_text(), config.source_feishu_url, len(tasks))
        )
    else:
        csv_path = resolve_source_csv_path(config.source_csv_path)
        read_limit = config.prefetch_rows
        if target_ids:
            read_limit = max(read_limit, int(os.getenv("WORKFLOWGYM_TARGET_ID_PREFETCH_ROWS", "5000")))
        if not Path(csv_path).is_file():
            if target_ids:
                raise ValueError("本地任务 CSV 不存在: %s" % csv_path)
            print("[%s] 本地任务 CSV 不存在，跳过加载: %s" % (now_text(), csv_path))
        else:
            tasks = read_tasks_from_csv(csv_path, config.run_id, config.start_row, read_limit)
            print("[%s] 从本地 CSV 加载任务: path=%s count=%s" % (now_text(), csv_path, len(tasks)))
    if target_ids:
        target_id_set = set(target_ids)
        tasks = [task for task in tasks if normalize_task_id_value(task.task_id) in target_id_set]
    if not tasks:
        tasks = [demo_task(config)]
    return tasks


def filter_tasks_by_target_ids(tasks: list[TaskRecord], target_ids: tuple[str, ...]) -> tuple[list[TaskRecord], list[str]]:
    if not target_ids:
        return tasks, []
    target_id_set = set(target_ids)
    filtered = [task for task in tasks if normalize_task_id_value(task.task_id) in target_id_set]
    found_ids = {normalize_task_id_value(task.task_id) for task in filtered}
    missing_ids = [target_id for target_id in target_ids if target_id not in found_ids]
    return filtered, missing_ids


def print_task_platform_demand(
    tasks: list[TaskRecord],
    image_platforms: dict[str, str],
    pool_summary: dict[str, int],
) -> None:
    demand = {"windows": 0, "ubuntu": 0, "unknown": 0}
    for task in tasks:
        platform = resolve_task_platform(task, image_platforms) or "unknown"
        if platform in demand:
            demand[platform] += 1
        else:
            demand["unknown"] += 1
    print(
        "[%s] 任务平台需求: ubuntu=%s windows=%s unknown=%s | 环境池: ubuntu=%s windows=%s"
        % (
            now_text(),
            demand["ubuntu"],
            demand["windows"],
            demand["unknown"],
            pool_summary.get("ubuntu", 0),
            pool_summary.get("windows", 0),
        ),
        flush=True,
    )


def load_tasks_from_replay_db(db_path: str, run_id: str, target_ids: tuple[str, ...]) -> list[TaskRecord]:
    if not target_ids:
        raise ValueError("--task-replay-db 需要同时指定 --id")
    path = Path(db_path)
    if not path.exists():
        raise ValueError("task replay db 不存在: %s" % db_path)
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    try:
        rows = []
        for target_id in target_ids:
            row = conn.execute(
                """
                SELECT task_id, row_number, fields_json
                FROM tasks
                WHERE task_id=?
                ORDER BY updated_at DESC
                LIMIT 1
                """,
                (str(target_id),),
            ).fetchone()
            if row is None:
                raise ValueError("task replay db 中未找到任务: %s" % target_id)
            rows.append(row)
    finally:
        conn.close()
    return [
        TaskRecord(
            run_id=run_id,
            task_id=str(row["task_id"]),
            row_number=int(row["row_number"]),
            fields=json.loads(row["fields_json"]),
        )
        for row in rows
    ]


if __name__ == "__main__":
    raise SystemExit(main())
