# 贡献指南

感谢你对 Open WorkflowGym 的关注！我们欢迎各种形式的贡献。

## 开发环境

```bash
cd open_workflowgym   # 项目根目录（含 main.py）
python3.11 -m venv .venv && source .venv/bin/activate   # Python >= 3.10
pip install -r requirements.txt
cp .env.local.example .env   # 或 cp .env.redis.example .env
set -a && source .env && set +a
```

本地验证（离线 / 飞书表格）见 **[docs/local_testing.md](docs/local_testing.md)**。

## 如何贡献

1. **Fork** 本仓库并在新分支上开发
2. 保持改动范围聚焦，遵循现有代码风格
3. 为新功能或 bug 修复添加/更新测试
4. 按 [docs/local_testing.md](docs/local_testing.md) 至少跑通离线环境测试；若改动飞书读写，再跑线上飞书表格测试
5. 提交 Pull Request，说明改动动机与验证方式

## 开发约定

- Python >= 3.10，使用 type hints 与 `from __future__ import annotations`
- 云相关逻辑集中在 `envs/`，Agent 逻辑集中在 `agents/`，判分逻辑集中在 `judgers/`
- 新增 Agent：在 `agents/factory.py` 注册，并实现 `BaseAgentAdapter` 接口
- 新增判分策略：在 `judgers/agent.py` 的 `JudgerAgent.judge()` 中扩展分支
- 不要提交 `.env`、API Key、`output/` 运行产物

## Issue 报告

提交 Issue 时请包含：

- 操作系统与 Python 版本
- 完整命令行（脱敏 API Key）
- 相关日志或 `output/` 下片段
- 预期行为 vs 实际行为

## 许可证

贡献代码将按 [Apache License 2.0](LICENSE) 授权。
