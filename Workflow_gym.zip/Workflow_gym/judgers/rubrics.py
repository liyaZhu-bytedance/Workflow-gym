from __future__ import annotations

import json
import os
from typing import Any

from ..records import TrajectoryResult
from .common import (
    ERROR_SCORE,
    extract_json_object,
    field_text,
    image_content_items,
    load_traj,
    valid_screenshots,
    vm_output_listing,
)
from .file_product import archive_file_products_for_judge, product_text_from_production_snapshots
from .factory import JudgeModelFactory
from .prompts import (
    RUBRICS_SINGLE_HARD_SYSTEM_PROMPT,
    RUBRICS_SINGLE_ITEM_USER_TEMPLATE,
    RUBRICS_SINGLE_SOFT_SYSTEM_PROMPT,
)


class RubricsJudgerMixin:
    def judge_rubrics(self, trajectory: TrajectoryResult, answer_type: str, metric_type: str) -> dict[str, Any]:
        traj = load_traj(trajectory.traj_json_path)
        screenshots = valid_screenshots(traj)[-6:]
        screenshot_payload = {
            "last_screenshots": [os.path.abspath(path) for path in screenshots],
            "screenshot_filenames": [os.path.basename(path) for path in screenshots],
        }
        production_snapshots = archive_file_products_for_judge(trajectory)
        product_payload = {
            "production_snapshots": production_snapshots,
            "vm_output_listing": vm_output_listing(trajectory),
        }
        loaded, err = load_rubrics_structure(field_text(trajectory.task_fields, "rubrics"))
        if err or loaded is None:
            base = err or "rubrics 解析失败"
            evidence = base if "字段为空" in base else f"{base}；rubrics JSON 无法解析"
            return {**rubric_discard(evidence, error=err or "rubrics 解析失败"), **screenshot_payload, **product_payload}
        hard_list, soft_list = loaded
        if not screenshots:
            return {
                **rubric_discard("无有效截图路径；无有效截图 / 读图失败", error="no valid screenshots"),
                **screenshot_payload,
                **product_payload,
            }
        image_items = image_content_items(screenshots)
        if not image_items:
            return {
                **rubric_discard("截图读取失败；无有效截图 / 读图失败", error="failed to read screenshots"),
                **screenshot_payload,
                **product_payload,
            }
        product_text = product_text_from_production_snapshots(trajectory, production_snapshots)
        traj_text = rubrics_trajectory_text(traj)[:80000]
        raw_parts: list[str] = []
        hard_scores: list[int] = []
        soft_scores: list[int] = []
        judge_model_parts: list[tuple[str, str]] = []

        for index, item in enumerate(hard_list):
            call_raw_parts, call_error, score, judge_model = self.judge_single_rubric_with_fallback(
                RUBRICS_SINGLE_HARD_SYSTEM_PROMPT,
                format_hard_item(item, index),
                product_text,
                traj_text,
                image_items,
                f"[hard {index}]",
                validate_hard_score,
            )
            raw_parts.extend(call_raw_parts)
            judge_model_parts.append((f"hard[{index}]", judge_model))
            if call_error or score is None:
                return {
                    **rubric_discard(
                        f"硬约束[{index}] 判分失败: {call_error}",
                        error=f"hard[{index}] inference failed: {call_error}",
                        raw_parts=raw_parts,
                        judge_model=summarize_judge_model(judge_model_parts),
                    ),
                    **screenshot_payload,
                    **product_payload,
                }
            hard_scores.append(score)

        for index, item in enumerate(soft_list):
            call_raw_parts, call_error, score, judge_model = self.judge_single_rubric_with_fallback(
                RUBRICS_SINGLE_SOFT_SYSTEM_PROMPT,
                format_soft_item(item, index),
                product_text,
                traj_text,
                image_items,
                f"[soft {index}]",
                validate_soft_score,
            )
            raw_parts.extend(call_raw_parts)
            judge_model_parts.append((f"soft[{index}]", judge_model))
            if call_error or score is None:
                return {
                    **rubric_discard(
                        f"软约束[{index}] 判分失败: {call_error}",
                        error=f"soft[{index}] inference failed: {call_error}",
                        raw_parts=raw_parts,
                        judge_model=summarize_judge_model(judge_model_parts),
                    ),
                    **screenshot_payload,
                    **product_payload,
                }
            soft_scores.append(score)

        hard_avg, quality_avg, rubric_score = compute_rubric_final_score(hard_scores, soft_scores)
        score = 1 if rubric_score > 0.8 else 0
        return {
            "status": "success",
            "answer_score": score,
            "rubric_score": rubric_score,
            "hard_score": hard_avg,
            "quality_score": quality_avg,
            "hard_item_scores": hard_scores,
            "soft_item_scores": soft_scores,
            "evidence": f"rubric_score={rubric_score:.4f}, hard_avg={hard_avg:.4f}, quality={quality_avg:.4f}, answer_score={score}（>0.8 为 1）",
            "raw_response": "\n---\n".join(raw_parts),
            "error": "NA",
            "judge_model": summarize_judge_model(judge_model_parts),
            **screenshot_payload,
            **product_payload,
        }

    def judge_single_rubric_with_fallback(
        self,
        system_prompt: str,
        single_block: str,
        product_text: str,
        traj_text: str,
        image_items: list[dict[str, Any]],
        tag: str,
        validate_score,
    ) -> tuple[list[str], str | None, int | None, str]:
        user_text = RUBRICS_SINGLE_ITEM_USER_TEMPLATE.format(
            product_text=product_text,
            single_block=single_block,
            traj_text=traj_text,
            image_count=len(image_items),
        )
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": [{"type": "text", "text": user_text}, *image_items]},
        ]
        factory = JudgeModelFactory()
        raw_parts = []

        gemini_raw = call_judge_model(factory, "gemini3_pro", messages, retry_count=2)
        raw_parts.append(f"{tag}[gemini3_pro]\n{gemini_raw}")
        gemini_score, gemini_error = validate_rubric_raw(gemini_raw, validate_score)
        if gemini_error is None and gemini_score is not None:
            return raw_parts, None, gemini_score, "gemini3_pro"

        retry_raw = call_judge_model(factory, "gemini3_pro", messages, retry_count=3)
        raw_parts.append(f"{tag}[gemini3_pro_retry]\n{retry_raw}")
        retry_score, retry_error = validate_rubric_raw(retry_raw, validate_score)
        if retry_error is not None or retry_score is None:
            return (
                raw_parts,
                f"gemini3_pro 判分失败: {gemini_error}; gemini3_pro_retry 判分失败: {retry_error}",
                None,
                "gemini3_pro",
            )
        return raw_parts, None, retry_score, "gemini3_pro"


def load_rubrics_structure(raw: str) -> tuple[tuple[list, list] | None, str | None]:
    text = (raw or "").strip()
    if not text:
        return None, "rubrics 字段为空"
    try:
        data = json.loads(text)
    except Exception as exc:
        return None, f"rubrics 解析失败: {exc}"
    if not isinstance(data, dict):
        return None, "rubrics JSON 根节点须为 JSON 对象（含「硬约束」「软约束」）"
    hard = data.get("硬约束") or data.get("hard")
    soft = data.get("软约束") or data.get("soft")
    return (hard if isinstance(hard, list) else [], soft if isinstance(soft, list) else []), None


def format_hard_item(item: Any, index: int) -> str:
    if not isinstance(item, dict):
        item = {}
    desc = str(item.get("rubric描述", "")).strip()
    z0 = str(item.get("0分情况", "")).strip()
    z1 = str(item.get("1分情况", "")).strip()
    return f"{index}. {desc}\n   0分情况: {z0}\n   1分情况: {z1}"


def format_soft_item(item: Any, index: int) -> str:
    if not isinstance(item, dict):
        item = {}
    desc = str(item.get("rubric描述", "")).strip()
    z0 = str(item.get("0分情况", "")).strip()
    z1 = str(item.get("1分情况", "")).strip()
    z2 = str(item.get("2分情况", "")).strip()
    return f"{index}. {desc}\n   0分: {z0}\n   1分: {z1}\n   2分: {z2}"


def validate_hard_score(parsed: dict[str, Any] | None) -> tuple[int | None, str | None]:
    if not parsed:
        return None, "JSON 非对象"
    try:
        score = int(parsed.get("score"))
    except Exception:
        return None, "score 不是整数"
    if score not in (0, 1):
        return None, "硬约束 score 必须为 0 或 1"
    return score, None


def validate_soft_score(parsed: dict[str, Any] | None) -> tuple[int | None, str | None]:
    if not parsed:
        return None, "JSON 非对象"
    try:
        score = int(parsed.get("score"))
    except Exception:
        return None, "score 不是整数"
    if score not in (0, 1, 2):
        return None, "软约束 score 必须为 0、1 或 2"
    return score, None


def call_judge_model(factory: JudgeModelFactory, model_name: str, messages: list[dict[str, Any]], *, retry_count: int) -> str:
    try:
        return factory.create(model_name).call_model(messages, retry_count=retry_count, delay_seconds=1)
    except Exception as exc:
        return json.dumps({"error": f"Request failed: {exc}"}, ensure_ascii=False)


def validate_rubric_raw(raw: Any, validate_score) -> tuple[int | None, str | None]:
    if not raw:
        return None, "模型返回空"
    if is_rubric_inference_request_error(raw):
        return None, "请求失败"
    parsed = extract_json_object(raw)
    return validate_score(parsed)


def is_rubric_inference_request_error(raw: Any) -> bool:
    if isinstance(raw, dict):
        parsed = raw
    else:
        try:
            parsed = json.loads(str(raw or "").strip())
        except (TypeError, ValueError, json.JSONDecodeError):
            return False
    if not isinstance(parsed, dict) or "error" not in parsed:
        return False
    if "score" in parsed or "answer_score" in parsed:
        return False
    error_text = str(parsed.get("error") or parsed.get("details") or "")
    request_error_markers = (
        "retry over times",
        "base_url is required",
        "unsupported provider",
        "get_one_request_url failed",
        "Request failed",
    )
    return any(marker in error_text for marker in request_error_markers)


def summarize_judge_model(parts: list[tuple[str, str]]) -> str:
    if not parts:
        return ""
    models = [model for _, model in parts]
    if len(set(models)) == 1:
        return models[0]
    return "mixed: " + ", ".join(f"{tag}={model}" for tag, model in parts)


def compute_rubric_final_score(hard_scores: list[int], soft_scores: list[int]) -> tuple[float, float, float]:
    hard_count = len(hard_scores)
    soft_count = len(soft_scores)
    hard_avg = sum(hard_scores) / hard_count if hard_count else 0.0
    quality_avg = sum(soft_scores) / (2.0 * soft_count) if soft_count else 0.0
    if hard_count == 0:
        return 0.0, quality_avg, quality_avg
    if abs(hard_avg - 1.0) < 1e-9:
        rubric_score = 0.75 * hard_avg + 0.25 * quality_avg
    elif hard_avg < 1e-9:
        rubric_score = quality_avg
    else:
        rubric_score = hard_avg * (0.75 + 0.25 * quality_avg) + (1.0 - hard_avg) * quality_avg
    return hard_avg, quality_avg, rubric_score


def rubric_discard(evidence: str, *, error: str | None = None, raw_parts: list[str] | None = None, judge_model: str = "") -> dict[str, Any]:
    return {
        "status": "failed",
        "answer_score": ERROR_SCORE,
        "rubric_score": None,
        "hard_score": None,
        "quality_score": None,
        "hard_item_scores": None,
        "soft_item_scores": None,
        "evidence": evidence,
        "raw_response": "\n---\n".join(raw_parts or []),
        "error": error or evidence,
        "judge_model": judge_model,
    }


def rubrics_trajectory_text(traj: list[dict[str, Any]]) -> str:
    lines = []
    for index, item in enumerate(traj):
        if not isinstance(item, dict):
            continue
        response = str(item.get("response") or "")[:4000]
        lines.append(f"步骤{index}: {response}")
    return "\n".join(lines)
