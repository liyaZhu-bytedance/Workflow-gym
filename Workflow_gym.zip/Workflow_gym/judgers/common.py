from __future__ import annotations

import base64
from io import BytesIO
import json
import mimetypes
import os
import re
import tempfile
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from ..tosutil_local import run_tosutil_cp
from ..platform_failure import (
    PLATFORM_MATCH_UNAVAILABLE,
    PLATFORM_MISMATCH_EXHAUSTED,
    build_platform_failure_evidence,
    is_platform_mismatch_failure,
    platform_mismatch_context_from_trajectory,
)
from ..records import TrajectoryResult
from ..task_files import download_url_from_url, filename_from_url, parse_final_answer_names, parse_tos_urls
from .file_content_reader import read_file_content


ERROR_SCORE = -100000
IMAGE_LLM_FAIL_SCORE = -100000
IMAGE_LLM_EMPTY_EVALUATION_SCORE = -100000
MAX_IMAGE_LLM_STUDENT_SCREENSHOTS = 8
MAX_FILE_CONTENT_READ_BYTES = 50 * 1024 * 1024
IMAGE_LLM_REFERENCE_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}
SAMPLING_FAILURE_STATUSES = frozenset(
    {
        "sample_failed",
        "sample_interrupted",
        "resume_failed",
    }
)
MAX_SAMPLING_EXCEPTION_EVIDENCE_CHARS = 1200


def is_sampling_failure(trajectory: TrajectoryResult) -> bool:
    if (trajectory.error or "").strip():
        return True
    return (trajectory.status or "") in SAMPLING_FAILURE_STATUSES


def summarize_sampling_error_text(error: str, max_chars: int = 400) -> str:
    text = " ".join((error or "").strip().split())
    if not text:
        return ""
    for marker in (
        "error_code': '",
        "error_message': '",
        "invocation_result_status': '",
        "Task execution timeout",
        "Task execution failed",
        "RunCommand 执行失败",
    ):
        if marker in text:
            start = text.find(marker)
            snippet = text[start : start + max_chars]
            return snippet[:max_chars]
    return text[:max_chars]


def load_exception_records(sample_dir: str) -> list[dict[str, Any]]:
    path = Path(sample_dir) / "exception.json"
    if not path.exists():
        return []
    try:
        with open(path, "r", encoding="utf-8") as file_obj:
            loaded = json.load(file_obj)
    except Exception:
        return []
    if isinstance(loaded, list):
        return [item for item in loaded if isinstance(item, dict)]
    if isinstance(loaded, dict):
        return [loaded]
    return []


def platform_failure_reason_from_trajectory(trajectory: TrajectoryResult) -> str:
    for record in load_exception_records(trajectory.sample_dir):
        reason = str(record.get("reason") or "").strip()
        if reason in (PLATFORM_MATCH_UNAVAILABLE, PLATFORM_MISMATCH_EXHAUSTED):
            return reason
        if record.get("exception_type") == "PlatformMatchUnavailableError":
            return str(record.get("reason") or PLATFORM_MATCH_UNAVAILABLE)
    return ""


def build_sampling_exception_evidence(trajectory: TrajectoryResult) -> str:
    platform_reason = platform_failure_reason_from_trajectory(trajectory)
    if platform_reason:
        required_platform = ""
        image_id = ""
        tried_instance_ids: list[str] = []
        for record in load_exception_records(trajectory.sample_dir):
            required_platform = required_platform or str(record.get("required_platform") or "").strip()
            image_id = image_id or str(record.get("image_id") or "").strip()
            tried = record.get("tried_instance_ids")
            if isinstance(tried, list) and tried:
                tried_instance_ids = [str(item) for item in tried if str(item).strip()]
        mismatch_context = platform_mismatch_context_from_trajectory(trajectory)
        return build_platform_failure_evidence(
            reason=platform_reason,
            required_platform=required_platform,
            image_id=image_id,
            tried_instance_ids=tried_instance_ids,
            mismatch_context=mismatch_context,
        )

    parts: list[str] = ["采样异常，未进入正常判分"]
    status = (trajectory.status or "").strip()
    if status:
        parts.append("status=%s" % status)
    if trajectory.last_step >= 0:
        parts.append("last_step=%s" % trajectory.last_step)
    else:
        parts.append("last_step=%s（环境初始化或采样前失败）" % trajectory.last_step)

    error_text = summarize_sampling_error_text(trajectory.error or "")
    if error_text:
        parts.append("error=%s" % error_text)

    for index, record in enumerate(load_exception_records(trajectory.sample_dir)[:3]):
        message = summarize_sampling_error_text(str(record.get("message") or ""), max_chars=300)
        parts.append(
            "exception[%s] stage=%s type=%s step=%s message=%s"
            % (
                index,
                record.get("stage") or "",
                record.get("exception_type") or "",
                record.get("step_index", ""),
                message,
            )
        )

    parts.append("answer_score=%s" % ERROR_SCORE)
    evidence = "；".join(part for part in parts if part)
    if len(evidence) > MAX_SAMPLING_EXCEPTION_EVIDENCE_CHARS:
        return evidence[: MAX_SAMPLING_EXCEPTION_EVIDENCE_CHARS - 3] + "..."
    return evidence


def field_text(fields: dict[str, Any], *names: str) -> str:
    for name in names:
        value = fields.get(name)
        if value not in (None, ""):
            if isinstance(value, (list, tuple)):
                return ",".join(str(item).strip() for item in value if str(item).strip())
            return str(value).strip()
    return ""


def join_answer_type(answer_type: str, metric_type: str) -> str:
    return f"{answer_type}-{metric_type}" if metric_type else answer_type


def load_traj(path: str) -> list[dict[str, Any]]:
    try:
        with open(path, "r", encoding="utf-8") as file_obj:
            data = json.load(file_obj)
        return data if isinstance(data, list) else []
    except Exception:
        return []


def valid_screenshots(traj: list[dict[str, Any]]) -> list[str]:
    out = []
    for item in traj:
        path = item.get("screenshot") if isinstance(item, dict) else ""
        if path and os.path.isfile(path):
            out.append(path)
    return out


def image_content_items(paths: list[str]) -> list[dict[str, Any]]:
    items = []
    for path in paths:
        try:
            b64, mime = normalized_image_base64(path)
            items.append({"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64}", "detail": "high"}})
        except Exception:
            continue
    return items


def normalized_image_base64(path: str) -> tuple[str, str]:
    try:
        from PIL import Image

        with Image.open(path) as image:
            buffer = BytesIO()
            image.save(buffer, format="PNG")
        return base64.b64encode(buffer.getvalue()).decode("ascii"), "image/png"
    except Exception:
        mime = mimetypes.guess_type(path)[0] or "image/png"
        with open(path, "rb") as file_obj:
            return base64.b64encode(file_obj.read()).decode("ascii"), mime


def parse_binary_judge_response(raw: str) -> dict[str, Any]:
    score, evidence = parse_judge_raw_content(raw)
    if score is None:
        return {"status": "failed", "exists": False, "evidence": evidence or str(raw)[:200], "raw_response": str(raw), "error": "模型输出无法解析为 JSON 或 answer_score", "answer_score": -1}
    normalized = 1 if int(score) == 1 else 0
    return {"status": "success", "exists": normalized == 1, "evidence": evidence or f"评分：{normalized}分", "raw_response": str(raw), "answer_score": normalized, "error": "NA"}


def parse_judge_raw_content(raw: Any) -> tuple[int | None, str]:
    text = str(raw or "")
    for pattern in (r"```json\s*(\{.*?\})\s*```", r"```\s*(\{.*?\})\s*```", r"\{[^{}]*\"answer_score\"[^{}]*\}"):
        match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
        if match:
            obj_text = match.group(1) if match.groups() else match.group(0)
            try:
                return int(json.loads(obj_text).get("answer_score")), extract_evidence(text)
            except Exception:
                pass
    try:
        return int(json.loads(text).get("answer_score")), extract_evidence(text)
    except Exception:
        pass
    match = re.search(r"【分数】：\s*(\d+)分", text)
    if match:
        return int(match.group(1)), extract_evidence(text)
    return None, extract_evidence(text)


def extract_evidence(text: str) -> str:
    match = re.search(r"【评分依据】：(.*?)(?=【分数】|【JSON】|$)", text or "", re.DOTALL)
    return match.group(1).strip() if match else ""


def extract_json_object(raw: Any) -> dict[str, Any] | None:
    text = str(raw or "").strip()
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end <= start:
        return None
    try:
        data = json.loads(text[start:end + 1])
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def failed_check(error: str) -> dict[str, Any]:
    return {"status": "failed", "exists": False, "evidence": "", "raw_response": "", "error": error, "answer_score": -1}


def normalize_binary_score(value: Any, exists: Any) -> int:
    try:
        score = int(value)
        if score == ERROR_SCORE:
            return ERROR_SCORE
        return 1 if score == 1 else 0
    except (TypeError, ValueError):
        return 1 if bool(exists) else 0


def merge_image_llm_score(raw: dict[str, Any]) -> int:
    try:
        score = int(raw.get("answer_score"))
        if score in (IMAGE_LLM_EMPTY_EVALUATION_SCORE, IMAGE_LLM_FAIL_SCORE):
            return score
        if raw.get("status") == "failed":
            return IMAGE_LLM_FAIL_SCORE
        return 1 if score == 1 else 0
    except (TypeError, ValueError):
        return IMAGE_LLM_FAIL_SCORE


def sample_output_urls(trajectory: TrajectoryResult) -> list[str]:
    return [
        item.get("tos_url") or item.get("tos_path") or ""
        for item in trajectory.task_files.output_uploads
        if item.get("tos_url") or item.get("tos_path")
    ]


def read_remote_file(url: str) -> bytes:
    if url.startswith("tos://"):
        with tempfile.TemporaryDirectory() as temp_dir:
            target = os.path.join(temp_dir, Path(url).name or "download.bin")
            run_tosutil_cp(url, target)
            return Path(target).read_bytes()
    with urllib.request.urlopen(download_url_from_url(url), timeout=60) as response:
        return response.read()


def download_remote_file(url: str, target_path: str) -> None:
    Path(target_path).parent.mkdir(parents=True, exist_ok=True)
    if url.startswith("tos://"):
        run_tosutil_cp(url, target_path)
        return
    with urllib.request.urlopen(download_url_from_url(url), timeout=60) as response:
        Path(target_path).write_bytes(response.read())


def read_remote_file_with_content_reader(url: str, display_name: str, max_bytes: int = MAX_FILE_CONTENT_READ_BYTES) -> str:
    """Download a remote product and read it through the migrated extension-based reader."""
    safe_name = Path(str(display_name or "")).name or Path(str(url)).name or "output"
    with tempfile.TemporaryDirectory() as temp_dir:
        local_path = os.path.join(temp_dir, safe_name)
        download_remote_file(url, local_path)
        result = read_file_content(local_path, max_bytes=max_bytes)
        if not result.ok:
            raise RuntimeError(result.error or "读取文件内容失败")
        return result.content


def final_answer_name_basenames(trajectory: TrajectoryResult) -> set[str]:
    raw_value = first_field_value(
        trajectory.task_fields,
        "final_answer文件名",
        "final answer 文件名",
        "final_answer_names",
    )
    names = parse_final_answer_names_legacy_style(raw_value)
    return {Path(name.replace("\\", "/")).name for name in names if Path(name.replace("\\", "/")).name}


def first_field_value(fields: dict[str, Any], *names: str) -> Any:
    for name in names:
        value = fields.get(name)
        if value not in (None, ""):
            return value
    return ""


def parse_final_answer_names_legacy_style(raw_value: Any) -> list[str]:
    if isinstance(raw_value, str) and "\n" in raw_value and not raw_value.lstrip().startswith(("[", "{")):
        return [item.strip() for item in raw_value.replace(",", "\n").splitlines() if item.strip()]
    try:
        names = parse_final_answer_names(raw_value)
    except Exception:
        names = []
    if names:
        return names
    if isinstance(raw_value, str):
        return [item.strip() for item in raw_value.replace(",", "\n").splitlines() if item.strip()]
    return []


def filter_output_uploads_by_final_answer_names(trajectory: TrajectoryResult) -> list[dict[str, Any]]:
    wanted = final_answer_name_basenames(trajectory)
    if not wanted:
        return list(trajectory.task_files.output_uploads)
    return [
        item
        for item in trajectory.task_files.output_uploads
        if output_upload_basename(item) in wanted
    ]


def output_upload_basename(item: dict[str, Any]) -> str:
    relative_path = str(item.get("relative_path") or "").strip()
    if relative_path:
        return Path(relative_path.replace("\\", "/")).name
    url = str(item.get("tos_url") or item.get("tos_path") or "")
    if not url:
        return ""
    try:
        return filename_from_url(url)
    except Exception:
        return Path(url).name


def normalize_compare_bytes(value: bytes) -> bytes:
    bom = b"\xef\xbb\xbf"
    if value.startswith(bom):
        value = value[len(bom):]
    return value.replace(b"\r\n", b"\n").replace(b"\r", b"\n")


def vm_output_listing(trajectory: TrajectoryResult) -> dict[str, Any]:
    return {
        "output_uploads": trajectory.task_files.output_uploads,
        "missing_or_errors": trajectory.task_files.errors,
    }


def raw_reference_image_field(fields: dict[str, Any]) -> Any:
    for name in ("sheetshot_url", "final_answer截图", "reference_image"):
        value = fields.get(name)
        if value not in (None, ""):
            return value
    return None


def reference_image_candidates(raw: Any) -> list[str]:
    if raw in (None, ""):
        return []
    candidates: list[str] = []
    seen: set[str] = set()
    for url in parse_tos_urls(raw):
        if url not in seen:
            candidates.append(url)
            seen.add(url)
    if candidates:
        return candidates
    if isinstance(raw, (list, tuple, dict)):
        return []
    text = str(raw).strip()
    for item in text.replace("\n", ",").split(","):
        item = item.strip()
        if not item or item in seen:
            continue
        if item.startswith(("http://", "https://")) or os.path.isfile(item):
            candidates.append(item)
            seen.add(item)
    return candidates


def collect_reference_image_paths(trajectory: TrajectoryResult) -> list[str]:
    candidates = reference_image_candidates(raw_reference_image_field(trajectory.task_fields))
    if not candidates:
        return []
    local_paths = []
    ref_dir = os.path.join(trajectory.sample_dir, "gt_sreenshot")
    Path(ref_dir).mkdir(parents=True, exist_ok=True)
    for index, item in enumerate(candidates):
        filename = reference_image_filename(item, index)
        if not filename:
            continue
        target = os.path.join(ref_dir, filename)
        if os.path.isfile(target) and os.path.getsize(target) > 0:
            local_paths.append(target)
            continue
        if os.path.isfile(item):
            try:
                Path(target).write_bytes(Path(item).read_bytes())
            except Exception:
                continue
            if os.path.isfile(target) and os.path.getsize(target) > 0:
                local_paths.append(target)
            continue
        if item.startswith("http://") or item.startswith("https://"):
            try:
                urllib.request.urlretrieve(download_url_from_url(item), target)
                if os.path.isfile(target) and os.path.getsize(target) > 0:
                    local_paths.append(target)
            except Exception:
                continue
    return local_paths


def reference_image_filename(value: str, index: int) -> str:
    try:
        parsed = urllib.parse.urlparse(value)
        name = urllib.parse.unquote(Path(parsed.path or value).name)
    except Exception:
        name = Path(value).name
    suffix = Path(name).suffix.lower()
    if suffix not in IMAGE_LLM_REFERENCE_IMAGE_EXTS:
        return ""
    return name or f"reference_{index}{suffix or '.png'}"


def product_text_from_outputs(trajectory: TrajectoryResult) -> str:
    parts = []
    for item in filter_output_uploads_by_final_answer_names(trajectory):
        url = item.get("tos_url") or item.get("tos_path") or ""
        name = item.get("relative_path") or Path(str(url)).name or "output"
        if not url:
            continue
        try:
            text = read_remote_file_with_content_reader(url, name)
        except Exception as exc:
            text = f"(读取失败: {exc})"
        parts.append(f"## 文件：{name}\n{text[:50000]}")
    return "\n\n".join(parts) if parts else "（无产物文本）"


def trajectory_text(traj: list[dict[str, Any]]) -> str:
    lines = []
    for item in traj:
        if not isinstance(item, dict):
            continue
        lines.append(f"步骤{item.get('step_index', '')}: {str(item.get('response') or '')[:1000]}")
    return "\n\n".join(lines)
