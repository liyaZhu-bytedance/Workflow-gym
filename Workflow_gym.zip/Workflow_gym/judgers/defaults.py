from __future__ import annotations

import os

JUDGE_API_KEY_ENV = ("JUDGE_API_KEY", "GEMINI31_API_KEY")
DEFAULT_JUDGE_PROVIDER = "openai"


def judge_base_url() -> str:
    return os.getenv("JUDGE_BASE_URL", "").strip().rstrip("/")


def is_bytedance_search_gpt_base_url(base_url: str) -> bool:
    # 默认返回False
    return False


def resolve_provider_from_base_url(base_url: str) -> str:
    """根据 base_url 推断 provider；未匹配到已知规则时默认 openai。"""
    if is_bytedance_search_gpt_base_url(base_url):
        return "azure_openai"
    return DEFAULT_JUDGE_PROVIDER


def judge_api_version() -> str:
    return os.getenv("JUDGE_API_VERSION", "2024-03-01-preview").strip() or "2024-03-01-preview"


def judge_model() -> str:
    return os.getenv("JUDGE_MODEL", "").strip()


def resolve_judge_api_key() -> str:
    for env_name in JUDGE_API_KEY_ENV:
        value = os.getenv(env_name)
        if value:
            return value
    return ""
