from __future__ import annotations

from typing import Any

from ..records import TrajectoryResult
from .client import JudgeClient
from .common import ERROR_SCORE, build_sampling_exception_evidence, field_text, is_sampling_failure, join_answer_type, vm_output_listing
from .file_product import FileProductJudgerMixin, archive_student_products, attach_production_archive_payload
from .image_llm import ImageLlmJudgerMixin
from .rubrics import RubricsJudgerMixin
from .screenshot import ScreenshotJudgerMixin


class JudgerAgent(
    ScreenshotJudgerMixin,
    FileProductJudgerMixin,
    ImageLlmJudgerMixin,
    RubricsJudgerMixin,
    JudgeClient,
):
    def judge(self, trajectory: TrajectoryResult) -> dict[str, Any]:
        fields = trajectory.task_fields or {}
        answer_type = field_text(fields, "answer_type")
        metric_type = field_text(fields, "metric_type", "判分类型")
        student_snapshots = (
            archive_student_products(trajectory)
            if trajectory.task_files.output_uploads
            else []
        )

        if is_sampling_failure(trajectory):
            return attach_production_archive_payload(
                self.error_score(trajectory, answer_type, metric_type),
                trajectory,
                student_snapshots,
            )

        if answer_type in ("数值/文本-单点验证", "数值/文本-多点验证"):
            if metric_type == "image-llm":
                return attach_production_archive_payload(
                    self.judge_image_llm(trajectory, answer_type, metric_type),
                    trajectory,
                    student_snapshots,
                )
            return attach_production_archive_payload(
                self.judge_last_screenshots(trajectory, answer_type, metric_type),
                trajectory,
                student_snapshots,
            )

        if answer_type == "文件产物" and metric_type == "规则判分":
            return self.judge_rule_files(trajectory, answer_type, metric_type)

        if answer_type == "文件产物" and metric_type == "规则判分+LLM-as-judge":
            return self.judge_file_content(trajectory, answer_type, metric_type)

        if metric_type in ("Rubrics", "rubrics"):
            return attach_production_archive_payload(
                self.judge_rubrics(trajectory, answer_type, metric_type),
                trajectory,
                student_snapshots,
            )

        return attach_production_archive_payload(
            {
                "answer_score": -1,
                "evidence": "未配置判分方式或判分方式不正确",
                "answer_type": answer_type or "unknown",
                "error": f"answer_type={answer_type}, metric_type={metric_type}",
                "raw_response": "",
            },
            trajectory,
            student_snapshots,
        )

    def error_score(self, trajectory: TrajectoryResult, answer_type: str, metric_type: str) -> dict[str, Any]:
        return {
            "answer_score": ERROR_SCORE,
            "evidence": build_sampling_exception_evidence(trajectory),
            "answer_type": join_answer_type(answer_type, metric_type),
            "discard_reason": "sample_failed",
            "error": trajectory.error or trajectory.status,
            "raw_response": "",
            "vm_output_listing": vm_output_listing(trajectory),
        }
