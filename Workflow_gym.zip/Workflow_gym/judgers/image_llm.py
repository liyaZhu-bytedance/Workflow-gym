from __future__ import annotations

import base64
import os
from typing import Any

from ..records import TrajectoryResult
from .common import (
    IMAGE_LLM_EMPTY_EVALUATION_SCORE,
    IMAGE_LLM_FAIL_SCORE,
    MAX_IMAGE_LLM_STUDENT_SCREENSHOTS,
    collect_reference_image_paths,
    field_text,
    load_traj,
    merge_image_llm_score,
    parse_judge_raw_content,
    valid_screenshots,
    vm_output_listing,
)
from .factory import JudgeModelFactory
from .prompts import (
    IMAGE_LLM_PARSE_MAX_ATTEMPTS,
    IMAGE_LLM_RETRY_USER_PROMPT,
    IMAGE_LLM_SYSTEM_PROMPT,
    IMAGE_LLM_SYSTEM_PROMPT_SUFFIX,
    IMAGE_LLM_USER_PROMPT_EVALUATION,
    IMAGE_LLM_USER_PROMPT_REFERENCE,
    IMAGE_LLM_USER_PROMPT_REFERENCE_ZERO,
    IMAGE_LLM_USER_PROMPT_STUDENT,
)


class ImageLlmJudgerMixin:
    def judge_image_llm(self, trajectory: TrajectoryResult, answer_type: str, metric_type: str) -> dict[str, Any]:
        reference_images = collect_reference_image_paths(trajectory)
        student_screenshots = valid_screenshots(load_traj(trajectory.traj_json_path))
        total = len(student_screenshots)
        student_screenshots = student_screenshots[-MAX_IMAGE_LLM_STUDENT_SCREENSHOTS:]
        raw = self.image_llm_metrics(
            reference_response=field_text(trajectory.task_fields, "response_reference"),
            reference_image_paths=reference_images,
            screenshot_paths=student_screenshots,
        )
        score = merge_image_llm_score(raw)
        evidence = (raw.get("evidence") or "").strip()
        judge_models = raw.get("judge_models") or []
        return {
            "answer_score": score,
            "exists": score == 1,
            "evidence": (
                f"image-llm 判分：reference_images={len(reference_images)} 张, "
                f"学生末尾截图={len(student_screenshots)} 张；"
                f"model={judge_models[0] if judge_models else ''}"
                + (
                    f" (parse_retry={','.join(str(model) for model in judge_models[1:])})"
                    if len(judge_models) > 1 else ""
                )
                + "；"
                f"answer_score={raw.get('answer_score')}, status={raw.get('status')}"
                + (f"；{evidence}" if evidence else "")
            ),
            "answer_type": f"{answer_type}-image-llm",
            "judge_results": [{
                **raw,
                "judge_subset": "image-llm_sheetshot_plus_last_8",
                "sheetshot_url": field_text(trajectory.task_fields, "sheetshot_url", "final_answer截图", "reference_image"),
                "student_screenshots_total": total,
                "student_screenshots_used": len(student_screenshots),
                "reference_image_paths": [os.path.abspath(p) for p in reference_images],
                "reference_image_filenames": [os.path.basename(p) for p in reference_images],
                "last_screenshots": [os.path.abspath(p) for p in student_screenshots],
                "screenshot_filenames": [os.path.basename(p) for p in student_screenshots],
            }],
            "vm_output_listing": vm_output_listing(trajectory),
        }

    def image_llm_metrics(self, *, reference_response: str, reference_image_paths: list[str], screenshot_paths: list[str]) -> dict[str, Any]:
        reference_paths = [p for p in reference_image_paths if p and os.path.exists(p)]
        screenshot_list = [p for p in screenshot_paths if p and os.path.exists(p)]
        evaluation = (reference_response or "").strip()
        if not screenshot_list:
            return {"status": "failed", "exists": False, "evidence": "", "raw_response": "", "error": "student screenshots are empty", "answer_score": IMAGE_LLM_FAIL_SCORE}
        if bool(reference_paths) != bool(evaluation):
            return {"status": "failed", "exists": False, "evidence": "", "raw_response": "", "error": "输入不完整：参考截图与评估要点必须同时提供", "answer_score": IMAGE_LLM_EMPTY_EVALUATION_SCORE}
        if not evaluation:
            return {"status": "failed", "exists": False, "evidence": "", "raw_response": "", "error": "评估要点为空：image-llm 拒绝判分", "answer_score": IMAGE_LLM_EMPTY_EVALUATION_SCORE}
        reference_items = [item for item in (load_image_item(path) for path in reference_paths) if item]
        screenshot_items = [item for item in (load_image_item(path) for path in screenshot_list) if item]
        if not screenshot_items:
            return {"status": "failed", "exists": False, "evidence": "", "raw_response": "", "error": "failed to read student screenshots", "answer_score": IMAGE_LLM_FAIL_SCORE}
        reference_count = len(reference_items)
        student_count = len(screenshot_items)
        scoring_branch = "有参考截图（要点与参考图同级，任一不满足即0分）"
        system_prompt = (
            IMAGE_LLM_SYSTEM_PROMPT
            + IMAGE_LLM_SYSTEM_PROMPT_SUFFIX.format(
                reference_image_count=reference_count,
                student_image_count=student_count,
                scoring_branch=scoring_branch,
            )
        )
        reference_content = [
            {
                "type": "text",
                "text": IMAGE_LLM_USER_PROMPT_EVALUATION.format(evaluation_points=evaluation),
            },
            {
                "type": "text",
                "text": (
                    IMAGE_LLM_USER_PROMPT_REFERENCE_ZERO
                    if reference_count == 0
                    else IMAGE_LLM_USER_PROMPT_REFERENCE.format(reference_image_count=reference_count)
                ),
            },
            *image_content_items_raw(reference_items),
        ]
        student_content = [
            {
                "type": "text",
                "text": IMAGE_LLM_USER_PROMPT_STUDENT.format(student_image_count=student_count),
            },
            *image_content_items_raw(screenshot_items),
        ]
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": reference_content},
            {"role": "user", "content": student_content},
        ]
        messages_for_call = messages
        raw: Any = ""
        judge_models: list[str] = []
        factory = JudgeModelFactory()
        for attempt in range(IMAGE_LLM_PARSE_MAX_ATTEMPTS):
            model_key = "gemini3_pro"
            retry_count = 3 if attempt == 0 else 2
            try:
                client = factory.create(model_key)
                raw = client.call_model(messages_for_call, retry_count=retry_count, delay_seconds=1)
            except Exception as exc:
                if attempt + 1 < IMAGE_LLM_PARSE_MAX_ATTEMPTS:
                    messages_for_call = messages + [{"role": "user", "content": IMAGE_LLM_RETRY_USER_PROMPT}]
                    continue
                return {"status": "failed", "exists": False, "evidence": "", "raw_response": "", "error": str(exc), "answer_score": IMAGE_LLM_FAIL_SCORE, "parse_attempts": attempt + 1, "judge_models": judge_models}
            judge_models.append(client.model)
            if raw == "":
                if attempt + 1 < IMAGE_LLM_PARSE_MAX_ATTEMPTS:
                    messages_for_call = messages + [{"role": "user", "content": IMAGE_LLM_RETRY_USER_PROMPT}]
                    continue
                return {"status": "failed", "exists": False, "evidence": "", "raw_response": "", "error": "模型返回空内容", "answer_score": IMAGE_LLM_FAIL_SCORE, "parse_attempts": attempt + 1, "judge_models": judge_models}
            score, evidence = parse_judge_raw_content(raw)
            if score is not None:
                normalized = 1 if int(score) == 1 else 0
                return {"status": "success", "exists": normalized == 1, "evidence": evidence or f"评分：{normalized}分", "raw_response": str(raw), "answer_score": normalized, "error": "NA", "parse_attempts": attempt + 1, "judge_models": judge_models}
            if attempt + 1 < IMAGE_LLM_PARSE_MAX_ATTEMPTS:
                messages_for_call = messages + [
                    {"role": "assistant", "content": str(raw)[:8000]},
                    {"role": "user", "content": IMAGE_LLM_RETRY_USER_PROMPT},
                ]
        return {"status": "failed", "exists": False, "evidence": parse_judge_raw_content(raw)[1] or str(raw)[:200], "raw_response": str(raw), "error": "模型输出无法解析为 JSON 或无法提取 answer_score", "answer_score": IMAGE_LLM_FAIL_SCORE, "parse_attempts": IMAGE_LLM_PARSE_MAX_ATTEMPTS, "judge_models": judge_models}


def mime_from_path(path: str) -> str:
    ext = os.path.splitext(path or "")[1].lower()
    return {
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".webp": "image/webp",
        ".gif": "image/gif",
        ".bmp": "image/bmp",
    }.get(ext, "image/png")


def load_image_item(path: str) -> tuple[str, str] | None:
    try:
        with open(path, "rb") as file_obj:
            return base64.b64encode(file_obj.read()).decode("utf-8"), mime_from_path(path)
    except Exception:
        return None


def image_content_items_raw(items: list[tuple[str, str]]) -> list[dict[str, Any]]:
    return [
        {
            "type": "image_url",
            "image_url": {
                "url": f"data:{mime};base64,{b64}",
                "detail": "high",
            },
        }
        for b64, mime in items
    ]
