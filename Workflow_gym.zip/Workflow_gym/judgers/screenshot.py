from __future__ import annotations

import os
from typing import Any

from ..records import TrajectoryResult
from .common import (
    failed_check,
    field_text,
    image_content_items,
    join_answer_type,
    load_traj,
    normalize_binary_score,
    parse_binary_judge_response,
    valid_screenshots,
    vm_output_listing,
)
from .factory import JudgeModelFactory
from .prompts import GT_ANSWER_SYSTEM_PROMPT, GT_ANSWER_USER_PROMPT_TEMPLATE


class ScreenshotJudgerMixin:
    def judge_last_screenshots(self, trajectory: TrajectoryResult, answer_type: str, metric_type: str) -> dict[str, Any]:
        screenshots = valid_screenshots(load_traj(trajectory.traj_json_path))[-10:]
        raw = self.judge_screenshots(
            screenshot_paths=screenshots,
            reference_response=field_text(trajectory.task_fields, "response_reference"),
        )
        score = normalize_binary_score(raw.get("answer_score"), raw.get("exists"))
        check = {
            **raw,
            "judge_subset": "last_10",
            "last_screenshots": [os.path.abspath(p) for p in screenshots],
            "screenshot_filenames": [os.path.basename(p) for p in screenshots],
            "answer_type": join_answer_type(answer_type, metric_type),
        }
        return {
            "answer_score": score,
            "exists": score == 1,
            "evidence": f"末 {len(screenshots)} 张截图判分(last_10)；answer_score={raw.get('answer_score')}, exists={raw.get('exists')}",
            "answer_type": join_answer_type(answer_type, metric_type),
            "judge_results": [check],
            "vm_output_listing": vm_output_listing(trajectory),
        }

    def judge_screenshots(
        self,
        *,
        screenshot_paths: list[str],
        reference_response: str,
    ) -> dict[str, Any]:
        if not screenshot_paths:
            return failed_check("no valid screenshots found")
        image_items = image_content_items(screenshot_paths)
        if not image_items:
            return failed_check("failed to read any screenshots")
        user_text = GT_ANSWER_USER_PROMPT_TEMPLATE.format(
            evaluation_points=reference_response or "（未提供评估要点）",
            image_count=len(image_items),
        )
        messages = [
            {"role": "system", "content": GT_ANSWER_SYSTEM_PROMPT},
            {"role": "user", "content": [{"type": "text", "text": user_text}, *image_items]},
        ]
        try:
            raw_content = JudgeModelFactory().create("gemini3_pro").call_model(messages, retry_count=3, delay_seconds=1)
        except Exception as exc:
            return {"status": "failed", "exists": False, "evidence": "", "raw_response": "", "error": str(exc), "answer_score": -1}
        if raw_content == "":
            return {"status": "failed", "exists": False, "evidence": "", "raw_response": "", "error": "模型返回空内容", "answer_score": -1}
        return parse_binary_judge_response(raw_content)
