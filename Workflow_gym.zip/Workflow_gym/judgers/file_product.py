from __future__ import annotations

from pathlib import Path
from typing import Any

from ..records import TrajectoryResult
from ..task_files import filename_from_url, parse_tos_urls, validate_relative_output_path
from .common import (
    download_remote_file,
    field_text,
    filter_output_uploads_by_final_answer_names,
    join_answer_type,
    normalize_compare_bytes,
    parse_judge_raw_content,
    read_remote_file_with_content_reader,
    vm_output_listing,
)
from .file_content_reader import read_file_content
from .factory import JudgeModelFactory
from .prompts import GT_ANSWER_FILE_CONTENT_USER_PROMPT_TEMPLATE, GT_ANSWER_SYSTEM_PROMPT

MAX_FILE_CONTENT_READ_BYTES = 50000


def local_product_paths(sample_dir: str, relative_path: str) -> tuple[str, str]:
    safe_relative = validate_relative_output_path(relative_path)
    base = Path(sample_dir)
    return (
        str(base / "production" / safe_relative),
        str(base / "gt_production" / safe_relative),
    )


def _production_already_saved(production_path: str) -> bool:
    path = Path(production_path)
    return path.is_file() and path.stat().st_size > 0


def output_upload_missing(item: dict[str, Any]) -> bool:
    if str(item.get("status") or "").strip().lower() == "missing":
        return True
    if item.get("output_file_exists") is False:
        return True
    file_check = item.get("file_check") or {}
    if file_check.get("exists") is False:
        return True
    return False


def _new_production_snapshot(
    *,
    trajectory: TrajectoryResult,
    item: dict[str, Any],
    gt_by_filename: dict[str, str] | None = None,
) -> dict[str, Any]:
    url = item.get("tos_url") or item.get("tos_path") or ""
    relative_path = str(item.get("relative_path") or output_filename(item) or "output")
    filename = output_filename(item) or Path(relative_path.replace("\\", "/")).name
    production_path, gt_production_path = local_product_paths(trajectory.sample_dir, relative_path)
    gt_by_filename = gt_by_filename or {}
    return {
        "filename": filename,
        "relative_path": relative_path,
        "sample_url": url,
        "final_answer_url": gt_by_filename.get(filename, ""),
        "production_path": production_path,
        "gt_production_path": gt_production_path,
        "production_saved": _production_already_saved(production_path),
        "gt_production_saved": Path(gt_production_path).is_file() and Path(gt_production_path).stat().st_size > 0,
        "error": "",
    }


def archive_student_products(trajectory: TrajectoryResult) -> list[dict[str, Any]]:
    snapshots: list[dict[str, Any]] = []
    for item in filter_output_uploads_by_final_answer_names(trajectory):
        snapshot = _new_production_snapshot(trajectory=trajectory, item=item)
        if output_upload_missing(item):
            snapshot["error"] = "产物未生成，跳过下载"
            snapshots.append(snapshot)
            continue
        url = snapshot["sample_url"]
        production_path = snapshot["production_path"]
        if url and not snapshot["production_saved"]:
            try:
                Path(production_path).parent.mkdir(parents=True, exist_ok=True)
                download_remote_file(url, production_path)
                snapshot["production_saved"] = True
            except Exception as exc:
                snapshot["error"] = "production保存失败: %s" % exc
        snapshots.append(snapshot)
    return snapshots


def archive_gt_products(trajectory: TrajectoryResult, snapshots: list[dict[str, Any]]) -> list[dict[str, Any]]:
    final_answer_urls = parse_tos_urls(
        field_text(trajectory.task_fields, "final answer 文件", "final_answer_urls")
    )
    gt_by_filename = {
        filename_from_url(url): url
        for url in final_answer_urls
        if filename_from_url(url)
    }
    for snapshot in snapshots:
        gt_url = gt_by_filename.get(snapshot["filename"], "")
        snapshot["final_answer_url"] = gt_url
        if not gt_url or snapshot.get("gt_production_saved"):
            continue
        gt_production_path = snapshot["gt_production_path"]
        try:
            Path(gt_production_path).parent.mkdir(parents=True, exist_ok=True)
            download_remote_file(gt_url, gt_production_path)
            snapshot["gt_production_saved"] = True
        except Exception as exc:
            prefix = "%s; " % snapshot["error"] if snapshot.get("error") else ""
            snapshot["error"] = "%sgt_production保存失败: %s" % (prefix, exc)
    return snapshots


def archive_file_products_for_judge(trajectory: TrajectoryResult) -> list[dict[str, Any]]:
    snapshots = archive_student_products(trajectory)
    return archive_gt_products(trajectory, snapshots)


archive_file_products_for_llm_judge = archive_file_products_for_judge


def attach_production_archive_payload(
    result: dict[str, Any],
    trajectory: TrajectoryResult,
    student_snapshots: list[dict[str, Any]],
) -> dict[str, Any]:
    payload = dict(result)
    if student_snapshots and not payload.get("production_snapshots"):
        payload["production_snapshots"] = student_snapshots
    if not payload.get("vm_output_listing"):
        payload["vm_output_listing"] = vm_output_listing(trajectory)
    return payload


def read_archived_or_remote_file_content(
    *,
    production_path: str,
    production_saved: bool,
    url: str,
    display_name: str,
) -> str:
    if production_saved and Path(production_path).is_file():
        result = read_file_content(production_path, max_bytes=MAX_FILE_CONTENT_READ_BYTES)
        if result.ok:
            return result.content
        raise RuntimeError(result.error or "读取本地产物失败")
    return read_remote_file_with_content_reader(url, display_name, max_bytes=MAX_FILE_CONTENT_READ_BYTES)


def product_text_from_production_snapshots(
    trajectory: TrajectoryResult,
    production_snapshots: list[dict[str, Any]],
) -> str:
    snapshot_by_filename = {item["filename"]: item for item in production_snapshots}
    parts = []
    for item in filter_output_uploads_by_final_answer_names(trajectory):
        url = item.get("tos_url") or item.get("tos_path") or ""
        name = item.get("relative_path") or Path(str(url)).name or "output"
        filename = output_filename(item) or Path(str(name).replace("\\", "/")).name
        snapshot = snapshot_by_filename.get(filename) or {}
        if output_upload_missing(item):
            parts.append(f"## 文件：{name}\n(文件不存在)")
            continue
        if not url and not snapshot.get("production_saved"):
            continue
        try:
            text = read_archived_or_remote_file_content(
                production_path=snapshot.get("production_path", ""),
                production_saved=bool(snapshot.get("production_saved")),
                url=url,
                display_name=filename or name,
            )
        except Exception as exc:
            text = f"(读取失败: {exc})"
        parts.append(f"## 文件：{name}\n{text[:MAX_FILE_CONTENT_READ_BYTES]}")
    return "\n\n".join(parts) if parts else "（无产物文本）"


class FileProductJudgerMixin:
    def judge_rule_files(self, trajectory: TrajectoryResult, answer_type: str, metric_type: str) -> dict[str, Any]:
        production_snapshots = archive_file_products_for_judge(trajectory)
        snapshot_by_filename = {item["filename"]: item for item in production_snapshots}
        final_answer_urls = parse_tos_urls(
            field_text(trajectory.task_fields, "final answer 文件", "final_answer_urls")
        )
        output_by_filename, filename_errors = sample_outputs_by_filename(trajectory.task_files.output_uploads)
        comparisons = []
        errors = list(trajectory.task_files.errors) + filename_errors
        for index, answer_url in enumerate(final_answer_urls):
            answer_filename = filename_from_url(answer_url)
            sample_item = output_by_filename.get(answer_filename) or {}
            sample_url = sample_item.get("tos_url") or sample_item.get("tos_path") or ""
            snapshot = snapshot_by_filename.get(answer_filename) or {}
            production_path = snapshot.get("production_path") or local_product_paths(
                trajectory.sample_dir,
                sample_item.get("relative_path") or answer_filename,
            )[0]
            gt_production_path = snapshot.get("gt_production_path") or local_product_paths(
                trajectory.sample_dir,
                sample_item.get("relative_path") or answer_filename,
            )[1]
            if output_upload_missing(sample_item):
                comparisons.append({
                    "index": index,
                    "filename": answer_filename,
                    "final_answer_url": answer_url,
                    "sample_url": sample_url,
                    "production_path": production_path,
                    "gt_production_path": gt_production_path,
                    "matched": False,
                })
                continue
            if not sample_url:
                errors.append(f"缺少同名采样输出文件用于对比: filename={answer_filename} final_answer={answer_url}")
                comparisons.append({
                    "index": index,
                    "filename": answer_filename,
                    "final_answer_url": answer_url,
                    "sample_url": "",
                    "production_path": production_path,
                    "gt_production_path": gt_production_path,
                    "matched": False,
                })
                continue
            try:
                if not snapshot.get("production_saved"):
                    raise RuntimeError(snapshot.get("error") or "production未落盘")
                if not snapshot.get("gt_production_saved"):
                    raise RuntimeError(snapshot.get("error") or "gt_production未落盘")
                matched = normalize_compare_bytes(Path(production_path).read_bytes()) == normalize_compare_bytes(Path(gt_production_path).read_bytes())
                comparisons.append({
                    "index": index,
                    "filename": answer_filename,
                    "final_answer_url": answer_url,
                    "sample_url": sample_url,
                    "production_path": production_path,
                    "gt_production_path": gt_production_path,
                    "matched": matched,
                })
            except Exception as exc:
                errors.append(f"规则判分读取文件失败 index={index}: {exc}")
                comparisons.append({
                    "index": index,
                    "filename": answer_filename,
                    "final_answer_url": answer_url,
                    "sample_url": sample_url,
                    "production_path": production_path,
                    "gt_production_path": gt_production_path,
                    "matched": False,
                })
        all_matched = bool(comparisons) and all(item.get("matched") for item in comparisons)
        has_missing_output = any(
            output_upload_missing(output_by_filename.get(filename_from_url(answer_url)) or {})
            for answer_url in final_answer_urls
        )
        if has_missing_output and not all_matched:
            evidence = "规则判分：采样产物文件未生成"
        else:
            evidence = "规则判分：采样输出文件与 final answer 文件%s" % (
                "一致" if all_matched and not errors else "不一致或读取失败"
            )
        return {
            "answer_score": 1 if all_matched and not errors else 0,
            "error": "; ".join(errors) if errors else "NA",
            "evidence": evidence,
            "raw_response": "",
            "answer_type": join_answer_type(answer_type, metric_type),
            "comparisons": comparisons,
            "production_snapshots": production_snapshots,
            "vm_output_listing": vm_output_listing(trajectory),
        }

    def judge_file_content(self, trajectory: TrajectoryResult, answer_type: str, metric_type: str) -> dict[str, Any]:
        production_snapshots = archive_file_products_for_judge(trajectory)
        snapshot_by_filename = {item["filename"]: item for item in production_snapshots}
        file_contents = []
        for item in filter_output_uploads_by_final_answer_names(trajectory):
            url = item.get("tos_url") or item.get("tos_path") or ""
            name = item.get("relative_path") or Path(str(url)).name or "output"
            filename = output_filename(item) or Path(str(name).replace("\\", "/")).name
            snapshot = snapshot_by_filename.get(filename) or {}
            if output_upload_missing(item):
                file_contents.append((name, "(文件不存在)"))
                continue
            if not url and not snapshot.get("production_saved"):
                file_contents.append((name, "(文件不存在)"))
                continue
            try:
                file_contents.append(
                    (
                        name,
                        read_archived_or_remote_file_content(
                            production_path=snapshot.get("production_path", ""),
                            production_saved=bool(snapshot.get("production_saved")),
                            url=url,
                            display_name=filename or name,
                        ),
                    )
                )
            except Exception as exc:
                file_contents.append((name, f"(读取失败: {exc})"))
        if not file_contents:
            return {
                "answer_score": -1,
                "evidence": "无产出文件可判分",
                "answer_type": join_answer_type(answer_type, metric_type),
                "production_snapshots": production_snapshots,
            }
        if all(content == "(文件不存在)" for _, content in file_contents):
            return {
                "answer_score": 0,
                "error": "NA",
                "evidence": "文件产物判分：采样产物文件未生成",
                "raw_response": "",
                "answer_type": join_answer_type(answer_type, metric_type),
                "production_snapshots": production_snapshots,
                "vm_output_listing": vm_output_listing(trajectory),
            }
        raw = self.judge_file_contents(
            file_contents=file_contents,
            reference_response=field_text(trajectory.task_fields, "response_reference"),
        )
        return {
            "answer_score": raw.get("answer_score", 0),
            "error": raw.get("error", "NA"),
            "evidence": raw.get("evidence", ""),
            "raw_response": raw.get("raw_response", ""),
            "answer_type": join_answer_type(answer_type, metric_type),
            "production_snapshots": production_snapshots,
            "vm_output_listing": vm_output_listing(trajectory),
        }

    def judge_file_contents(self, *, file_contents: list[tuple[str, str]], reference_response: str) -> dict[str, Any]:
        if not file_contents:
            return {"status": "failed", "answer_score": 0, "evidence": "", "raw_response": "", "error": "无文件内容可判分"}
        parts = []
        for filename, content in file_contents:
            preview = (content or "")[:50000]
            if len(content or "") > 50000:
                preview += "\n...(内容已截断)"
            parts.append(f"## 文件：{filename}\n{preview}")
        evaluation_points = (
            reference_response.strip()
            if reference_response and isinstance(reference_response, str) and reference_response.strip()
            else "（未提供评估要点）"
        )
        user_text = GT_ANSWER_FILE_CONTENT_USER_PROMPT_TEMPLATE.format(
            evaluation_points=evaluation_points,
            student_answer_text="\n\n".join(parts),
        )
        messages = [
            {"role": "system", "content": GT_ANSWER_SYSTEM_PROMPT},
            {"role": "user", "content": user_text},
        ]
        try:
            raw_content = JudgeModelFactory().create("gemini3_pro").call_model(messages, retry_count=3, delay_seconds=1)
        except Exception as exc:
            return {"status": "failed", "evidence": "", "raw_response": "", "error": str(exc), "answer_score": 0}
        if raw_content == "":
            return {"status": "failed", "evidence": "", "raw_response": "", "error": "模型返回空内容", "answer_score": 0}
        score, evidence = parse_judge_raw_content(raw_content)
        if score is None:
            return {"status": "failed", "evidence": evidence or str(raw_content)[:200], "raw_response": str(raw_content), "error": "无法解析 answer_score", "answer_score": 0}
        return {"status": "success", "evidence": evidence or f"评分：{score}分", "raw_response": str(raw_content), "answer_score": int(score), "error": "NA"}


def sample_outputs_by_filename(output_uploads: list[dict[str, Any]]) -> tuple[dict[str, dict[str, Any]], list[str]]:
    outputs: dict[str, dict[str, Any]] = {}
    errors: list[str] = []
    for item in output_uploads:
        if not item.get("tos_url") and not item.get("tos_path"):
            continue
        filename = output_filename(item)
        if not filename:
            continue
        if filename in outputs:
            errors.append(f"采样输出文件名重复，无法唯一匹配: {filename}")
            continue
        outputs[filename] = item
    return outputs, errors


def output_filename(item: dict[str, Any]) -> str:
    relative_path = str(item.get("relative_path") or "").strip()
    if relative_path:
        return Path(relative_path.replace("\\", "/")).name
    url = item.get("tos_url") or item.get("tos_path") or ""
    return filename_from_url(str(url)) if url else ""
