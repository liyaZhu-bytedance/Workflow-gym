from __future__ import annotations

from typing import Any

from .defaults import (
    judge_api_version,
    judge_base_url,
    judge_model,
    resolve_judge_api_key,
    resolve_provider_from_base_url,
)


class JudgeClient:
    request_kwargs = {"stream": False, "max_tokens": 8192}

    def __init__(
        self,
        *,
        api_key: str = "",
        base_url: str = "",
        model: str = "",
        provider: str = "",
        api_version: str = "",
        default_headers: dict[str, str] | None = None,
    ):
        self.api_key = (api_key or "").strip()
        self.base_url = (base_url or "").strip().rstrip("/")
        self.model = (model or "").strip()
        self.provider = (provider or "").strip()
        self.api_version = (api_version or "").strip()
        self.default_headers = dict(default_headers or {})

    def resolve_api_key(self) -> str:
        return self.api_key or resolve_judge_api_key()

    def resolve_base_url(self) -> str:
        return self.base_url or judge_base_url()

    def resolve_model(self) -> str:
        return self.model or judge_model()

    def resolve_provider(self) -> str:
        if self.provider:
            return self.provider
        return resolve_provider_from_base_url(self.resolve_base_url())

    def call_model(self, messages: list[dict[str, Any]]) -> str:
        api_key = self.resolve_api_key()
        if not api_key:
            raise ValueError("缺少 JUDGE_API_KEY 或 GEMINI31_API_KEY，无法调用 JudgeClient")
        base_url = self.resolve_base_url()
        if not base_url:
            raise ValueError("缺少 JUDGE_BASE_URL，无法调用 JudgeClient")
        model = self.resolve_model()
        if not model:
            raise ValueError("缺少 JUDGE_MODEL，无法调用 JudgeClient")

        provider = self.resolve_provider()
        if provider == "azure_openai":
            return self._call_azure_openai(messages, api_key=api_key, base_url=base_url, model=model)
        if provider == "openai":
            return self._call_openai(messages, api_key=api_key, base_url=base_url, model=model)
        # 未知 provider 默认走 openai
        return self._call_openai(messages, api_key=api_key, base_url=base_url, model=model)

    def _call_openai(
        self,
        messages: list[dict[str, Any]],
        *,
        api_key: str,
        base_url: str,
        model: str,
    ) -> str:
        try:
            from openai import OpenAI  # type: ignore[import-not-found]
        except ImportError as exc:
            raise RuntimeError("缺少 openai 依赖，无法调用 JudgeClient") from exc
        client = OpenAI(api_key=api_key, base_url=base_url)
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            **self.request_kwargs,
        )
        return response.choices[0].message.content or ""

    def _call_azure_openai(
        self,
        messages: list[dict[str, Any]],
        *,
        api_key: str,
        base_url: str,
        model: str,
    ) -> str:
        try:
            from openai import AzureOpenAI  # type: ignore[import-not-found]
        except ImportError as exc:
            raise RuntimeError("缺少 openai 依赖，无法调用 JudgeClient") from exc
        client = AzureOpenAI(
            azure_endpoint=base_url,
            api_key=api_key,
            api_version=self.api_version or judge_api_version(),
            default_headers=self.default_headers,
        )
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            **self.request_kwargs,
        )
        return response.choices[0].message.content or ""


# 兼容旧名称
GeminiJudgeClient = JudgeClient
