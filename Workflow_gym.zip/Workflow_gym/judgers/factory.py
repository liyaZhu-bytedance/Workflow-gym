from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from typing import Any

from .defaults import (
    JUDGE_API_KEY_ENV,
    judge_api_version,
    judge_base_url,
    judge_model,
    resolve_provider_from_base_url,
)


@dataclass(frozen=True)
class JudgeModelConfig:
    name: str
    provider: str
    model: str
    base_url: str
    api_key_env: tuple[str, ...]
    request_kwargs: dict[str, Any] = field(default_factory=dict)
    api_version: str = ""
    default_headers: dict[str, str] = field(default_factory=dict)
    retry_count: int = 1
    delay_seconds: float = 0.0


class JudgeModelClient:
    def __init__(self, config: JudgeModelConfig):
        self.config = config
        self.name = config.name
        self.model = config.model

    def call_model(self, messages: list[dict[str, Any]], *, retry_count: int | None = None, delay_seconds: float | None = None) -> str:
        if not self.config.base_url:
            raise ValueError("缺少 JUDGE_BASE_URL，无法调用判分模型 %s" % self.name)
        if not self.config.model:
            raise ValueError("缺少 JUDGE_MODEL，无法调用判分模型 %s" % self.name)
        api_key = self._api_key()
        last_exc: Exception | None = None
        attempts = max(1, retry_count if retry_count is not None else self.config.retry_count)
        delay = self.config.delay_seconds if delay_seconds is None else delay_seconds
        for attempt in range(attempts):
            try:
                provider = resolve_provider_from_base_url(self.config.base_url)
                if provider == "azure_openai":
                    return self._call_azure_openai(messages, api_key)
                # 未匹配到已知 provider 时默认走 openai
                return self._call_openai(messages, api_key)
            except Exception as exc:
                last_exc = exc
                if attempt + 1 < attempts and delay > 0:
                    time.sleep(delay)
        if last_exc:
            raise last_exc
        return ""

    def _api_key(self) -> str:
        for env_name in self.config.api_key_env:
            value = os.getenv(env_name)
            if value:
                return value
        names = " 或 ".join(self.config.api_key_env)
        raise ValueError(f"缺少 {names}，无法调用判分模型 {self.name}")

    def _call_openai(self, messages: list[dict[str, Any]], api_key: str) -> str:
        try:
            from openai import OpenAI  # type: ignore[import-not-found]
        except ImportError as exc:
            raise RuntimeError("缺少 openai 依赖，无法调用判分模型") from exc
        client = OpenAI(api_key=api_key, base_url=self.config.base_url)
        response = client.chat.completions.create(
            model=self.config.model,
            messages=messages,
            **self.config.request_kwargs,
        )
        return response.choices[0].message.content or ""

    def _call_azure_openai(self, messages: list[dict[str, Any]], api_key: str) -> str:
        try:
            from openai import AzureOpenAI  # type: ignore[import-not-found]
        except ImportError as exc:
            raise RuntimeError("缺少 openai 依赖，无法调用判分模型") from exc
        client = AzureOpenAI(
            azure_endpoint=self.config.base_url,
            api_key=api_key,
            api_version=self.config.api_version or judge_api_version(),
            default_headers=self.config.default_headers,
        )
        response = client.chat.completions.create(
            model=self.config.model,
            messages=messages,
            **self.config.request_kwargs,
        )
        return response.choices[0].message.content or ""


def _build_gemini3_pro_judge_config() -> JudgeModelConfig:
    return JudgeModelConfig(
        name="gemini3_pro",
        provider="openai",
        model=judge_model(),
        base_url=judge_base_url(),
        api_key_env=JUDGE_API_KEY_ENV,
        request_kwargs={
            "stream": False,
            "max_tokens": 4096,
        },
        api_version=judge_api_version(),
        retry_count=3,
        delay_seconds=1,
    )


class JudgeModelFactory:
    def __init__(self):
        self._configs: dict[str, JudgeModelConfig] = {}

    def register(self, config: JudgeModelConfig) -> None:
        self._configs[config.name] = config

    def create(self, name: str) -> JudgeModelClient:
        if name == "gemini3_pro":
            return JudgeModelClient(_build_gemini3_pro_judge_config())
        config = self._configs.get(name)
        if not config:
            raise ValueError(f"unknown judge model: {name}")
        return JudgeModelClient(config)
