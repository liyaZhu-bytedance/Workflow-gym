"""
本地文件内容读取：按扩展名分发到不同读取器，供 open_workflowgym 判分使用。
已在 _READERS 注册的扩展名：走对应读取器。
未注册扩展名：仅当列入 _TEXT_FALLBACK_WHITELIST 时按纯文本读取（与 .txt 相同，含编码探测）；
其余扩展名及无后缀文件不读取正文（返回 ok=False）。
典型未读：.png / .zip / .mp4 / .bin 等（未注册且不在下方白名单则无法读取内容）。
.docx：python-docx；.doc：先试 docx（误扩展名），再 antiword / LibreOffice 转 txt。
新增格式：实现读取函数后通过 register_reader(".ext", fn) 注册；或把扩展名加入 _TEXT_FALLBACK_WHITELIST。
"""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from typing import Callable, Dict, Optional

import chardet
import pandas as pd
from bs4 import BeautifulSoup
from charset_normalizer import from_bytes as cn_from_bytes
from docx import Document
from openpyxl import load_workbook
from pptx import Presentation
from pypdf import PdfReader


@dataclass
class FileReadResult:
    """文件读取结果：成功时 error 为 None。"""

    ok: bool
    content: str
    error: Optional[str]
    path: str
    extension: str


ReaderFn = Callable[[str, Optional[int]], str]


def _safe_close_fileobj(fobj: Optional[object]) -> None:
    if fobj is None:
        return
    try:
        close = getattr(fobj, "close", None)
        if callable(close):
            close()
    except Exception:
        pass


def _truncate_utf8_text(s: str, max_bytes: Optional[int]) -> str:
    """按 UTF-8 字节长度截断字符串，避免超长内容占满内存。"""
    if max_bytes is None or max_bytes <= 0:
        return s
    data = s.encode("utf-8", errors="replace")
    if len(data) <= max_bytes:
        return s
    cut = data[:max_bytes].decode("utf-8", errors="replace")
    return cut + "\n...(内容已按 max_bytes 截断)"


def _decode_text_bytes(data: bytes) -> str:
    """
    将原始字节解码为 str。无明确 charset 声明时只能启发式判断，无法 100% 保证与源文件一致。

    策略顺序（简述）：
    1. UTF-16 LE/BE（BOM）
    2. UTF-8（含 BOM，utf-8-sig 严格解码）
    3. charset-normalizer：取其最佳匹配（对多语言常比单独 chardet 稳）
    4. chardet：仅在置信度足够时使用，先 strict 再 replace
    5. 常见中文编码 strict 轮询（gb18030 / gbk / big5），避免误用 replace 把任意字节「糊成」错误汉字
    6. UTF-8 replace、最后 latin-1（单字节映射，总能出字但可能是乱码）

    说明：纯二进制或高噪声内容仍可能被误判；需要绝对可靠时应由文件格式或元数据指定编码。
    """
    if not data:
        return ""

    if len(data) >= 2:
        if data.startswith(b"\xff\xfe"):
            try:
                return data.decode("utf-16-le", errors="replace")
            except Exception:
                pass
        if data.startswith(b"\xfe\xff"):
            try:
                return data.decode("utf-16-be", errors="replace")
            except Exception:
                pass

    try:
        return data.decode("utf-8-sig", errors="strict")
    except UnicodeDecodeError:
        pass

    try:
        matches = cn_from_bytes(data)
        best = matches.best()
        if best is not None:
            out = getattr(best, "string", None)
            if isinstance(out, str):
                return out
            return str(best)
    except Exception:
        pass

    try:
        sample = data[: min(len(data), 512 * 1024)]
        det = chardet.detect(sample) or {}
        enc = (det.get("encoding") or "").strip()
        conf = float(det.get("confidence") or 0.0)
        if enc and conf >= 0.55:
            try:
                return data.decode(enc, errors="strict")
            except (UnicodeDecodeError, LookupError):
                try:
                    return data.decode(enc, errors="replace")
                except (UnicodeDecodeError, LookupError):
                    pass
    except Exception:
        pass

    for enc in ("gb18030", "gbk", "cp936", "big5"):
        try:
            return data.decode(enc, errors="strict")
        except (UnicodeDecodeError, LookupError):
            continue

    try:
        return data.decode("utf-8", errors="replace")
    except Exception:
        pass
    return data.decode("latin-1", errors="replace")


def read_text_like_file(abs_path: str, max_bytes: Optional[int]) -> str:
    """读取纯文本类文件（txt/md/csv/log 等），自动探测编码。"""
    f = None
    try:
        f = open(abs_path, "rb")
        raw = f.read()
        if max_bytes is not None and max_bytes > 0 and len(raw) > max_bytes:
            raw = raw[:max_bytes]
        return _decode_text_bytes(raw)
    except Exception as e:
        raise RuntimeError(f"读取文本文件失败: {e}") from e
    finally:
        _safe_close_fileobj(f)


def read_html_file(abs_path: str, max_bytes: Optional[int]) -> str:
    """读取 HTML：先按字节正确解码，再提取可见文本（避免标签干扰语义时可读性）。"""
    f = None
    try:
        f = open(abs_path, "rb")
        raw = f.read()
        if max_bytes is not None and max_bytes > 0 and len(raw) > max_bytes:
            raw = raw[:max_bytes]
        html = _decode_text_bytes(raw)
        try:
            soup = BeautifulSoup(html, "html.parser")
            text = soup.get_text(separator="\n", strip=False)
        except Exception:
            text = html
        return _truncate_utf8_text(text, max_bytes)
    except Exception as e:
        raise RuntimeError(f"读取 HTML 失败: {e}") from e
    finally:
        _safe_close_fileobj(f)


def read_pdf_file(abs_path: str, max_bytes: Optional[int]) -> str:
    """提取 PDF 文本（pypdf）。"""
    try:
        with open(abs_path, "rb") as f:
            reader = PdfReader(f)
            parts: list[str] = []
            for page in reader.pages:
                try:
                    text = page.extract_text() or ""
                except Exception:
                    text = ""
                parts.append(text)
        return _truncate_utf8_text("\n".join(parts), max_bytes)
    except Exception as e:
        raise RuntimeError(f"读取 PDF 失败: {e}") from e


EXCEL_OPENXML_EXTENSIONS = frozenset(
    {
        ".xlsx",
        ".xlsm",
        ".xltx",
        ".xltm",
    }
)


def read_xlsx_file(abs_path: str, max_bytes: Optional[int]) -> str:
    """读取 Excel Open XML 工作簿/模板（.xlsx/.xlsm/.xltx/.xltm，openpyxl）。"""
    wb = None
    try:
        wb = load_workbook(filename=abs_path, read_only=True, data_only=True)
        lines: list[str] = []
        for sheet in wb.worksheets:
            lines.append(f"## Sheet: {sheet.title}")
            for row in sheet.iter_rows(values_only=True):
                cells = []
                for cell in row:
                    if cell is None:
                        cells.append("")
                    else:
                        cells.append(str(cell).replace("\n", " "))
                lines.append("\t".join(cells))
        return _truncate_utf8_text("\n".join(lines), max_bytes)
    except Exception as e:
        raise RuntimeError(f"读取 Excel(xlsx) 失败: {e}") from e
    finally:
        if wb is not None:
            try:
                wb.close()
            except Exception:
                pass


def read_xls_file(abs_path: str, max_bytes: Optional[int]) -> str:
    """读取旧版 xls（优先 pandas + xlrd，不可用时给出明确提示）。"""
    try:
        sheets = pd.read_excel(abs_path, sheet_name=None, engine="xlrd")
        lines: list[str] = []
        for name, df in sheets.items():
            lines.append(f"## Sheet: {name}")
            lines.append(df.to_csv(index=False, sep="\t"))
        return _truncate_utf8_text("\n".join(lines), max_bytes)
    except Exception as e:
        raise RuntimeError(
            f"读取 xls 失败（需安装 xlrd 或将文件转为 xlsx）: {e}"
        ) from e


def read_pptx_file(abs_path: str, max_bytes: Optional[int]) -> str:
    """读取 pptx 中的文本。"""
    try:
        prs = Presentation(abs_path)
        parts: list[str] = []
        for i, slide in enumerate(prs.slides, start=1):
            parts.append(f"## Slide {i}")
            for shape in slide.shapes:
                if not hasattr(shape, "text"):
                    continue
                text = (shape.text or "").strip()
                if text:
                    parts.append(text)
        return _truncate_utf8_text("\n".join(parts), max_bytes)
    except Exception as e:
        raise RuntimeError(f"读取 PPTX 失败: {e}") from e


def read_ppt_legacy_file(abs_path: str, max_bytes: Optional[int]) -> str:
    """旧版 .ppt 二进制格式，python-pptx 不支持。"""
    del max_bytes
    raise RuntimeError(
        "不支持直接读取 .ppt（二进制格式），请将文件另存为 .pptx 后再读取。"
    )


def _text_from_docx_document(doc: object) -> str:
    """从 python-docx Document 抽取段落与表格单元格文本。"""
    parts: list[str] = []
    for paragraph in doc.paragraphs:
        text = (paragraph.text or "").strip()
        if text:
            parts.append(text)
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                text = (cell.text or "").strip()
                if text:
                    parts.append(text)
    return "\n".join(parts)


def read_docx_file(abs_path: str, max_bytes: Optional[int]) -> str:
    """读取 Office Open XML Word 文档（.docx）。"""
    try:
        doc = Document(abs_path)
        text = _text_from_docx_document(doc)
        return _truncate_utf8_text(text, max_bytes)
    except Exception as e:
        raise RuntimeError(f"读取 DOCX 失败: {e}") from e


def _read_doc_via_antiword(abs_path: str) -> Optional[str]:
    exe = shutil.which("antiword")
    if not exe:
        return None
    try:
        proc = subprocess.run(
            [exe, abs_path],
            capture_output=True,
            timeout=120,
        )
        if proc.returncode != 0 or not proc.stdout:
            return None
        return proc.stdout.decode("utf-8", errors="replace")
    except Exception:
        return None


def _read_doc_via_libreoffice(abs_path: str) -> Optional[str]:
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        return None
    try:
        with tempfile.TemporaryDirectory(prefix="wg_doc_txt_") as temp_dir:
            proc = subprocess.run(
                [
                    soffice,
                    "--headless",
                    "--convert-to",
                    "txt:Text",
                    "--outdir",
                    temp_dir,
                    abs_path,
                ],
                capture_output=True,
                timeout=180,
            )
            if proc.returncode != 0:
                return None
            base = os.path.splitext(os.path.basename(abs_path))[0]
            candidate = os.path.join(temp_dir, base + ".txt")
            if os.path.isfile(candidate):
                with open(candidate, "rb") as f:
                    raw = f.read()
                return _decode_text_bytes(raw)
            for name in os.listdir(temp_dir):
                if name.lower().endswith(".txt"):
                    with open(os.path.join(temp_dir, name), "rb") as f:
                        raw = f.read()
                    return _decode_text_bytes(raw)
    except Exception:
        return None
    return None


def read_doc_file(abs_path: str, max_bytes: Optional[int]) -> str:
    """
    读取旧版 Word 二进制 .doc，或误标扩展名的 docx。

    顺序：python-docx（实为 docx）→ antiword → LibreOffice/soffice 转 txt。
    """
    try:
        doc = Document(abs_path)
        text = _text_from_docx_document(doc)
        return _truncate_utf8_text(text, max_bytes)
    except Exception:
        pass
    text = _read_doc_via_antiword(abs_path)
    if text is not None:
        return _truncate_utf8_text(text, max_bytes)
    text = _read_doc_via_libreoffice(abs_path)
    if text is not None:
        return _truncate_utf8_text(text, max_bytes)
    raise RuntimeError(
        "读取 .doc 失败：当前环境未安装 antiword / LibreOffice，"
        "或文件已损坏。可将文件另存为 .docx 后重试。"
    )


_READERS: Dict[str, ReaderFn] = {
    ".txt": read_text_like_file,
    ".md": read_text_like_file,
    ".markdown": read_text_like_file,
    ".csv": read_text_like_file,
    ".log": read_text_like_file,
    ".json": read_text_like_file,
    ".xml": read_text_like_file,
    ".ini": read_text_like_file,
    ".yaml": read_text_like_file,
    ".yml": read_text_like_file,
    ".html": read_html_file,
    ".htm": read_html_file,
    ".pdf": read_pdf_file,
    ".xls": read_xls_file,
    ".pptx": read_pptx_file,
    ".ppt": read_ppt_legacy_file,
    ".docx": read_docx_file,
    ".doc": read_doc_file,
}
_READERS.update({extension: read_xlsx_file for extension in EXCEL_OPENXML_EXTENSIONS})

_TEXT_FALLBACK_WHITELIST: frozenset[str] = frozenset(
    {
        ".sql",
        ".bib",
        ".arff",
        ".cif",
        ".pmml",
        ".cue",
        ".pir",
        ".aln",
        ".gde",
        ".pdb",
        ".dnd",
        ".qscores",
        ".ph",
        ".dtstyle",
        ".phb",
    }
)


def register_reader(extension: str, reader_fn: ReaderFn) -> None:
    """
    注册自定义扩展名读取函数。
    extension: 如 '.docx' 或 'docx'（会规范为前导点、小写）。
    reader_fn: (abs_path, max_bytes) -> str
    """
    ext = extension.strip().lower()
    if not ext.startswith("."):
        ext = "." + ext
    _READERS[ext] = reader_fn


def read_file_content(
    abs_path: str,
    max_bytes: Optional[int] = None,
) -> FileReadResult:
    """
    按扩展名分发读取本地文件，返回 UTF-8 字符串内容。

    已在 _READERS 中的后缀：使用对应读取器。
    未注册后缀：仅当在 _TEXT_FALLBACK_WHITELIST 中时按纯文本读取；无后缀或其它未白名单后缀不读取正文（ok=False）。
    如 .png、.zip、.mp4、.bin 等未注册时均无法读取内容。
    """
    path = os.path.abspath(os.path.normpath(abs_path))
    ext = ""
    try:
        if not os.path.isfile(path):
            return FileReadResult(
                ok=False,
                content="",
                error=f"文件不存在或不是文件: {path}",
                path=path,
                extension=ext,
            )
        ext = os.path.splitext(path)[1].lower()
        reader = _READERS.get(ext) if ext else None
        if reader is None:
            if ext and ext in _TEXT_FALLBACK_WHITELIST:
                reader = read_text_like_file
            else:
                label = ext if ext else "(无后缀)"
                return FileReadResult(
                    ok=False,
                    content="",
                    error=(
                        f"扩展名未在白名单，未读取文件内容: {label}。"
                        "请使用 register_reader 注册读取器，或将扩展名加入 _TEXT_FALLBACK_WHITELIST。"
                    ),
                    path=path,
                    extension=ext,
                )
        content = reader(path, max_bytes)
        return FileReadResult(
            ok=True, content=content, error=None, path=path, extension=ext
        )
    except Exception as e:
        return FileReadResult(
            ok=False,
            content="",
            error=str(e),
            path=path,
            extension=ext,
        )


def read_file_content_or_raise(abs_path: str, max_bytes: Optional[int] = None) -> str:
    """成功返回 content；失败抛出 RuntimeError。"""
    result = read_file_content(abs_path, max_bytes=max_bytes)
    if not result.ok:
        raise RuntimeError(result.error or "未知错误")
    return result.content
