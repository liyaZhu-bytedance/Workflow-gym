from __future__ import annotations

from dataclasses import dataclass


@dataclass
class UploadResult:
    local_path: str
    file_token: str = ""
    status: str = "pending"
    error: str = ""


class AttachmentUploader:
    """Boundary for Feishu attachment uploads.

    The real Feishu upload implementation should be injected later. The scaffold
    returns local-path placeholders so Writer can be exercised in dry-run mode.
    """

    def __init__(self, feishu_client=None):
        self.feishu_client = feishu_client

    def upload(self, spreadsheet_token: str, local_path: str) -> UploadResult:
        if not self.feishu_client:
            return UploadResult(local_path=local_path, file_token="", status="dry_run")
        try:
            file_token = self.feishu_client.upload_attachment(spreadsheet_token, local_path)
            return UploadResult(local_path=local_path, file_token=file_token, status="uploaded")
        except Exception as exc:
            return UploadResult(local_path=local_path, status="failed", error="%s" % exc)

