from __future__ import annotations

import sqlite3
import tempfile
from pathlib import Path

from .main import main


def run_smoke_test() -> None:
    with tempfile.TemporaryDirectory(prefix="workflowgym_smoke_") as temp_dir:
        output_root = str(Path(temp_dir) / "run")
        exit_code = main(
            [
                "--dry-run",
                "local",
                "--sampleNum",
                "1",
                "--stepNum",
                "1",
                "--output-root",
                output_root,
                "--instance-ids",
                "i-smoke-1",
            ]
        )
        if exit_code != 0:
            raise AssertionError("main returned non-zero exit code: %s" % exit_code)
        db_path = Path(output_root) / "workflowgym_state.db"
        conn = sqlite3.connect(str(db_path))
        try:
            task_status = conn.execute("SELECT status FROM tasks WHERE task_id='task_demo'").fetchone()[0]
            sample_status, last_step = conn.execute(
                "SELECT status, last_step FROM samples WHERE task_id='task_demo' AND sample_index=1"
            ).fetchone()
            pending_count = conn.execute("SELECT COUNT(*) FROM outbox_events WHERE status!='done'").fetchone()[0]
        finally:
            conn.close()
        assert task_status == "synced", task_status
        assert sample_status == "scored", sample_status
        assert last_step == 0, last_step
        assert pending_count == 0, pending_count


if __name__ == "__main__":
    run_smoke_test()
    print("workflowgym smoke test passed")

