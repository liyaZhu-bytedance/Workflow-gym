from __future__ import annotations

import json
import mimetypes
import os
import re
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
from typing import Any


FEISHU_OPEN_BASE_URL = ""


class FeishuHTTPError(ValueError):
    def __init__(self, status_code: int, body: str):
        super().__init__("飞书 HTTP 调用失败 %s: %s" % (status_code, body))
        self.status_code = status_code
        self.body = body
        try:
            self.response = json.loads(body)
        except ValueError:
            self.response = {}


class FeishuClient:
    """Small Feishu boundary.

    Real API calls can reuse patterns from batch_image_copy_to_feishu.py. This
    scaffold keeps side effects isolated and dry-run friendly.
    """

    def __init__(
        self,
        app_id: str = "",
        app_secret: str = "",
        dry_run: bool = True,
        base_url: str = FEISHU_OPEN_BASE_URL,
        folder_token: str = "",
    ):
        self.app_id = app_id or os.getenv("APP_ID", "")
        self.app_secret = app_secret or os.getenv("APP_SECRET", "")
        self.dry_run = dry_run
        self.base_url = base_url.rstrip("/")
        self.folder_token = folder_token or os.getenv("FEISHU_FOLDER_TOKEN", "")
        self.app_access_token = ""
        if not self.dry_run:
            if not self.app_id or not self.app_secret:
                raise ValueError("缺少 APP_ID 或 APP_SECRET，无法访问飞书")
            self.app_access_token = self.get_app_access_token()

    def get_app_access_token(self) -> str:
        response = self.request_json(
            "POST",
            "/auth/v3/app_access_token/internal",
            {"app_id": self.app_id, "app_secret": self.app_secret},
            auth=False,
        )
        data = response.get("data") or {}
        token = (
            response.get("app_access_token")
            or response.get("tenant_access_token")
            or data.get("app_access_token")
            or data.get("tenant_access_token")
        )
        if not token:
            raise ValueError("获取飞书 app_access_token 失败: %s" % response)
        return token

    def refresh_app_access_token(self) -> None:
        self.app_access_token = self.get_app_access_token()

    def is_auth_error_response(self, response: dict[str, Any]) -> bool:
        return response.get("code") == 99991663

    def is_auth_error(self, exc: Exception) -> bool:
        if isinstance(exc, FeishuHTTPError):
            return self.is_auth_error_response(exc.response)
        return False

    def request_json(self, method: str, path: str, payload: dict[str, Any] | None = None, auth: bool = True) -> dict[str, Any]:
        if self.dry_run:
            return {"code": 0, "data": {}}
        try:
            return self._request_json_once(method, path, payload, auth)
        except Exception as exc:
            if auth and self.is_auth_error(exc):
                self.refresh_app_access_token()
                return self._request_json_once(method, path, payload, auth)
            raise

    def _request_json_once(self, method: str, path: str, payload: dict[str, Any] | None = None, auth: bool = True) -> dict[str, Any]:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8") if payload is not None else None
        headers = {"Content-Type": "application/json; charset=utf-8"}
        if auth:
            headers["Authorization"] = "Bearer %s" % self.app_access_token
        request = urllib.request.Request(
            self.base_url + path,
            data=data,
            headers=headers,
            method=method,
        )
        response = self.open_request(request)
        code = response.get("code", 0)
        if code not in (0, None):
            raise ValueError("飞书接口调用失败 %s %s: %s" % (method, path, response))
        return response

    def open_request(self, request: urllib.request.Request) -> dict[str, Any]:
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                body = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise FeishuHTTPError(exc.code, body)
        if not body:
            return {}
        try:
            return json.loads(body)
        except ValueError:
            raise ValueError("飞书接口返回非 JSON 内容: %s" % body)

    def create_or_get_report(self, title: str) -> dict[str, str]:
        if self.dry_run:
            return {
                "spreadsheet_token": "dry_run_spreadsheet",
                "spreadsheet_url": "dry-run://spreadsheet",
                "validation_sheet_id": "validation",
                "samples_sheet_id": "samples",
                "agent_config_sheet_id": "agent_config",
            }
        spreadsheet_url = os.getenv("FEISHU_REPORT_SPREADSHEET_URL", "").strip()
        spreadsheet_token = os.getenv("FEISHU_REPORT_SPREADSHEET_TOKEN", "").strip()
        if spreadsheet_url and not spreadsheet_token:
            spreadsheet_token = spreadsheet_token_from_url(spreadsheet_url)
        if spreadsheet_token:
            spreadsheet_url = spreadsheet_url 
            print("复用飞书报表: %s" % spreadsheet_url)
        else:
            spreadsheet_token, spreadsheet_url = self.create_spreadsheet(title)
        admin_member_id = os.getenv("FEISHU_SHEET_ADMIN_MEMBER_ID", "").strip()
        if admin_member_id:
            try:
                self.grant_admin_permission(spreadsheet_token, admin_member_id)
                print("飞书电子表格已授予管理员权限: %s" % admin_member_id)
            except Exception as exc:
                print("授权飞书电子表格管理员失败，继续写入表格: %s" % exc)
        return {
            "spreadsheet_token": spreadsheet_token,
            "spreadsheet_url": spreadsheet_url,
            "validation_sheet_id": self.get_or_add_sheet(spreadsheet_token, "validation"),
            "samples_sheet_id": self.get_or_add_sheet(spreadsheet_token, "samples"),
            "agent_config_sheet_id": self.get_or_add_sheet(spreadsheet_token, "agent_config"),
        }

    def create_spreadsheet(self, title: str) -> tuple[str, str]:
        payload: dict[str, Any] = {"title": title}
        if self.folder_token:
            payload["folder_token"] = self.folder_token
        response = self.request_json("POST", "/sheets/v3/spreadsheets", payload)
        data = response.get("data") or {}
        spreadsheet = data.get("spreadsheet") or {}
        token = spreadsheet.get("spreadsheet_token") or data.get("spreadsheet_token") or data.get("token")
        url = spreadsheet.get("url") or data.get("url")
        if not token:
            raise ValueError("创建飞书电子表格失败，响应中没有 spreadsheet_token: %s" % response)
        return token, url

    def grant_admin_permission(self, spreadsheet_token: str, member_id: str) -> dict[str, Any]:
        payload = {
            "member_type": "email",
            "member_id": member_id,
            "perm": "full_access",
        }
        return self.request_json(
            "POST",
            "/drive/v1/permissions/%s/members?type=sheet" % spreadsheet_token,
            payload,
        )

    def grant_docx_admin_permission(self, document_id: str, member_id: str) -> dict[str, Any]:
        payload = {
            "member_type": "email",
            "member_id": member_id,
            "perm": "full_access",
        }
        return self.request_json(
            "POST",
            "/drive/v1/permissions/%s/members?type=docx" % document_id,
            payload,
        )

    def upload_import_source_file(
        self,
        file_path: str,
        file_name: str = "",
        file_extension: str = "md",
        obj_type: str = "docx",
    ) -> str:
        if self.dry_run:
            return "dry_run_import_file_token"
        file_name = file_name or os.path.basename(file_path)
        fields = {
            "file_name": file_name,
            "parent_type": "ccm_import_open",
            "size": str(os.path.getsize(file_path)),
            "extra": json.dumps(
                {"obj_type": obj_type, "file_extension": file_extension},
                ensure_ascii=False,
            ),
        }
        body, content_type = build_multipart_body(fields, file_path, file_name)
        request = urllib.request.Request(
            self.base_url + "/drive/v1/medias/upload_all",
            data=body,
            headers={
                "Authorization": "Bearer %s" % self.app_access_token,
                "Content-Type": content_type,
            },
            method="POST",
        )
        response = self.open_request(request)
        code = response.get("code", 0)
        if code not in (0, None):
            raise ValueError("上传 Markdown 导入素材失败: %s" % response)
        data = response.get("data") or {}
        token = data.get("file_token") or response.get("file_token")
        if not token:
            raise ValueError("上传 Markdown 导入素材失败，响应中没有 file_token: %s" % response)
        return token

    def create_import_task(
        self,
        file_token: str,
        file_extension: str = "md",
        obj_type: str = "docx",
        file_name: str = "",
        folder_token: str = "",
    ) -> str:
        if self.dry_run:
            return "dry_run_import_ticket"
        point: dict[str, Any] = {"mount_type": 1, "mount_key": ""}
        if folder_token:
            point = {"mount_type": 1, "mount_key": folder_token}
        payload: dict[str, Any] = {
            "file_extension": file_extension,
            "file_token": file_token,
            "type": obj_type,
            "point": point,
        }
        if file_name:
            payload["file_name"] = file_name
        response = self.request_json("POST", "/drive/v1/import_tasks", payload)
        data = response.get("data") or {}
        ticket = data.get("ticket") or response.get("ticket")
        if not ticket:
            raise ValueError("创建导入任务失败，响应中没有 ticket: %s" % response)
        return ticket

    def get_import_task_result(self, ticket: str) -> dict[str, Any]:
        response = self.request_json("GET", "/drive/v1/import_tasks/%s" % ticket)
        return response.get("data") or response

    def wait_import_task(
        self,
        ticket: str,
        timeout_seconds: int = 180,
        poll_seconds: int = 2,
    ) -> dict[str, Any]:
        import time

        deadline = time.time() + timeout_seconds
        last_result: dict[str, Any] = {}
        while time.time() < deadline:
            last_result = self.get_import_task_result(ticket)
            result = last_result.get("result") or {}
            status_raw = result.get("job_status")
            if status_raw is None:
                status_raw = last_result.get("job_status")
            status = int(status_raw if status_raw is not None else -1)
            if status in (1, 2):
                time.sleep(poll_seconds)
                continue
            if status == 0:
                return last_result
            raise ValueError("Markdown 导入失败: %s" % last_result)
        raise TimeoutError("等待 Markdown 导入超时: ticket=%s last=%s" % (ticket, last_result))

    def import_markdown_as_docx(
        self,
        md_path: str,
        title: str = "",
        folder_token: str = "",
    ) -> tuple[str, str]:
        path = Path(md_path)
        if not path.is_file():
            raise FileNotFoundError("Markdown 文件不存在: %s" % md_path)
        file_extension = path.suffix.lstrip(".").lower() or "md"
        if file_extension not in {"md", "markdown", "mark"}:
            file_extension = "md"
        file_token = self.upload_import_source_file(
            str(path),
            file_name=path.name,
            file_extension=file_extension,
            obj_type="docx",
        )
        ticket = self.create_import_task(
            file_token,
            file_extension=file_extension,
            obj_type="docx",
            file_name=title or path.stem,
            folder_token=folder_token or self.folder_token,
        )
        import_result = self.wait_import_task(ticket)
        result = import_result.get("result") or {}
        document_id = str(result.get("token") or result.get("doc_token") or "")
        url = str(result.get("url") or "")
        if not document_id:
            raise ValueError("Markdown 导入成功但未返回 document_id: %s" % import_result)
        if not url:
            url = ""
        return document_id, url

    def query_first_sheet_id(self, spreadsheet_token: str) -> str:
        response = self.request_json("GET", "/sheets/v3/spreadsheets/%s/sheets/query" % spreadsheet_token)
        data = response.get("data") or {}
        sheets = data.get("sheets") or []
        if not sheets:
            raise ValueError("飞书电子表格中没有 sheet: %s" % response)
        return sheets[0].get("sheet_id") or sheets[0].get("sheetId")

    def add_sheet(self, spreadsheet_token: str, title: str) -> str:
        payload = {"requests": [{"addSheet": {"properties": {"title": title}}}]}
        response = self.request_json(
            "POST",
            "/sheets/v2/spreadsheets/%s/sheets_batch_update" % spreadsheet_token,
            payload,
        )
        replies = (response.get("data") or {}).get("replies") or response.get("replies") or []
        for reply in replies:
            properties = (
                reply.get("addSheet", {}).get("properties")
                or reply.get("add_sheet", {}).get("properties")
                or {}
            )
            sheet_id = properties.get("sheetId") or properties.get("sheet_id")
            if sheet_id:
                return sheet_id
        # Fallback for API variants: query sheets and match by title.
        response = self.request_json("GET", "/sheets/v3/spreadsheets/%s/sheets/query" % spreadsheet_token)
        for sheet in (response.get("data") or {}).get("sheets") or []:
            if sheet.get("title") == title:
                return sheet.get("sheet_id") or sheet.get("sheetId")
        raise ValueError("创建 sheet 失败，未返回 sheet_id: %s" % response)

    def get_or_add_sheet(self, spreadsheet_token: str, title: str) -> str:
        response = self.request_json("GET", "/sheets/v3/spreadsheets/%s/sheets/query" % spreadsheet_token)
        for sheet in (response.get("data") or {}).get("sheets") or []:
            if sheet.get("title") == title:
                return sheet.get("sheet_id") or sheet.get("sheetId")
        return self.add_sheet(spreadsheet_token, title)

    def resolve_wiki_spreadsheet_token(self, wiki_token: str) -> str:
        response = self.request_json("GET", "/wiki/v2/spaces/get_node?token=%s" % urllib.parse.quote(wiki_token, safe=""))
        data = response.get("data") or {}
        node = data.get("node") or data
        obj_token = node.get("obj_token") or node.get("objToken") or node.get("token")
        if not obj_token:
            raise ValueError("解析 wiki 表格 token 失败: %s" % response)
        return obj_token

    def read_values(self, spreadsheet_token: str, cell_range: str) -> list[list[Any]]:
        if self.dry_run:
            return []
        encoded_range = urllib.parse.quote(cell_range, safe="")
        response = self.request_json(
            "GET",
            "/sheets/v2/spreadsheets/%s/values/%s" % (spreadsheet_token, encoded_range),
        )
        data = response.get("data") or {}
        value_range = data.get("valueRange") or data.get("value_range") or {}
        return value_range.get("values") or data.get("values") or response.get("values") or []

    def write_values(self, spreadsheet_token: str, sheet_id: str, start_cell: str, values: list[list[Any]]) -> None:
        if self.dry_run:
            return None
        if not values:
            return None
        values = normalize_sheet_values(values)
        end_cell = offset_cell(start_cell, len(values), len(values[0]) if values else 1)
        payload = {
            "valueRanges": [
                {
                    "range": "%s!%s:%s" % (sheet_id, start_cell, end_cell),
                    "values": values,
                }
            ]
        }
        self.request_json(
            "POST",
            "/sheets/v2/spreadsheets/%s/values_batch_update" % spreadsheet_token,
            payload,
        )
        return None

    def write_file_cell(self, spreadsheet_token: str, sheet_id: str, cell: str, file_token: str) -> None:
        if self.dry_run:
            return None
        payload = {
            "value_ranges": [
                {
                    "range": "%s!%s:%s" % (sheet_id, cell, cell),
                    "values": [
                        [
                            [
                                {
                                    "type": "file",
                                    "file": {"file_token": file_token},
                                }
                            ]
                        ]
                    ],
                }
            ]
        }
        self.request_json(
            "POST",
            "/sheets/v3/spreadsheets/%s/sheets/%s/values/batch_update?user_id_type=open_id"
            % (spreadsheet_token, sheet_id),
            payload,
        )
        return None

    def set_cells_background(
        self,
        spreadsheet_token: str,
        ranges: list[str],
        back_color: str = "#ffccc7",
    ) -> None:
        if self.dry_run or not ranges:
            return None
        payload = {
            "data": [
                {
                    "ranges": ranges,
                    "style": {
                        "backColor": back_color,
                    },
                }
            ]
        }
        self.request_json(
            "PUT",
            "/sheets/v2/spreadsheets/%s/styles_batch_update" % spreadsheet_token,
            payload,
        )
        return None

    def upload_attachment(self, spreadsheet_token: str, file_path: str, file_name: str = "") -> str:
        if self.dry_run:
            return ""
        file_name = file_name or os.path.basename(file_path)
        try:
            return self.upload_media(spreadsheet_token, file_path, file_name, parent_type="sheet")
        except Exception:
            return self.upload_media(
                spreadsheet_token,
                file_path,
                file_name,
                parent_type="sheet_file",
                extra={"drive_route_token": spreadsheet_token},
            )

    def upload_media(
        self,
        spreadsheet_token: str,
        file_path: str,
        file_name: str,
        parent_type: str,
        extra: dict[str, Any] | None = None,
    ) -> str:
        fields = {
            "file_name": file_name,
            "parent_type": parent_type,
            "parent_node": spreadsheet_token,
            "size": str(os.path.getsize(file_path)),
        }
        if extra:
            fields["extra"] = json.dumps(extra, ensure_ascii=False)
        body, content_type = build_multipart_body(fields, file_path, file_name)
        request = urllib.request.Request(
            self.base_url + "/drive/v1/medias/upload_all",
            data=body,
            headers={
                "Authorization": "Bearer %s" % self.app_access_token,
                "Content-Type": content_type,
            },
            method="POST",
        )
        try:
            response = self.open_request(request)
        except Exception as exc:
            if self.is_auth_error(exc):
                self.refresh_app_access_token()
                request = urllib.request.Request(
                    self.base_url + "/drive/v1/medias/upload_all",
                    data=body,
                    headers={
                        "Authorization": "Bearer %s" % self.app_access_token,
                        "Content-Type": content_type,
                    },
                    method="POST",
                )
                response = self.open_request(request)
            else:
                raise
        code = response.get("code", 0)
        if code not in (0, None):
            raise ValueError("上传飞书附件失败: %s" % response)
        data = response.get("data") or {}
        token = data.get("file_token") or response.get("file_token")
        if not token:
            raise ValueError("上传飞书附件失败，响应中没有 file_token: %s" % response)
        return token


def offset_cell(start_cell: str, row_count: int, column_count: int) -> str:
    match = re.match(r"^([A-Z]+)([0-9]+)$", start_cell)
    if not match:
        raise ValueError("非法单元格坐标: %s" % start_cell)
    start_column = column_to_number(match.group(1))
    start_row = int(match.group(2))
    return "%s%s" % (
        number_to_column(start_column + column_count - 1),
        start_row + row_count - 1,
    )


def spreadsheet_token_from_url(url: str) -> str:
    parsed = urllib.parse.urlparse(url)
    parts = [part for part in parsed.path.split("/") if part]
    if "sheets" in parts:
        index = parts.index("sheets")
        if index + 1 < len(parts):
            return parts[index + 1]
    return parts[-1] if parts else ""


def normalize_sheet_values(values: list[list[Any]]) -> list[list[Any]]:
    return [[normalize_sheet_cell_value(cell) for cell in row] for row in values]


def normalize_sheet_cell_value(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (str, int, float)):
        return value
    return json.dumps(value, ensure_ascii=False)


def column_to_number(column: str) -> int:
    number = 0
    for char in column:
        number = number * 26 + ord(char) - ord("A") + 1
    return number


def number_to_column(number: int) -> str:
    chars = []
    while number:
        number, remainder = divmod(number - 1, 26)
        chars.append(chr(ord("A") + remainder))
    return "".join(reversed(chars))


def build_multipart_body(fields: dict[str, str], file_path: str, file_name: str) -> tuple[bytes, str]:
    boundary = "----WorkflowGymBoundary%s" % uuid.uuid4().hex
    chunks = []
    for name, value in fields.items():
        chunks.append(("--%s\r\n" % boundary).encode("utf-8"))
        chunks.append(
            ('Content-Disposition: form-data; name="%s"\r\n\r\n%s\r\n' % (name, value)).encode("utf-8")
        )
    content_type = mimetypes.guess_type(file_name)[0] or "application/octet-stream"
    chunks.append(("--%s\r\n" % boundary).encode("utf-8"))
    chunks.append(
        (
            'Content-Disposition: form-data; name="file"; filename="%s"\r\n'
            "Content-Type: %s\r\n\r\n"
            % (escape_header_value(file_name), content_type)
        ).encode("utf-8")
    )
    with open(file_path, "rb") as file_obj:
        chunks.append(file_obj.read())
    chunks.append(b"\r\n")
    chunks.append(("--%s--\r\n" % boundary).encode("utf-8"))
    return b"".join(chunks), "multipart/form-data; boundary=%s" % boundary


def escape_header_value(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')
