---
name: volcengine
description: Work with Volcano Engine ECS and TOS using the Python SDK, unittest test cases, RunCommand, image create/copy task polling, instance lifecycle operations, console screenshots, desktop automation, and tosutil. Use when the user asks about 火山云, 火山引擎, Volcengine, ECS, TOS, 镜像, 实例, RunCommand, pyautogui, or tosutil workflows in this repository.
---

# Volcengine

## Scope

Use this skill when adding, reviewing, or explaining Volcano Engine workflows in Python tests, especially:

- ECS instance creation, start/stop, system volume replacement, and RunCommand.
- ECS image creation and image copy with asynchronous task polling.
- Console screenshot capture and desktop automation through Xorg, GDM, and pyautogui.
- TOS object storage quick-start flows with `tosutil`.

## Safety Rules

- Never hard-code AK/SK, TOS_AK/TOS_SK, passwords, temporary tokens, or bucket credentials in code or final answers.
- Read credentials from environment variables: `AK`, `SK`, `TOS_AK`, `TOS_SK`, and optional security token variables if introduced.
- When logging commands that contain credentials, provide a redacted `display_command` and keep the real command only inside the remote execution payload.
- Do not run tests that create, replace, stop, start, upload, or delete cloud resources unless the user explicitly asks to execute them.
- Prefer environment-variable overrides for resource IDs, regions, names, timeouts, and paths so tests can be reused safely.
- 不能针对某道题对player进行特殊处理；只允许改进通用的坐标转换、输入、等待、截图、日志、环境恢复等能力。

## Common Python Test Pattern

Use `unittest` and the Volcano Engine Python SDK:

```python
from __future__ import print_function

import os
import unittest
import warnings

warnings.filterwarnings(
    "ignore",
    message="urllib3 v2 only supports OpenSSL.*",
)

import volcenginesdkcore
import volcenginesdkecs
from volcenginesdkcore.rest import ApiException

from main import get_result_payload, to_plain_dict
```

Create API clients through the global SDK configuration:

```python
def create_api_instance(region):
    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = region
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkecs.ECSApi()
```

For SDK responses, normalize with `to_plain_dict(response)` and unwrap `Result` with `get_result_payload(response_data)`. Always check both SDK field styles, for example `ImageId` and `image_id`.

## ECS Instance Workflows

### Create Instance

Use `RunInstancesRequest` with environment-overridable fields:

- `PROJECT_NAME`, `IMAGE_ID`, `INSTANCE_NAME`, `INSTANCE_TYPE_ID`.
- `SECURITY_GROUP_ID`, `SUBNET_ID`, `ZONE_ID`.
- `VOLUME_SIZE`, `INSTANCE_PASSWORD`.

Set `client_token=str(uuid.uuid4())` for idempotency and assert that `InstanceIds` or `instance_ids` is returned.

### Instance Status

Use `DescribeInstancesRequest(instance_ids=[instance_id])` to read current status. Treat no matching instance as an error. For lifecycle waits, poll until expected status or timeout:

- Stop before replacing system volume unless the instance is already `STOPPED`.
- Start after replacement and wait until `RUNNING`.
- Use clear timeout environment variables such as `STOP_TIMEOUT_SECONDS`, `START_TIMEOUT_SECONDS`, and `POLL_INTERVAL_SECONDS`.

### Replace System Volume

Before calling `ReplaceSystemVolumeRequest`, stop the instance if needed. Request fields usually include:

- `image_id`
- `instance_id`
- `keep_image_credential`
- `client_token`
- optional `password` when `INSTANCE_PASSWORD` is set

After replacement, start the instance and wait until `RUNNING`.

## ECS Image Workflows

### Create Image

Use `CreateImageRequest` with:

- `image_name`
- `instance_id`
- `project_name`

After `create_image`, extract `ImageId` or `image_id`. Creating an image is asynchronous, so always poll task progress before considering the test complete.

### Copy Image

Use `CopyImageRequest` with:

- `copy_image_tags`
- `destination_region`
- `image_id`
- `image_name`
- `project_name`

Create the source-region client for `copy_image`, then create the destination-region client for task polling.

### Task Polling

Use the same task query shape for image create and copy:

```python
def describe_tasks(api_instance, image_id):
    request = volcenginesdkecs.DescribeTasksRequest(
        resource_ids=[image_id],
    )
    response = api_instance.describe_tasks(request)
    response_data = to_plain_dict(response)
    result = get_result_payload(response_data)
    return result.get("Tasks") or result.get("tasks") or []
```

Poll with `TASK_POLL_INTERVAL_SECONDS` and `TASK_TIMEOUT_SECONDS`. For each task, read:

- `Id` or `id`
- `Type` or `type`
- `Status` or `status`
- `Process` or `process`
- `ResourceId` or `resource_id`

Fail fast on `Failed`, `FAILED`, `Error`, or `ERROR`. For image creation, `process == 100` means success and the test should return. For image copy, treat `process == 100` or success-like statuses such as `Success`, `Succeeded`, or `Finished` as complete, then verify `ResourceId == ImageId`.

## RunCommand Workflow

`RunCommandRequest` **must** include a non-empty `invocation_name`. The Volcengine Python SDK validates this client-side; omitting it fails before the API call with:

```text
Invalid value for `invocation_name`, must not be `None`
```

Use a stable, descriptive name per workflow, for example `workflowgym-run-command` in `envs/volcengine_env.py` or `deploy-public-site-install` in `tools/deploy_public_site.py`.

Minimal Linux shell example:

```python
request = volcenginesdkecs.RunCommandRequest(
    instance_ids=[instance_id],
    type="Shell",
    command_content=command,
    invocation_name="workflowgym-run-command",  # required
    timeout=600,
    content_encoding="PlainText",
    working_dir="/root",
)
response = api.run_command(request)
```

Prefer the shared `run_command_and_wait` helper in `envs/volcengine_env.py` when working inside this repo:

- Submit `RunCommandRequest` with `working_dir`, `timeout`, `type`, `command_content`, **`invocation_name` (required)**, `instance_ids`, and `content_encoding="PlainText"`.
- Extract `InvocationId`, then poll `DescribeInvocationResultsRequest`.
- Decode base64 output when present.
- Continue while invocation status is `Pending` or `Running`.
- Treat non-`Success` status or non-zero exit code as failure.

Cloud Assistant readiness: treat `Online`, `Running`, `Available`, and `Normal` as ready (`cloud_assistant_ready()` in `envs/volcengine_env.py`). Do not wait only for `Online` if the instance reports `Running`.

Use RunCommand for simple commands such as `ifconfig`, dependency installation, desktop checks, and TOS CLI execution.

## Console And Desktop Automation

For screenshots, call `GetConsoleScreenshotRequest(instance_id=..., wake_up=True)`, extract `Screenshot`, strip any data URI prefix, base64-decode it, and save under `screenshots/<instance_id>/<number>.jpg`.

For pyautogui workflows:

- Configure GDM for Xorg and automatic login: `WaylandEnable=false`, `AutomaticLoginEnable=true`, and `AutomaticLogin=<DESKTOP_USER>`.
- Wait after GDM restart only when the config changed.
- Ensure `/usr/bin/python` points to Python 3 if needed.
- Install or verify `python3-tk`, `python3-dev`, and `pyautogui`.
- Discover `XAUTHORITY` from `/home` or `/run/user`.
- Disable lock/idle settings and unlock sessions with `loginctl`.
- Run pyautogui as the desktop user with `DISPLAY`, `HOME`, and `XAUTHORITY` set.
- Capture a console screenshot after the desktop operation.

Validate `DESKTOP_USER` before shell interpolation; allow only letters, digits, `_`, and `-`. Use `shlex.quote` for shell arguments.

## TOS tosutil Workflow

The TOS quick-start flow is:

1. Download or locate `tosutil`, then `chmod a+x tosutil`.
2. Configure permanent credentials:

```bash
./tosutil config -i <access key> -k <secret key> -e <endpoint> -re <region>
```

3. Check version:

```bash
./tosutil version
```

4. Check connectivity:

```bash
./tosutil ls
```

`Bucket number is:` means configuration and connectivity are OK. `Http status [403]` indicates bad credentials or insufficient permission. `A connection attempt failed` indicates network or endpoint issues.

5. Common object operations:

```bash
./tosutil mb tos://bucketname
./tosutil cp /temp/file.txt tos://bucketname/file.txt
./tosutil cp tos://bucketname/file.txt /temp/file.txt
./tosutil rm tos://bucketname/file.txt
./tosutil cp /temp/test_folder tos://bucketname -r
./tosutil cp tos://bucketname/test_folder/ /temp/ -r
./tosutil rm tos://bucketname/test_folder/ -r
```

When driving `tosutil` through ECS RunCommand, read credentials from `TOS_AK/TOS_SK` or fall back to `AK/SK`, configure endpoint and region through `TOS_ENDPOINT` and `TOS_REGION`, and assert command output contains both `Bucket number is:` and expected upload markers.

Use TOS protocol endpoints such as `tos-cn-beijing.volces.com`; do not substitute S3 protocol endpoints unless the user specifically asks for S3 compatibility.

## Verification

For code edits, run lightweight checks first:

```bash
PYTHONPYCACHEPREFIX=".pycache" python3 -m py_compile "<test_file>.py"
```

Use `ReadLints` for edited files. Avoid real `unittest` execution unless the user approves resource-changing operations.
