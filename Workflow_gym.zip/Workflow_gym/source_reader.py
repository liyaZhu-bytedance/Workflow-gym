from __future__ import annotations

import re
import urllib.parse
from pathlib import Path

from .feishu_client import FeishuClient
from .local_spreadsheet import read_csv_rows
from .records import TaskRecord


def parse_feishu_sheet_url(url: str) -> dict[str, str]:
    parsed = urllib.parse.urlparse(url)
    query = urllib.parse.parse_qs(parsed.query)
    token = parsed.path.rstrip("/").split("/")[-1] if parsed.path else ""
    return {
        "token": token,
        "sheet_id": (query.get("sheet") or [""])[0],
        "is_wiki": "/wiki/" in parsed.path,
    }


class SourceReader:
    def __init__(self, client: FeishuClient, run_id: str):
        self.client = client
        self.run_id = run_id

    def read_tasks(self, source_url: str, cell_range: str = "", start_row: int = 2, limit: int = 100) -> list[TaskRecord]:
        info = parse_feishu_sheet_url(source_url)
        token = self.client.resolve_wiki_spreadsheet_token(info["token"]) if info.get("is_wiki") else info["token"]
        sheet_id = info["sheet_id"] or self.client.query_first_sheet_id(token)
        read_range = cell_range or "%s!A1:AZ%s" % (sheet_id, start_row + limit)
        rows = self.client.read_values(token, read_range)
        if not rows:
            return []
        headers = [str(item).strip() for item in rows[0]]
        records = []
        for index, row in enumerate(rows[1:], start=2):
            if index < start_row:
                continue
            if len(records) >= limit:
                break
            fields = row_to_fields(headers, row)
            task_id = infer_task_id(fields)
            if not task_id:
                continue
            records.append(TaskRecord(run_id=self.run_id, task_id=task_id, row_number=index, fields=fields))
        return records


def read_tasks_from_csv(
    csv_path: str,
    run_id: str,
    start_row: int = 2,
    limit: int = 100,
) -> list[TaskRecord]:
    path = Path(csv_path)
    if not path.is_file():
        raise ValueError("本地任务 CSV 不存在: %s" % csv_path)
    rows = read_csv_rows(path)
    if not rows:
        return []
    headers = [str(item).strip() for item in rows[0]]
    records: list[TaskRecord] = []
    for index, row in enumerate(rows[1:], start=2):
        if index < start_row:
            continue
        if len(records) >= limit:
            break
        fields = row_to_fields(headers, row)
        task_id = infer_task_id(fields)
        if not task_id:
            continue
        records.append(TaskRecord(run_id=run_id, task_id=task_id, row_number=index, fields=fields))
    return records


def row_to_fields(headers: list[str], row: list) -> dict:
    fields = {}
    for index, header in enumerate(headers):
        if not header:
            continue
        fields[header] = row[index] if index < len(row) else ""
    return fields


def infer_task_id(fields: dict) -> str:
    for key in ("id", "ID", "task_id", "任务ID", "题目ID"):
        value = normalize_task_id_value(fields.get(key))
        if value:
            return value
    return ""


def normalize_task_id_value(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return str(value).strip()
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    text = str(value).strip()
    if re.match(r"^\d+\.0+$", text):
        return text.split(".", 1)[0]
    return text

