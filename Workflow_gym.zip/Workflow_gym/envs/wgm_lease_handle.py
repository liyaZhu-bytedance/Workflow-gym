"""WGM 租约句柄：状态只活在实例上，不挂全局表。"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, fields
from typing import Any, TYPE_CHECKING

from ..records import InstanceLease, now_text
from ..states import InstanceStatus

if TYPE_CHECKING:
    from .wgm_client import WgmClient


@dataclass
class WgmLeaseHandle(InstanceLease):
    """单次 WGM 占用的句柄；renew/release 只认 self.lease_id。

    不维护类变量 / 全局登记表。``_client`` 不是 dataclass 字段，避免进 asdict。
    """

    os_type: str = ""

    def __post_init__(self) -> None:
        # non-field attribute: shared or per-handle WgmClient
        if not hasattr(self, "_client"):
            object.__setattr__(self, "_client", None)

    @classmethod
    def from_remote(
        cls,
        *,
        run_id: str,
        task_id: str,
        sample_index: int,
        remote: dict[str, Any],
        client: WgmClient,
        required_platform: str = "",
        ttl_seconds: int = 1800,
    ) -> WgmLeaseHandle | None:
        instance_id = str(remote.get("instance_id") or "").strip()
        lease_id = str(remote.get("lease_id") or "").strip()
        if not instance_id or not lease_id:
            return None
        platform = str(required_platform or remote.get("os_type") or "").strip().lower()
        expires_at = str(remote.get("expires_at") or "").strip() or _future_text(ttl_seconds)
        handle = cls(
            run_id=run_id,
            lease_id=lease_id,
            instance_id=instance_id,
            task_id=task_id,
            sample_index=sample_index,
            status=InstanceStatus.LEASED.value,
            acquired_at=now_text(),
            expires_at=expires_at,
            os_type=platform,
        )
        handle._client = client
        return handle

    def bind_client(self, client: WgmClient) -> WgmLeaseHandle:
        self._client = client
        return self

    def renew(self, seconds: int) -> None:
        client = getattr(self, "_client", None)
        if client is None:
            return
        ttl = max(60, int(seconds))
        try:
            data = client.renew(self.lease_id, ttl_seconds=ttl)
            if data.get("expires_at"):
                self.expires_at = str(data["expires_at"])
            else:
                self.expires_at = _future_text(ttl)
        except Exception:
            self.expires_at = _future_text(ttl)

    def release(self, reason: str = "") -> None:
        _ = reason
        client = getattr(self, "_client", None)
        if client is not None:
            try:
                client.release(self.lease_id)
            except Exception:
                pass
        self.status = InstanceStatus.IDLE.value
        if not self.released_at:
            self.released_at = now_text()

    def as_instance_lease(self) -> InstanceLease:
        """纯数据副本（无 client），供 store / 序列化。"""
        data = {f.name: getattr(self, f.name) for f in fields(InstanceLease)}
        return InstanceLease(**data)


def _future_text(seconds: int) -> str:
    return (dt.datetime.now() + dt.timedelta(seconds=seconds)).strftime("%Y-%m-%d %H:%M:%S")
