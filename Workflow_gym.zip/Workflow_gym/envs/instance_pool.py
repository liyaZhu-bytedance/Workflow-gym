from __future__ import annotations

from dataclasses import dataclass

from ..records import InstanceLease, now_text
from ..state_store import StateStore
from ..states import InstanceStatus
from .lease_backend import create_lease_backend


@dataclass
class InstancePoolRecoveryResult:
    idle: int = 0
    quarantined: int = 0
    notes: list[str] | None = None


class InstancePool:
    def __init__(
        self,
        instance_ids: list[str],
        store: StateStore,
        instance_platforms: dict[str, str] | None = None,
        lease_ttl_seconds: int = 3600,
        lease_backend=None,
        lease_backend_kind: str = "local",
        wgm_api_base: str | None = None,
        wgm_token: str | None = None,
    ):
        self.instance_ids = list(instance_ids)
        self.instance_platforms = dict(instance_platforms or {})
        self.store = store
        if lease_backend is not None:
            self.lease_backend = lease_backend
        else:
            self.lease_backend = create_lease_backend(
                lease_backend_kind,
                instance_ids=self.instance_ids,
                instance_platforms=self.instance_platforms,
                ttl_seconds=lease_ttl_seconds,
                api_base=wgm_api_base,
                api_token=wgm_token,
            )
        self.status_by_instance = {instance_id: InstanceStatus.IDLE.value for instance_id in self.instance_ids}
        self.reserved_eips_by_instance: dict[str, dict[str, str]] = {}

    def set_reserved_eips(self, eip_allocations: list[dict]) -> None:
        self.reserved_eips_by_instance = {}
        for instance_id, allocation in zip(self.instance_ids, eip_allocations):
            eip = allocation.get("eip") if isinstance(allocation, dict) else {}
            if not isinstance(eip, dict):
                eip = {}
            allocation_id = str(allocation.get("allocation_id") or "") if isinstance(allocation, dict) else ""
            if not allocation_id:
                continue
            self.reserved_eips_by_instance[instance_id] = {
                "allocation_id": allocation_id,
                "eip_address": str(eip.get("EipAddress") or eip.get("eip_address") or ""),
            }

    def recover(self, force_reset: bool = False, auto_reset_unknown: bool = False) -> InstancePoolRecoveryResult:
        notes = []
        if force_reset:
            notes.append("force reset requested; instances marked idle locally")
            self.status_by_instance = {instance_id: InstanceStatus.IDLE.value for instance_id in self.instance_ids}
        elif auto_reset_unknown:
            notes.append("auto reset unknown requested; no unknown local states found")
        return InstancePoolRecoveryResult(idle=len(self.instance_ids), quarantined=0, notes=notes)

    def _quarantined_instance_ids(self) -> set[str]:
        return {
            instance_id
            for instance_id, status in self.status_by_instance.items()
            if status == InstanceStatus.QUARANTINED.value
        }

    def _blocked_instance_ids(self) -> set[str]:
        blocked = self._quarantined_instance_ids()
        blocked.update(self.store.blocked_instance_ids(list(self.instance_ids)))
        return blocked

    def expire_stale_leases(self, reason: str = "ttl_expired") -> list[InstanceLease]:
        self.lease_backend.sync_expires_from_store(self.store)
        expired = self.lease_backend.expire_stale_leases(self._blocked_instance_ids(), store=self.store)
        for lease in expired:
            lease.status = InstanceStatus.QUARANTINED.value
            if not lease.released_at:
                lease.released_at = now_text()
            self.mark(lease.instance_id, InstanceStatus.QUARANTINED)
            self.store.upsert_lease(lease)
        return expired

    def acquire(
        self,
        run_id: str,
        task_id: str,
        sample_index: int,
        required_platform: str = "",
        excluded_instance_ids: set[str] | None = None,
        image_id: str = "",
    ) -> InstanceLease | None:
        self.expire_stale_leases()
        blocked = self._blocked_instance_ids()
        blocked.update(excluded_instance_ids or ())
        lease = self.lease_backend.acquire(
            run_id,
            task_id,
            sample_index,
            required_platform,
            blocked_instance_ids=blocked,
            image_id=str(image_id or ""),
        )
        if lease:
            if lease.instance_id not in self.instance_ids:
                self.instance_ids.append(lease.instance_id)
            if lease.instance_id not in self.status_by_instance:
                self.status_by_instance[lease.instance_id] = InstanceStatus.IDLE.value
            reserved_eip = self.reserved_eips_by_instance.get(lease.instance_id) or {}
            lease.reserved_eip_allocation_id = reserved_eip.get("allocation_id", "")
            lease.reserved_eip_address = reserved_eip.get("eip_address", "")
            self.status_by_instance[lease.instance_id] = InstanceStatus.LEASED.value
            self.store.upsert_lease(lease)
        return lease

    def acquire_status(
        self,
        required_platform: str = "",
        excluded_instance_ids: set[str] | None = None,
    ) -> str:
        self.expire_stale_leases()
        normalized_platform = str(required_platform or "").strip().lower()
        blocked = self._blocked_instance_ids()
        blocked.update(excluded_instance_ids or ())
        capacity = self.lease_backend.platform_capacity(normalized_platform, blocked)
        # redis：total/idle == -1 表示未知，允许尝试 WGM acquire（成败由网关决定）
        if int(capacity.get("total") or 0) < 0:
            return "available"
        if capacity["total"] <= 0:
            return "unavailable"
        if capacity["idle"] > 0:
            return "available"
        return "wait"

    def platform_capacity(
        self,
        required_platform: str = "",
        excluded_instance_ids: set[str] | None = None,
    ) -> dict[str, int]:
        blocked = self._blocked_instance_ids()
        blocked.update(excluded_instance_ids or ())
        normalized_platform = str(required_platform or "").strip().lower()
        return self.lease_backend.platform_capacity(normalized_platform, blocked)

    def platform_summary(self) -> dict[str, int]:
        summary = {"windows": 0, "ubuntu": 0}
        for platform in self.instance_platforms.values():
            if platform in summary:
                summary[platform] += 1
        return summary

    def mark(self, instance_id: str, status: InstanceStatus | str) -> None:
        self.status_by_instance[instance_id] = status.value if isinstance(status, InstanceStatus) else str(status)

    def release(self, lease: InstanceLease, reason: str = "") -> None:
        self.mark(lease.instance_id, InstanceStatus.RELEASING)
        # 统一走 backend.release，保证 redis 的 _active_leases 同步摘除
        self.lease_backend.release(lease.lease_id, reason)
        quarantine = self.store.lease_requires_quarantine(lease.lease_id) or reason in (
            "init_orphan",
            "hung_worker",
            "ttl_expired",
        )
        lease.status = InstanceStatus.QUARANTINED.value if quarantine else InstanceStatus.IDLE.value
        if not lease.released_at:
            lease.released_at = now_text()
        self.store.upsert_lease(lease)
        self.mark(lease.instance_id, InstanceStatus.QUARANTINED if quarantine else InstanceStatus.IDLE)

    def release_all(self, reason: str = "shutdown") -> dict:
        """Ctrl+C：只释放本进程持有的租约。

        redis：``release_held``（按本 backend 登记的 lease_id），不调用用户级 release-all。
        local：遍历本机 ``_leases_by_instance``。
        """
        if hasattr(self.lease_backend, "release_held"):
            return self.lease_backend.release_held(reason=reason)
        if hasattr(self.lease_backend, "release_all"):
            # 兼容旧 backend：语义应为 process-held，不应再打用户级 release-all
            return self.lease_backend.release_all(reason=reason)
        released = 0
        if hasattr(self.lease_backend, "_leases_by_instance"):
            for lease in list(getattr(self.lease_backend, "_leases_by_instance").values()):
                try:
                    self.release(lease, reason)
                    released += 1
                except Exception:
                    pass
        return {"released_count": released, "success": True, "scope": "process_held"}
