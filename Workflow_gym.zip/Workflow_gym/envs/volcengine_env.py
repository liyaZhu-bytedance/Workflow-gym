from __future__ import annotations

import base64
from io import BytesIO
import json
import os
import shlex
import time
import uuid
from pathlib import Path
from typing import Any

from .volcengine_eip import allocate_and_associate_eip, disassociate_eip
from ..lease_renewal import LeaseRenewContext, lease_heartbeat_interval_seconds, renew_lease_from_context
from ..records import now_text
from ..sample_log import append_sample_log


RUN_COMMAND_MAX_CONTENT_BYTES = 16 * 1024

DRY_RUN_SCREENSHOT_BYTES = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAFgwJ/l4iQGQAAAABJRU5ErkJggg=="
)


def log_env_sample(sample_dir: str, message: str, extra: dict[str, Any] | None = None) -> None:
    timestamp = now_text()
    line = "[%s] %s" % (timestamp, message)
    print(line, flush=True)
    append_sample_log(sample_dir, message, source="env", timestamp=timestamp, line=line, extra=extra)


class VolcengineEnv:
    """Boundary wrapper for VM lifecycle and remote commands.

    The first implementation supports dry-run/local scaffolding. Real Volcano
    SDK calls should be added inside this boundary, not in scheduler/sampler.
    """

    def __init__(self, dry_run: str = "", region: str = "", lease_renew_context: LeaseRenewContext | None = None):
        self.dry_run = dry_run
        self.region = region or os.getenv("VOLCENGINE_REGION") or os.getenv("SOURCE_REGION") or "cn-beijing"
        self._api_instance = None
        self.lease_renew_context = lease_renew_context
        self._lease_heartbeat_last_at = 0.0

    def renew_lease_now(self) -> str | None:
        self._lease_heartbeat_last_at = time.monotonic()
        return renew_lease_from_context(self.lease_renew_context)

    def maybe_renew_lease_heartbeat(self, force: bool = False) -> str | None:
        if self.lease_renew_context is None:
            return None
        interval = lease_heartbeat_interval_seconds()
        now = time.monotonic()
        if not force and now - self._lease_heartbeat_last_at < interval:
            return None
        self._lease_heartbeat_last_at = now
        return renew_lease_from_context(self.lease_renew_context)

    def _renew_lease_after_successful_command(self) -> str | None:
        return self.renew_lease_now()

    def initialize_for_sample(
        self,
        instance_id: str,
        image_id: str,
        sample_dir: str,
        requires_public_ip: bool = False,
        platform_hint: str = "",
        preferred_eip_allocation_id: str = "",
    ) -> dict[str, Any]:
        metadata = {
            "instance_id": instance_id,
            "image_id": image_id,
            "ensure_stopped_started_at": now_text(),
            "replace_image_started_at": "",
            "replace_image_finished_at": "",
            "instance_started_at": "",
            "requires_public_ip": bool(requires_public_ip),
        }
        if self.dry_run in ("local", "read", "env"):
            metadata.update(
                {
                    "replace_image_started_at": now_text(),
                    "replace_image_finished_at": now_text(),
                    "instance_started_at": now_text(),
                    "dry_run": True,
                }
            )
            return metadata

        metadata["replace_image_started_at"] = now_text()
        skip_replace_if_same_image = os.getenv("WORKFLOWGYM_SKIP_REPLACE_IF_SAME_IMAGE", "1").lower() not in (
            "0",
            "false",
            "no",
            "off",
        )
        instance_before_replace = self.describe_instance(instance_id)
        target_image_record = self.describe_image(image_id) if image_id else {}
        instance_platform = instance_platform_from_name(instance_before_replace)
        target_image_platform = image_record_platform(target_image_record)
        metadata["instance_platform"] = instance_platform
        metadata["target_image_platform"] = target_image_platform
        metadata["target_image_os_type"] = image_os_type_label(target_image_record)
        metadata["instance_cloud_assistant_platform"] = instance_platform
        if target_image_platform and instance_platform != target_image_platform:
            described_os = instance_os_type(instance_before_replace)
            raise CloudAssistantPlatformMismatchError(
                "实例 %s 平台=%s(name=%s) 与目标镜像 %s 平台=%s(%s) 不一致，跳过换盘并停止采样。"
                "请使用与镜像 OS 一致的原生实例（open_workflow_gym_windows / open_workflow_gym_ubuntu）。"
                % (
                    instance_id,
                    instance_platform,
                    instance_display_name(instance_before_replace),
                    image_id,
                    target_image_platform,
                    metadata["target_image_os_type"] or "<unknown>",
                ),
                instance_id=instance_id,
                instance_name=instance_display_name(instance_before_replace),
                instance_platform=instance_platform,
                instance_os_type=described_os or platform_to_os_type_label(instance_platform),
                expected_platform=target_image_platform,
                expected_os_type=metadata["target_image_os_type"] or platform_to_os_type_label(target_image_platform),
                image_id=image_id,
                task_expected_platform=str(platform_hint or "").strip(),
                task_expected_os_type=platform_to_os_type_label(platform_hint) if str(platform_hint or "").strip() else "",
            )
        current_image_id = instance_image_id(instance_before_replace)
        current_status = str(instance_before_replace.get("Status") or instance_before_replace.get("status") or "").strip()
        if skip_replace_if_same_image and current_image_id == image_id:
            log_env_sample(
                sample_dir,
                "目标镜像已就绪，跳过换盘: instance_id=%s image_id=%s status=%s"
                % (instance_id, image_id, current_status or "<unknown>"),
                extra={"instance_id": instance_id, "image_id": image_id, "status": current_status},
            )
            metadata["replace_image_skipped_reason"] = "same_image"
            metadata["replace_image_finished_at"] = now_text()
            if current_status == "STOPPED":
                log_env_sample(sample_dir, "实例已停止，直接启动: instance_id=%s" % instance_id, extra={"instance_id": instance_id})
                self.start_instance(instance_id)
                self.wait_for_status(instance_id, "RUNNING", timeout_seconds=int(os.getenv("INSTANCE_START_TIMEOUT_SECONDS", "600")))
            elif current_status in ("STOPPING",):
                log_env_sample(sample_dir, "等待实例停止: instance_id=%s" % instance_id, extra={"instance_id": instance_id})
                self.wait_for_status(instance_id, "STOPPED", timeout_seconds=int(os.getenv("INSTANCE_START_TIMEOUT_SECONDS", "600")))
                self.start_instance(instance_id)
                self.wait_for_status(instance_id, "RUNNING", timeout_seconds=int(os.getenv("INSTANCE_START_TIMEOUT_SECONDS", "600")))
            elif current_status != "RUNNING":
                raise ValueError(
                    "实例状态无法跳过换盘: instance_id=%s image_id=%s status=%s"
                    % (instance_id, image_id, current_status)
                )
            else:
                log_env_sample(sample_dir, "实例已在运行，跳过停机和换盘: instance_id=%s" % instance_id, extra={"instance_id": instance_id})
            metadata["instance_started_at"] = now_text()
        else:
            self.ensure_stopped(instance_id, sample_dir=sample_dir)
            log_env_sample(
                sample_dir,
                "开始换盘: instance_id=%s image_id=%s current_image_id=%s status=%s"
                % (instance_id, image_id, current_image_id or "<unknown>", current_status or "<unknown>"),
                extra={
                    "instance_id": instance_id,
                    "image_id": image_id,
                    "current_image_id": current_image_id,
                    "status": current_status,
                },
            )
            self.replace_system_volume(instance_id, image_id)
            replaced_instance = self.wait_for_replace_system_volume(
                instance_id,
                image_id,
                sample_dir=sample_dir,
                timeout_seconds=int(os.getenv("REPLACE_SYSTEM_VOLUME_TIMEOUT_SECONDS", "600")),
            )
            metadata["replace_image_finished_at"] = now_text()
            metadata["replaced_image_id"] = instance_image_id(replaced_instance)
            log_env_sample(sample_dir, "换盘完成，启动实例: instance_id=%s" % instance_id, extra={"instance_id": instance_id})
            self.start_instance(instance_id)
            self.wait_for_status(instance_id, "RUNNING", timeout_seconds=int(os.getenv("INSTANCE_START_TIMEOUT_SECONDS", "600")))
            metadata["instance_started_at"] = now_text()
        if requires_public_ip and public_ip_binding_enabled():
            log_env_sample(
                sample_dir,
                "绑定公网 IP 开始: instance_id=%s preferred_allocation_id=%s"
                % (instance_id, preferred_eip_allocation_id or "<auto>"),
                extra={"instance_id": instance_id, "preferred_allocation_id": preferred_eip_allocation_id},
            )
            metadata["public_ip_binding_started_at"] = now_text()
            eip_result = allocate_and_associate_eip(
                instance_id=instance_id,
                region=self.region,
                billing_type=int(os.getenv("VOLCENGINE_EIP_BILLING_TYPE", "2")),
                project_name=os.getenv("VOLCENGINE_EIP_PROJECT_NAME", "default"),
                preferred_allocation_id=preferred_eip_allocation_id,
            )
            metadata["public_ip_binding_finished_at"] = now_text()
            metadata["public_ip_binding_result"] = eip_result
            log_env_sample(
                sample_dir,
                "绑定公网 IP 完成: instance_id=%s allocation_id=%s" % (instance_id, eip_result.get("allocation_id")),
                extra={"instance_id": instance_id, "allocation_id": eip_result.get("allocation_id")},
            )
        elif requires_public_ip:
            metadata["public_ip_binding_skipped_reason"] = "disabled"
        log_env_sample(sample_dir, "确认 Cloud Assistant 就绪", extra={"instance_id": instance_id})
        metadata["cloud_assistant_status"] = self.ensure_cloud_assistant_ready(instance_id)
        metadata["cloud_assistant_ready_at"] = now_text()
        instance = self.describe_instance(instance_id)
        metadata["image_id_after_start"] = instance_image_id(instance)
        instance_platform = instance_platform_from_name(instance)
        metadata["instance_platform"] = instance_platform
        metadata["instance_name"] = instance_display_name(instance)
        metadata["described_os_type"] = instance_os_type(instance)
        metadata["platform_hint"] = platform_hint
        metadata["platform"] = instance_platform
        metadata["os_type"] = platform_to_os_type_label(instance_platform)
        self.verify_cloud_assistant_platform_with_runcommand(
            instance_id,
            instance_platform,
            sample_dir,
            image_platform=target_image_platform,
            image_os_type_label=metadata.get("target_image_os_type") or "",
        )
        if instance_platform == "windows":
            metadata.update(self.initialize_windows_for_sample(instance_id, sample_dir))
        else:
            metadata.update(self.initialize_linux_for_sample(instance_id, sample_dir))
        metadata["desktop_ready_screenshot"] = self.wait_for_console_screenshot_ready(
            instance_id,
            sample_dir,
            timeout_seconds=int(os.getenv("DESKTOP_READY_TIMEOUT_SECONDS", "300")),
        )
        metadata["desktop_ready_at"] = now_text()
        return metadata

    def initialize_linux_for_sample(self, instance_id: str, sample_dir: str) -> dict[str, Any]:
        metadata: dict[str, Any] = {}
        metadata.update(self.initialize_tosutil_for_sample(instance_id, sample_dir, platform="linux"))
        update_cleanup_result = self.run_command(
            instance_id,
            build_disable_ubuntu_update_prompts_command(),
            timeout=int(os.getenv("DISABLE_UBUNTU_UPDATES_TIMEOUT_SECONDS", "300")),
        )
        metadata["disable_ubuntu_updates_at"] = now_text()
        metadata["disable_ubuntu_updates_result"] = update_cleanup_result
        desktop_metadata = self.prepare_desktop_for_pyautogui(instance_id, sample_dir)
        metadata.update(desktop_metadata)
        action_runner = ubuntu_action_runner_mode()
        metadata["ubuntu_action_runner"] = action_runner
        metadata["ubuntu_flask_token"] = ubuntu_flask_runner_token()
        metadata["ubuntu_flask_port"] = ubuntu_flask_runner_port()
        if action_runner == "flask":
            metadata.update(self.ensure_ubuntu_flask_runner(instance_id, sample_dir, metadata))
        return metadata

    def ensure_ubuntu_flask_runner(
        self,
        instance_id: str,
        sample_dir: str,
        desktop_metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        metadata: dict[str, Any] = {}
        flask_token = ubuntu_flask_runner_token()
        port_candidates = ubuntu_flask_runner_port_candidates()
        desktop = dict(desktop_metadata or {})
        desktop_user = str(desktop.get("desktop_user") or "user")
        desktop_home = str(desktop.get("desktop_home") or "/home/user")
        display = str(desktop.get("display") or ":0")
        xauthority = str(desktop.get("xauthority") or "")
        log_env_sample(sample_dir, "确认 Ubuntu Flask runner 存活", extra={"instance_id": instance_id})
        probe_errors: list[str] = []
        for flask_port in port_candidates:
            try:
                probe_result = self.run_command(
                    instance_id,
                    build_ubuntu_probe_flask_runner_command(flask_port, flask_token),
                    timeout=int(os.getenv("UBUNTU_FLASK_RUNNER_PROBE_TIMEOUT_SECONDS", "120")),
                    command_type="Shell",
                )
                metadata["ubuntu_flask_port"] = flask_port
                metadata["ubuntu_flask_runner_probe"] = "ok"
                metadata["ubuntu_flask_runner_probe_result"] = probe_result
                return metadata
            except Exception as exc:
                probe_errors.append("port=%s error=%s" % (flask_port, exc))
        log_env_sample(
            sample_dir,
            "Ubuntu Flask runner 未就绪，重新拉起: %s" % ("; ".join(probe_errors) or "unknown"),
            extra={"instance_id": instance_id},
        )
        metadata["ubuntu_flask_runner_probe_error"] = "; ".join(probe_errors)
        if not xauthority:
            refreshed = self.prepare_desktop_for_pyautogui(instance_id, sample_dir)
            desktop_user = str(refreshed.get("desktop_user") or desktop_user)
            desktop_home = str(refreshed.get("desktop_home") or desktop_home)
            display = str(refreshed.get("display") or display)
            xauthority = str(refreshed.get("xauthority") or "")
            metadata.update(refreshed)
        if not xauthority:
            raise ValueError("Ubuntu Flask runner 需要 desktop xauthority，prepare_desktop_for_pyautogui 未返回有效值")
        setup_errors: list[str] = []
        for flask_port in port_candidates:
            try:
                setup_result = self.run_command(
                    instance_id,
                    build_ubuntu_interactive_flask_runner_setup_command(
                        desktop_user,
                        desktop_home,
                        display,
                        xauthority,
                        flask_token,
                        flask_port,
                    ),
                    timeout=int(os.getenv("UBUNTU_FLASK_RUNNER_SETUP_TIMEOUT_SECONDS", "300")),
                    command_type="Shell",
                )
                probe_result = self.run_command(
                    instance_id,
                    build_ubuntu_probe_flask_runner_command(flask_port, flask_token),
                    timeout=int(os.getenv("UBUNTU_FLASK_RUNNER_PROBE_TIMEOUT_SECONDS", "120")),
                    command_type="Shell",
                )
                metadata["ubuntu_flask_port"] = flask_port
                metadata["ubuntu_flask_runner_setup_result"] = setup_result
                metadata["ubuntu_flask_runner_probe"] = "ok"
                metadata["ubuntu_flask_runner_probe_result"] = probe_result
                return metadata
            except Exception as exc:
                setup_errors.append("port=%s error=%s" % (flask_port, exc))
        raise ValueError(
            "Ubuntu Flask runner 在所有候选端口上拉起失败: %s"
            % ("; ".join(setup_errors) or ",".join(str(port) for port in port_candidates))
        )

    def initialize_windows_for_sample(self, instance_id: str, sample_dir: str) -> dict[str, Any]:
        metadata: dict[str, Any] = {}
        if os.getenv("WORKFLOWGYM_WINDOWS_FAST_INIT", "1").lower() not in ("0", "false", "no", "off"):
            log_env_sample(sample_dir, "探测 Windows 环境是否可复用", extra={"instance_id": instance_id})
            try:
                probe_result = self.run_command(
                    instance_id,
                    build_windows_fast_init_probe_command(),
                    timeout=int(os.getenv("WINDOWS_FAST_INIT_PROBE_TIMEOUT_SECONDS", "120")),
                    command_type="PowerShell",
                )
                probe_output = command_decoded_output(probe_result)
                if "WORKFLOWGYM_WINDOWS_FAST_INIT_READY" in probe_output:
                    log_env_sample(
                        sample_dir,
                        "Windows 环境已就绪，跳过重复初始化: %s" % probe_output.strip().splitlines()[-1],
                        extra={"instance_id": instance_id},
                    )
                    metadata["windows_fast_init"] = True
                    metadata["windows_fast_init_probe_result"] = probe_result
                    metadata["windows_action_runner"] = windows_action_runner_mode()
                    metadata["windows_flask_token"] = windows_flask_runner_token()
                    metadata["windows_flask_port"] = windows_flask_runner_port()
                    metadata["desktop_user"] = windows_login_user()
                    metadata["desktop_prepared_at"] = now_text()
                    if metadata["windows_action_runner"] == "file_queue":
                        metadata.update(self.ensure_windows_file_queue_runner(instance_id, sample_dir))
                    elif metadata["windows_action_runner"] == "flask":
                        metadata.update(self.ensure_windows_flask_runner(instance_id, sample_dir))
                    return metadata
            except Exception as exc:
                if isinstance(exc, CloudAssistantPlatformMismatchError) or is_cloud_assistant_platform_mismatch_error(exc):
                    raise_cloud_assistant_platform_mismatch(
                        exc,
                        instance_platform="windows",
                        image_platform="windows",
                    )
                log_env_sample(
                    sample_dir,
                    "Windows 快速初始化探测未通过，走完整初始化: %s" % exc,
                    extra={"instance_id": instance_id},
                )
                metadata["windows_fast_init_probe_error"] = "%s" % exc
        metadata.update(self.initialize_tosutil_for_sample(instance_id, sample_dir, platform="windows"))
        login_user = windows_login_user()
        metadata["windows_auto_login_user"] = login_user
        if os.getenv("WINDOWS_CONFIGURE_AUTO_LOGIN", "1").lower() in ("1", "true", "yes", "on"):
            log_env_sample(sample_dir, "准备 Windows 自动登录", extra={"instance_id": instance_id})
            login_password = windows_login_password()
            if not login_password:
                raise ValueError("配置 Windows 自动登录需要设置 WINDOWS_LOGIN_PASSWORD 或 INSTANCE_PASSWORD")
            auto_login_result = self.run_command(
                instance_id,
                build_windows_autologon_command(login_user, login_password),
                timeout=int(os.getenv("WINDOWS_AUTO_LOGIN_TIMEOUT_SECONDS", "300")),
                command_type="PowerShell",
            )
            metadata["windows_auto_login_at"] = now_text()
            metadata["windows_auto_login_result"] = auto_login_result
            if os.getenv("WINDOWS_AUTO_LOGIN_REBOOT", "1").lower() not in ("0", "false", "no", "off"):
                log_env_sample(sample_dir, "Windows 自动登录已配置，重启实例", extra={"instance_id": instance_id})
                self.reboot_instance(instance_id)
                time.sleep(int(os.getenv("WINDOWS_REBOOT_SETTLE_SECONDS", "20")))
                self.wait_for_status(instance_id, "RUNNING", timeout_seconds=int(os.getenv("INSTANCE_START_TIMEOUT_SECONDS", "600")))
                self.ensure_cloud_assistant_ready(instance_id)
                metadata["windows_auto_login_rebooted_at"] = now_text()
                time.sleep(int(os.getenv("WINDOWS_AUTO_LOGIN_WAIT_SECONDS", "30")))
        else:
            metadata["windows_auto_login_skipped_reason"] = "already_logged_in"
        login_password = windows_login_password()
        if login_password and windows_should_set_desktop_resolution():
            log_env_sample(
                sample_dir,
                "设置 Windows 桌面分辨率: %sx%s"
                % (windows_desktop_resolution_width(), windows_desktop_resolution_height()),
                extra={"instance_id": instance_id},
            )
            resolution_result = self.run_command(
                instance_id,
                build_set_windows_desktop_resolution_command(
                    login_user,
                    login_password,
                    windows_desktop_resolution_width(),
                    windows_desktop_resolution_height(),
                ),
                timeout=int(os.getenv("WINDOWS_DESKTOP_RESOLUTION_TIMEOUT_SECONDS", "120")),
                command_type="PowerShell",
            )
            metadata["windows_desktop_resolution_result"] = resolution_result
            time.sleep(int(os.getenv("WINDOWS_DESKTOP_RESOLUTION_SETTLE_SECONDS", "8")))
        log_env_sample(sample_dir, "准备 Windows pyautogui 依赖", extra={"instance_id": instance_id})
        prepare_result = self.run_command(
            instance_id,
            build_prepare_windows_pyautogui_command(),
            timeout=int(os.getenv("WINDOWS_DESKTOP_PREPARE_TIMEOUT_SECONDS", "1800")),
            command_type="PowerShell",
        )
        metadata["windows_pyautogui_prepare_result"] = prepare_result
        validate_result = self.run_command(
            instance_id,
            build_validate_windows_pyautogui_command(),
            timeout=int(os.getenv("WINDOWS_DESKTOP_VALIDATE_TIMEOUT_SECONDS", "300")),
            command_type="PowerShell",
        )
        metadata["pyautogui_validation_result"] = validate_result
        action_runner = windows_action_runner_mode()
        metadata["windows_action_runner"] = action_runner
        metadata["windows_flask_token"] = windows_flask_runner_token()
        metadata["windows_flask_port"] = windows_flask_runner_port()
        if action_runner == "flask":
            log_env_sample(sample_dir, "准备 Windows Flask runner（本机 127.0.0.1，不依赖 EIP）", extra={"instance_id": instance_id})
            login_password = windows_login_password()
            if not login_password:
                raise ValueError("配置 Windows Flask runner 需要设置 WINDOWS_LOGIN_PASSWORD 或 INSTANCE_PASSWORD")
            flask_token = windows_flask_runner_token()
            flask_port = windows_flask_runner_port()
            try:
                self.run_command(
                    instance_id,
                    build_windows_probe_flask_runner_command(flask_port, flask_token),
                    timeout=int(os.getenv("WINDOWS_FLASK_RUNNER_PROBE_TIMEOUT_SECONDS", "120")),
                    command_type="PowerShell",
                )
                metadata["windows_flask_runner_probe"] = "ok"
            except Exception:
                flask_result = self.run_command(
                    instance_id,
                    build_windows_interactive_flask_runner_setup_command(login_user, login_password, flask_token, flask_port),
                    timeout=int(os.getenv("WINDOWS_FLASK_RUNNER_SETUP_TIMEOUT_SECONDS", "300")),
                    command_type="PowerShell",
                )
                metadata["windows_flask_runner_setup_result"] = flask_result
                self.run_command(
                    instance_id,
                    build_windows_probe_flask_runner_command(flask_port, flask_token),
                    timeout=int(os.getenv("WINDOWS_FLASK_RUNNER_PROBE_TIMEOUT_SECONDS", "120")),
                    command_type="PowerShell",
                )
                metadata["windows_flask_runner_probe"] = "ok"
        elif action_runner == "file_queue":
            log_env_sample(sample_dir, "准备 Windows file-queue runner", extra={"instance_id": instance_id})
            login_password = windows_login_password()
            if not login_password:
                raise ValueError("配置 Windows file-queue runner 需要设置 WINDOWS_LOGIN_PASSWORD 或 INSTANCE_PASSWORD")
            file_queue_result = self.run_command(
                instance_id,
                build_windows_file_queue_runner_setup_command(login_user, login_password),
                timeout=int(os.getenv("WINDOWS_FILE_QUEUE_SETUP_TIMEOUT_SECONDS", "300")),
                command_type="PowerShell",
            )
            metadata["windows_file_queue_runner_result"] = file_queue_result
        metadata["desktop_user"] = login_user
        metadata["desktop_prepared_at"] = now_text()
        return metadata

    def ensure_windows_file_queue_runner(self, instance_id: str, sample_dir: str) -> dict[str, Any]:
        metadata: dict[str, Any] = {}
        log_env_sample(sample_dir, "确认 Windows file-queue runner 存活", extra={"instance_id": instance_id})
        try:
            probe_result = self.run_command(
                instance_id,
                build_windows_file_queue_runner_probe_command(),
                timeout=int(os.getenv("WINDOWS_FILE_QUEUE_PROBE_TIMEOUT_SECONDS", "60")),
                command_type="PowerShell",
            )
            metadata["windows_file_queue_runner_probe"] = "ok"
            metadata["windows_file_queue_runner_probe_result"] = probe_result
            return metadata
        except Exception as exc:
            log_env_sample(
                sample_dir,
                "Windows file-queue runner 未就绪，重新拉起: %s" % exc,
                extra={"instance_id": instance_id},
            )
            metadata["windows_file_queue_runner_probe_error"] = "%s" % exc
        login_user = windows_login_user()
        login_password = windows_login_password()
        if not login_password:
            raise ValueError("配置 Windows file-queue runner 需要设置 WINDOWS_LOGIN_PASSWORD 或 INSTANCE_PASSWORD")
        file_queue_result = self.run_command(
            instance_id,
            build_windows_file_queue_runner_setup_command(login_user, login_password),
            timeout=int(os.getenv("WINDOWS_FILE_QUEUE_SETUP_TIMEOUT_SECONDS", "300")),
            command_type="PowerShell",
        )
        metadata["windows_file_queue_runner_result"] = file_queue_result
        return self.wait_for_windows_file_queue_runner_ready(instance_id, sample_dir, metadata)

    def wait_for_windows_file_queue_runner_ready(self, instance_id: str, sample_dir: str, metadata: dict[str, Any]) -> dict[str, Any]:
        timeout_seconds = int(os.getenv("WINDOWS_FILE_QUEUE_READY_TIMEOUT_SECONDS", "90"))
        poll_seconds = int(os.getenv("WINDOWS_FILE_QUEUE_READY_POLL_SECONDS", "5"))
        deadline = time.time() + timeout_seconds
        last_error = ""
        while time.time() < deadline:
            self.maybe_renew_lease_heartbeat()
            try:
                probe_result = self.run_command(
                    instance_id,
                    build_windows_file_queue_runner_probe_command(),
                    timeout=int(os.getenv("WINDOWS_FILE_QUEUE_PROBE_TIMEOUT_SECONDS", "60")),
                    command_type="PowerShell",
                )
                metadata["windows_file_queue_runner_probe"] = "ok"
                metadata["windows_file_queue_runner_probe_result"] = probe_result
                return metadata
            except Exception as exc:
                last_error = "%s" % exc
                time.sleep(poll_seconds)
        raise TimeoutError("等待 Windows file-queue runner 就绪超时: %s" % last_error)

    def ensure_windows_flask_runner(self, instance_id: str, sample_dir: str) -> dict[str, Any]:
        metadata: dict[str, Any] = {}
        flask_token = windows_flask_runner_token()
        flask_port = windows_flask_runner_port()
        log_env_sample(sample_dir, "确认 Windows Flask runner 存活", extra={"instance_id": instance_id})
        try:
            probe_result = self.run_command(
                instance_id,
                build_windows_probe_flask_runner_command(flask_port, flask_token),
                timeout=int(os.getenv("WINDOWS_FLASK_RUNNER_PROBE_TIMEOUT_SECONDS", "120")),
                command_type="PowerShell",
            )
            metadata["windows_flask_runner_probe"] = "ok"
            metadata["windows_flask_runner_probe_result"] = probe_result
            return metadata
        except Exception as exc:
            log_env_sample(
                sample_dir,
                "Windows Flask runner 未就绪，重新拉起: %s" % exc,
                extra={"instance_id": instance_id},
            )
            metadata["windows_flask_runner_probe_error"] = "%s" % exc
        login_user = windows_login_user()
        login_password = windows_login_password()
        if not login_password:
            raise ValueError("配置 Windows Flask runner 需要设置 WINDOWS_LOGIN_PASSWORD 或 INSTANCE_PASSWORD")
        setup_result = self.run_command(
            instance_id,
            build_windows_interactive_flask_runner_setup_command(login_user, login_password, flask_token, flask_port),
            timeout=int(os.getenv("WINDOWS_FLASK_RUNNER_SETUP_TIMEOUT_SECONDS", "300")),
            command_type="PowerShell",
        )
        metadata["windows_flask_runner_setup_result"] = setup_result
        probe_result = self.run_command(
            instance_id,
            build_windows_probe_flask_runner_command(flask_port, flask_token),
            timeout=int(os.getenv("WINDOWS_FLASK_RUNNER_PROBE_TIMEOUT_SECONDS", "120")),
            command_type="PowerShell",
        )
        metadata["windows_flask_runner_probe"] = "ok"
        metadata["windows_flask_runner_probe_result"] = probe_result
        return metadata

    def initialize_tosutil_for_sample(self, instance_id: str, sample_dir: str, platform: str) -> dict[str, Any]:
        metadata: dict[str, Any] = {}
        if os.getenv("WORKFLOWGYM_CONFIGURE_TOSUTIL", "1").lower() in ("0", "false", "no", "off"):
            metadata["tosutil_skipped_reason"] = "disabled"
            return metadata
        tos_ak = os.getenv("TOS_AK") or os.getenv("AK")
        tos_sk = os.getenv("TOS_SK") or os.getenv("SK")
        if not tos_ak or not tos_sk:
            raise ValueError("配置 tosutil 需要设置 TOS_AK/TOS_SK，或 AK/SK")
        tos_region = os.getenv("TOS_REGION") or self.region
        tos_endpoint = os.getenv("TOS_ENDPOINT") or tos_endpoint_for_region(tos_region)
        is_windows = platform == "windows"
        log_env_sample(sample_dir, "下载 tosutil: platform=%s" % platform, extra={"instance_id": instance_id})
        download_result = self.run_command(
            instance_id,
            build_windows_download_tosutil_command() if is_windows else build_linux_download_tosutil_command(),
            timeout=int(os.getenv("TOSUTIL_DOWNLOAD_TIMEOUT_SECONDS", "300")),
            command_type="PowerShell" if is_windows else "Shell",
        )
        metadata["tosutil_download_result"] = download_result
        log_env_sample(
            sample_dir,
            "配置 tosutil: endpoint=%s region=%s" % (tos_endpoint, tos_region),
            extra={"instance_id": instance_id},
        )
        config_command = (
            build_windows_configure_tosutil_command(tos_ak, tos_sk, tos_endpoint, tos_region)
            if is_windows
            else build_linux_configure_tosutil_command(tos_ak, tos_sk, tos_endpoint, tos_region)
        )
        display_command = (
            build_windows_configure_tosutil_command("<access key>", "<secret key>", tos_endpoint, tos_region)
            if is_windows
            else build_linux_configure_tosutil_command("<access key>", "<secret key>", tos_endpoint, tos_region)
        )
        config_result = self.run_command(
            instance_id,
            config_command,
            timeout=int(os.getenv("TOSUTIL_CONFIG_TIMEOUT_SECONDS", "360")),
            command_type="PowerShell" if is_windows else "Shell",
            display_command=display_command,
        )
        metadata["tosutil_config_result"] = config_result
        metadata["tosutil_configured_at"] = now_text()
        metadata["tosutil_endpoint"] = tos_endpoint
        metadata["tosutil_region"] = tos_region
        if is_windows and os.getenv("WORKFLOWGYM_WINDOWS_PREDOWNLOAD_PYTHON_INSTALLER", "1").lower() not in (
            "0",
            "false",
            "no",
            "off",
        ):
            log_env_sample(sample_dir, "下载 Windows Python 安装包", extra={"instance_id": instance_id})
            python_installer_result = self.run_command(
                instance_id,
                build_windows_download_python_installer_command(),
                timeout=int(os.getenv("WINDOWS_PYTHON_INSTALLER_TOS_COPY_TIMEOUT_SECONDS", "300")),
                command_type="PowerShell",
            )
            metadata["windows_python_installer_download_result"] = python_installer_result
            metadata["windows_python_installer_downloaded_at"] = now_text()
        return metadata

    def capture_screenshot(self, instance_id: str, sample_dir: str, step_index: int) -> str:
        sample_path = Path(sample_dir)
        sample_path.mkdir(parents=True, exist_ok=True)
        if not self.dry_run:
            if not instance_id:
                raise ValueError("缺少 instance_id，无法调用 GetConsoleScreenshot")
            screenshot = self.get_console_screenshot(instance_id)
            if not screenshot:
                raise ValueError("GetConsoleScreenshot 返回空截图: %s" % instance_id)
            if not is_image_bytes(screenshot):
                raise ValueError("GetConsoleScreenshot 返回的不是有效图片: %s" % instance_id)
            path = sample_path / ("step_%s.%s" % (step_index, image_extension(screenshot)))
            path.write_bytes(screenshot)
            return str(path)
        path = sample_path / ("step_%s.png" % step_index)
        dry_run_screenshot = os.getenv("DRY_RUN_SCREENSHOT_PATH", "")
        if dry_run_screenshot:
            source_path = Path(dry_run_screenshot)
            if not source_path.exists():
                raise ValueError("DRY_RUN_SCREENSHOT_PATH 不存在: %s" % dry_run_screenshot)
            path.write_bytes(source_path.read_bytes())
        elif not path.exists() or path.stat().st_size == 0:
            path.write_bytes(DRY_RUN_SCREENSHOT_BYTES)
        return str(path)

    def wait_for_screen_stable(
        self,
        instance_id: str,
        sample_dir: str = "",
        label: str = "",
        previous_screenshot: str = "",
        timeout_seconds: float | None = None,
        poll_interval_seconds: float | None = None,
    ) -> dict[str, Any]:
        timeout = float(os.getenv("ACTION_SCREEN_STABLE_TIMEOUT_SECONDS", str(timeout_seconds or 4.0)))
        poll_interval = float(os.getenv("ACTION_SCREEN_STABLE_POLL_SECONDS", str(poll_interval_seconds or 0.5)))
        initial_delay = float(os.getenv("ACTION_SCREEN_STABLE_INITIAL_DELAY_SECONDS", "1.0"))
        unchanged_timeout = float(os.getenv("ACTION_SCREEN_STABLE_UNCHANGED_TIMEOUT_SECONDS", "2.0"))
        threshold = float(os.getenv("ACTION_SCREEN_STABLE_DIFF_THRESHOLD", "2.0"))
        required_stable = max(1, int(os.getenv("ACTION_SCREEN_STABLE_CONSECUTIVE", "2")))
        if self.dry_run or not instance_id:
            time.sleep(min(initial_delay, timeout))
            return {"status": "skipped", "reason": "dry_run_or_missing_instance"}

        previous_bytes = read_optional_bytes(previous_screenshot)
        changed = previous_bytes is None
        last_bytes: bytes | None = None
        stable_count = 0
        captures = 0
        last_diff: float | None = None
        deadline = time.time() + max(0.0, timeout)
        started_at = time.time()
        if initial_delay > 0:
            time.sleep(min(initial_delay, max(0.0, timeout)))

        while time.time() <= deadline:
            self.maybe_renew_lease_heartbeat()
            screenshot = self.get_console_screenshot(instance_id)
            captures += 1
            if not screenshot or not is_image_bytes(screenshot):
                time.sleep(poll_interval)
                continue
            if previous_bytes is not None and not changed:
                previous_diff = screenshot_difference(previous_bytes, screenshot)
                changed = previous_diff > threshold
            if last_bytes is not None:
                last_diff = screenshot_difference(last_bytes, screenshot)
                stable_count = stable_count + 1 if last_diff <= threshold else 0
            last_bytes = screenshot
            if (changed or previous_bytes is None) and stable_count >= required_stable:
                saved_path = self.write_stability_screenshot(sample_dir, label, screenshot)
                return {
                    "status": "stable",
                    "captures": captures,
                    "changed": changed,
                    "last_diff": last_diff,
                    "screenshot": saved_path,
                }
            if not changed and stable_count >= required_stable and time.time() - started_at >= unchanged_timeout:
                saved_path = self.write_stability_screenshot(sample_dir, label, screenshot)
                return {
                    "status": "stable_unchanged",
                    "captures": captures,
                    "changed": changed,
                    "last_diff": last_diff,
                    "screenshot": saved_path,
                }
            time.sleep(poll_interval)

        saved_path = self.write_stability_screenshot(sample_dir, label, last_bytes)
        return {
            "status": "timeout",
            "captures": captures,
            "changed": changed,
            "last_diff": last_diff,
            "screenshot": saved_path,
        }

    def write_stability_screenshot(self, sample_dir: str, label: str, screenshot: bytes | None) -> str:
        if not sample_dir or not screenshot or not is_image_bytes(screenshot):
            return ""
        sample_path = Path(sample_dir)
        sample_path.mkdir(parents=True, exist_ok=True)
        safe_label = "".join(ch if str(ch).isalnum() or ch in ("_", "-") else "_" for ch in str(label or "stable"))
        path = sample_path / ("%s.%s" % (safe_label, image_extension(screenshot)))
        path.write_bytes(screenshot)
        return str(path)

    def prepare_desktop_for_pyautogui(self, instance_id: str, sample_dir: str = "") -> dict[str, Any]:
        desktop_user = os.getenv("DESKTOP_USER", "user")
        if not desktop_user.replace("_", "").replace("-", "").isalnum():
            raise ValueError("DESKTOP_USER 只能包含字母、数字、下划线或中划线: %s" % desktop_user)
        desktop_home = os.getenv("DESKTOP_HOME", "/home/%s" % desktop_user)
        display = os.getenv("DESKTOP_DISPLAY", ":0")
        xauthority = os.getenv("XAUTHORITY", os.path.join(desktop_home, ".Xauthority"))
        resolution_width = int(os.getenv("DESKTOP_RESOLUTION_WIDTH", "1920"))
        resolution_height = int(os.getenv("DESKTOP_RESOLUTION_HEIGHT", "1080"))
        log_env_sample(
            sample_dir,
            "准备桌面: instance_id=%s user=%s display=%s target_resolution=%sx%s"
            % (instance_id, desktop_user, display, resolution_width, resolution_height),
            extra={"instance_id": instance_id},
        )

        log_env_sample(sample_dir, "配置 Xorg/GDM 自动登录", extra={"instance_id": instance_id})
        configure_output = self.run_command(
            instance_id,
            build_configure_xorg_command(desktop_user),
            timeout=int(os.getenv("DESKTOP_CONFIGURE_TIMEOUT_SECONDS", "300")),
        )
        if command_output_contains(configure_output, "GDM config updated"):
            log_env_sample(sample_dir, "GDM 配置已更新，等待桌面重新登录", extra={"instance_id": instance_id})
            time.sleep(int(os.getenv("GDM_RESTART_WAIT_SECONDS", "90")))

        log_env_sample(sample_dir, "准备 pyautogui 依赖", extra={"instance_id": instance_id})
        self.run_command(
            instance_id,
            build_prepare_pyautogui_dependencies_command(),
            timeout=int(os.getenv("DESKTOP_PREPARE_TIMEOUT_SECONDS", "900")),
        )
        log_env_sample(sample_dir, "安装 Linux action helpers", extra={"instance_id": instance_id})
        from open_workflowgym.agents.pyautogui_actions import build_install_linux_action_helpers_command

        helpers_result = self.run_command(
            instance_id,
            build_install_linux_action_helpers_command(desktop_home),
            timeout=int(os.getenv("DESKTOP_LINUX_HELPERS_TIMEOUT_SECONDS", "120")),
        )
        log_env_sample(
            sample_dir,
            "Linux action helpers 安装输出:\n%s" % command_decoded_output(helpers_result),
            extra={"instance_id": instance_id},
        )
        log_env_sample(sample_dir, "探测 X session/XAUTHORITY", extra={"instance_id": instance_id})
        discover_output = self.run_command(
            instance_id,
            build_discover_x_session_command(desktop_user, desktop_home),
            timeout=int(os.getenv("DESKTOP_DISCOVER_TIMEOUT_SECONDS", "300")),
        )
        discovered_xauthority = find_xauthority(command_decoded_output(discover_output)) or xauthority
        log_env_sample(sample_dir, "使用 XAUTHORITY: %s" % discovered_xauthority, extra={"instance_id": instance_id})
        log_env_sample(sample_dir, "解锁桌面会话", extra={"instance_id": instance_id})
        self.run_command(
            instance_id,
            build_unlock_desktop_command(desktop_user, desktop_home, display, discovered_xauthority),
            timeout=int(os.getenv("DESKTOP_UNLOCK_TIMEOUT_SECONDS", "300")),
        )
        log_env_sample(sample_dir, "配置英文键盘与输入法", extra={"instance_id": instance_id})
        english_input_result = self.run_command(
            instance_id,
            build_configure_english_desktop_command(
                desktop_user,
                desktop_home,
                display,
                discovered_xauthority,
            ),
            timeout=int(os.getenv("DESKTOP_ENGLISH_INPUT_TIMEOUT_SECONDS", "120")),
        )
        log_env_sample(
            sample_dir,
            "英文环境配置输出:\n%s" % command_decoded_output(english_input_result),
            extra={"instance_id": instance_id},
        )
        target_mode = "%sx%s" % (resolution_width, resolution_height)
        probe_result = self.run_command(
            instance_id,
            build_probe_xrandr_command(desktop_user, desktop_home, display, discovered_xauthority),
            timeout=int(os.getenv("DESKTOP_PROBE_TIMEOUT_SECONDS", "60")),
        )
        probe_output = command_decoded_output(probe_result)
        if display_session_needs_xorg_reboot(probe_output, target_mode):
            log_env_sample(
                sample_dir,
                "检测到 Wayland/XWayland 会话，重启实例以切换到 Xorg: instance_id=%s" % instance_id,
                extra={"instance_id": instance_id},
            )
            self.reboot_instance(instance_id)
            self.wait_for_status(
                instance_id,
                "RUNNING",
                timeout_seconds=int(os.getenv("INSTANCE_START_TIMEOUT_SECONDS", "600")),
            )
            time.sleep(int(os.getenv("DESKTOP_XORG_REBOOT_SETTLE_SECONDS", "60")))
            self.ensure_cloud_assistant_ready(instance_id)
            discover_output = self.run_command(
                instance_id,
                build_discover_x_session_command(desktop_user, desktop_home),
                timeout=int(os.getenv("DESKTOP_DISCOVER_TIMEOUT_SECONDS", "300")),
            )
            discovered_xauthority = find_xauthority(command_decoded_output(discover_output)) or xauthority
            log_env_sample(sample_dir, "Xorg 重启后使用 XAUTHORITY: %s" % discovered_xauthority, extra={"instance_id": instance_id})
            self.run_command(
                instance_id,
                build_unlock_desktop_command(desktop_user, desktop_home, display, discovered_xauthority),
                timeout=int(os.getenv("DESKTOP_UNLOCK_TIMEOUT_SECONDS", "300")),
            )
            self.run_command(
                instance_id,
                build_configure_english_desktop_command(
                    desktop_user,
                    desktop_home,
                    display,
                    discovered_xauthority,
                ),
                timeout=int(os.getenv("DESKTOP_ENGLISH_INPUT_TIMEOUT_SECONDS", "120")),
            )
        log_env_sample(
            sample_dir,
            "设置桌面分辨率: %sx%s" % (resolution_width, resolution_height),
            extra={"instance_id": instance_id},
        )
        resolution_result = self.run_command(
            instance_id,
            build_set_desktop_resolution_command(
                desktop_user,
                desktop_home,
                display,
                discovered_xauthority,
                resolution_width,
                resolution_height,
            ),
            timeout=int(os.getenv("DESKTOP_RESOLUTION_TIMEOUT_SECONDS", "300")),
        )
        log_env_sample(
            sample_dir,
            "分辨率设置输出:\n%s" % command_decoded_output(resolution_result),
            extra={"instance_id": instance_id},
        )
        log_env_sample(sample_dir, "校验 pyautogui/display 分辨率", extra={"instance_id": instance_id})
        validate_result = self.run_command(
            instance_id,
            build_validate_pyautogui_command(desktop_user, desktop_home, display, discovered_xauthority),
            timeout=int(os.getenv("DESKTOP_VALIDATE_TIMEOUT_SECONDS", "300")),
        )
        log_env_sample(
            sample_dir,
            "pyautogui 校验输出:\n%s" % command_decoded_output(validate_result),
            extra={"instance_id": instance_id},
        )
        validate_output = command_decoded_output(validate_result)
        display_width, display_height = parse_validated_display_resolution(
            validate_output,
            fallback_width=resolution_width,
            fallback_height=resolution_height,
        )
        desktop_metadata = {
            "desktop_resolution_result": resolution_result,
            "pyautogui_validation_result": validate_result,
            "display_width": display_width,
            "display_height": display_height,
            "display_resolution": "%sx%s" % (display_width, display_height),
            "english_input_configured_at_startup": True,
        }
        return {
            "desktop_user": desktop_user,
            "desktop_home": desktop_home,
            "display": display,
            "xauthority": discovered_xauthority,
            "desktop_prepared_at": now_text(),
            **desktop_metadata,
        }

    def prepare_gui_desktop_session(
        self,
        instance_id: str,
        desktop_user: str,
        sample_dir: str = "",
        resolution_width: int | None = None,
        resolution_height: int | None = None,
        enable_auto_login: bool | None = None,
    ) -> dict[str, Any]:
        if not desktop_user.replace("_", "").replace("-", "").isalnum():
            raise ValueError("desktop_user 只能包含字母、数字、下划线或中划线: %s" % desktop_user)
        if enable_auto_login is None:
            enable_auto_login = gui_image_enable_auto_login()
        desktop_home = os.getenv("DESKTOP_HOME", "/home/%s" % desktop_user)
        display = os.getenv("DESKTOP_DISPLAY", ":0")
        xauthority = os.getenv("XAUTHORITY", os.path.join(desktop_home, ".Xauthority"))
        width = int(resolution_width or os.getenv("DESKTOP_RESOLUTION_WIDTH", "1920"))
        height = int(resolution_height or os.getenv("DESKTOP_RESOLUTION_HEIGHT", "1080"))
        target_resolution = "%sx%s" % (width, height)
        log_env_sample(
            sample_dir,
            "准备 GUI 桌面会话: instance_id=%s user=%s resolution=%s auto_login=%s"
            % (instance_id, desktop_user, target_resolution, enable_auto_login),
            extra={"instance_id": instance_id},
        )
        configure_output: dict[str, Any] | None = None
        if enable_auto_login:
            log_env_sample(sample_dir, "配置 GDM 免密自动登录", extra={"instance_id": instance_id})
            configure_output = self.run_command(
                instance_id,
                build_configure_xorg_command(desktop_user),
                timeout=int(os.getenv("DESKTOP_CONFIGURE_TIMEOUT_SECONDS", "300")),
            )
            if command_output_contains(configure_output, "GDM config updated"):
                log_env_sample(sample_dir, "GDM 配置已更新，等待桌面重新登录", extra={"instance_id": instance_id})
                time.sleep(int(os.getenv("GDM_RESTART_WAIT_SECONDS", "90")))
                self.wait_for_status(
                    instance_id,
                    "RUNNING",
                    timeout_seconds=int(os.getenv("INSTANCE_START_TIMEOUT_SECONDS", "600")),
                )
                self.ensure_cloud_assistant_ready(instance_id)
                time.sleep(int(os.getenv("GDM_RESTART_SETTLE_SECONDS", "30")))
        discover_output = self.run_command(
            instance_id,
            build_discover_x_session_command(desktop_user, desktop_home),
            timeout=int(os.getenv("DESKTOP_DISCOVER_TIMEOUT_SECONDS", "300")),
        )
        discovered_xauthority = find_xauthority(command_decoded_output(discover_output)) or xauthority
        self.run_command(
            instance_id,
            build_unlock_desktop_command(desktop_user, desktop_home, display, discovered_xauthority),
            timeout=int(os.getenv("DESKTOP_UNLOCK_TIMEOUT_SECONDS", "300")),
        )
        xrandr_probe = self.run_command(
            instance_id,
            build_probe_xrandr_command(desktop_user, desktop_home, display, discovered_xauthority),
            timeout=int(os.getenv("DESKTOP_PROBE_TIMEOUT_SECONDS", "60")),
        )
        xrandr_output = command_decoded_output(xrandr_probe)
        if display_session_needs_xorg_reboot(xrandr_output, target_resolution):
            log_env_sample(
                sample_dir,
                "检测到 Wayland/XWayland 会话，重启实例以切换到 Xorg: instance_id=%s" % instance_id,
                extra={"instance_id": instance_id},
            )
            self.reboot_instance(instance_id)
            self.wait_for_status(
                instance_id,
                "RUNNING",
                timeout_seconds=int(os.getenv("INSTANCE_START_TIMEOUT_SECONDS", "600")),
            )
            time.sleep(int(os.getenv("DESKTOP_XORG_REBOOT_SETTLE_SECONDS", "60")))
            self.ensure_cloud_assistant_ready(instance_id)
            discover_output = self.run_command(
                instance_id,
                build_discover_x_session_command(desktop_user, desktop_home),
                timeout=int(os.getenv("DESKTOP_DISCOVER_TIMEOUT_SECONDS", "300")),
            )
            discovered_xauthority = find_xauthority(command_decoded_output(discover_output)) or xauthority
            self.run_command(
                instance_id,
                build_unlock_desktop_command(desktop_user, desktop_home, display, discovered_xauthority),
                timeout=int(os.getenv("DESKTOP_UNLOCK_TIMEOUT_SECONDS", "300")),
            )
        resolution_result = self.run_command(
            instance_id,
            build_set_desktop_resolution_command(
                desktop_user,
                desktop_home,
                display,
                discovered_xauthority,
                width,
                height,
            ),
            timeout=int(os.getenv("DESKTOP_RESOLUTION_TIMEOUT_SECONDS", "300")),
        )
        resolution_output = command_decoded_output(resolution_result)
        if target_resolution not in resolution_output:
            raise ValueError(
                "设置桌面分辨率失败: target=%s output=%s" % (target_resolution, resolution_output[:1000])
            )
        validate_result = self.run_command(
            instance_id,
            build_pyautogui_size_probe_command(desktop_user, desktop_home, display, discovered_xauthority),
            timeout=int(os.getenv("DESKTOP_VALIDATE_TIMEOUT_SECONDS", "300")),
        )
        validate_output = command_decoded_output(validate_result)
        assert_pyautogui_size_output(validate_output, width, height)
        return {
            "desktop_user": desktop_user,
            "desktop_home": desktop_home,
            "display": display,
            "xauthority": discovered_xauthority,
            "target_resolution": target_resolution,
            "auto_login_enabled": enable_auto_login,
            "gdm_configure_result": configure_output,
            "desktop_resolution_result": resolution_result,
            "pyautogui_validation_result": validate_result,
        }

    def wait_for_console_screenshot_ready(self, instance_id: str, sample_dir: str, timeout_seconds: int = 300) -> str:
        deadline = time.time() + timeout_seconds
        last_error = ""
        sample_path = Path(sample_dir)
        sample_path.mkdir(parents=True, exist_ok=True)
        while time.time() < deadline:
            self.maybe_renew_lease_heartbeat()
            try:
                screenshot = self.get_console_screenshot(instance_id)
                if not screenshot:
                    last_error = "空截图"
                elif not is_image_bytes(screenshot):
                    last_error = "非图片响应，bytes=%s" % len(screenshot)
                else:
                    ready_path = sample_path / ("env_ready.%s" % image_extension(screenshot))
                    ready_path.write_bytes(screenshot)
                    return str(ready_path)
            except Exception as exc:
                last_error = "%s" % exc
            time.sleep(int(os.getenv("DESKTOP_READY_POLL_INTERVAL_SECONDS", "10")))
        raise TimeoutError("等待实例桌面截图就绪超时: %s last_error=%s" % (instance_id, last_error))

    def run_command(
        self,
        instance_id: str,
        command: str,
        timeout: int = 300,
        command_type: str = "Shell",
        display_command: str = "",
        username: str = "",
    ) -> dict[str, Any]:
        if not self.dry_run:
            return self.run_command_and_wait(
                instance_id,
                command,
                timeout,
                command_type,
                display_command=display_command,
                username=username,
            )
        command_type = resolve_run_command_type(command_type, command, "")
        validate_run_command_payload(command, command_type)
        return {
            "instance_id": instance_id,
            "command_type": command_type,
            "command": command,
            "display_command": display_command or command,
            "username": username,
            "timeout": timeout,
            "status": "dry_run" if self.dry_run else "not_executed",
            "output": "",
        }

    def discover_reusable_instance_ids(
        self,
        name_prefix: str = "workflow_gym",
        project_name: str = "",
        limit: int = 30,
    ) -> list[str]:
        """Find existing ECS instances that can be leased by WorkflowGym."""
        return [
            str(item.get("InstanceId") or item.get("instance_id") or "")
            for item in self.discover_reusable_instances(name_prefix, project_name, limit)
            if item.get("InstanceId") or item.get("instance_id")
        ]

    def discover_reusable_instances(
        self,
        name_prefix: str = "workflow_gym",
        project_name: str = "",
        limit: int = 30,
        platform: str = "",
        target_image_id: str = "",
    ) -> list[dict[str, Any]]:
        """Find existing ECS instances that can be leased by WorkflowGym."""
        if self.dry_run:
            return []

        target_image_platform = ""
        if target_image_id:
            target_image_record = self.describe_image(target_image_id)
            target_image_platform = image_record_platform(target_image_record)

        instances = self.describe_instances(
            name_prefix=name_prefix,
            project_name=project_name,
            limit=max(1, limit * 4 if target_image_platform else limit),
        )
        reusable_statuses = {"RUNNING", "STOPPED"}
        reusable_instances = []
        for item in instances:
            status = item.get("Status") or item.get("status") or ""
            instance_id = item.get("InstanceId") or item.get("instance_id") or ""
            if not instance_id or status not in reusable_statuses:
                continue
            if platform == "windows" and not instance_supports_windows_runcommand(item):
                continue
            if platform == "ubuntu" and instance_supports_windows_runcommand(item):
                continue
            if target_image_platform and not instance_compatible_for_image_platform(item, target_image_platform):
                continue
            reusable_instances.append(item)
            if len(reusable_instances) >= limit:
                break
        return reusable_instances[:limit]

    def stop_instance(self, instance_id: str) -> dict[str, Any]:
        if not self.dry_run:
            self.ensure_stopped(instance_id)
        return {"instance_id": instance_id, "status": "stopped", "stopped_at": now_text()}

    def cleanup_public_ip_binding(self, env_metadata: dict[str, Any], sample_dir: str = "") -> dict[str, Any]:
        binding_result = env_metadata.get("public_ip_binding_result") or {}
        allocation_id = binding_result.get("allocation_id")
        if not allocation_id:
            return {"status": "skipped", "reason": "missing_allocation_id"}
        if self.dry_run:
            return {"status": "skipped", "reason": "dry_run", "allocation_id": allocation_id}
        log_env_sample(sample_dir, "解绑公网 IP 开始: allocation_id=%s" % allocation_id, extra={"allocation_id": allocation_id})
        result = disassociate_eip(allocation_id, self.region)
        log_env_sample(sample_dir, "解绑公网 IP 完成: allocation_id=%s" % allocation_id, extra={"allocation_id": allocation_id})
        return {"status": "disassociated", **result}

    def list_output_files(self, instance_id: str, output_path: str) -> dict[str, Any]:
        return {"instance_id": instance_id, "output_path": output_path, "files": []}

    def api(self):
        if self._api_instance is None:
            import volcenginesdkcore
            import volcenginesdkecs

            configuration = volcenginesdkcore.Configuration()
            configuration.ak = os.getenv("AK")
            configuration.sk = os.getenv("SK")
            configuration.region = self.region
            volcenginesdkcore.Configuration.set_default(configuration)
            self._api_instance = volcenginesdkecs.ECSApi()
        return self._api_instance

    def describe_instance_status(self, instance_id: str) -> str:
        instance = self.describe_instance(instance_id)
        return instance.get("Status") or instance.get("status")

    def describe_instance(self, instance_id: str) -> dict[str, Any]:
        import volcenginesdkecs

        request = volcenginesdkecs.DescribeInstancesRequest(instance_ids=[instance_id])
        response = self.api().describe_instances(request)
        data = to_plain_dict(response)
        result = get_result_payload(data)
        instances = result.get("Instances") or result.get("instances") or []
        if not instances:
            raise ValueError("DescribeInstances 响应中没有找到实例: %s" % instance_id)
        return instances[0]

    def describe_image(self, image_id: str) -> dict[str, Any]:
        import volcenginesdkecs

        image_id = str(image_id or "").strip()
        if not image_id:
            return {}
        if self.dry_run:
            return {"ImageId": image_id, "OsType": "Windows Server 2022"}
        request = volcenginesdkecs.DescribeImagesRequest(image_ids=[image_id])
        response = self.api().describe_images(request)
        data = to_plain_dict(response)
        result = get_result_payload(data)
        images = result.get("Images") or result.get("images") or []
        if not images:
            raise ValueError("DescribeImages 响应中没有找到镜像: %s" % image_id)
        return images[0]

    def describe_instances(
        self,
        name_prefix: str = "",
        project_name: str = "",
        limit: int = 30,
    ) -> list[dict[str, Any]]:
        import volcenginesdkecs

        instances: list[dict[str, Any]] = []
        next_token = ""
        while len(instances) < limit:
            request_kwargs: dict[str, Any] = {}
            if next_token:
                request_kwargs["next_token"] = next_token
            if project_name:
                request_kwargs["project_name"] = project_name
            request = volcenginesdkecs.DescribeInstancesRequest(**request_kwargs)
            response = self.api().describe_instances(request)
            data = to_plain_dict(response)
            result = get_result_payload(data)
            page_instances = result.get("Instances") or result.get("instances") or []
            for item in page_instances:
                instance_name = str(item.get("InstanceName") or item.get("instance_name") or "")
                if not instance_name_matches_prefix(instance_name, name_prefix):
                    continue
                instances.append(item)
                if len(instances) >= limit:
                    break
            next_token = result.get("NextToken") or result.get("next_token") or ""
            if not next_token:
                break
        return instances[:limit]

    def ensure_stopped(self, instance_id: str, timeout_seconds: int = 600, sample_dir: str = "") -> None:
        status = self.describe_instance_status(instance_id)
        if status == "STOPPED":
            if sample_dir:
                log_env_sample(sample_dir, "实例已停止: instance_id=%s" % instance_id, extra={"instance_id": instance_id})
            return
        if status in ("STOPPING",):
            if sample_dir:
                log_env_sample(sample_dir, "等待实例停止: instance_id=%s status=%s" % (instance_id, status), extra={"instance_id": instance_id})
            self.wait_for_status(instance_id, "STOPPED", timeout_seconds)
            return
        if status in ("RUNNING", "STARTING"):
            if sample_dir:
                log_env_sample(sample_dir, "停止实例: instance_id=%s status=%s" % (instance_id, status), extra={"instance_id": instance_id})
            import volcenginesdkecs

            self.api().stop_instance(volcenginesdkecs.StopInstanceRequest(instance_id=instance_id))
            self.wait_for_status(instance_id, "STOPPED", timeout_seconds)
            if sample_dir:
                log_env_sample(sample_dir, "实例已停止: instance_id=%s" % instance_id, extra={"instance_id": instance_id})
            return
        raise ValueError("实例状态不可停止或替换: %s status=%s" % (instance_id, status))

    def ensure_instance_running(self, instance_id: str) -> str:
        if self.dry_run:
            return "RUNNING"
        status = str(self.describe_instance_status(instance_id) or "").strip().upper()
        if status == "RUNNING":
            return status
        if status == "STOPPING":
            self.wait_for_status(
                instance_id,
                "STOPPED",
                timeout_seconds=int(os.getenv("INSTANCE_STOP_TIMEOUT_SECONDS", "600")),
            )
            status = "STOPPED"
        if status == "STOPPED":
            print("启动实例用于探测: instance_id=%s previous_status=STOPPED" % instance_id, flush=True)
            self.start_instance(instance_id)
            return "RUNNING"
        raise ValueError("实例状态无法启动: %s status=%s" % (instance_id, status or "<unknown>"))

    def start_instance(self, instance_id: str) -> None:
        import volcenginesdkecs

        deadline = time.time() + int(os.getenv("INSTANCE_START_TIMEOUT_SECONDS", "600"))
        request = volcenginesdkecs.StartInstanceRequest(instance_id=instance_id)
        last_error = None
        while time.time() < deadline:
            self.maybe_renew_lease_heartbeat()
            status = self.describe_instance_status(instance_id)
            if status == "RUNNING":
                return
            try:
                self.api().start_instance(request)
            except Exception as exc:
                last_error = exc
                if not is_instance_status_retryable(exc):
                    raise
            status = self.describe_instance_status(instance_id)
            if status == "RUNNING":
                return
            time.sleep(int(os.getenv("POLL_INTERVAL_SECONDS", "30")))
        raise TimeoutError("等待实例启动超时: %s last_error=%s" % (instance_id, last_error))

    def reboot_instance(self, instance_id: str) -> None:
        import volcenginesdkecs

        if hasattr(volcenginesdkecs, "RebootInstanceRequest"):
            self.api().reboot_instance(volcenginesdkecs.RebootInstanceRequest(instance_id=instance_id))
            return
        self.api().stop_instance(volcenginesdkecs.StopInstanceRequest(instance_id=instance_id))
        self.wait_for_status(instance_id, "STOPPED", timeout_seconds=int(os.getenv("INSTANCE_STOP_TIMEOUT_SECONDS", "600")))
        self.start_instance(instance_id)

    def wait_for_status(self, instance_id: str, expected: str, timeout_seconds: int = 600) -> None:
        deadline = time.time() + timeout_seconds
        while time.time() < deadline:
            self.maybe_renew_lease_heartbeat()
            status = self.describe_instance_status(instance_id)
            if status == expected:
                return
            time.sleep(5)
        raise TimeoutError("等待实例状态超时: %s expected=%s" % (instance_id, expected))

    def replace_system_volume(self, instance_id: str, image_id: str) -> None:
        import uuid
        import volcenginesdkecs

        password = os.getenv("INSTANCE_PASSWORD")
        request_kwargs = {
            "instance_id": instance_id,
            "image_id": image_id,
            "keep_image_credential": not bool(password),
            "client_token": str(uuid.uuid4()),
        }
        if password:
            request_kwargs["password"] = password
        request = volcenginesdkecs.ReplaceSystemVolumeRequest(**request_kwargs)
        self.api().replace_system_volume(request)

    def wait_for_replace_system_volume(
        self,
        instance_id: str,
        image_id: str,
        timeout_seconds: int = 600,
        sample_dir: str = "",
    ) -> dict[str, Any]:
        deadline = time.time() + timeout_seconds
        poll_seconds = int(os.getenv("REPLACE_SYSTEM_VOLUME_POLL_SECONDS", "5"))
        progress_seconds = int(os.getenv("REPLACE_SYSTEM_VOLUME_PROGRESS_SECONDS", "30"))
        last_progress_at = time.time()
        last_instance: dict[str, Any] = {}
        while time.time() < deadline:
            self.maybe_renew_lease_heartbeat()
            instance = self.describe_instance(instance_id)
            last_instance = instance
            status = str(instance.get("Status") or instance.get("status") or "").strip()
            current_image_id = instance_image_id(instance)
            if is_replace_system_volume_complete(instance, image_id):
                if sample_dir:
                    log_env_sample(
                        sample_dir,
                        "换盘完成: instance_id=%s image_id=%s status=%s"
                        % (instance_id, image_id, status or "<unknown>"),
                        extra={"instance_id": instance_id, "image_id": image_id, "status": status},
                    )
                return instance
            if sample_dir and time.time() - last_progress_at >= progress_seconds:
                log_env_sample(
                    sample_dir,
                    "等待换盘: instance_id=%s target_image=%s current_image=%s status=%s"
                    % (instance_id, image_id, current_image_id or "<unknown>", status or "<unknown>"),
                    extra={
                        "instance_id": instance_id,
                        "target_image_id": image_id,
                        "current_image_id": current_image_id,
                        "status": status,
                    },
                )
                last_progress_at = time.time()
            time.sleep(poll_seconds)
        raise TimeoutError(
            "等待镜像替换完成超时: instance_id=%s image_id=%s last_image_id=%s last_status=%s"
            % (
                instance_id,
                image_id,
                instance_image_id(last_instance),
                last_instance.get("Status") or last_instance.get("status") or "",
            )
        )

    def create_image_from_instance(
        self,
        instance_id: str,
        image_name: str,
        project_name: str = "",
    ) -> str:
        import volcenginesdkecs

        request = volcenginesdkecs.CreateImageRequest(
            image_name=image_name,
            instance_id=instance_id,
            project_name=project_name or os.getenv("PROJECT_NAME", "default"),
        )
        response = self.api().create_image(request)
        result = get_result_payload(to_plain_dict(response))
        image_id = result.get("ImageId") or result.get("image_id")
        if not image_id:
            raise ValueError("CreateImage 响应中没有 ImageId: %s" % result)
        print(
            "创建镜像任务已提交: instance_id=%s image_name=%s image_id=%s"
            % (instance_id, image_name, image_id),
            flush=True,
        )
        return str(image_id)

    def wait_for_image_task(
        self,
        image_id: str,
        timeout_seconds: int | None = None,
    ) -> list[dict[str, Any]]:
        import volcenginesdkecs

        poll_seconds = int(os.getenv("TASK_POLL_INTERVAL_SECONDS", "30"))
        deadline = time.time() + int(timeout_seconds or os.getenv("TASK_TIMEOUT_SECONDS", "1800"))
        last_tasks: list[dict[str, Any]] = []
        while time.time() < deadline:
            self.maybe_renew_lease_heartbeat()
            request = volcenginesdkecs.DescribeTasksRequest(resource_ids=[image_id])
            response = self.api().describe_tasks(request)
            result = get_result_payload(to_plain_dict(response))
            tasks = result.get("Tasks") or result.get("tasks") or []
            if tasks:
                last_tasks = tasks
                for task in tasks:
                    task_id = task.get("Id") or task.get("id")
                    task_type = task.get("Type") or task.get("type")
                    status = task.get("Status") or task.get("status")
                    process = task.get("Process")
                    if process is None:
                        process = task.get("process")
                    resource_id = task.get("ResourceId") or task.get("resource_id")
                    print(
                        "镜像任务进展: image_id=%s task_id=%s type=%s status=%s process=%s resource=%s"
                        % (image_id, task_id, task_type, status, process, resource_id),
                        flush=True,
                    )
                    if status in ("Failed", "FAILED", "Error", "ERROR"):
                        raise RuntimeError("镜像任务失败: %s" % task)
                    if process == 100 or status in (
                        "Success",
                        "SUCCESS",
                        "Succeeded",
                        "SUCCEEDED",
                        "Finished",
                        "FINISHED",
                    ):
                        return tasks
            time.sleep(poll_seconds)
        raise TimeoutError("等待镜像任务完成超时: image_id=%s last_tasks=%s" % (image_id, last_tasks))

    def get_console_screenshot(self, instance_id: str) -> bytes:
        import concurrent.futures
        import volcenginesdkecs

        request = volcenginesdkecs.GetConsoleScreenshotRequest(instance_id=instance_id, wake_up=True)
        max_attempts = int(os.getenv("CONSOLE_SCREENSHOT_MAX_ATTEMPTS", "6"))
        retry_base_seconds = float(os.getenv("CONSOLE_SCREENSHOT_RETRY_BASE_SECONDS", "5"))
        total_timeout_seconds = console_screenshot_total_timeout_seconds()
        call_timeout_seconds = console_screenshot_call_timeout_seconds()
        deadline = time.monotonic() + total_timeout_seconds
        last_error: Exception | None = None
        response = None

        def remaining_seconds() -> float:
            return max(0.0, deadline - time.monotonic())

        for attempt in range(1, max_attempts + 1):
            self.maybe_renew_lease_heartbeat()
            remaining = remaining_seconds()
            if remaining <= 0:
                raise TimeoutError(
                    "GetConsoleScreenshot 总超时: instance_id=%s timeout=%ss last_error=%s"
                    % (instance_id, total_timeout_seconds, last_error)
                )
            per_call_timeout = min(call_timeout_seconds, remaining)

            def call_api():
                return self.api().get_console_screenshot(request)

            try:
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                    future = executor.submit(call_api)
                    response = future.result(timeout=per_call_timeout)
                break
            except concurrent.futures.TimeoutError as exc:
                last_error = TimeoutError(
                    "GetConsoleScreenshot 单次调用超时: instance_id=%s attempt=%s/%s timeout=%ss"
                    % (instance_id, attempt, max_attempts, per_call_timeout)
                )
                if attempt >= max_attempts or remaining_seconds() <= 0:
                    raise TimeoutError(
                        "GetConsoleScreenshot 总超时: instance_id=%s timeout=%ss last_error=%s"
                        % (instance_id, total_timeout_seconds, last_error)
                    ) from exc
                sleep_seconds = min(retry_base_seconds * attempt, remaining_seconds())
                if sleep_seconds > 0:
                    print(
                        "GetConsoleScreenshot 单次调用超时，等待后重试: instance_id=%s attempt=%s/%s sleep=%ss"
                        % (instance_id, attempt, max_attempts, sleep_seconds),
                        flush=True,
                    )
                    time.sleep(sleep_seconds)
            except Exception as exc:
                last_error = exc
                if is_console_screenshot_invalid_timestamp_error(exc):
                    self._api_instance = None
                if not is_console_screenshot_retryable(exc) or attempt >= max_attempts:
                    raise
                remaining = remaining_seconds()
                if remaining <= 0:
                    raise TimeoutError(
                        "GetConsoleScreenshot 总超时: instance_id=%s timeout=%ss last_error=%s"
                        % (instance_id, total_timeout_seconds, last_error)
                    ) from exc
                if is_flow_limit_retryable(exc):
                    flow_limit_sleep = float(os.getenv("CONSOLE_SCREENSHOT_FLOW_LIMIT_RETRY_SECONDS", "10"))
                    sleep_seconds = min(flow_limit_sleep, remaining)
                else:
                    sleep_seconds = min(retry_base_seconds * attempt, remaining)
                reason = "被限流" if is_flow_limit_retryable(exc) else "签名过期"
                print(
                    "GetConsoleScreenshot %s，等待后重试: instance_id=%s attempt=%s/%s sleep=%ss"
                    % (reason, instance_id, attempt, max_attempts, sleep_seconds),
                    flush=True,
                )
                if sleep_seconds > 0:
                    time.sleep(sleep_seconds)
        else:
            raise TimeoutError("GetConsoleScreenshot 重试耗尽: %s last_error=%s" % (instance_id, last_error))
        data = to_plain_dict(response)
        result = get_result_payload(data)
        screenshot = result.get("Screenshot") or result.get("screenshot")
        if not screenshot:
            raise ValueError("GetConsoleScreenshot 响应中没有 Screenshot 字段")
        if "," in screenshot:
            screenshot = screenshot.split(",", 1)[1]
        return base64.b64decode(screenshot)

    def run_command_and_wait(
        self,
        instance_id: str,
        command: str,
        timeout: int,
        command_type: str,
        display_command: str = "",
        username: str = "",
    ) -> dict[str, Any]:
        import volcenginesdkecs

        self.ensure_cloud_assistant_ready(instance_id)
        instance = self.describe_instance(instance_id)
        os_type = platform_to_os_type_label(instance_platform_from_name(instance))
        command_type = resolve_run_command_type(command_type, command, os_type)
        validate_run_command_payload(command, command_type)
        working_dir = "C:\\Users\\" if command_type in ("PowerShell", "Bat") else "/home"
        request_kwargs = {
            "working_dir": working_dir,
            "timeout": timeout,
            "type": command_type,
            "command_content": command,
            "invocation_name": "workflowgym-run-command",
            "instance_ids": [instance_id],
            "content_encoding": "PlainText",
        }
        windows_password_for_log = ""
        if command_type in ("PowerShell", "Bat"):
            windows_password = windows_login_password()
            if not windows_password:
                raise ValueError("Windows RunCommand 需要设置 WINDOWS_LOGIN_PASSWORD 或 INSTANCE_PASSWORD")
            request_kwargs["windows_password"] = windows_password
            windows_password_for_log = windows_password
            if username:
                request_kwargs["username"] = username
        request = volcenginesdkecs.RunCommandRequest(**request_kwargs)
        response = self.api().run_command(request)
        data = to_plain_dict(response)
        result = get_result_payload(data)
        invocation_id = result.get("InvocationId") or result.get("invocation_id")
        if not invocation_id:
            raise ValueError("RunCommand 响应中没有 InvocationId")
        print(
            "WORKFLOWGYM_RUNCOMMAND_SUBMITTED instance_id=%s invocation_id=%s type=%s working_dir=%s timeout=%s"
            % (instance_id, invocation_id, command_type, working_dir, timeout),
            flush=True,
        )
        deadline = time.time() + timeout + 60
        while time.time() < deadline:
            self.maybe_renew_lease_heartbeat()
            time.sleep(5)
            results_request = volcenginesdkecs.DescribeInvocationResultsRequest(
                invocation_id=invocation_id,
                instance_id=instance_id,
                page_number=1,
                page_size=10,
            )
            response = self.api().describe_invocation_results(results_request)
            result_data = get_result_payload(to_plain_dict(response))
            invocation_results = result_data.get("InvocationResults") or result_data.get("invocation_results") or []
            if not invocation_results:
                continue
            for item in invocation_results:
                output = item.get("Output") or item.get("output")
                if output:
                    item["decoded_output"] = maybe_decode_output(output)
            finished = True
            failed = False
            for item in invocation_results:
                status = item.get("InvocationResultStatus") or item.get("invocation_result_status")
                exit_code = item.get("ExitCode")
                if exit_code is None:
                    exit_code = item.get("exit_code")
                if status in ("Pending", "Running"):
                    finished = False
                elif status != "Success" or exit_code != 0:
                    failed = True
            print_run_command_invocation_results(invocation_id, invocation_results, finished=finished, failed=failed)
            if not finished:
                continue
            if failed:
                failure_text = format_run_command_failure_text(invocation_results)
                raise_cloud_assistant_platform_mismatch_from_text(
                    failure_text,
                    instance_platform=instance_platform_from_name(self.describe_instance(instance_id)),
                )
                raise ValueError(
                    "RunCommand 执行失败: %s\n%s"
                    % (
                        invocation_results,
                        format_run_command_context(
                            instance_id,
                            invocation_id,
                            command_type,
                            working_dir,
                            timeout,
                            display_command or command,
                            windows_password_for_log,
                        ),
                    )
                )
            self._renew_lease_after_successful_command()
            return {"invocation_id": invocation_id, "results": invocation_results}
        raise TimeoutError(
            "等待 RunCommand 超时: %s\n%s"
            % (
                invocation_id,
                format_run_command_context(
                    instance_id,
                    invocation_id,
                    command_type,
                    working_dir,
                    timeout,
                    display_command or command,
                    windows_password_for_log,
                ),
            )
        )

    def describe_cloud_assistant_status(self, instance_id: str) -> dict[str, Any] | None:
        import volcenginesdkecs

        request = volcenginesdkecs.DescribeCloudAssistantStatusRequest(
            instance_ids=[instance_id],
        )
        response = self.api().describe_cloud_assistant_status(request)
        data = to_plain_dict(response)
        result = get_result_payload(data)
        instances = result.get("Instances") or result.get("instances") or []
        for item in instances:
            item_id = item.get("InstanceId") or item.get("instance_id")
            if item_id == instance_id:
                return item
        return None

    def _reboot_for_cloud_assistant(self, instance_id: str) -> None:
        print("Cloud Assistant 需要重启实例，开始自动重启: instance_id=%s" % instance_id, flush=True)
        self.reboot_instance(instance_id)
        self.wait_for_status(instance_id, "RUNNING", timeout_seconds=int(os.getenv("INSTANCE_START_TIMEOUT_SECONDS", "600")))
        time.sleep(int(os.getenv("CLOUD_ASSISTANT_REBOOT_SETTLE_SECONDS", "20")))

    def ensure_cloud_assistant_ready(self, instance_id: str) -> dict[str, Any]:
        import volcenginesdkecs

        if self.dry_run:
            return {"InstanceId": instance_id, "Status": "Online", "dry_run": True}

        max_reboot_attempts = max(0, int(os.getenv("CLOUD_ASSISTANT_MAX_REBOOT_ATTEMPTS", "1")))
        reboot_attempts = 0
        timeout_seconds = int(os.getenv("CLOUD_ASSISTANT_WAIT_TIMEOUT_SECONDS", "300"))
        poll_interval_seconds = int(os.getenv("CLOUD_ASSISTANT_POLL_INTERVAL_SECONDS", "10"))
        deadline = time.time() + timeout_seconds
        installed = False
        last_status: dict[str, Any] | None = None

        def maybe_reboot_for_readyreboot(status: dict[str, Any] | None) -> bool:
            nonlocal reboot_attempts, deadline
            if not cloud_assistant_needs_reboot(status):
                return False
            if reboot_attempts >= max_reboot_attempts:
                raise RuntimeError("Cloud Assistant 已安装但需要重启实例后才能使用: instance_id=%s" % instance_id)
            reboot_attempts += 1
            self._reboot_for_cloud_assistant(instance_id)
            deadline = time.time() + timeout_seconds
            return True

        status = self.describe_cloud_assistant_status(instance_id)
        last_status = status
        if cloud_assistant_ready(status):
            return status or {}
        if maybe_reboot_for_readyreboot(status):
            status = self.describe_cloud_assistant_status(instance_id)
            last_status = status
            if cloud_assistant_ready(status):
                print("Cloud Assistant 已可用: instance_id=%s" % instance_id, flush=True)
                return status or {}
        elif status is None and not installed:
            print("Cloud Assistant 未注册，开始安装: instance_id=%s" % instance_id, flush=True)
            request = volcenginesdkecs.InstallCloudAssistantRequest(instance_ids=[instance_id])
            self.api().install_cloud_assistant(request)
            installed = True
        else:
            print(
                "Cloud Assistant 尚未可用，等待状态恢复: instance_id=%s status=%s"
                % (instance_id, cloud_assistant_status_value(status)),
                flush=True,
            )

        while time.time() < deadline:
            self.maybe_renew_lease_heartbeat()
            time.sleep(poll_interval_seconds)
            last_status = self.describe_cloud_assistant_status(instance_id)
            if cloud_assistant_ready(last_status):
                print("Cloud Assistant 已可用: instance_id=%s" % instance_id, flush=True)
                return last_status or {}
            if maybe_reboot_for_readyreboot(last_status):
                last_status = self.describe_cloud_assistant_status(instance_id)
                if cloud_assistant_ready(last_status):
                    print("Cloud Assistant 已可用: instance_id=%s" % instance_id, flush=True)
                    return last_status or {}
        raise TimeoutError("等待 Cloud Assistant 可用超时: instance_id=%s status=%s" % (instance_id, last_status))

    def probe_cloud_assistant_platform(self, instance_id: str, instance_platform: str) -> dict[str, Any]:
        command_type = "PowerShell" if instance_platform == "windows" else "Shell"
        command = (
            "Write-Output 'WORKFLOWGYM_CA_PROBE_OK'"
            if instance_platform == "windows"
            else "#!/bin/bash\necho WORKFLOWGYM_CA_PROBE_OK"
        )
        try:
            result = self.run_command(instance_id, command, timeout=60, command_type=command_type)
        except Exception as exc:
            raise_cloud_assistant_platform_mismatch(
                exc,
                instance_platform=instance_platform,
                image_platform=instance_platform,
            )
            raise
        output = command_decoded_output(result)
        if "WORKFLOWGYM_CA_PROBE_OK" not in output:
            raise_cloud_assistant_platform_mismatch_from_text(
                output,
                instance_platform=instance_platform,
                image_platform=instance_platform,
            )
            raise ValueError("云助手探针未返回预期结果: instance_id=%s output=%s" % (instance_id, output[:500]))
        return result

    def verify_cloud_assistant_platform_with_runcommand(
        self,
        instance_id: str,
        instance_platform: str,
        sample_dir: str,
        image_platform: str = "",
        image_os_type_label: str = "",
    ) -> dict[str, Any]:
        log_env_sample(
            sample_dir,
            "RunCommand 校验云助手与实例 OS 平台: instance_id=%s platform=%s"
            % (instance_id, instance_platform),
            extra={"instance_id": instance_id, "instance_platform": instance_platform},
        )
        result = self.probe_cloud_assistant_platform(instance_id, instance_platform)
        log_env_sample(
            sample_dir,
            "云助手与实例 OS 平台校验通过: instance_id=%s platform=%s"
            % (instance_id, instance_platform),
            extra={"instance_id": instance_id, "instance_platform": instance_platform},
        )
        return result


def to_plain_dict(response):
    if isinstance(response, dict):
        return response
    if hasattr(response, "to_dict"):
        return response.to_dict()
    return response


def get_result_payload(response_data):
    if isinstance(response_data, dict):
        return response_data.get("Result", response_data)
    return response_data


def maybe_decode_output(output: str) -> str:
    if not output:
        return output
    try:
        return base64.b64decode(output, validate=True).decode("utf-8")
    except Exception:
        return output


def instance_os_type(instance: dict[str, Any]) -> str:
    for key in (
        "OsType",
        "os_type",
        "OSType",
        "Platform",
        "platform",
        "OperatingSystem",
        "operating_system",
        "OsName",
        "os_name",
    ):
        value = str(instance.get(key) or "").strip()
        if value:
            return value
    return ""


def instance_image_id(instance: dict[str, Any]) -> str:
    for key in ("ImageId", "image_id"):
        value = str(instance.get(key) or "").strip()
        if value:
            return value
    return ""


def instance_display_name(instance: dict[str, Any]) -> str:
    return str(instance.get("InstanceName") or instance.get("instance_name") or "").strip()


class CloudAssistantPlatformMismatchError(ValueError):
    """Raised when image OS and Cloud Assistant capability do not match."""

    def __init__(
        self,
        message: str,
        *,
        instance_id: str = "",
        instance_name: str = "",
        instance_platform: str = "",
        instance_os_type: str = "",
        expected_platform: str = "",
        expected_os_type: str = "",
        image_id: str = "",
        task_expected_platform: str = "",
        task_expected_os_type: str = "",
    ):
        super().__init__(message)
        self.instance_id = instance_id
        self.instance_name = instance_name
        self.instance_platform = instance_platform
        self.instance_os_type = instance_os_type
        self.expected_platform = expected_platform
        self.expected_os_type = expected_os_type
        self.image_id = image_id
        self.task_expected_platform = task_expected_platform
        self.task_expected_os_type = task_expected_os_type

    def context(self) -> dict[str, str]:
        return {
            key: value
            for key, value in {
                "instance_id": self.instance_id,
                "instance_name": self.instance_name,
                "instance_platform": self.instance_platform,
                "instance_os_type": self.instance_os_type,
                "expected_platform": self.expected_platform,
                "expected_os_type": self.expected_os_type,
                "image_id": self.image_id,
                "task_expected_platform": self.task_expected_platform,
                "task_expected_os_type": self.task_expected_os_type,
            }.items()
            if value
        }


def instance_platform_from_name(instance: dict[str, Any]) -> str:
    """Authoritative instance OS platform from InstanceName (Cloud Assistant binding)."""
    name = instance_display_name(instance).lower()
    if "windows" in name or name.endswith("_win") or "_win_" in name:
        return "windows"
    if "ubuntu" in name or "linux" in name:
        return "ubuntu"
    for key in ("OsType", "os_type", "OSType", "OsName", "os_name", "Platform", "platform"):
        value = str(instance.get(key) or "").strip().lower()
        if not value:
            continue
        if "windows" in value:
            return "windows"
        if "linux" in value or "ubuntu" in value:
            return "ubuntu"
    raise ValueError(
        "无法从实例名判断 OS 平台: name=%s；请使用 open_workflow_gym_windows 或 open_workflow_gym_ubuntu"
        % instance_display_name(instance)
    )


def instance_cloud_assistant_platform(instance: dict[str, Any]) -> str:
    return instance_platform_from_name(instance)


def instance_supports_windows_runcommand(instance: dict[str, Any]) -> bool:
    try:
        return instance_platform_from_name(instance) == "windows"
    except ValueError:
        return False


def instance_supports_linux_runcommand(instance: dict[str, Any]) -> bool:
    try:
        return instance_platform_from_name(instance) == "ubuntu"
    except ValueError:
        return False


def image_record_field(image: dict[str, Any], *keys: str) -> str:
    for key in keys:
        value = str(image.get(key) or "").strip()
        if value:
            return value
    return ""


def image_os_type_label(image: dict[str, Any]) -> str:
    os_type = image_record_field(image, "OsType", "os_type", "OSType")
    platform = image_record_field(image, "Platform", "platform")
    if os_type and platform:
        return "%s/%s" % (os_type, platform)
    return os_type or platform or image_os_type(image)


def image_record_platform(image: dict[str, Any]) -> str:
    os_type = image_record_field(image, "OsType", "os_type", "OSType")
    platform = image_record_field(image, "Platform", "platform")
    if is_windows_os(os_type) or is_windows_os(platform):
        return "windows"
    if is_linux_os(os_type) or is_linux_os(platform):
        return "ubuntu"
    image_name = str(image.get("ImageName") or image.get("image_name") or "").lower()
    if "windows" in image_name:
        return "windows"
    if any(item in image_name for item in ("ubuntu", "linux", "debian", "centos")):
        return "ubuntu"
    return ""


def platform_to_os_type_label(platform: str) -> str:
    normalized = str(platform or "").strip().lower()
    if normalized == "windows":
        return "Windows"
    if normalized == "ubuntu":
        return "Ubuntu"
    raise ValueError("未知 platform: %s" % platform)


def is_cloud_assistant_platform_mismatch_error(exc: Exception) -> bool:
    return is_cloud_assistant_platform_mismatch_text("%s" % exc)


def is_cloud_assistant_platform_mismatch_text(text: str) -> bool:
    lowered = str(text or "").lower()
    return any(
        token in lowered
        for token in (
            "unsupported command type powershell on linux",
            "powershell on linux",
            "unsupported command type bat on linux",
            "linux/ubuntu 实例仅支持 shell 和 python",
            "linux/ubuntu 实例不能执行 powershell",
            "目标实例为 windows，不能执行 linux bash",
            "镜像 os 与云助手版本不匹配",
            "云助手与实例 os 平台",
            "与目标镜像",
            "跳过换盘",
            "平台不一致",
        )
    )


def raise_cloud_assistant_platform_mismatch_from_text(
    text: str,
    *,
    instance_platform: str = "",
    image_platform: str = "",
    image_os_type_label: str = "",
) -> None:
    if not is_cloud_assistant_platform_mismatch_text(text):
        return
    raise CloudAssistantPlatformMismatchError(
        "镜像 OS(%s) 与云助手版本不匹配（instance_platform=%s, image_platform=%s）。"
        "请使用与镜像 OS 一致的原生实例名（open_workflow_gym_windows / open_workflow_gym_ubuntu），停止采样。"
        "原始错误: %s"
        % (
            image_os_type_label or image_platform or "<unknown>",
            instance_platform or "<unknown>",
            image_platform or "<unknown>",
            text,
        ),
        instance_platform=instance_platform or "",
        instance_os_type=platform_to_os_type_label(instance_platform) if instance_platform else "",
        expected_platform=image_platform or "",
        expected_os_type=image_os_type_label or platform_to_os_type_label(image_platform) if image_platform else (image_os_type_label or ""),
    )


def raise_cloud_assistant_platform_mismatch(
    exc: Exception,
    *,
    instance_platform: str = "",
    image_platform: str = "",
    image_os_type_label: str = "",
) -> None:
    if isinstance(exc, CloudAssistantPlatformMismatchError):
        raise exc
    text = "%s" % exc
    if is_cloud_assistant_platform_mismatch_text(text):
        raise CloudAssistantPlatformMismatchError(
            "镜像 OS(%s) 与云助手版本不匹配（instance_platform=%s, image_platform=%s）。"
            "请使用与镜像 OS 一致的原生实例名（open_workflow_gym_windows / open_workflow_gym_ubuntu），停止采样。"
            "原始错误: %s"
            % (
                image_os_type_label or image_platform or "<unknown>",
                instance_platform or "<unknown>",
                image_platform or "<unknown>",
                text,
            ),
            instance_platform=instance_platform or "",
            instance_os_type=platform_to_os_type_label(instance_platform) if instance_platform else "",
            expected_platform=image_platform or "",
            expected_os_type=image_os_type_label or platform_to_os_type_label(image_platform) if image_platform else (image_os_type_label or ""),
        ) from exc


def format_run_command_failure_text(invocation_results: list[dict[str, Any]]) -> str:
    parts: list[str] = []
    for item in invocation_results:
        for key in ("ErrorMessage", "error_message", "Output", "output"):
            value = item.get(key)
            if value:
                parts.append(str(value))
        decoded = item.get("decoded_output")
        if decoded:
            parts.append(str(decoded))
    return "\n".join(parts)


def image_os_type(image: dict[str, Any]) -> str:
    for key in (
        "OsType",
        "os_type",
        "OSType",
        "Platform",
        "platform",
        "OperatingSystem",
        "operating_system",
        "OsName",
        "os_name",
    ):
        value = str(image.get(key) or "").strip()
        if value:
            return value
    image_name = str(image.get("ImageName") or image.get("image_name") or "").lower()
    if "windows" in image_name:
        return "Windows"
    if any(item in image_name for item in ("ubuntu", "linux", "debian", "centos")):
        return "Ubuntu"
    return ""


def platform_from_image_os_type(os_type: str) -> str:
    if is_windows_os(os_type):
        return "windows"
    if is_linux_os(os_type):
        return "ubuntu"
    return ""


def instance_compatible_for_image_platform(instance: dict[str, Any], image_platform: str) -> bool:
    try:
        instance_platform = instance_platform_from_name(instance)
    except ValueError:
        return False
    normalized_image_platform = str(image_platform or "").strip().lower()
    if not normalized_image_platform:
        return True
    return instance_platform == normalized_image_platform


def is_replace_system_volume_complete(instance: dict[str, Any], image_id: str) -> bool:
    if instance_image_id(instance) != image_id:
        return False
    status = str(instance.get("Status") or instance.get("status") or "").strip()
    return status in ("STOPPED", "RUNNING")


def is_windows_os(os_type: str) -> bool:
    return "windows" in str(os_type or "").lower()


def is_linux_os(os_type: str) -> bool:
    text = str(os_type or "").lower()
    return any(item in text for item in ("linux", "ubuntu", "debian", "centos", "rocky", "almalinux", "fedora"))


def platform_from_os_type(os_type: str) -> str:
    if is_windows_os(os_type):
        return "windows"
    return "ubuntu"


def resolve_effective_os_type(described_os_type: str, platform_hint: str = "") -> str:
    described = str(described_os_type or "").strip()
    hint = str(platform_hint or "").strip().lower()
    if hint in ("windows", "win"):
        return described if is_windows_os(described) else "Windows"
    if hint in ("ubuntu", "linux"):
        return described if is_linux_os(described) else "Ubuntu"
    if is_windows_os(described) or is_linux_os(described):
        return described
    if hint:
        return "Windows" if "win" in hint else "Ubuntu"
    return described


def resolve_run_command_type(command_type: str, command: str, os_type: str) -> str:
    requested = str(command_type or "").strip() or "Shell"
    if is_windows_os(os_type):
        if command.lstrip().startswith("#!/bin/bash"):
            raise ValueError("目标实例为 Windows，不能执行 Linux bash 脚本；请使用 Type=Bat 或 Type=PowerShell")
        if requested == "Python":
            return "Python"
        if requested in ("Bat", "PowerShell"):
            return requested
        return "PowerShell" if looks_like_powershell(command) else "Bat"
    if requested in ("PowerShell", "Bat"):
        raise ValueError(
            "Linux/Ubuntu 实例仅支持 Shell 和 Python RunCommand，不能使用 Type=%s；请换 Windows 实例"
            % requested
        )
    if requested == "Python":
        return "Python"
    if requested not in ("", "Shell"):
        raise ValueError("Linux/Ubuntu 实例仅支持 Shell 和 Python RunCommand")
    if looks_like_powershell(command):
        raise ValueError("Linux/Ubuntu 实例不能执行 PowerShell 脚本，请改用 Shell 或 Python")
    return "Shell"


def looks_like_powershell(command: str) -> bool:
    text = command.lstrip().lower()
    return text.startswith("#requires") or any(
        token in text
        for token in (
            "powershell",
            "$erroractionpreference",
            "invoke-webrequest",
            "write-host",
            "write-output",
            "new-item",
            "remove-item",
            "test-path",
            "get-",
            "set-",
            "$env:",
        )
    )


def validate_run_command_payload(command: str, command_type: str, content_encoding: str = "PlainText") -> None:
    payload = command
    if content_encoding == "Base64":
        try:
            payload = base64.b64decode(command, validate=True).decode("utf-8")
        except Exception as exc:
            raise ValueError("RunCommand Base64 编码内容无效") from exc
    content_size = len(payload.encode("utf-8"))
    if content_size > RUN_COMMAND_MAX_CONTENT_BYTES:
        raise ValueError("RunCommand 脚本内容超过 16KB: %s bytes" % content_size)
    if command_type == "Shell" and not payload.startswith("#!/bin/bash"):
        raise ValueError("Linux Shell 脚本首行必须包含 #!/bin/bash")


def windows_login_user() -> str:
    return os.getenv("WINDOWS_LOGIN_USER") or os.getenv("DESKTOP_USER") or os.getenv("INSTANCE_USERNAME") or "Administrator"


def windows_login_password() -> str:
    return os.getenv("WINDOWS_LOGIN_PASSWORD") or os.getenv("INSTANCE_PASSWORD") or ""


def format_run_command_context(
    instance_id: str,
    invocation_id: str,
    command_type: str,
    working_dir: str,
    timeout: int,
    command: str,
    windows_password: str = "",
) -> str:
    lines = [
        "RunCommand context:",
        "  instance_id=%s" % instance_id,
        "  invocation_id=%s" % invocation_id,
        "  type=%s" % command_type,
        "  working_dir=%s" % working_dir,
        "  timeout=%s" % timeout,
    ]
    if command_type in ("PowerShell", "Bat"):
        lines.append("  windows_password=%s" % mask_secret_for_log(windows_password))
    lines.extend(
        [
            "  command:",
            command,
        ]
    )
    return "\n".join(lines)


def mask_secret_for_log(value: str) -> str:
    if not value:
        return "<empty>"
    text = str(value)
    return "<set len=%s last4=%s>" % (len(text), text[-4:])


def ps_single_quote(value: str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def tos_endpoint_for_region(region: str) -> str:
    normalized = str(region or "cn-beijing").strip() or "cn-beijing"
    return "tos-%s.volces.com" % normalized


def tosutil_verify_bucket_uri() -> str:
    """Return a narrow TOS prefix for init connectivity checks (avoids listing the whole bucket)."""
    explicit = (os.getenv("TOS_VERIFY_LIST_URI") or "").strip()
    if explicit:
        return explicit.rstrip("/") + "/"
    bucket = os.getenv("TOS_VERIFY_BUCKET") or os.getenv("TOS_UPLOAD_BUCKET", "tos://open-workflowgym-sample")
    bucket = bucket.rstrip("/")
    prefix = (os.getenv("TOS_VERIFY_PREFIX") or ".workflowgym-healthcheck").strip().strip("/")
    if prefix:
        return "%s/%s/" % (bucket, prefix)
    return bucket + "/"


def build_linux_download_tosutil_command() -> str:
    download_url = os.getenv(
        "LINUX_TOSUTIL_DOWNLOAD_URL",
        "https://m645b3e1bb36e-mrap.mrap.accesspoint.tos-global.volces.com/linux/amd64/tosutil",
    )
    target = os.getenv("LINUX_TOSUTIL_PATH", "/usr/local/bin/tosutil")
    return "\n".join(
        [
            "#!/bin/bash",
            "set -euo pipefail",
            "download_url=%s" % shlex.quote(download_url),
            "target=%s" % shlex.quote(target),
            "tmp_path=\"${target}.tmp\"",
            "mkdir -p \"$(dirname \"$target\")\"",
            "rm -f \"$tmp_path\"",
            "wget -q \"$download_url\" -O \"$tmp_path\"",
            "chmod a+x \"$tmp_path\"",
            "mv \"$tmp_path\" \"$target\"",
            "\"$target\" version",
            "printf 'WORKFLOWGYM_LINUX_TOSUTIL_DOWNLOAD_READY path=%s\\n' \"$target\"",
        ]
    )


def build_linux_configure_tosutil_command(tos_ak: str, tos_sk: str, tos_endpoint: str, tos_region: str) -> str:
    target = os.getenv("LINUX_TOSUTIL_PATH", "/usr/local/bin/tosutil")
    verify_bucket = tosutil_verify_bucket_uri()
    return "\n".join(
        [
            "#!/bin/bash",
            "set -euo pipefail",
            "target=%s" % shlex.quote(target),
            "verify_bucket=%s" % shlex.quote(verify_bucket),
            "test -x \"$target\"",
            "\"$target\" config -i %s -k %s -e %s -re %s"
            % (
                shlex.quote(tos_ak),
                shlex.quote(tos_sk),
                shlex.quote(tos_endpoint),
                shlex.quote(tos_region),
            ),
            "\"$target\" ls \"$verify_bucket\"",
            "printf 'WORKFLOWGYM_LINUX_TOSUTIL_CONFIG_DONE endpoint=%s region=%s bucket=%s\\n' %s %s %s"
            % ("%s", "%s", "%s", shlex.quote(tos_endpoint), shlex.quote(tos_region), shlex.quote(verify_bucket)),
        ]
    )


def build_windows_download_tosutil_command() -> str:
    download_url = os.getenv(
        "WINDOWS_TOSUTIL_DOWNLOAD_URL",
        "https://m645b3e1bb36e-mrap.mrap.accesspoint.tos-global.volces.com/windows/tosutil",
    )
    target = os.getenv("WINDOWS_TOSUTIL_PATH", r"C:\Windows\System32\tosutil.exe")
    return r"""$ErrorActionPreference = 'Stop'
$url = __DOWNLOAD_URL__
$target = __TARGET__
if (Test-Path -LiteralPath $target) {
  & $target version
  if ($LASTEXITCODE -eq 0) {
    Write-Output ('WORKFLOWGYM_WINDOWS_TOSUTIL_DOWNLOAD_EXISTING path=' + $target)
    Write-Output ('WORKFLOWGYM_WINDOWS_TOSUTIL_DOWNLOAD_READY path=' + $target)
    exit 0
  }
}
$tmpPath = $target + '.tmp'
Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue
Invoke-WebRequest -Uri $url -OutFile $tmpPath -UseBasicParsing -TimeoutSec 300
if (-not (Test-Path -LiteralPath $tmpPath)) {
  throw ('tosutil download target missing: ' + $tmpPath)
}
Unblock-File -LiteralPath $tmpPath -ErrorAction SilentlyContinue
Move-Item -LiteralPath $tmpPath -Destination $target -Force
& $target version
if ($LASTEXITCODE -ne 0) {
  throw ('tosutil version failed with exit code ' + $LASTEXITCODE)
}
Write-Output ('WORKFLOWGYM_WINDOWS_TOSUTIL_DOWNLOAD_READY path=' + $target)
""".replace("__DOWNLOAD_URL__", ps_single_quote(download_url)).replace("__TARGET__", ps_single_quote(target))


def build_windows_configure_tosutil_command(tos_ak: str, tos_sk: str, tos_endpoint: str, tos_region: str) -> str:
    target = os.getenv("WINDOWS_TOSUTIL_PATH", r"C:\Windows\System32\tosutil.exe")
    verify_bucket = tosutil_verify_bucket_uri()
    command = r"""$ErrorActionPreference = 'Stop'
$target = __TARGET__
$verifyBucket = __VERIFY_BUCKET__
$tosAk = __TOS_AK__
$tosSk = __TOS_SK__
$tosEndpoint = __TOS_ENDPOINT__
$tosRegion = __TOS_REGION__
if (-not (Test-Path -LiteralPath $target)) {
  throw ('tosutil missing, run download RunCommand first: ' + $target)
}
& $target config -i $tosAk -k $tosSk -e $tosEndpoint -re $tosRegion
if ($LASTEXITCODE -ne 0) {
  throw ('tosutil config failed with exit code ' + $LASTEXITCODE)
}
& $target ls $verifyBucket
if ($LASTEXITCODE -ne 0) {
  throw ('tosutil verify ls failed with exit code ' + $LASTEXITCODE)
}
Write-Output ('WORKFLOWGYM_WINDOWS_TOSUTIL_CONFIG_DONE endpoint=' + $tosEndpoint + ' region=' + $tosRegion + ' bucket=' + $verifyBucket)
"""
    return (
        command.replace("__TARGET__", ps_single_quote(target))
        .replace("__VERIFY_BUCKET__", ps_single_quote(verify_bucket))
        .replace("__TOS_AK__", ps_single_quote(tos_ak))
        .replace("__TOS_SK__", ps_single_quote(tos_sk))
        .replace("__TOS_ENDPOINT__", ps_single_quote(tos_endpoint))
        .replace("__TOS_REGION__", ps_single_quote(tos_region))
    )


def build_windows_download_python_installer_command() -> str:
    tosutil_path = os.getenv("WINDOWS_TOSUTIL_PATH", r"C:\Windows\System32\tosutil.exe")
    installer_tos_uri = os.getenv(
        "WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_TOS_URI",
        os.getenv(
            "WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_TOS_URL",
            "tos://open-workflowgym-win-python/python-3.12.8-amd64_1.exe",
        ),
    )
    installer_path = os.getenv("WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_PATH", "")
    installer_expr = ps_single_quote(installer_path) if installer_path else "Join-Path $env:TEMP 'workflowgym-python-installer.exe'"
    return r"""$ErrorActionPreference = 'Stop'
$tosutilPath = __TOSUTIL_PATH__
$pythonInstallerTosUri = __INSTALLER_TOS_URI__
$installer = __INSTALLER_PATH__
if (-not (Test-Path -LiteralPath $tosutilPath)) {
  Write-Output ('WORKFLOWGYM_WINDOWS_PYTHON_TOSUTIL_MISSING path=' + $tosutilPath)
  throw ('tosutil not found: ' + $tosutilPath)
}
Remove-Item -LiteralPath $installer -Force -ErrorAction SilentlyContinue
Write-Output ('WORKFLOWGYM_WINDOWS_PYTHON_TOSUTIL path=' + $tosutilPath)
Write-Output ('WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_DOWNLOAD_START uri=' + $pythonInstallerTosUri + ' path=' + $installer)
& $tosutilPath cp $pythonInstallerTosUri $installer
if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $installer)) {
  Write-Output ('WORKFLOWGYM_WINDOWS_PYTHON_TOS_COPY_FAILED uri=' + $pythonInstallerTosUri + ' exit=' + $LASTEXITCODE)
  Remove-Item -LiteralPath $installer -Force -ErrorAction SilentlyContinue
  throw ('Python installer TOS copy failed: ' + $pythonInstallerTosUri)
}
$installerSize = (Get-Item -LiteralPath $installer).Length
Write-Output ('WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_READY path=' + $installer + ' bytes=' + $installerSize)
""".replace("__TOSUTIL_PATH__", ps_single_quote(tosutil_path)).replace(
        "__INSTALLER_TOS_URI__", ps_single_quote(installer_tos_uri)
    ).replace(
        "__INSTALLER_PATH__", installer_expr
    )


def cloud_assistant_status_value(status: dict[str, Any] | None) -> str:
    if not status:
        return ""
    return str(status.get("Status") or status.get("status") or "")


def cloud_assistant_ready(status: dict[str, Any] | None) -> bool:
    return cloud_assistant_status_value(status).lower() in {"online", "running", "available", "normal"}


def cloud_assistant_needs_reboot(status: dict[str, Any] | None) -> bool:
    return cloud_assistant_status_value(status).lower() == "readyreboot"


def command_decoded_output(response_data: dict[str, Any]) -> str:
    outputs = []
    for item in response_data.get("results") or []:
        output = item.get("decoded_output")
        if output is None:
            output = maybe_decode_output(item.get("Output") or item.get("output") or "")
        if output:
            outputs.append(output)
    return "\n".join(outputs)


def print_run_command_invocation_results(
    invocation_id: str,
    invocation_results: list[dict[str, Any]],
    *,
    finished: bool,
    failed: bool,
) -> None:
    if not finished:
        return
    decoded_outputs = []
    for index, item in enumerate(invocation_results, start=1):
        status = item.get("InvocationResultStatus") or item.get("invocation_result_status") or ""
        exit_code = item.get("ExitCode")
        if exit_code is None:
            exit_code = item.get("exit_code")
        error_code = item.get("ErrorCode") or item.get("error_code") or ""
        error_message = item.get("ErrorMessage") or item.get("error_message") or ""
        output = item.get("decoded_output")
        if output is None:
            output = maybe_decode_output(item.get("Output") or item.get("output") or "")
            if output:
                item["decoded_output"] = output
        if output:
            decoded_outputs.append(str(output))
        if failed:
            print(
                "WORKFLOWGYM_RUNCOMMAND_RESULT_ITEM invocation_id=%s index=%s invocation_result_status=%s exit_code=%s error_code=%s"
                % (invocation_id, index, status, exit_code, error_code),
                flush=True,
            )
            if error_message:
                print("WORKFLOWGYM_RUNCOMMAND_ERROR_MESSAGE %s" % error_message, flush=True)
    print("invocation_id=%s" % invocation_id, flush=True)
    print("——cmd exe res———", flush=True)
    print("\n".join(decoded_outputs) if decoded_outputs else "<empty>", flush=True)
    print("__________________", flush=True)


def command_output_contains(response_data: dict[str, Any], text: str) -> bool:
    return text in command_decoded_output(response_data)


def assert_pyautogui_size_output(
    output: str,
    expected_width: int = 1920,
    expected_height: int = 1080,
) -> tuple[int, int]:
    expected_size = "%sx%s" % (expected_width, expected_height)
    for line in output.splitlines():
        if "WORKFLOWGYM_PYAUTOGUI_SIZE" not in line:
            continue
        size_text = line.split("WORKFLOWGYM_PYAUTOGUI_SIZE", 1)[1].strip()
        if size_text != expected_size:
            raise ValueError(
                "pyautogui.size() 校验失败，期望 %s 实际 %s: %s"
                % (expected_size, size_text, output[:1000])
            )
        width, height = size_text.split("x", 1)
        return int(width), int(height)
    raise ValueError("pyautogui.size() 校验失败，未找到 WORKFLOWGYM_PYAUTOGUI_SIZE: %s" % output[:1000])


def assert_pyautogui_validation_output(output: str, expected_resolution: str = "1920x1080") -> None:
    if "x" in expected_resolution:
        width, height = expected_resolution.split("x", 1)
        assert_pyautogui_size_output(output, int(width), int(height))
        return
    if "pyautogui ready:" not in output:
        raise ValueError("pyautogui 校验失败，未检测到 pyautogui ready: %s" % output[:1000])
    if expected_resolution not in output:
        raise ValueError(
            "pyautogui 校验失败，分辨率未达到 %s: %s" % (expected_resolution, output[:1000])
        )
    if "desktop resolution validated:" not in output:
        raise ValueError("pyautogui 校验失败，未通过分辨率验证: %s" % output[:1000])


def parse_validated_display_resolution(
    output: str,
    fallback_width: int = 1920,
    fallback_height: int = 1080,
) -> tuple[int, int]:
    for line in output.splitlines():
        marker = "desktop resolution validated:"
        if marker not in line:
            continue
        size_text = line.split(marker, 1)[1].strip()
        if "x" not in size_text:
            continue
        width_text, height_text = size_text.split("x", 1)
        return int(width_text), int(height_text)
    try:
        return assert_pyautogui_size_output(output, fallback_width, fallback_height)
    except ValueError:
        return int(fallback_width), int(fallback_height)


def public_ip_binding_enabled() -> bool:
    return os.getenv("WORKFLOWGYM_BIND_EIP_FOR_TOS", "0").lower() not in ("0", "false", "no", "off")


def gui_image_enable_auto_login() -> bool:
    return os.getenv("GUI_IMAGE_ENABLE_AUTO_LOGIN", "1").lower() not in ("0", "false", "no", "off")


def find_xauthority(output: str) -> str:
    for line in output.splitlines():
        line = line.strip()
        if line.endswith(".Xauthority") or line.endswith("Xauthority"):
            return line
    return ""


def instance_name_matches_prefix(instance_name: str, name_prefix: str) -> bool:
    prefixes = [item.strip().lower() for item in name_prefix.split(",") if item.strip()]
    if not prefixes:
        return True
    normalized_name = instance_name.lower()
    return any(normalized_name.startswith(prefix) for prefix in prefixes)


def is_instance_status_retryable(error: Exception) -> bool:
    error_text = "%s\n%s" % (getattr(error, "body", ""), error)
    return "InvalidInstanceStatus" in error_text or "does not support this request" in error_text


def is_flow_limit_retryable(error: Exception) -> bool:
    error_text = "%s\n%s" % (getattr(error, "body", ""), error)
    return "FlowLimitExceeded" in error_text or "Too Many Requests" in error_text or "(429)" in error_text


def is_console_screenshot_invalid_timestamp_error(error: Exception) -> bool:
    error_text = "%s\n%s" % (getattr(error, "body", ""), error)
    return "InvalidTimestamp" in error_text or "Signature of the request is expired" in error_text


def is_console_screenshot_retryable(error: Exception) -> bool:
    return is_flow_limit_retryable(error) or is_console_screenshot_invalid_timestamp_error(error)


def console_screenshot_total_timeout_seconds() -> float:
    return max(1.0, float(os.getenv("CONSOLE_SCREENSHOT_TOTAL_TIMEOUT_SECONDS", "120")))


def console_screenshot_call_timeout_seconds() -> float:
    return max(1.0, float(os.getenv("CONSOLE_SCREENSHOT_CALL_TIMEOUT_SECONDS", "60")))


def build_configure_xorg_command(desktop_user: str) -> str:
    return """#!/bin/bash
set -euo pipefail
sudo mkdir -p /etc/gdm3
config_ok=false
if sudo test -f /etc/gdm3/custom.conf; then
  if sudo grep -q '^WaylandEnable=false$' /etc/gdm3/custom.conf && sudo grep -q '^AutomaticLoginEnable=true$' /etc/gdm3/custom.conf && sudo grep -q '^AutomaticLogin={desktop_user}$' /etc/gdm3/custom.conf; then
    config_ok=true
  fi
fi
if [ "$config_ok" = true ]; then
  echo "GDM config already satisfied"
else
  sudo cp /etc/gdm3/custom.conf /etc/gdm3/custom.conf.bak 2>/dev/null || true
  sudo bash -c 'cat > /etc/gdm3/custom.conf <<EOF
[daemon]
WaylandEnable=false
AutomaticLoginEnable=true
AutomaticLogin={desktop_user}
EOF'
  echo "GDM config updated, restarting gdm3"
  sudo systemctl restart gdm3 || sudo reboot
fi
""".format(desktop_user=desktop_user)


def _sanitize_apt_sources_shell() -> str:
    return """
workflowgym_sanitize_apt_sources() {
  local list_file line
  shopt -s nullglob
  if [ -f /etc/apt/sources.list ]; then
    if grep -Eqi 'puppetlabs|puppet_enterprise|adoptium|zabbix|^[[:space:]]*deb[[:space:]]+file:' /etc/apt/sources.list 2>/dev/null; then
      sudo cp /etc/apt/sources.list /etc/apt/sources.list.bak.workflowgym
      sudo awk '!/puppetlabs|puppet_enterprise|adoptium|zabbix/ && !/^[[:space:]]*deb[[:space:]]+file:/' /etc/apt/sources.list.bak.workflowgym | sudo tee /etc/apt/sources.list >/dev/null
    fi
  fi
  for list_file in /etc/apt/sources.list.d/*; do
    [ -f "$list_file" ] || continue
    case "$list_file" in
      *.disabled|*.disabled.workflowgym|*.bak|*.bak.workflowgym|*.save) continue ;;
    esac
    if grep -Eqi 'puppetlabs|puppet_enterprise|adoptium|zabbix|file:/opt/puppetlabs|\\$\\(lsb_release' "$list_file" 2>/dev/null; then
      sudo mv "$list_file" "${list_file}.disabled.workflowgym"
      continue
    fi
    if grep -Eq '^(deb|deb-src|Types|URIs|Suites)[[:space:]]' "$list_file" 2>/dev/null; then
      if grep -Eqi '^URIs:[[:space:]]*file:' "$list_file" 2>/dev/null; then
        sudo mv "$list_file" "${list_file}.disabled.workflowgym"
      fi
      continue
    fi
    if grep -Eq '^(deb|deb-src)[[:space:]]+file:' "$list_file" 2>/dev/null; then
      sudo mv "$list_file" "${list_file}.disabled.workflowgym"
    fi
  done
}
workflowgym_sanitize_apt_sources
"""


def _pip_install_pyautogui_shell() -> str:
    return """
workflowgym_pip_install_pyautogui() {
  local pip_index_url="$1"
  local pip_trusted_host="$2"
  sudo env PIP_INDEX_URL="$pip_index_url" PIP_TRUSTED_HOST="$pip_trusted_host" \
    /usr/bin/python -m pip install --upgrade pip setuptools packaging wheel || true
  sudo env PIP_INDEX_URL="$pip_index_url" PIP_TRUSTED_HOST="$pip_trusted_host" \
    /usr/bin/python -m pip install --upgrade pyautogui
}

workflowgym_pip_install_pyautogui_fallback() {
  local pip_index_url="$1"
  local pip_trusted_host="$2"
  if /usr/bin/python -m pip install --help 2>/dev/null | grep -q -- '--break-system-packages'; then
    sudo env PIP_INDEX_URL="$pip_index_url" PIP_TRUSTED_HOST="$pip_trusted_host" PIP_BREAK_SYSTEM_PACKAGES=1 \
      /usr/bin/python -m pip install --upgrade --break-system-packages pyautogui
    return $?
  fi
  sudo env PIP_INDEX_URL="$pip_index_url" PIP_TRUSTED_HOST="$pip_trusted_host" \
    /usr/bin/python -m pip install --upgrade --user pyautogui
}
"""


def _pip_install_flask_shell() -> str:
    return """
workflowgym_pip_install_flask() {
  local pip_index_url="$1"
  local pip_trusted_host="$2"
  env PIP_INDEX_URL="$pip_index_url" PIP_TRUSTED_HOST="$pip_trusted_host" \
    /usr/bin/python3 -m pip install --upgrade flask
}

workflowgym_pip_install_flask_fallback() {
  local pip_index_url="$1"
  local pip_trusted_host="$2"
  if /usr/bin/python3 -m pip install --help 2>/dev/null | grep -q -- '--break-system-packages'; then
    env PIP_INDEX_URL="$pip_index_url" PIP_TRUSTED_HOST="$pip_trusted_host" PIP_BREAK_SYSTEM_PACKAGES=1 \
      /usr/bin/python3 -m pip install --upgrade --ignore-installed --break-system-packages flask
    return $?
  fi
  env PIP_INDEX_URL="$pip_index_url" PIP_TRUSTED_HOST="$pip_trusted_host" \
    /usr/bin/python3 -m pip install --upgrade --ignore-installed --user flask
}
"""


def build_disable_ubuntu_update_prompts_command() -> str:
    return """#!/bin/bash
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive

# Ubuntu 22.04 may auto-open Software Updater after login; it blocks GUI sampling.
sudo systemctl disable --now apt-daily.timer apt-daily-upgrade.timer || true
sudo systemctl disable --now apt-daily.service apt-daily-upgrade.service || true
sudo systemctl stop unattended-upgrades.service || true

sudo mkdir -p /etc/apt/apt.conf.d
sudo tee /etc/apt/apt.conf.d/99workflowgym-disable-updates >/dev/null <<'EOF'
APT::Periodic::Enable "0";
APT::Periodic::Update-Package-Lists "0";
APT::Periodic::Download-Upgradeable-Packages "0";
APT::Periodic::AutocleanInterval "0";
EOF

sudo pkill -x update-manager || true
sudo pkill -x software-updater || true
sudo pkill -x update-notifier || true
sudo apt-get remove -y update-notifier update-manager || true

echo "workflowgym ubuntu update prompts disabled"
"""


def build_prepare_pyautogui_dependencies_command() -> str:
    return """#!/bin/bash
set -euo pipefail
if [ ! -x /usr/bin/python ]; then
  sudo ln -sf /usr/bin/python3 /usr/bin/python
fi
""" + _sanitize_apt_sources_shell() + _pip_install_pyautogui_shell() + """
sudo apt-get update -o Acquire::https::Timeout=15 -o Acquire::http::Timeout=15
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y python3-tk python3-dev python3-pip xdotool x11-utils x11-xkb-utils xclip xsel
pip_index_url="${PIP_INDEX_URL:-https://mirrors.ivolces.com/pypi/simple/}"
pip_trusted_host="${PIP_TRUSTED_HOST:-mirrors.ivolces.com}"
pip_fallback_index_url="${PIP_FALLBACK_INDEX_URL:-https://pypi.tuna.tsinghua.edu.cn/simple}"
pip_fallback_trusted_host="${PIP_FALLBACK_TRUSTED_HOST:-pypi.tuna.tsinghua.edu.cn}"
if ! workflowgym_pip_install_pyautogui "$pip_index_url" "$pip_trusted_host"; then
  echo "workflowgym pip primary mirror failed, retry with fallback index=$pip_fallback_index_url" >&2
  if ! workflowgym_pip_install_pyautogui "$pip_fallback_index_url" "$pip_fallback_trusted_host"; then
    workflowgym_pip_install_pyautogui_fallback "$pip_fallback_index_url" "$pip_fallback_trusted_host"
  fi
fi
echo "WORKFLOWGYM_PYAUTOGUI_INSTALL_OK"
"""


def build_pyautogui_size_probe_command(
    desktop_user: str,
    desktop_home: str,
    display: str,
    xauthority: str,
) -> str:
    return """#!/bin/bash
set -euo pipefail
sudo -H -u {desktop_user} env DISPLAY={display} HOME={desktop_home} XAUTHORITY={xauthority} /usr/bin/python - <<'PY'
import pyautogui

size = pyautogui.size()
print("WORKFLOWGYM_PYAUTOGUI_SIZE %sx%s" % (int(size.width), int(size.height)))
PY
""".format(
        desktop_user=shlex.quote(desktop_user),
        desktop_home=shlex.quote(desktop_home),
        display=shlex.quote(display),
        xauthority=shlex.quote(xauthority),
    )


def build_windows_autologon_command(username: str, password: str) -> str:
    return "\n".join(
        [
            "$ErrorActionPreference = 'Stop'",
            "$user = %s" % ps_single_quote(username),
            "$password = %s" % ps_single_quote(password),
            "$winlogon = 'HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon'",
            "Set-ItemProperty -Path $winlogon -Name AutoAdminLogon -Value '1' -Type String",
            "Set-ItemProperty -Path $winlogon -Name DefaultUserName -Value $user -Type String",
            "Set-ItemProperty -Path $winlogon -Name DefaultPassword -Value $password -Type String",
            "Set-ItemProperty -Path $winlogon -Name ForceAutoLogon -Value '1' -Type String",
            "powercfg /change monitor-timeout-ac 0 | Out-Null",
            "powercfg /change standby-timeout-ac 0 | Out-Null",
            "powercfg /change hibernate-timeout-ac 0 | Out-Null",
            "Write-Output ('WORKFLOWGYM_WINDOWS_AUTOLOGIN user=' + $user)",
        ]
    )


def build_prepare_windows_pyautogui_command() -> str:
    return r"""
$ErrorActionPreference = 'Stop'
function Find-Python {
  $commands = @('python', 'py')
  foreach ($command in $commands) {
    $resolved = Get-Command $command -ErrorAction SilentlyContinue
    if ($resolved) {
      try {
        & $command --version | Out-Null
        return $command
      } catch {}
    }
  }
  $paths = @(
    "$env:ProgramFiles\Python312\python.exe",
    "$env:ProgramFiles\Python311\python.exe",
    "$env:LocalAppData\Programs\Python\Python312\python.exe",
    "$env:LocalAppData\Programs\Python\Python311\python.exe"
  )
  foreach ($path in $paths) {
    if (Test-Path -LiteralPath $path) { return $path }
  }
  return ''
}

$pythonInstallerTosUri = 'tos://open-workflowgym-win-python/python-3.12.8-amd64_1.exe'
if ($env:WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_TOS_URI) {
  $pythonInstallerTosUri = $env:WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_TOS_URI
} else {
  if ($env:WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_TOS_URL) {
    $pythonInstallerTosUri = $env:WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_TOS_URL
  }
}
Write-Output ('WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_TOS_URI uri=' + $pythonInstallerTosUri)

$python = Find-Python
if (-not $python) {
  $installer = Join-Path $env:TEMP 'workflowgym-python-installer.exe'
  $adminInstaller = 'C:\Users\Administrator\AppData\Local\Temp\workflowgym-python-installer.exe'
  if (-not (Test-Path -LiteralPath $installer) -and (Test-Path -LiteralPath $adminInstaller)) {
    $installer = $adminInstaller
  }
  $tosutilPath = $env:WINDOWS_TOSUTIL_PATH
  if (-not $tosutilPath) { $tosutilPath = 'C:\Windows\System32\tosutil.exe' }
  if (Test-Path -LiteralPath $installer) {
    Write-Output ('WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_EXISTING path=' + $installer)
  } else {
    if (-not (Test-Path -LiteralPath $tosutilPath)) {
      Write-Output ('WORKFLOWGYM_WINDOWS_PYTHON_TOSUTIL_MISSING path=' + $tosutilPath)
      throw ('tosutil not found: ' + $tosutilPath)
    }
    Write-Output ('WORKFLOWGYM_WINDOWS_PYTHON_TOSUTIL path=' + $tosutilPath)
    Write-Output ('WORKFLOWGYM_WINDOWS_PYTHON_INSTALL from_tos=' + $pythonInstallerTosUri)
    & $tosutilPath cp $pythonInstallerTosUri $installer
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $installer)) {
      Write-Output ('WORKFLOWGYM_WINDOWS_PYTHON_TOS_COPY_FAILED uri=' + $pythonInstallerTosUri + ' exit=' + $LASTEXITCODE)
      Remove-Item -LiteralPath $installer -Force -ErrorAction SilentlyContinue
      throw ('Python installer TOS copy failed: ' + $pythonInstallerTosUri)
    }
  }
  if (-not (Test-Path -LiteralPath $installer)) { throw ('Python installer was not prepared: ' + $installer) }
  $installerSize = (Get-Item -LiteralPath $installer).Length
  Write-Output ('WORKFLOWGYM_WINDOWS_PYTHON_INSTALLER_READY path=' + $installer + ' bytes=' + $installerSize)
  Start-Process -FilePath $installer -ArgumentList '/quiet InstallAllUsers=1 PrependPath=1 Include_test=0' -Wait -NoNewWindow
  $python = Find-Python
}
if (-not $python) { throw 'Python is not available after install attempt' }

$pipIndex = $env:PIP_INDEX_URL
if (-not $pipIndex) { $pipIndex = 'https://pypi.tuna.tsinghua.edu.cn/simple' }
$pipTrustedHost = $env:PIP_TRUSTED_HOST
if (-not $pipTrustedHost) { $pipTrustedHost = 'pypi.tuna.tsinghua.edu.cn' }
Write-Output ('WORKFLOWGYM_WINDOWS_PIP_INDEX url=' + $pipIndex)
& $python -m ensurepip --upgrade
& $python -m pip install --upgrade pip setuptools wheel -i $pipIndex --trusted-host $pipTrustedHost
& $python -m pip install --upgrade pyautogui pyperclip pillow -i $pipIndex --trusted-host $pipTrustedHost
if ($LASTEXITCODE -ne 0) {
  Write-Output ('WORKFLOWGYM_WINDOWS_PYAUTOGUI_PIP_FAILED exit=' + $LASTEXITCODE + '; installing ctypes shim')
  $sitePackages = (& $python -c "import site; print(site.getsitepackages()[0])").Trim()
  if (-not $sitePackages) { throw 'unable to locate Python site-packages for pyautogui shim' }
  New-Item -ItemType Directory -Path $sitePackages -Force | Out-Null
  $pyautoguiShim = Join-Path $sitePackages 'pyautogui.py'
  @'
import ctypes
import ctypes.wintypes
import time
from collections import namedtuple

FAILSAFE = False
PAUSE = 0
Size = namedtuple("Size", "width height")
Point = namedtuple("Point", "x y")
user32 = ctypes.windll.user32

MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
MOUSEEVENTF_MIDDLEDOWN = 0x0020
MOUSEEVENTF_MIDDLEUP = 0x0040
MOUSEEVENTF_WHEEL = 0x0800
MOUSEEVENTF_HWHEEL = 0x01000
KEYEVENTF_KEYUP = 0x0002

KEYS = {
    "backspace": 0x08, "tab": 0x09, "enter": 0x0D, "return": 0x0D,
    "shift": 0x10, "ctrl": 0x11, "control": 0x11, "alt": 0x12,
    "pause": 0x13, "capslock": 0x14, "escape": 0x1B, "esc": 0x1B,
    "space": 0x20, "pageup": 0x21, "pagedown": 0x22, "end": 0x23,
    "home": 0x24, "left": 0x25, "up": 0x26, "right": 0x27, "down": 0x28,
    "insert": 0x2D, "delete": 0x2E, "del": 0x2E, "win": 0x5B,
    "command": 0x5B, "cmd": 0x5B, "f1": 0x70, "f2": 0x71, "f3": 0x72,
    "f4": 0x73, "f5": 0x74, "f6": 0x75, "f7": 0x76, "f8": 0x77,
    "f9": 0x78, "f10": 0x79, "f11": 0x7A, "f12": 0x7B,
}

def _sleep():
    if PAUSE:
        time.sleep(PAUSE)

def sleep(seconds=0):
    time.sleep(float(seconds or 0))

def size():
    return Size(user32.GetSystemMetrics(0), user32.GetSystemMetrics(1))

def position():
    point = ctypes.wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(point))
    return Point(point.x, point.y)

def moveTo(x=None, y=None, duration=0, *args, **kwargs):
    if x is None or y is None:
        return
    user32.SetCursorPos(int(x), int(y))
    if duration:
        time.sleep(float(duration))
    _sleep()

def mouseDown(x=None, y=None, button="left", *args, **kwargs):
    if x is not None and y is not None:
        moveTo(x, y)
    flag = {"left": MOUSEEVENTF_LEFTDOWN, "right": MOUSEEVENTF_RIGHTDOWN, "middle": MOUSEEVENTF_MIDDLEDOWN}.get(button, MOUSEEVENTF_LEFTDOWN)
    user32.mouse_event(flag, 0, 0, 0, 0)
    _sleep()

def mouseUp(x=None, y=None, button="left", *args, **kwargs):
    if x is not None and y is not None:
        moveTo(x, y)
    flag = {"left": MOUSEEVENTF_LEFTUP, "right": MOUSEEVENTF_RIGHTUP, "middle": MOUSEEVENTF_MIDDLEUP}.get(button, MOUSEEVENTF_LEFTUP)
    user32.mouse_event(flag, 0, 0, 0, 0)
    _sleep()

def click(x=None, y=None, clicks=1, interval=0.0, button="left", *args, **kwargs):
    if x is not None and y is not None:
        moveTo(x, y)
    for index in range(int(clicks or 1)):
        mouseDown(button=button)
        mouseUp(button=button)
        if interval and index + 1 < int(clicks or 1):
            time.sleep(float(interval))
    _sleep()

def doubleClick(x=None, y=None, interval=0.0, button="left", *args, **kwargs):
    click(x, y, clicks=2, interval=interval, button=button)

def tripleClick(x=None, y=None, interval=0.0, button="left", *args, **kwargs):
    click(x, y, clicks=3, interval=interval, button=button)

def rightClick(x=None, y=None, *args, **kwargs):
    click(x, y, button="right")

def dragTo(x, y, duration=0, button="left", *args, **kwargs):
    mouseDown(button=button)
    moveTo(x, y, duration=duration)
    mouseUp(button=button)

def scroll(clicks, x=None, y=None):
    if x is not None and y is not None:
        moveTo(x, y)
    user32.mouse_event(MOUSEEVENTF_WHEEL, 0, 0, int(clicks) * 120, 0)
    _sleep()

def hscroll(clicks, x=None, y=None):
    if x is not None and y is not None:
        moveTo(x, y)
    user32.mouse_event(MOUSEEVENTF_HWHEEL, 0, 0, int(clicks) * 120, 0)
    _sleep()

def _vk(key):
    key = str(key).lower()
    if key in KEYS:
        return KEYS[key]
    if len(key) == 1:
        code = user32.VkKeyScanW(ord(key))
        return code & 0xff
    raise ValueError("unsupported key: %s" % key)

def keyDown(key):
    user32.keybd_event(_vk(key), 0, 0, 0)
    _sleep()

def keyUp(key):
    user32.keybd_event(_vk(key), 0, KEYEVENTF_KEYUP, 0)
    _sleep()

def press(key, presses=1, interval=0.0):
    for index in range(int(presses or 1)):
        keyDown(key)
        keyUp(key)
        if interval and index + 1 < int(presses or 1):
            time.sleep(float(interval))

def hotkey(*keys):
    for key in keys:
        keyDown(key)
    for key in reversed(keys):
        keyUp(key)

def write(message, interval=0.0):
    for char in str(message):
        code = user32.VkKeyScanW(ord(char))
        vk = code & 0xff
        shift = code & 0x0100
        if shift:
            keyDown("shift")
        user32.keybd_event(vk, 0, 0, 0)
        user32.keybd_event(vk, 0, KEYEVENTF_KEYUP, 0)
        if shift:
            keyUp("shift")
        if interval:
            time.sleep(float(interval))

typewrite = write
'@ | Set-Content -LiteralPath $pyautoguiShim -Encoding ASCII
  $pyperclipShim = Join-Path $sitePackages 'pyperclip.py'
  @'
import subprocess

def copy(text):
    subprocess.run(
        ["powershell", "-NoProfile", "-Command", "Set-Clipboard -Value $input"],
        input=str(text),
        text=True,
        check=True,
    )

def paste():
    return subprocess.check_output(
        ["powershell", "-NoProfile", "-Command", "Get-Clipboard -Raw"],
        text=True,
    )
'@ | Set-Content -LiteralPath $pyperclipShim -Encoding ASCII
  Write-Output ('WORKFLOWGYM_WINDOWS_PYAUTOGUI_SHIM_READY path=' + $pyautoguiShim)
}
$scriptPath = Join-Path $env:TEMP 'workflowgym_validate_pyautogui.py'
@'
import pyautogui
print('WORKFLOWGYM_WINDOWS_PYAUTOGUI_READY file=%s' % getattr(pyautogui, '__file__', ''))
print('WORKFLOWGYM_WINDOWS_PYAUTOGUI_SIZE %sx%s' % tuple(pyautogui.size()))
'@ | Set-Content -LiteralPath $scriptPath -Encoding ASCII
& $python $scriptPath
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
""".strip()


def build_windows_file_queue_runner_probe_command(max_age_seconds: int = 15) -> str:
    runner_version = int(os.getenv("WINDOWS_FILE_QUEUE_RUNNER_VERSION", "3"))
    return r"""
$ErrorActionPreference = 'Stop'
$desktop = 'C:\Users\Administrator\Desktop'
$heartbeatPath = Join-Path $desktop 'workflowgym_file_queue_heartbeat.json'
$watchdogHeartbeatPath = Join-Path $desktop 'workflowgym_file_queue_watchdog_heartbeat.json'
$runnerPath = Join-Path $desktop 'workflowgym_file_queue_runner.py'
$maxAge = __MAX_AGE__

function Test-FreshHeartbeat($path, $label) {
  if (-not (Test-Path -LiteralPath $path)) {
    throw ($label + ' heartbeat missing: ' + $path)
  }
  $data = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
  if (-not $data.time) {
    throw ($label + ' heartbeat missing time field: ' + $path)
  }
  if ($label -eq 'runner') {
    $runnerVersion = 0
    if ($data.runner_version) { $runnerVersion = [int]$data.runner_version }
    if ($runnerVersion -lt __RUNNER_VERSION__) {
      throw ('runner version stale version=' + $runnerVersion + ' required=' + __RUNNER_VERSION__)
    }
  }
  $age = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - [double]$data.time
  if ($age -gt $maxAge) {
    throw ($label + ' heartbeat stale age=' + $age + 's path=' + $path)
  }
}

Test-FreshHeartbeat $heartbeatPath 'runner'
Test-FreshHeartbeat $watchdogHeartbeatPath 'watchdog'
$output = & wmic process where "name='python.exe'" get CommandLine 2>$null
if (-not $output) {
  throw 'unable to inspect python.exe processes'
}
if ($output -notlike '*workflowgym_file_queue_runner.py*') {
  throw ('workflowgym file queue runner process missing path=' + $runnerPath)
}
Write-Output 'WORKFLOWGYM_FILE_QUEUE_RUNNER_PROBE_OK'
""".strip().replace("__MAX_AGE__", str(int(max_age_seconds))).replace("__RUNNER_VERSION__", str(runner_version)) + "\n"


def build_windows_fast_init_probe_command() -> str:
    pyautogui_probe = r"""
$scriptPath = Join-Path $env:TEMP 'workflowgym_fast_init_probe.py'
@'
import pyautogui
size = pyautogui.size()
print('WORKFLOWGYM_WINDOWS_FAST_INIT_READY size=%sx%s' % (int(size.width), int(size.height)))
'@ | Set-Content -LiteralPath $scriptPath -Encoding ASCII
& $python.Source $scriptPath
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
""".strip()
    runner_probe = _build_windows_fast_init_runner_probe_block()
    return (
        r"""
$ErrorActionPreference = 'Stop'
$desktop = 'C:\Users\Administrator\Desktop'
$tosutilPath = $env:WINDOWS_TOSUTIL_PATH
if (-not $tosutilPath) { $tosutilPath = 'C:\Windows\System32\tosutil.exe' }
if (-not (Test-Path -LiteralPath $tosutilPath)) {
  throw ('tosutil missing: ' + $tosutilPath)
}
& $tosutilPath version | Out-Null
if ($LASTEXITCODE -ne 0) { throw ('tosutil version failed: ' + $tosutilPath) }
$python = (Get-Command python -ErrorAction SilentlyContinue)
if (-not $python) { $python = (Get-Command py -ErrorAction SilentlyContinue) }
if (-not $python) { throw 'python command not found' }
""".strip()
        + "\n"
        + runner_probe
        + pyautogui_probe
    )


def _build_windows_fast_init_runner_probe_block() -> str:
    if windows_action_runner_mode() == "file_queue":
        max_age = int(os.getenv("WINDOWS_FILE_QUEUE_HEARTBEAT_MAX_AGE_SECONDS", "15"))
        return build_windows_file_queue_runner_probe_command(max_age)
    return build_windows_probe_flask_runner_command(
        windows_flask_runner_port(),
        windows_flask_runner_token(),
    )


def build_validate_windows_pyautogui_command() -> str:
    return r"""
$ErrorActionPreference = 'Stop'
$python = (Get-Command python -ErrorAction SilentlyContinue)
if (-not $python) { $python = (Get-Command py -ErrorAction SilentlyContinue) }
if (-not $python) { throw 'python command not found' }
$scriptPath = Join-Path $env:TEMP 'workflowgym_validate_pyautogui.py'
@'
import pyautogui
print('pyautogui ready:', getattr(pyautogui, '__file__', ''))
size = pyautogui.size()
print('pyautogui dimensions: %sx%s' % (int(size.width), int(size.height)))
'@ | Set-Content -LiteralPath $scriptPath -Encoding ASCII
& $python.Source $scriptPath
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
""".strip()


def windows_action_runner_mode() -> str:
    explicit = os.getenv("WINDOWS_ACTION_RUNNER", "").strip().lower()
    if explicit in ("flask", "file_queue"):
        return explicit
    if os.getenv("WINDOWS_FILE_QUEUE_RUNNER", "0").lower() in ("1", "true", "yes", "on"):
        return "file_queue"
    return "flask"


def windows_flask_runner_token() -> str:
    return os.getenv("WORKFLOWGYM_FLASK_RUNNER_TOKEN", "workflowgym-flask-token")


def windows_flask_runner_port() -> int:
    return int(os.getenv("WORKFLOWGYM_FLASK_RUNNER_PORT", "8080"))


def flask_runner_bind_host() -> str:
    """Flask runner listen address.

    Local 与 Redis/WGM 动作均经 RunCommand 在 VM 内访问 ``127.0.0.1``，默认只绑回环。
    """
    explicit = str(os.getenv("WORKFLOWGYM_FLASK_BIND_HOST") or "").strip()
    if explicit:
        return explicit
    return "127.0.0.1"


def _flask_action_script_guard_source() -> str:
    """Embedded into Flask runners: reject dangerous python payloads for /action."""
    return '''
import ast as _ast

_FORBIDDEN_ACTION_MODULES = frozenset({
    "socket", "importlib", "pty", "fcntl", "http", "urllib", "requests",
    "pickle", "marshal", "code", "codeop", "ctypes", "multiprocessing", "asyncio",
})
_FORBIDDEN_ACTION_CALLS = frozenset({
    "eval", "exec", "compile", "__import__", "breakpoint",
    "os.system", "os.popen", "os.remove", "os.unlink", "os.rmdir", "os.removedirs",
    "os.execv", "os.execve", "os.execl", "os.execle", "os.execlp", "os.execvp", "os.execvpe",
    "shutil.rmtree",
})

def _action_call_name(node):
    if isinstance(node, _ast.Name):
        return node.id
    if isinstance(node, _ast.Attribute):
        parts = []
        cur = node
        while isinstance(cur, _ast.Attribute):
            parts.append(cur.attr)
            cur = cur.value
        if isinstance(cur, _ast.Name):
            parts.append(cur.id)
            return ".".join(reversed(parts))
    return ""

def validate_action_script(script):
    text = str(script or "")
    if not text.strip():
        raise ValueError("empty action script")
    if len(text) > 200000:
        raise ValueError("action script too large")
    try:
        tree = _ast.parse(text)
    except SyntaxError as exc:
        raise ValueError("invalid action script syntax: %s" % exc) from exc
    for node in _ast.walk(tree):
        if isinstance(node, _ast.Import):
            for alias in node.names:
                name = alias.name or ""
                root = name.split(".")[0]
                if root in _FORBIDDEN_ACTION_MODULES or name in _FORBIDDEN_ACTION_MODULES:
                    raise ValueError("disallowed import: %s" % name)
        elif isinstance(node, _ast.ImportFrom):
            mod = node.module or ""
            root = mod.split(".")[0] if mod else ""
            if root in _FORBIDDEN_ACTION_MODULES or mod in _FORBIDDEN_ACTION_MODULES:
                raise ValueError("disallowed import: %s" % (mod or "."))
        elif isinstance(node, _ast.Call):
            name = _action_call_name(node.func)
            leaf = name.split(".")[-1] if name else ""
            if name in _FORBIDDEN_ACTION_CALLS or leaf in ("eval", "exec", "compile", "__import__"):
                raise ValueError("disallowed call: %s" % (name or leaf))
            for kw in (node.keywords or []):
                if kw.arg == "shell" and isinstance(kw.value, _ast.Constant) and kw.value.value is True:
                    raise ValueError("disallowed subprocess shell=True")
'''


def windows_flask_exec_timeout_seconds() -> int:
    return max(5, int(os.getenv("WORKFLOWGYM_FLASK_EXEC_TIMEOUT_SECONDS", "45")))


def windows_flask_runner_probe_seconds() -> int:
    return max(10, int(os.getenv("WINDOWS_FLASK_RUNNER_PROBE_SECONDS", "60")))


def windows_flask_runner_probe_attempts() -> int:
    return max(1, int(os.getenv("WINDOWS_FLASK_RUNNER_PROBE_ATTEMPTS", "3")))


def windows_flask_runner_setup_wait_seconds() -> int:
    return max(10, int(os.getenv("WINDOWS_FLASK_RUNNER_SETUP_WAIT_SECONDS", "90")))


def _build_windows_flask_health_wait_block(log_path_var: str = "$logPath", max_seconds: int | None = None) -> str:
    wait_seconds = max_seconds if max_seconds is not None else windows_flask_runner_setup_wait_seconds()
    return """
$deadline = (Get-Date).AddSeconds(__WAIT_SECONDS__)
$health = $null
while ((Get-Date) -lt $deadline) {
  try {
    $health = Invoke-RestMethod -Uri ('http://127.0.0.1:' + $port + '/health') -Headers @{ 'X-WorkflowGym-Token' = $token } -TimeoutSec 3
    if ($health.ok) { break }
  } catch {}
  Start-Sleep -Seconds 2
}
if (-not $health -or -not $health.ok) {
  if (Test-Path -LiteralPath __LOG_PATH__) {
    Write-Output 'WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_LOG'
    Get-Content -LiteralPath __LOG_PATH__ -Tail 60
  }
  throw ('flask runner health not ready within __WAIT_SECONDS__s on port ' + $port)
}
Write-Output 'WORKFLOWGYM_PROBE_FLASK_RUNNER_OK'
Write-Output ('WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_HEALTH ' + ($health | ConvertTo-Json -Compress))
""".replace("__WAIT_SECONDS__", str(wait_seconds)).replace("__LOG_PATH__", log_path_var)


def _build_windows_flask_health_retry_block(
    log_path_var: str = "$logPath",
    max_seconds: int | None = None,
    max_attempts: int | None = None,
) -> str:
    attempts = max_attempts if max_attempts is not None else windows_flask_runner_probe_attempts()
    per_attempt_seconds = max(10, int((max_seconds if max_seconds is not None else windows_flask_runner_probe_seconds()) / max(1, attempts)))
    wait_block = _build_windows_flask_health_wait_block(log_path_var, per_attempt_seconds)
    indented_wait = "\n".join("  " + line if line else line for line in wait_block.splitlines())
    return (
        """
$healthReady = $false
for ($attempt = 1; $attempt -le __MAX_ATTEMPTS__; $attempt++) {
  try {
__WAIT_BLOCK__
    $healthReady = $true
    break
  } catch {
    Write-Output ('WORKFLOWGYM_PROBE_FLASK_RUNNER_RETRY attempt=' + $attempt + ' error=' + $_.Exception.Message)
    if ($attempt -ge __MAX_ATTEMPTS__) { throw }
    schtasks /Run /TN $taskName | Out-Null
    Start-Sleep -Seconds 5
  }
}
if (-not $healthReady) {
  throw 'flask runner probe failed after retries'
}
"""
        .replace("__MAX_ATTEMPTS__", str(int(attempts)))
        .replace("__WAIT_BLOCK__", indented_wait)
    )


def windows_desktop_resolution_width() -> int:
    return int(os.getenv("DESKTOP_RESOLUTION_WIDTH", os.getenv("WINDOWS_DESKTOP_RESOLUTION_WIDTH", "1920")))


def windows_desktop_resolution_height() -> int:
    return int(os.getenv("DESKTOP_RESOLUTION_HEIGHT", os.getenv("WINDOWS_DESKTOP_RESOLUTION_HEIGHT", "1080")))


def windows_should_set_desktop_resolution() -> bool:
    return os.getenv("WINDOWS_SET_DESKTOP_RESOLUTION", "0").lower() in ("1", "true", "yes", "on")


def build_set_windows_desktop_resolution_command(
    username: str,
    password: str,
    width: int | None = None,
    height: int | None = None,
) -> str:
    target_width = int(width if width is not None else windows_desktop_resolution_width())
    target_height = int(height if height is not None else windows_desktop_resolution_height())
    if target_width <= 0 or target_height <= 0:
        raise ValueError("Windows 桌面分辨率必须为正数: %sx%s" % (target_width, target_height))
    command = r"""$ErrorActionPreference = 'Stop'
$user = __USERNAME__
$password = __PASSWORD__
$targetWidth = __WIDTH__
$targetHeight = __HEIGHT__
$profileName = ($user -split '\\')[-1]
$desktop = Join-Path (Join-Path 'C:\Users' $profileName) 'Desktop'
$scriptPath = Join-Path $desktop 'workflowgym_set_desktop_resolution.ps1'
$logPath = Join-Path $desktop 'workflowgym_set_desktop_resolution.log'
$taskName = 'WorkflowGymSetDesktopResolution'

New-Item -ItemType Directory -Path $desktop -Force | Out-Null

@'
$ErrorActionPreference = 'Stop'
$targetWidth = __WIDTH__
$targetHeight = __HEIGHT__
$logPath = Join-Path ([Environment]::GetFolderPath('Desktop')) 'workflowgym_set_desktop_resolution.log'
Start-Transcript -LiteralPath $logPath -Append -Force | Out-Null
try {
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class WorkflowGymDisplayResolution {
    private const int ENUM_CURRENT_SETTINGS = -1;
    private const int CDS_UPDATEREGISTRY = 0x01;
    private const int DISP_CHANGE_SUCCESSFUL = 0;
    private const int DM_PELSWIDTH = 0x80000;
    private const int DM_PELSHEIGHT = 0x100000;
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct DEVMODE {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmDeviceName;
        public short dmSpecVersion;
        public short dmDriverVersion;
        public short dmSize;
        public short dmDriverExtra;
        public int dmFields;
        public int dmPositionX;
        public int dmPositionY;
        public int dmDisplayOrientation;
        public int dmDisplayFixedOutput;
        public short dmColor;
        public short dmDuplex;
        public short dmYResolution;
        public short dmTPosition;
        public short dmReserved1;
        public short dmReserved2;
        public int dmDisplayFrequency;
        public int dmPelsWidth;
        public int dmPelsHeight;
        public int dmDisplayFlags;
        public int dmDisplayFrequency2;
        public int dmNupWidth;
        public int dmNupHeight;
    }
    [DllImport("user32.dll", CharSet = CharSet.Ansi)]
    public static extern bool EnumDisplaySettings(string deviceName, int modeNum, ref DEVMODE devMode);
    [DllImport("user32.dll", CharSet = CharSet.Ansi)]
    public static extern int ChangeDisplaySettings(ref DEVMODE devMode, int flags);
    public static string Apply(int width, int height) {
        DEVMODE dm = new DEVMODE();
        dm.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));
        if (!EnumDisplaySettings(null, ENUM_CURRENT_SETTINGS, ref dm)) {
            return "enum_failed";
        }
        dm.dmPelsWidth = width;
        dm.dmPelsHeight = height;
        dm.dmFields = DM_PELSWIDTH | DM_PELSHEIGHT;
        int result = ChangeDisplaySettings(ref dm, CDS_UPDATEREGISTRY);
        return result == DISP_CHANGE_SUCCESSFUL ? "ok" : ("code_" + result);
    }
}
"@
$result = [WorkflowGymDisplayResolution]::Apply($targetWidth, $targetHeight)
Write-Output ('WORKFLOWGYM_WINDOWS_RESOLUTION_TARGET ' + $targetWidth + 'x' + $targetHeight)
Write-Output ('WORKFLOWGYM_WINDOWS_RESOLUTION_APPLY ' + $result)
Add-Type -AssemblyName System.Windows.Forms
$bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
Write-Output ('WORKFLOWGYM_WINDOWS_RESOLUTION_SIZE ' + $bounds.Width + 'x' + $bounds.Height)
try {
  $pythonCommand = Get-Command python -ErrorAction SilentlyContinue
  if (-not $pythonCommand) { $pythonCommand = Get-Command py -ErrorAction SilentlyContinue }
  if ($pythonCommand) {
    $pySize = & $pythonCommand.Source -c "import pyautogui; size=pyautogui.size(); print('%sx%s' % (int(size.width), int(size.height)))"
    Write-Output ('WORKFLOWGYM_WINDOWS_RESOLUTION_PYAUTOGUI ' + ($pySize | Out-String).Trim())
  }
} catch {}
} finally {
  Stop-Transcript | Out-Null
}
'@ | Set-Content -LiteralPath $scriptPath -Encoding UTF8

cmd.exe /c "schtasks /Delete /TN $taskName /F >nul 2>nul"
$taskCommand = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $scriptPath + '"'
schtasks /Create /F /TN $taskName /SC ONCE /ST 23:59 /TR $taskCommand /RU $user /RP $password /RL HIGHEST /IT | Out-Null
schtasks /Run /TN $taskName | Out-Null
Start-Sleep -Seconds 8
if (Test-Path -LiteralPath $logPath) {
  Write-Output 'WORKFLOWGYM_WINDOWS_RESOLUTION_LOG'
  Get-Content -LiteralPath $logPath -Tail 40
}
Write-Output 'WORKFLOWGYM_WINDOWS_RESOLUTION_TASK_STARTED'
Write-Output ('WORKFLOWGYM_WINDOWS_RESOLUTION_SCRIPT ' + $scriptPath)
"""
    return (
        command.replace("__PASSWORD__", ps_single_quote(password))
        .replace("__USERNAME__", ps_single_quote(username))
        .replace("__WIDTH__", str(target_width))
        .replace("__HEIGHT__", str(target_height))
    )


def build_windows_probe_flask_runner_command(port: int, token: str) -> str:
    retry_block = _build_windows_flask_health_retry_block(
        max_seconds=windows_flask_runner_probe_seconds(),
    )
    return (
        r"""
$ErrorActionPreference = 'Stop'
$port = __PORT__
$token = __TOKEN__
$desktop = 'C:\Users\Administrator\Desktop'
$runnerPath = Join-Path $desktop 'workflowgym_interactive_flask_runner.py'
$logPath = Join-Path $desktop 'workflowgym_interactive_flask_runner.log'
$taskName = 'WorkflowGymInteractiveFlaskRunner'
if (-not (Test-Path -LiteralPath $runnerPath)) {
  throw ('flask runner script missing: ' + $runnerPath)
}
$task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if (-not $task) {
  throw ('flask runner scheduled task missing: ' + $taskName)
}
"""
        + retry_block
    ).strip().replace("__PORT__", str(int(port))).replace("__TOKEN__", ps_single_quote(token))


def build_windows_interactive_flask_runner_setup_command(username: str, password: str, token: str, port: int) -> str:
    pip_index = os.getenv("PIP_INDEX_URL", "https://pypi.tuna.tsinghua.edu.cn/simple")
    pip_trusted_host = os.getenv("PIP_TRUSTED_HOST", "pypi.tuna.tsinghua.edu.cn")
    bind_host = flask_runner_bind_host()
    command = r"""$ErrorActionPreference = 'Stop'

$password = __PASSWORD__
$user = __USERNAME__
$taskName = 'WorkflowGymInteractiveFlaskRunner'
$desktop = Join-Path (Join-Path 'C:\Users' (($user -split '\\')[-1])) 'Desktop'
$pythonCommand = Get-Command python -ErrorAction SilentlyContinue
if (-not $pythonCommand) { $pythonCommand = Get-Command py -ErrorAction SilentlyContinue }
if (-not $pythonCommand) { throw 'python executable not found' }
$python = $pythonCommand.Source
$runnerPath = Join-Path $desktop 'workflowgym_interactive_flask_runner.py'
$runnerLaunchPath = Join-Path $desktop 'workflowgym_interactive_flask_runner_launch.ps1'
$logPath = Join-Path $desktop 'workflowgym_interactive_flask_runner.log'
$port = __PORT__
$token = __FLASK_TOKEN__
$pipIndex = __PIP_INDEX__
$pipTrustedHost = __PIP_TRUSTED_HOST__

Get-CimInstance Win32_Process |
  Where-Object {
    $_.CommandLine -like '*workflowgym_interactive_flask_runner.py*' -or
    $_.CommandLine -like '*workflowgym_interactive_flask_runner.cmd*' -or
    $_.CommandLine -like '*workflowgym_interactive_flask_runner.vbs*' -or
    $_.CommandLine -like '*workflowgym_interactive_flask_runner_launch.ps1*'
  } |
  ForEach-Object {
    Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
  }
Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue |
  ForEach-Object {
    Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue
  }
Remove-Item -LiteralPath $logPath -Force -ErrorAction SilentlyContinue

& $python -m pip install --upgrade flask -i $pipIndex --trusted-host $pipTrustedHost | Out-String | Write-Output

@"
import base64
import json
import os
import subprocess
import sys
import time
import traceback
from pathlib import Path

import pyautogui
from flask import Flask, jsonify, request

TOKEN = __TOKEN_JSON__
PORT = __PORT__
BIND_HOST = __BIND_HOST_JSON__
EXEC_TIMEOUT_SECONDS = __EXEC_TIMEOUT_SECONDS__

app = Flask(__name__)
pyautogui.FAILSAFE = False
DESKTOP_ROOT = Path(__file__).resolve().parent

def check_token():
    return request.headers.get("X-WorkflowGym-Token") == TOKEN

def under_desktop(path):
    try:
        path.resolve().relative_to(DESKTOP_ROOT)
        return True
    except ValueError:
        return False

__ACTION_SCRIPT_GUARD__

def screen_size():
    try:
        width, height = pyautogui.size()
        return [int(width), int(height)]
    except Exception:
        return []

def safe_position():
    try:
        return list(pyautogui.position())
    except Exception:
        return []

def run_python_script(script, action_id):
    desktop = Path(__file__).resolve().parent
    script_path = desktop / ("workflowgym_flask_exec_%s.py" % (action_id or "action"))
    script_path.write_text(script, encoding="utf-8")
    try:
        return subprocess.run(
            [sys.executable, str(script_path)],
            capture_output=True,
            text=True,
            timeout=EXEC_TIMEOUT_SECONDS,
        )
    finally:
        try:
            script_path.unlink(missing_ok=True)
        except Exception:
            pass

@app.get("/health")
def health():
    if not check_token():
        return jsonify({"ok": False, "error": "unauthorized"}), 401
    return jsonify({
        "ok": True,
        "runner": "flask",
        "exec_mode": "subprocess",
        "exec_timeout_seconds": EXEC_TIMEOUT_SECONDS,
        "screen_size": screen_size(),
        "pid": os.getpid(),
        "time": time.time(),
    })

@app.get("/file")
def file_get():
    if not check_token():
        return jsonify({"ok": False, "error": "unauthorized"}), 401
    raw_path = (request.args.get("path") or "").strip()
    if not raw_path:
        return jsonify({"ok": False, "error": "path required"}), 400
    try:
        path = Path(raw_path).expanduser().resolve()
    except Exception as exc:
        return jsonify({"ok": False, "error": "invalid path: %s" % exc}), 400
    if not under_desktop(path):
        return jsonify({
            "ok": False,
            "error": "path_outside_desktop",
            "path": str(path),
            "desktop_root": str(DESKTOP_ROOT),
        }), 403
    if not path.is_file():
        return jsonify({"ok": False, "error": "not_found", "path": str(path)}), 404
    meta = str(request.args.get("meta") or "").strip().lower()
    if meta in ("1", "true", "yes", "on"):
        return jsonify({
            "ok": True,
            "exists": True,
            "path": str(path),
            "name": path.name,
            "size": int(path.stat().st_size),
        })
    from flask import send_file
    return send_file(path, as_attachment=True, download_name=path.name)

@app.post("/action")
def action():
    if not check_token():
        return jsonify({"ok": False, "error": "unauthorized"}), 401
    data = request.get_json(force=True) or {}
    action_id = data.get("id", "")
    try:
        kind = data.get("action")
        if kind == "python":
            script = base64.b64decode(data.get("script_b64") or "").decode("utf-8")
            try:
                validate_action_script(script)
            except ValueError as exc:
                return jsonify({
                    "ok": False,
                    "id": action_id,
                    "runner": "flask",
                    "status": "rejected",
                    "error": str(exc),
                }), 403
            try:
                completed = run_python_script(script, action_id)
                return jsonify({
                    "ok": completed.returncode == 0,
                    "id": action_id,
                    "runner": "flask",
                    "status": "executed" if completed.returncode == 0 else "error",
                    "output": completed.stdout,
                    "stderr": completed.stderr,
                    "screen_size": screen_size(),
                    "position": safe_position(),
                    "pid": os.getpid(),
                    "error": "" if completed.returncode == 0 else ("exit_code=%s" % completed.returncode),
                })
            except subprocess.TimeoutExpired as exc:
                if exc.process is not None:
                    try:
                        exc.process.kill()
                    except Exception:
                        pass
                return jsonify({
                    "ok": False,
                    "id": action_id,
                    "runner": "flask",
                    "status": "timeout",
                    "output": exc.stdout or "",
                    "stderr": exc.stderr or "",
                    "error": "action_exec_timeout seconds=%s" % EXEC_TIMEOUT_SECONDS,
                    "screen_size": screen_size(),
                    "pid": os.getpid(),
                }), 500
        return jsonify({"ok": False, "id": action_id, "error": "unknown action", "action": kind}), 400
    except Exception as exc:
        return jsonify({
            "ok": False,
            "id": action_id,
            "runner": "flask",
            "status": "error",
            "error": repr(exc),
            "traceback": traceback.format_exc(),
            "screen_size": screen_size(),
            "pid": os.getpid(),
        }), 500

if __name__ == "__main__":
    log_path = Path(__file__).resolve().parent / "workflowgym_interactive_flask_runner.log"
    log_handle = open(log_path, "a", encoding="utf-8", buffering=1)
    sys.stdout = log_handle
    sys.stderr = log_handle
    print(time.strftime("%Y-%m-%d %H:%M:%S"), "START pid=", os.getpid(), "port=", PORT, "bind=", BIND_HOST)
    app.run(host=BIND_HOST, port=PORT, threaded=False)
"@ | Set-Content -LiteralPath $runnerPath -Encoding UTF8

@"
$ErrorActionPreference = 'Stop'
Start-Process -FilePath "$python" -ArgumentList @('-u', "$runnerPath") -WorkingDirectory "$desktop" -WindowStyle Hidden
Start-Sleep -Seconds 2
Write-Output ('WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_PID launched')
"@ | Set-Content -LiteralPath $runnerLaunchPath -Encoding UTF8

cmd.exe /c "schtasks /Delete /TN $taskName /F >nul 2>nul"
$taskCommand = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $runnerLaunchPath + '"'
schtasks /Create /F /TN $taskName /SC ONCE /ST 23:59 /TR $taskCommand /RU $user /RP $password /RL HIGHEST /IT | Out-Null

netsh advfirewall firewall delete rule name="WorkflowGym Flask Runner __PORT__" 2>$null | Out-Null
netsh advfirewall firewall add rule name="WorkflowGym Flask Runner __PORT__" dir=in action=allow protocol=TCP localport=__PORT__ | Out-Null

schtasks /Run /TN $taskName | Out-Null
Start-Sleep -Seconds 3
$healthReady = $false
for ($attempt = 1; $attempt -le 3; $attempt++) {
  try {
    __FLASK_HEALTH_WAIT__
    $healthReady = $true
    break
  } catch {
    Write-Output ('WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_HEALTH_RETRY attempt=' + $attempt + ' error=' + $_.Exception.Message)
    if ($attempt -ge 3) { throw }
    schtasks /Run /TN $taskName | Out-Null
    Start-Sleep -Seconds 5
  }
}
if (-not $healthReady) {
  throw 'flask runner health not ready after retries'
}
Write-Output 'WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_STARTED'
Write-Output 'WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_LAUNCH hidden_ps1'
Write-Output ('WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_PATH ' + $runnerPath)
Write-Output ('WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_LAUNCHER ' + $runnerLaunchPath)
Write-Output ('WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_LOG ' + $logPath)
Write-Output ('WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_PORT ' + $port)
"""
    health_wait = _build_windows_flask_health_wait_block()
    command = command.replace("__FLASK_HEALTH_WAIT__", health_wait)
    return (
        command.replace("__PASSWORD__", ps_single_quote(password))
        .replace("__USERNAME__", ps_single_quote(username))
        .replace("__TOKEN_JSON__", json.dumps(token))
        .replace("__BIND_HOST_JSON__", json.dumps(bind_host))
        .replace("__ACTION_SCRIPT_GUARD__", _flask_action_script_guard_source())
        .replace("__FLASK_TOKEN__", ps_single_quote(token))
        .replace("__PORT__", str(int(port)))
        .replace("__EXEC_TIMEOUT_SECONDS__", str(windows_flask_exec_timeout_seconds()))
        .replace("__PIP_INDEX__", ps_single_quote(pip_index))
        .replace("__PIP_TRUSTED_HOST__", ps_single_quote(pip_trusted_host))
    )


def ubuntu_flask_runner_token() -> str:
    return os.getenv("UBUNTU_FLASK_RUNNER_TOKEN", windows_flask_runner_token())


def ubuntu_flask_runner_port_candidates() -> list[int]:
    explicit = os.getenv("UBUNTU_FLASK_RUNNER_PORT", os.getenv("WORKFLOWGYM_UBUNTU_FLASK_RUNNER_PORT", "")).strip()
    if explicit:
        return [int(explicit)]
    return [80, 8080]


def ubuntu_flask_runner_port() -> int:
    return ubuntu_flask_runner_port_candidates()[0]


def ubuntu_flask_exec_timeout_seconds() -> int:
    return windows_flask_exec_timeout_seconds()


def ubuntu_flask_runner_probe_seconds() -> int:
    return max(10, int(os.getenv("UBUNTU_FLASK_RUNNER_PROBE_SECONDS", str(windows_flask_runner_probe_seconds()))))


def ubuntu_action_runner_mode() -> str:
    explicit = os.getenv("UBUNTU_ACTION_RUNNER", "").strip().lower()
    if explicit in ("flask", "legacy"):
        return explicit
    if os.getenv("UBUNTU_LEGACY_PYAUTOGUI_RUNNER", "0").lower() in ("1", "true", "yes", "on"):
        return "legacy"
    return "flask"


def _interactive_flask_runner_python_source(
    token: str,
    port: int,
    exec_timeout_seconds: int,
    bind_host: str | None = None,
    desktop_root: str | None = None,
) -> str:
    resolved_bind_host = bind_host if bind_host is not None else flask_runner_bind_host()
    resolved_desktop_root = (desktop_root or "").strip() or str(Path.home() / "Desktop")
    return """import base64
import json
import os
import subprocess
import sys
import time
import traceback
from pathlib import Path

from flask import Flask, jsonify, request

TOKEN = __TOKEN_JSON__
PORT = __PORT__
BIND_HOST = __BIND_HOST_JSON__
EXEC_TIMEOUT_SECONDS = __EXEC_TIMEOUT_SECONDS__
DESKTOP_ROOT = Path(__DESKTOP_ROOT_JSON__).expanduser().resolve()

app = Flask(__name__)
_pyautogui = None

def check_token():
    return request.headers.get("X-WorkflowGym-Token") == TOKEN

def under_desktop(path):
    try:
        path.resolve().relative_to(DESKTOP_ROOT)
        return True
    except ValueError:
        return False

__ACTION_SCRIPT_GUARD__

def load_pyautogui():
    global _pyautogui
    if _pyautogui is None:
        import pyautogui
        pyautogui.FAILSAFE = False
        _pyautogui = pyautogui
    return _pyautogui

def screen_size():
    try:
        width, height = load_pyautogui().size()
        return [int(width), int(height)]
    except Exception:
        return []

def safe_position():
    try:
        return list(load_pyautogui().position())
    except Exception:
        return []

def run_python_script(script, action_id):
    runner_dir = Path(__file__).resolve().parent
    script_path = runner_dir / ("workflowgym_flask_exec_%s.py" % (action_id or "action"))
    script_path.write_text(script, encoding="utf-8")
    try:
        return subprocess.run(
            [sys.executable, str(script_path)],
            capture_output=True,
            text=True,
            timeout=EXEC_TIMEOUT_SECONDS,
        )
    finally:
        try:
            script_path.unlink(missing_ok=True)
        except Exception:
            pass

@app.get("/health")
def health():
    if not check_token():
        return jsonify({"ok": False, "error": "unauthorized"}), 401
    return jsonify({
        "ok": True,
        "runner": "flask",
        "platform": "ubuntu",
        "exec_mode": "subprocess",
        "exec_timeout_seconds": EXEC_TIMEOUT_SECONDS,
        "screen_size": screen_size(),
        "pid": os.getpid(),
        "time": time.time(),
    })

@app.get("/file")
def file_get():
    if not check_token():
        return jsonify({"ok": False, "error": "unauthorized"}), 401
    raw_path = (request.args.get("path") or "").strip()
    if not raw_path:
        return jsonify({"ok": False, "error": "path required"}), 400
    try:
        path = Path(raw_path).expanduser().resolve()
    except Exception as exc:
        return jsonify({"ok": False, "error": "invalid path: %s" % exc}), 400
    if not under_desktop(path):
        return jsonify({
            "ok": False,
            "error": "path_outside_desktop",
            "path": str(path),
            "desktop_root": str(DESKTOP_ROOT),
        }), 403
    if not path.is_file():
        return jsonify({"ok": False, "error": "not_found", "path": str(path)}), 404
    meta = str(request.args.get("meta") or "").strip().lower()
    if meta in ("1", "true", "yes", "on"):
        return jsonify({
            "ok": True,
            "exists": True,
            "path": str(path),
            "name": path.name,
            "size": int(path.stat().st_size),
        })
    from flask import send_file
    return send_file(path, as_attachment=True, download_name=path.name)

@app.post("/action")
def action():
    if not check_token():
        return jsonify({"ok": False, "error": "unauthorized"}), 401
    data = request.get_json(force=True) or {}
    action_id = data.get("id", "")
    try:
        kind = data.get("action")
        if kind == "python":
            script = base64.b64decode(data.get("script_b64") or "").decode("utf-8")
            try:
                validate_action_script(script)
            except ValueError as exc:
                return jsonify({
                    "ok": False,
                    "id": action_id,
                    "runner": "flask",
                    "platform": "ubuntu",
                    "status": "rejected",
                    "error": str(exc),
                }), 403
            try:
                completed = run_python_script(script, action_id)
                return jsonify({
                    "ok": completed.returncode == 0,
                    "id": action_id,
                    "runner": "flask",
                    "platform": "ubuntu",
                    "status": "executed" if completed.returncode == 0 else "error",
                    "output": completed.stdout,
                    "stderr": completed.stderr,
                    "screen_size": screen_size(),
                    "position": safe_position(),
                    "pid": os.getpid(),
                    "error": "" if completed.returncode == 0 else ("exit_code=%s" % completed.returncode),
                })
            except subprocess.TimeoutExpired as exc:
                if exc.process is not None:
                    try:
                        exc.process.kill()
                    except Exception:
                        pass
                return jsonify({
                    "ok": False,
                    "id": action_id,
                    "runner": "flask",
                    "platform": "ubuntu",
                    "status": "timeout",
                    "output": exc.stdout or "",
                    "stderr": exc.stderr or "",
                    "error": "action_exec_timeout seconds=%s" % EXEC_TIMEOUT_SECONDS,
                    "screen_size": screen_size(),
                    "pid": os.getpid(),
                }), 500
        return jsonify({"ok": False, "id": action_id, "error": "unknown action", "action": kind}), 400
    except Exception as exc:
        return jsonify({
            "ok": False,
            "id": action_id,
            "runner": "flask",
            "platform": "ubuntu",
            "status": "error",
            "error": repr(exc),
            "traceback": traceback.format_exc(),
            "screen_size": screen_size(),
            "pid": os.getpid(),
        }), 500

if __name__ == "__main__":
    log_path = Path(__file__).resolve().parent / "workflowgym_interactive_flask_runner.log"
    log_handle = open(log_path, "a", encoding="utf-8", buffering=1)
    sys.stdout = log_handle
    sys.stderr = log_handle
    print(time.strftime("%Y-%m-%d %H:%M:%S"), "START pid=", os.getpid(), "port=", PORT, "bind=", BIND_HOST)
    app.run(host=BIND_HOST, port=PORT, threaded=False)
""".replace("__TOKEN_JSON__", json.dumps(token)).replace("__PORT__", str(int(port))).replace(
        "__BIND_HOST_JSON__", json.dumps(resolved_bind_host)
    ).replace("__DESKTOP_ROOT_JSON__", json.dumps(resolved_desktop_root)).replace(
        "__ACTION_SCRIPT_GUARD__", _flask_action_script_guard_source()
    ).replace("__EXEC_TIMEOUT_SECONDS__", str(int(exec_timeout_seconds)))


def _ubuntu_flask_health_wait_shell(port: int, token: str, max_seconds: int, log_path: str) -> str:
    return """
deadline=$((SECONDS + __MAX_SECONDS__))
health_body=""
while [ "$SECONDS" -lt "$deadline" ]; do
  if health_body="$(curl -sf -H "X-WorkflowGym-Token: __TOKEN__" "http://127.0.0.1:__PORT__/health" 2>/dev/null || true)"; then
    if echo "$health_body" | grep -q '"ok"[[:space:]]*:[[:space:]]*true'; then
      break
    fi
  fi
  health_body=""
  sleep 2
done
if [ -z "$health_body" ]; then
  if [ -f "__LOG_PATH__" ]; then
    echo "WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_LOG"
    tail -n 60 "__LOG_PATH__" || true
  fi
  echo "flask runner health not ready within __MAX_SECONDS__s on port __PORT__"
  exit 1
fi
echo "WORKFLOWGYM_PROBE_FLASK_RUNNER_OK"
echo "WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_HEALTH $health_body"
""".replace("__PORT__", str(int(port))).replace("__TOKEN__", shlex.quote(token)).replace(
        "__MAX_SECONDS__", str(int(max_seconds))
    ).replace("__LOG_PATH__", log_path)


def build_ubuntu_interactive_flask_runner_setup_command(
    desktop_user: str,
    desktop_home: str,
    display: str,
    xauthority: str,
    token: str,
    port: int,
) -> str:
    pip_index = os.getenv("PIP_INDEX_URL", "https://pypi.tuna.tsinghua.edu.cn/simple")
    pip_trusted_host = os.getenv("PIP_TRUSTED_HOST", "pypi.tuna.tsinghua.edu.cn")
    runner_dir = "%s/.workflowgym" % desktop_home.rstrip("/")
    runner_path = "%s/workflowgym_interactive_flask_runner.py" % runner_dir
    log_path = "%s/workflowgym_interactive_flask_runner.log" % runner_dir
    pid_path = "%s/workflowgym_interactive_flask_runner.pid" % runner_dir
    desktop_path = "%s/Desktop" % desktop_home.rstrip("/")
    runner_source = _interactive_flask_runner_python_source(
        token,
        port,
        ubuntu_flask_exec_timeout_seconds(),
        bind_host=flask_runner_bind_host(),
        desktop_root=desktop_path,
    )
    health_wait = _ubuntu_flask_health_wait_shell(port, token, ubuntu_flask_runner_probe_seconds(), log_path)
    return """#!/bin/bash
set -euo pipefail
""" + _pip_install_flask_shell() + """
desktop_user=__DESKTOP_USER__
desktop_home=__DESKTOP_HOME__
display=__DISPLAY__
xauthority=__XAUTHORITY__
runner_dir=__RUNNER_DIR__
runner_path=__RUNNER_PATH__
log_path=__LOG_PATH__
pid_path=__PID_PATH__
port=__PORT__
token=__TOKEN__
pip_index=__PIP_INDEX__
pip_trusted_host=__PIP_TRUSTED_HOST__

sudo mkdir -p "$runner_dir"
sudo chown "$desktop_user:$desktop_user" "$runner_dir"

if command -v fuser >/dev/null 2>&1; then
  sudo fuser -k "${port}/tcp" >/dev/null 2>&1 || true
fi
if [ -f "$pid_path" ]; then
  old_pid="$(cat "$pid_path" 2>/dev/null || true)"
  if [ -n "$old_pid" ]; then
    sudo kill "$old_pid" >/dev/null 2>&1 || true
  fi
fi
sudo pkill -f "$runner_path" >/dev/null 2>&1 || true
sudo rm -f "$log_path" "$pid_path"

pip_log="/tmp/workflowgym_flask_pip_$$.log"
if ! workflowgym_pip_install_flask "$pip_index" "$pip_trusted_host" > "$pip_log" 2>&1; then
  echo "workflowgym flask pip primary install failed, retry with fallback" >> "$pip_log"
  if ! workflowgym_pip_install_flask_fallback "$pip_index" "$pip_trusted_host" >> "$pip_log" 2>&1; then
    echo "WORKFLOWGYM_FLASK_PIP_INSTALL_FAILED" >> "$pip_log"
    cat "$pip_log" >&2 || true
    exit 1
  fi
fi
if ! /usr/bin/python3 -c "import flask" >> "$pip_log" 2>&1; then
  echo "WORKFLOWGYM_FLASK_IMPORT_FAILED" >> "$pip_log"
  cat "$pip_log" >&2 || true
  exit 1
fi
echo "WORKFLOWGYM_FLASK_PIP_INSTALL_OK" >> "$pip_log"
sudo cp "$pip_log" "$log_path" 2>/dev/null || true
rm -f "$pip_log"
sudo chown -R "$desktop_user:$desktop_user" "$runner_dir"

sudo tee "$runner_path" >/dev/null <<'PY'
__RUNNER_SOURCE__
PY
sudo chown "$desktop_user:$desktop_user" "$runner_path"
sudo chmod 644 "$runner_path"

sudo -H -u "$desktop_user" env \
  DISPLAY="$display" HOME="$desktop_home" XAUTHORITY="$xauthority" \
  WG_RUNNER_DIR="$runner_dir" WG_RUNNER_PATH="$runner_path" WG_LOG_PATH="$log_path" WG_PID_PATH="$pid_path" \
  bash -lc 'set -euo pipefail; cd "$WG_RUNNER_DIR"; nohup /usr/bin/python3 -u "$WG_RUNNER_PATH" >> "$WG_LOG_PATH" 2>&1 & echo $! > "$WG_PID_PATH"'

sleep 2
__HEALTH_WAIT__
echo "WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_STARTED"
echo "WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_LAUNCH nohup"
echo "WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_PATH $runner_path"
echo "WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_LOG $log_path"
echo "WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_PORT $port"
""".replace("__DESKTOP_USER__", shlex.quote(desktop_user)).replace(
        "__DESKTOP_HOME__", shlex.quote(desktop_home)
    ).replace("__DISPLAY__", shlex.quote(display)).replace("__XAUTHORITY__", shlex.quote(xauthority)).replace(
        "__RUNNER_DIR__", shlex.quote(runner_dir)
    ).replace("__RUNNER_PATH__", shlex.quote(runner_path)).replace("__LOG_PATH__", shlex.quote(log_path)).replace(
        "__PID_PATH__", shlex.quote(pid_path)
    ).replace("__PORT__", str(int(port))).replace("__TOKEN__", shlex.quote(token)).replace(
        "__PIP_INDEX__", shlex.quote(pip_index)
    ).replace("__PIP_TRUSTED_HOST__", shlex.quote(pip_trusted_host)).replace(
        "__RUNNER_SOURCE__", runner_source
    ).replace("__HEALTH_WAIT__", health_wait.strip())


def build_ubuntu_probe_flask_runner_command(port: int, token: str) -> str:
    log_guess = "/home/user/.workflowgym/workflowgym_interactive_flask_runner.log"
    health_wait = _ubuntu_flask_health_wait_shell(port, token, ubuntu_flask_runner_probe_seconds(), log_guess)
    return """#!/bin/bash
set -euo pipefail
port=__PORT__
token=__TOKEN__
__HEALTH_WAIT__
""".replace("__PORT__", str(int(port))).replace("__TOKEN__", shlex.quote(token)).replace(
        "__HEALTH_WAIT__", health_wait.strip()
    )


def build_ubuntu_flask_post_python_action_command(
    script: str,
    port: int,
    token: str,
    http_timeout: int,
    action_id: str = "",
    source: str = "workflowgym_pyautogui_wrapper",
    log_path: str = "",
) -> str:
    resolved_action_id = str(action_id or ("ubuntu-%s" % uuid.uuid4()))
    payload = {
        "action": "python",
        "id": resolved_action_id,
        "source": source,
        "script_b64": base64.b64encode(script.encode("utf-8")).decode("ascii"),
    }
    payload_json = json.dumps(payload, ensure_ascii=True)
    resolved_log_path = log_path or "/home/user/.workflowgym/workflowgym_interactive_flask_runner.log"
    return """#!/bin/bash
set -euo pipefail
port=__PORT__
token=__TOKEN__
http_timeout=__HTTP_TIMEOUT__
log_path=__LOG_PATH__
result_path="/tmp/workflowgym_ubuntu_flask_action_result.json"

echo "WORKFLOWGYM_RUNCOMMAND_IDENTITY user=$(id -un) uid=$(id -u)"

if ! curl -sf -m "$http_timeout" \
  -H "X-WorkflowGym-Token: $token" \
  -H "Content-Type: application/json" \
  -d __PAYLOAD_JSON__ \
  "http://127.0.0.1:${port}/action" > "$result_path"; then
  if [ -f "$log_path" ]; then
    echo "WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_LOG"
    tail -n 40 "$log_path" || true
  fi
  exit 1
fi

echo "WORKFLOWGYM_FLASK_AGENT_RESULT"
cat "$result_path"
/usr/bin/python3 - <<'PY'
import json
import sys
from pathlib import Path

result_path = Path("/tmp/workflowgym_ubuntu_flask_action_result.json")
data = json.loads(result_path.read_text(encoding="utf-8"))
output = data.get("output") or ""
stderr = data.get("stderr") or ""
if output:
    print(output, end="" if output.endswith("\\n") else "\\n")
if stderr:
    print(stderr, file=sys.stderr, end="" if str(stderr).endswith("\\n") else "\\n")
if not data.get("ok"):
    raise SystemExit(("workflowgym flask action failed: %s" % json.dumps(data, ensure_ascii=True))[:2000])
PY
""".replace("__PORT__", str(int(port))).replace("__TOKEN__", shlex.quote(token)).replace(
        "__HTTP_TIMEOUT__", str(int(http_timeout))
    ).replace("__LOG_PATH__", shlex.quote(resolved_log_path)).replace(
        "__PAYLOAD_JSON__", shlex.quote(payload_json)
    )


def build_ubuntu_flask_health_runcmd_python_command(
    port: int,
    token: str,
    http_timeout: int,
    log_path: str = "",
) -> str:
    resolved_log_path = log_path or "/home/user/.workflowgym/workflowgym_interactive_flask_runner.log"
    return """#!/usr/bin/python
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

print("WORKFLOWGYM_RUNCOMMAND_IDENTITY user=%s uid=%s" % (os.getenv("USER", "unknown"), os.getuid()))
PORT = __PORT__
TOKEN = __TOKEN_JSON__
HTTP_TIMEOUT = __HTTP_TIMEOUT__
LOG_PATH = __LOG_PATH_JSON__

req = urllib.request.Request(
    "http://127.0.0.1:%d/health" % PORT,
    headers={"X-WorkflowGym-Token": TOKEN},
    method="GET",
)
try:
    with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT) as resp:
        data = json.loads(resp.read().decode("utf-8"))
except urllib.error.URLError as exc:
    log_path = Path(LOG_PATH)
    if log_path.is_file():
        print("WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_LOG")
        print("".join(log_path.read_text(encoding="utf-8", errors="replace").splitlines(True)[-40:]), end="")
    raise SystemExit("urllib health request failed: %s" % exc) from exc

if not data.get("ok"):
    raise SystemExit("flask runner health not ready: %s" % json.dumps(data, ensure_ascii=True))
print("WORKFLOWGYM_PROBE_FLASK_RUNNER_OK")
print("WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_HEALTH %s" % json.dumps(data, ensure_ascii=True))
""".replace("__PORT__", str(int(port))).replace("__TOKEN_JSON__", json.dumps(token)).replace(
        "__HTTP_TIMEOUT__", str(int(http_timeout))
    ).replace("__LOG_PATH_JSON__", json.dumps(resolved_log_path))


def build_ubuntu_flask_post_python_action_runcmd_python_command(
    script: str,
    port: int,
    token: str,
    http_timeout: int,
    action_id: str = "",
    source: str = "workflowgym_pyautogui_wrapper",
    log_path: str = "",
) -> str:
    resolved_action_id = str(action_id or ("ubuntu-%s" % uuid.uuid4()))
    payload = {
        "action": "python",
        "id": resolved_action_id,
        "source": source,
        "script_b64": base64.b64encode(script.encode("utf-8")).decode("ascii"),
    }
    resolved_log_path = log_path or "/home/user/.workflowgym/workflowgym_interactive_flask_runner.log"
    return """#!/usr/bin/python
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

print("WORKFLOWGYM_RUNCOMMAND_IDENTITY user=%s uid=%s" % (os.getenv("USER", "unknown"), os.getuid()))
PORT = __PORT__
TOKEN = __TOKEN_JSON__
HTTP_TIMEOUT = __HTTP_TIMEOUT__
LOG_PATH = __LOG_PATH_JSON__
PAYLOAD = json.loads(__PAYLOAD_JSON__)

req = urllib.request.Request(
    "http://127.0.0.1:%d/action" % PORT,
    data=json.dumps(PAYLOAD).encode("utf-8"),
    headers={
        "Content-Type": "application/json",
        "X-WorkflowGym-Token": TOKEN,
    },
    method="POST",
)
try:
    with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT) as resp:
        data = json.loads(resp.read().decode("utf-8"))
except urllib.error.URLError as exc:
    log_path = Path(LOG_PATH)
    if log_path.is_file():
        print("WORKFLOWGYM_INTERACTIVE_FLASK_RUNNER_LOG")
        print("".join(log_path.read_text(encoding="utf-8", errors="replace").splitlines(True)[-40:]), end="")
    raise SystemExit("urllib action request failed: %s" % exc) from exc

print("WORKFLOWGYM_FLASK_AGENT_RESULT")
print(json.dumps(data, ensure_ascii=True))
output = data.get("output") or ""
stderr = data.get("stderr") or ""
if output:
    print(output, end="" if output.endswith("\\n") else "\\n")
if stderr:
    print(stderr, file=sys.stderr, end="" if str(stderr).endswith("\\n") else "\\n")
if not data.get("ok"):
    raise SystemExit(("workflowgym flask action failed: %s" % json.dumps(data, ensure_ascii=True))[:2000])
""".replace("__PORT__", str(int(port))).replace("__TOKEN_JSON__", json.dumps(token)).replace(
        "__HTTP_TIMEOUT__", str(int(http_timeout))
    ).replace("__LOG_PATH_JSON__", json.dumps(resolved_log_path)).replace(
        "__PAYLOAD_JSON__", json.dumps(json.dumps(payload, ensure_ascii=True))
    )


def build_windows_file_queue_runner_setup_command(username: str, password: str) -> str:
    command = r"""
$ErrorActionPreference = 'Stop'
$user = __USERNAME__
$password = __PASSWORD__
$profileName = ($user -split '\\')[-1]
$desktop = Join-Path (Join-Path 'C:\Users' $profileName) 'Desktop'
$pythonCommand = Get-Command python -ErrorAction SilentlyContinue
if (-not $pythonCommand) { $pythonCommand = Get-Command py -ErrorAction SilentlyContinue }
if (-not $pythonCommand) { throw 'python command not found' }
$python = $pythonCommand.Source
$taskName = 'WorkflowGymFileQueueWatchdog'
$runnerPath = Join-Path $desktop 'workflowgym_file_queue_runner.py'
$watchdogPath = Join-Path $desktop 'workflowgym_file_queue_watchdog.py'
$watchdogCmdPath = Join-Path $desktop 'workflowgym_file_queue_watchdog.cmd'
$actionPath = Join-Path $desktop 'workflowgym_file_queue_action.json'
$resultPath = Join-Path $desktop 'workflowgym_file_queue_result.json'
$heartbeatPath = Join-Path $desktop 'workflowgym_file_queue_heartbeat.json'
$watchdogHeartbeatPath = Join-Path $desktop 'workflowgym_file_queue_watchdog_heartbeat.json'
$runnerLogPath = Join-Path $desktop 'workflowgym_file_queue_runner.log'
$watchdogLogPath = Join-Path $desktop 'workflowgym_file_queue_watchdog.log'

New-Item -ItemType Directory -Path $desktop -Force | Out-Null
Get-CimInstance Win32_Process |
  Where-Object {
    $_.CommandLine -like '*workflowgym_file_queue_runner.py*' -or
    $_.CommandLine -like '*workflowgym_file_queue_watchdog.py*'
  } |
  ForEach-Object {
    Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
  }

Remove-Item -LiteralPath $actionPath -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $resultPath -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $heartbeatPath -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $watchdogHeartbeatPath -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $runnerLogPath -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $watchdogLogPath -Force -ErrorAction SilentlyContinue

@'
import base64
import json
import os
import subprocess
import sys
import time
import traceback
from pathlib import Path

import pyautogui

pyautogui.FAILSAFE = False
desktop = Path(__file__).resolve().parent
action_path = desktop / "workflowgym_file_queue_action.json"
result_path = desktop / "workflowgym_file_queue_result.json"
heartbeat_path = desktop / "workflowgym_file_queue_heartbeat.json"
log_path = desktop / "workflowgym_file_queue_runner.log"
exec_timeout_seconds = int(os.environ.get("WORKFLOWGYM_FILE_QUEUE_EXEC_TIMEOUT_SECONDS", "45"))
runner_version = 3

def log(message):
    with log_path.open("a", encoding="utf-8") as handle:
        handle.write(time.strftime("%Y-%m-%d %H:%M:%S") + " " + message + "\n")
        handle.flush()

def write_json(path, payload):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=True, indent=2), encoding="utf-8")
    tmp.replace(path)

def safe_screen_size():
    try:
        width, height = pyautogui.size()
        return [int(width), int(height)]
    except Exception:
        return []

def safe_position():
    try:
        return list(pyautogui.position())
    except Exception:
        return []

def subprocess_creation_flags():
    if os.name != "nt":
        return 0
    flags = 0
    for name in ("CREATE_NEW_PROCESS_GROUP", "CREATE_NO_WINDOW"):
        value = getattr(subprocess, name, 0)
        if value:
            flags |= int(value)
    return flags

def run_action_script(script_path):
    return subprocess.run(
        [sys.executable, str(script_path)],
        capture_output=True,
        text=True,
        timeout=exec_timeout_seconds,
        cwd=str(desktop),
        creationflags=subprocess_creation_flags(),
    )

log("START pid=%s" % os.getpid())
while True:
    try:
        write_json(heartbeat_path, {"ok": True, "runner": "file_queue", "runner_version": runner_version, "exec_mode": "subprocess", "pid": os.getpid(), "time": time.time()})
        if action_path.exists():
            action = {}
            script_path = None
            try:
                action = json.loads(action_path.read_text(encoding="utf-8-sig"))
                action_path.unlink()
                if action.get("action") != "python":
                    result = {
                        "id": action.get("id", ""),
                        "ok": False,
                        "runner": "file_queue",
                        "status": "unknown_action",
                        "action": action,
                        "screen_size": safe_screen_size(),
                        "pid": os.getpid(),
                    }
                else:
                    script = base64.b64decode(action.get("script_b64") or "").decode("utf-8")
                    script_path = desktop / ("workflowgym_file_queue_exec_%s.py" % (action.get("id") or "action"))
                    script_path.write_text(script, encoding="utf-8")
                    try:
                        completed = run_action_script(script_path)
                        result = {
                            "id": action.get("id", ""),
                            "ok": completed.returncode == 0,
                            "runner": "file_queue",
                            "status": "executed" if completed.returncode == 0 else "error",
                            "output": completed.stdout,
                            "stderr": completed.stderr,
                            "screen_size": safe_screen_size(),
                            "position": safe_position(),
                            "pid": os.getpid(),
                        }
                        if completed.returncode != 0:
                            result["error"] = "exit_code=%s" % completed.returncode
                    except subprocess.TimeoutExpired as exc:
                        if exc.process is not None:
                            try:
                                exc.process.kill()
                            except Exception:
                                pass
                        result = {
                            "id": action.get("id", ""),
                            "ok": False,
                            "runner": "file_queue",
                            "status": "timeout",
                            "output": exc.stdout or "",
                            "stderr": exc.stderr or "",
                            "error": "action_exec_timeout seconds=%s" % exec_timeout_seconds,
                            "screen_size": safe_screen_size(),
                            "pid": os.getpid(),
                        }
                    except BaseException as exc:
                        result = {
                            "id": action.get("id", ""),
                            "ok": False,
                            "runner": "file_queue",
                            "status": "error",
                            "output": "",
                            "stderr": "",
                            "error": repr(exc),
                            "traceback": traceback.format_exc(),
                            "screen_size": safe_screen_size(),
                            "pid": os.getpid(),
                        }
                write_json(result_path, result)
                log("RESULT " + json.dumps(result, ensure_ascii=True))
            except Exception as exc:
                error = {
                    "id": action.get("id", "") if isinstance(action, dict) else "",
                    "ok": False,
                    "runner": "file_queue",
                    "status": "runner_error",
                    "error": repr(exc),
                    "traceback": traceback.format_exc(),
                    "pid": os.getpid(),
                }
                write_json(result_path, error)
                log("ERROR " + json.dumps(error, ensure_ascii=True))
            finally:
                if script_path is not None:
                    try:
                        script_path.unlink(missing_ok=True)
                    except Exception:
                        pass
        time.sleep(0.2)
    except Exception as exc:
        log("LOOP_ERROR " + repr(exc))
        time.sleep(0.2)
'@ | Set-Content -LiteralPath $runnerPath -Encoding UTF8

@'
import json
import os
import subprocess
import sys
import time
from pathlib import Path

desktop = Path(__file__).resolve().parent
runner_path = desktop / "workflowgym_file_queue_runner.py"
heartbeat_path = desktop / "workflowgym_file_queue_watchdog_heartbeat.json"
log_path = desktop / "workflowgym_file_queue_watchdog.log"

def log(message):
    with log_path.open("a", encoding="utf-8") as handle:
        handle.write(time.strftime("%Y-%m-%d %H:%M:%S") + " " + message + "\n")
        handle.flush()

def write_heartbeat():
    tmp = heartbeat_path.with_suffix(".tmp")
    tmp.write_text(json.dumps({"ok": True, "watchdog": "file_queue", "pid": os.getpid(), "time": time.time()}), encoding="utf-8")
    tmp.replace(heartbeat_path)

def runner_process_exists():
    startupinfo = subprocess.STARTUPINFO()
    startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    output = subprocess.check_output(
        ["wmic", "process", "where", "name='python.exe'", "get", "CommandLine"],
        text=True,
        errors="ignore",
        startupinfo=startupinfo,
    )
    return str(runner_path).lower() in output.lower()

log("START pid=%s" % os.getpid())
while True:
    write_heartbeat()
    try:
        if not runner_process_exists():
            subprocess.Popen([sys.executable, str(runner_path)], cwd=str(desktop))
            log("START_RUNNER " + str(runner_path))
    except Exception as exc:
        log("ERROR " + repr(exc))
    time.sleep(2)
'@ | Set-Content -LiteralPath $watchdogPath -Encoding UTF8

('@echo off' + "`r`n" + '"' + $python + '" "' + $watchdogPath + '"' + "`r`n") |
  Set-Content -LiteralPath $watchdogCmdPath -Encoding ASCII

cmd.exe /c ('schtasks /Delete /TN "' + $taskName + '" /F >nul 2>nul')
schtasks /Create /TN $taskName /SC ONLOGON /TR ('"' + $watchdogCmdPath + '"') /RU $user /RP $password /IT /RL HIGHEST /F | Out-Null
schtasks /Run /TN $taskName | Out-Null

for ($i = 0; $i -lt 60; $i++) {
  if ((Test-Path $heartbeatPath) -and (Test-Path $watchdogHeartbeatPath)) {
    Write-Output 'WORKFLOWGYM_FILE_QUEUE_WATCHDOG_READY'
    Write-Output ('WORKFLOWGYM_FILE_QUEUE_RUNNER_PATH ' + $runnerPath)
    Write-Output ('WORKFLOWGYM_FILE_QUEUE_ACTION ' + $actionPath)
    Write-Output ('WORKFLOWGYM_FILE_QUEUE_RESULT ' + $resultPath)
    Write-Output 'WORKFLOWGYM_FILE_QUEUE_RUNNER_HEARTBEAT'
    Get-Content -LiteralPath $heartbeatPath -Raw
    exit 0
  }
  Start-Sleep -Seconds 1
}
if (Test-Path $watchdogLogPath) {
  Write-Output 'WORKFLOWGYM_FILE_QUEUE_WATCHDOG_LOG'
  Get-Content -LiteralPath $watchdogLogPath -Tail 40
}
if (Test-Path $runnerLogPath) {
  Write-Output 'WORKFLOWGYM_FILE_QUEUE_RUNNER_LOG'
  Get-Content -LiteralPath $runnerLogPath -Tail 40
}
throw 'workflowgym file queue watchdog did not become ready'
""".strip()
    return (
        command.replace("__USERNAME__", ps_single_quote(username))
        .replace("__PASSWORD__", ps_single_quote(password))
    )


def display_session_needs_xorg_reboot(xrandr_output: str, target_mode: str) -> bool:
    current_mode = ""
    primary_output = ""
    for line in (xrandr_output or "").splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if " connected" in stripped and not stripped.startswith(" "):
            primary_output = stripped.split()[0]
            continue
        if line.startswith(" ") and "*" in stripped:
            mode_token = stripped.split()[0]
            if "x" in mode_token:
                current_mode = mode_token
    if not primary_output.upper().startswith("XWAYLAND"):
        return False
    if current_mode == target_mode:
        return False
    return True


def build_probe_xrandr_command(desktop_user: str, desktop_home: str, display: str, xauthority: str) -> str:
    return """#!/bin/bash
set -euo pipefail
sudo -H -u {desktop_user} env DISPLAY={display} HOME={desktop_home} XAUTHORITY={xauthority} xrandr --current 2>/dev/null || true
""".format(
        desktop_user=shlex.quote(desktop_user),
        desktop_home=shlex.quote(desktop_home),
        display=shlex.quote(display),
        xauthority=shlex.quote(xauthority),
    )


def build_set_desktop_resolution_command(
    desktop_user: str,
    desktop_home: str,
    display: str,
    xauthority: str,
    width: int = 1920,
    height: int = 1080,
) -> str:
    if width <= 0 or height <= 0:
        raise ValueError("桌面分辨率必须为正数: %sx%s" % (width, height))
    mode_name = "%sx%s" % (width, height)
    cvt_mode_name = "%sx%s_60.00" % (width, height)
    return """#!/bin/bash
set -euo pipefail
target_mode={mode_name}
cvt_mode={cvt_mode_name}

sudo -H -u {desktop_user} env DISPLAY={display} HOME={desktop_home} XAUTHORITY={xauthority} bash -lc '
set -euo pipefail
target_mode="$1"
cvt_mode="$2"
output="$(xrandr --current | awk "/ connected/{{print \\$1; exit}}")"
if [ -z "$output" ]; then
  echo "无法找到已连接的显示输出" >&2
  exit 1
fi
current_mode="$(xrandr --current | awk "/\\*/ {{print \\$1; exit}}" || true)"
echo "desktop resolution target: $target_mode"
echo "desktop resolution output: $output"
echo "desktop resolution current: ${{current_mode:-unknown}}"

if xrandr --current | grep -qE "[[:space:]]$target_mode[[:space:]]"; then
  echo "desktop resolution mode exists: $target_mode"
  xrandr --output "$output" --mode "$target_mode"
else
  echo "desktop resolution mode missing: $target_mode, fallback mode: $cvt_mode"
  if ! xrandr --current | grep -qE "^$cvt_mode[[:space:]]"; then
    if command -v cvt >/dev/null 2>&1; then
      echo "desktop resolution modeline source: cvt"
      modeline="$(cvt {width} {height} 60 | awk "/Modeline/{{print substr(\\$0, 10); exit}}")"
    elif [ "$cvt_mode" = "1920x1080_60.00" ]; then
      echo "desktop resolution modeline source: built-in"
      modeline="\"1920x1080_60.00\" 173.00 1920 2048 2248 2576 1080 1083 1088 1120 -hsync +vsync"
    else
      echo "缺少 cvt，无法生成 $target_mode modeline" >&2
      exit 1
    fi
    echo "desktop resolution newmode: $modeline"
    xrandr --newmode $modeline
  fi
  if ! xrandr --current | awk -v output="$output" -v mode="$cvt_mode" "
    $1 == output {{in_output=1; next}}
    /^[^[:space:]]/ {{in_output=0}}
    in_output && $1 == mode {{found=1}}
    END {{exit(found ? 0 : 1)}}
  "; then
    echo "desktop resolution addmode: output=$output mode=$cvt_mode"
    xrandr --addmode "$output" "$cvt_mode"
  fi
  echo "desktop resolution applying fallback mode: $cvt_mode"
  xrandr --output "$output" --mode "$cvt_mode"
fi

dimensions="$(xdpyinfo 2>/dev/null | awk "/dimensions:/ {{print \\$2; exit}}" || true)"
echo "desktop resolution set: ${{dimensions:-unknown}}"
' bash "$target_mode" "$cvt_mode"
""".format(
        desktop_user=shlex.quote(desktop_user),
        desktop_home=shlex.quote(desktop_home),
        display=shlex.quote(display),
        xauthority=shlex.quote(xauthority),
        mode_name=shlex.quote(mode_name),
        cvt_mode_name=shlex.quote(cvt_mode_name),
        width=int(width),
        height=int(height),
    )


def build_validate_pyautogui_command(desktop_user: str, desktop_home: str, display: str, xauthority: str) -> str:
    return """#!/bin/bash
set -euo pipefail
echo "desktop home: {desktop_home}"
echo "display: {display}"
echo "xauthority: {xauthority}"
ls -la {desktop_home} || true
ls -la {xauthority} || true
xdpyinfo_size="$(sudo -H -u {desktop_user} env DISPLAY={display} HOME={desktop_home} XAUTHORITY={xauthority} xdpyinfo 2>/dev/null | awk '/dimensions:/ {{print $2; exit}}' || true)"
xrandr_size="$(sudo -H -u {desktop_user} env DISPLAY={display} HOME={desktop_home} XAUTHORITY={xauthority} xrandr --current 2>/dev/null | awk '/\\*/ {{print $1; exit}}' || true)"
pyautogui_size="$(sudo -H -u {desktop_user} env DISPLAY={display} HOME={desktop_home} XAUTHORITY={xauthority} /usr/bin/python - <<'PY'
import pyautogui
print("pyautogui ready:", getattr(pyautogui, "__file__", ""))
size = pyautogui.size()
print("%sx%s" % (int(size.width), int(size.height)))
PY
)"
echo "$pyautogui_size"
pyautogui_dimensions="$(printf '%s\\n' "$pyautogui_size" | tail -n 1)"
echo "xdpyinfo dimensions: $xdpyinfo_size"
echo "xrandr dimensions: $xrandr_size"
echo "pyautogui dimensions: $pyautogui_dimensions"
reference_size="${{xdpyinfo_size:-$xrandr_size}}"
if [ -z "$reference_size" ]; then
  echo "无法通过 xdpyinfo/xrandr 获取 X11 分辨率" >&2
  exit 1
fi
if [ "$pyautogui_dimensions" != "$reference_size" ]; then
  echo "分辨率不一致，将以 shell/X11 分辨率为准: shell=$reference_size pyautogui=$pyautogui_dimensions" >&2
  echo "desktop resolution source: shell"
  echo "desktop resolution validated: $reference_size"
  exit 0
fi
echo "desktop resolution source: shell"
echo "desktop resolution validated: $reference_size"
""".format(
        desktop_user=shlex.quote(desktop_user),
        desktop_home=shlex.quote(desktop_home),
        display=shlex.quote(display),
        xauthority=shlex.quote(xauthority),
    )


def build_discover_x_session_command(desktop_user: str, desktop_home: str) -> str:
    return """#!/bin/bash
set -euo pipefail
echo "DESKTOP_USER={desktop_user}"
id {desktop_user} || true
echo "HOME_CANDIDATE={desktop_home}"
ls -la {desktop_home} || true
echo "XAUTHORITY_CANDIDATES"
find /home /run/user -name ".Xauthority" -o -name "Xauthority" 2>/dev/null || true
echo "DISPLAY_PROCESSES"
ps aux | grep -E "Xorg|Xwayland|gnome-session|gdm" | grep -v grep || true
echo "LOGINCTL_SESSIONS"
loginctl list-sessions || true
""".format(
        desktop_user=shlex.quote(desktop_user),
        desktop_home=shlex.quote(desktop_home),
    )


def build_probe_desktop_user_command() -> str:
    """Probe desktop username from the running image without changing GDM or user config."""
    return """#!/bin/bash
set -uo pipefail
validate_probe_user() {
  local candidate="$1"
  if [ -z "$candidate" ] || [ "$candidate" = "gdm" ]; then
    return 0
  fi
  if id "$candidate" >/dev/null 2>&1; then
    printf '%s' "$candidate"
  fi
}
auto_user="$(grep -E '^AutomaticLogin=' /etc/gdm3/custom.conf 2>/dev/null | head -n1 | cut -d= -f2- | tr -d ' ' || true)"
auto_user="$(validate_probe_user "$auto_user")"
session_user="$(loginctl list-sessions --no-legend 2>/dev/null | awk '$4 ~ /^seat/ || $4 == "seat0" {{print $3; exit}}' || true)"
session_user="$(validate_probe_user "$session_user")"
xauth="$(find /run/user /home -name 'Xauthority' -o -name '.Xauthority' 2>/dev/null | head -n1 || true)"
xauth_user=""
if [ -n "$xauth" ]; then
  uid="$(stat -c '%u' "$xauth" 2>/dev/null || true)"
  if [ -n "$uid" ]; then
    xauth_user="$(getent passwd "$uid" 2>/dev/null | cut -d: -f1 || true)"
  fi
fi
xauth_user="$(validate_probe_user "$xauth_user")"
home_users="$(getent passwd | awk -F: '$6 ~ /^\\/home\\// {{print $1}}' | tr '\\n' ' ' || true)"
non_root_users="$(getent passwd | awk -F: '$3 >= 1000 && $3 < 65534 {{print $1}}' | tr '\\n' ' ' || true)"
validated_users=""
for candidate in $home_users $non_root_users; do
  [ -n "$candidate" ] || continue
  case " $validated_users " in
    *" $candidate "*) continue ;;
  esac
  if id "$candidate" >/dev/null 2>&1 && [ -d "/home/$candidate" ]; then
    validated_users="$validated_users $candidate"
  fi
done
validated_users="${{validated_users# }}"
echo "WORKFLOWGYM_DESKTOP_PROBE auto_user=$auto_user"
echo "WORKFLOWGYM_DESKTOP_PROBE session_user=$session_user"
echo "WORKFLOWGYM_DESKTOP_PROBE xauth_user=$xauth_user"
echo "WORKFLOWGYM_DESKTOP_PROBE xauthority=$xauth"
echo "WORKFLOWGYM_DESKTOP_PROBE home_users=$home_users"
echo "WORKFLOWGYM_DESKTOP_PROBE non_root_users=$non_root_users"
echo "WORKFLOWGYM_DESKTOP_PROBE validated_users=$validated_users"
exit 0
"""


def parse_desktop_user_probe_fields(output: str) -> dict[str, str]:
    fields: dict[str, str] = {}
    marker = "WORKFLOWGYM_DESKTOP_PROBE "
    for line in output.splitlines():
        if marker not in line:
            continue
        kv = line.split(marker, 1)[1]
        key, _, value = kv.partition("=")
        fields[key.strip()] = value.strip()
    return fields


def _desktop_user_name_tokens(value: str) -> list[str]:
    return [item for item in value.split() if item and item != "lost+found"]


DESKTOP_USER_BLOCKLIST = frozenset(
    {
        "root",
        "gdm",
        "syslog",
        "cups-pk-helper",
        "rot",
        "roo",
        "nobody",
        "daemon",
    }
)


def _filter_desktop_user_candidates(users: list[str]) -> list[str]:
    filtered = [item for item in users if item not in DESKTOP_USER_BLOCKLIST]
    if "user" in filtered:
        return ["user"] + [item for item in filtered if item != "user"]
    return filtered


def _validated_users_from_probe(fields: dict[str, str]) -> set[str] | None:
    if "validated_users" not in fields:
        return None
    validated_users = set(_desktop_user_name_tokens(fields.get("validated_users", "")))
    validated_users.difference_update(DESKTOP_USER_BLOCKLIST)
    return validated_users


def _known_desktop_users_from_probe(fields: dict[str, str]) -> set[str]:
    validated_users = _validated_users_from_probe(fields)
    if validated_users is not None:
        return validated_users
    known_users: set[str] = set()
    for key in ("home_users", "non_root_users"):
        known_users.update(_desktop_user_name_tokens(fields.get(key, "")))
    known_users.difference_update(DESKTOP_USER_BLOCKLIST)
    return known_users


def _is_plausible_desktop_user(candidate: str, known_users: set[str]) -> bool:
    if not candidate or candidate in DESKTOP_USER_BLOCKLIST:
        return False
    if not candidate.replace("_", "").replace("-", "").isalnum():
        return False
    return candidate in known_users


def resolve_desktop_user_from_probe(output: str) -> dict[str, str]:
    fields = parse_desktop_user_probe_fields(output)
    desktop_user = ""
    desktop_user_source = "unknown"
    validated_users_set = _validated_users_from_probe(fields)
    known_users = _known_desktop_users_from_probe(fields)
    if validated_users_set is not None:
        non_root_users = _filter_desktop_user_candidates(list(validated_users_set))
        home_users = list(non_root_users)
        preferred_home_users = list(non_root_users)
    else:
        non_root_users = _filter_desktop_user_candidates(_desktop_user_name_tokens(fields.get("non_root_users", "")))
        home_users = _filter_desktop_user_candidates(_desktop_user_name_tokens(fields.get("home_users", "")))
        preferred_home_users = [item for item in home_users if item in non_root_users]

    for key in ("session_user", "xauth_user", "auto_user"):
        candidate = fields.get(key, "")
        if _is_plausible_desktop_user(candidate, known_users):
            desktop_user = candidate
            desktop_user_source = key
            break
    if not desktop_user and "user" in known_users:
        desktop_user = "user"
        desktop_user_source = "preferred_user"
    elif not desktop_user and len(preferred_home_users) == 1:
        desktop_user = preferred_home_users[0]
        desktop_user_source = "home_users_non_root"
    elif not desktop_user and preferred_home_users:
        desktop_user = preferred_home_users[0]
        desktop_user_source = "home_users_non_root_first"
    elif not desktop_user and len(non_root_users) == 1:
        desktop_user = non_root_users[0]
        desktop_user_source = "non_root_users"
    elif not desktop_user and non_root_users:
        desktop_user = non_root_users[0]
        desktop_user_source = "non_root_users_first"
    elif not desktop_user and len(home_users) == 1:
        desktop_user = home_users[0]
        desktop_user_source = "home_users"
    elif not desktop_user and home_users:
        desktop_user = home_users[0]
        desktop_user_source = "home_users_first"
    return {
        "desktop_user": desktop_user,
        "desktop_user_source": desktop_user_source,
        "xauthority": fields.get("xauthority", ""),
        "non_root_users": fields.get("non_root_users", ""),
        "probe_fields": fields,
    }


def build_unlock_desktop_command(desktop_user: str, desktop_home: str, display: str, xauthority: str) -> str:
    return """#!/bin/bash
set -euo pipefail
user_name={desktop_user}
user_id=$(id -u "$user_name")
bus_address="unix:path=/run/user/${{user_id}}/bus"
sudo -H -u "$user_name" env DBUS_SESSION_BUS_ADDRESS="$bus_address" gsettings set org.gnome.desktop.screensaver lock-enabled false || true
sudo -H -u "$user_name" env DBUS_SESSION_BUS_ADDRESS="$bus_address" gsettings set org.gnome.desktop.screensaver ubuntu-lock-on-suspend false || true
sudo -H -u "$user_name" env DBUS_SESSION_BUS_ADDRESS="$bus_address" gsettings set org.gnome.desktop.session idle-delay 0 || true
for session_id in $(loginctl list-sessions --no-legend | awk -v user="$user_name" '$3 == user {{print $1}}'); do
  sudo loginctl unlock-session "$session_id" || true
  sudo loginctl activate "$session_id" || true
done
sudo loginctl unlock-sessions || true
if command -v gnome-screensaver-command >/dev/null 2>&1; then
  sudo -H -u "$user_name" env DISPLAY={display} HOME={desktop_home} XAUTHORITY={xauthority} gnome-screensaver-command -d || true
fi
echo "desktop unlock requested"
""".format(
        desktop_user=shlex.quote(desktop_user),
        display=shlex.quote(display),
        desktop_home=shlex.quote(desktop_home),
        xauthority=shlex.quote(xauthority),
    )


def build_configure_english_desktop_command(
    desktop_user: str,
    desktop_home: str,
    display: str,
    xauthority: str,
) -> str:
    return """#!/bin/bash
set -euo pipefail
user_name={desktop_user}
user_id=$(id -u "$user_name")
bus_address="unix:path=/run/user/${{user_id}}/bus"
session_env="DISPLAY={display} HOME={desktop_home} XAUTHORITY={xauthority}"

sudo -H -u "$user_name" env $session_env setxkbmap us || true
sudo -H -u "$user_name" env $session_env ibus engine xkb:us::eng || true
sudo -H -u "$user_name" env DBUS_SESSION_BUS_ADDRESS="$bus_address" gsettings set org.gnome.desktop.input-sources sources "[('xkb', 'us')]" || true
sudo -H -u "$user_name" env DBUS_SESSION_BUS_ADDRESS="$bus_address" gsettings set org.gnome.desktop.input-sources current uint32 0 || true
if [ -f /etc/default/locale ]; then
  sudo sed -i 's/^LANG=.*/LANG=en_US.UTF-8/' /etc/default/locale || true
  grep -q '^LANG=' /etc/default/locale || echo 'LANG=en_US.UTF-8' | sudo tee -a /etc/default/locale >/dev/null
fi
echo "WORKFLOWGYM_ENGLISH_DESKTOP_CONFIGURED"
""".format(
        desktop_user=shlex.quote(desktop_user),
        display=shlex.quote(display),
        desktop_home=shlex.quote(desktop_home),
        xauthority=shlex.quote(xauthority),
    )


def is_image_bytes(value: bytes) -> bool:
    return value.startswith(b"\xff\xd8\xff") or value.startswith(b"\x89PNG\r\n\x1a\n")


def image_extension(value: bytes) -> str:
    if value.startswith(b"\xff\xd8\xff"):
        return "jpg"
    if value.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    return "img"


def read_optional_bytes(path: str) -> bytes | None:
    if not path:
        return None
    try:
        return Path(path).read_bytes()
    except Exception:
        return None


def screenshot_difference(left: bytes, right: bytes) -> float:
    if left == right:
        return 0.0
    try:
        image_module = __import__("PIL.Image", fromlist=["Image"])

        with image_module.open(BytesIO(left)) as left_image, image_module.open(BytesIO(right)) as right_image:
            left_gray = left_image.convert("L").resize((64, 36))
            right_gray = right_image.convert("L").resize((64, 36))
            left_pixels = list(left_gray.getdata())
            right_pixels = list(right_gray.getdata())
        if not left_pixels or len(left_pixels) != len(right_pixels):
            return float("inf")
        total = sum(abs(int(a) - int(b)) for a, b in zip(left_pixels, right_pixels))
        return total / len(left_pixels)
    except Exception:
        return float("inf")

