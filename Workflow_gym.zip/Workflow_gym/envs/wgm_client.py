"""WGM 胖网关客户端：Redis 模式下本地只调用高层 Session API。"""
from __future__ import annotations

import base64
import json
import os
import time
from http.client import IncompleteRead
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


DEFAULT_API_BASE = (
    os.getenv("WGM_API_BASE")
    or os.getenv("WGM_HOST")
    or "http://118.145.252.36:8080"
)
DEFAULT_TTL_SECONDS = int(os.getenv("SESSION_LEASE_TTL_SECONDS") or os.getenv("LEASE_TTL_SECONDS") or "1800")


class WgmClientError(RuntimeError):
    def __init__(self, message: str, *, status: int | None = None, payload: dict | None = None):
        super().__init__(message)
        self.status = status
        self.payload = payload or {}


def _is_flow_limit_error(exc: BaseException) -> bool:
    if isinstance(exc, WgmClientError) and exc.status == 429:
        return True
    text = str(exc or "")
    return "FlowLimitExceeded" in text or "Too Many Requests" in text or "(429)" in text


def _wgm_retry_sleep_seconds(exc: BaseException, attempt: int, retry_base: float) -> float:
    if _is_flow_limit_error(exc):
        return max(0.0, float(os.getenv("WGM_SCREENSHOT_FLOW_LIMIT_RETRY_SECONDS") or "10"))
    return min(30.0, retry_base * attempt)


def _is_transient_wgm_error(exc: BaseException) -> bool:
    if isinstance(exc, IncompleteRead):
        return True
    if isinstance(exc, WgmClientError) and exc.status in (429, 502, 503, 504):
        return True
    if _is_flow_limit_error(exc):
        return True
    text = str(exc or "").lower()
    return any(
        token in text
        for token in (
            "504",
            "502",
            "503",
            "429",
            "flowlimitexceeded",
            "too many requests",
            "gateway timeout",
            "timed out",
            "timeout",
            "incompleteread",
            "incomplete read",
            "temporarily unavailable",
            "connection reset",
            "remote end closed",
            "broken pipe",
        )
    )


def wgm_screenshot_format() -> str:
    """stream=二进制流式 PNG（默认）；base64=旧版 JSON screenshot_base64。"""
    return str(os.getenv("WGM_SCREENSHOT_FORMAT") or "stream").strip().lower()


def wgm_screenshot_stream_path(lease_id: str) -> str:
    template = str(
        os.getenv("WGM_SCREENSHOT_STREAM_PATH")
        or "/api/v1/sessions/{lease_id}/screenshot/stream"
    ).strip()
    return template.replace("{lease_id}", str(lease_id or "").strip())


def _is_image_bytes(value: bytes) -> bool:
    return value.startswith(b"\xff\xd8\xff") or value.startswith(b"\x89PNG\r\n\x1a\n")


def _screenshot_body(lease_id: str, ttl_seconds: int | None, client: "WgmClient") -> dict[str, Any]:
    return {"ttl_seconds": int(ttl_seconds if ttl_seconds is not None else client.ttl_seconds)}


def _decode_screenshot_json_payload(data: dict[str, Any]) -> bytes:
    shot = str((data or {}).get("screenshot_base64") or "").strip()
    if not shot:
        raise WgmClientError("empty screenshot_base64 from WGM")
    if "," in shot and shot.lower().startswith("data:"):
        shot = shot.split(",", 1)[1]
    try:
        raw = base64.b64decode(shot)
    except Exception as exc:
        raise WgmClientError("invalid screenshot_base64 from WGM: %s" % exc) from exc
    if not raw:
        raise WgmClientError("empty screenshot bytes from base64")
    return raw


def _http_error_message(status: int, raw: bytes) -> str:
    text = raw.decode("utf-8", errors="replace") if raw else ""
    try:
        payload = json.loads(text) if text else {}
    except json.JSONDecodeError:
        payload = {}
    if isinstance(payload, dict):
        message = str(payload.get("message") or payload.get("error") or "").strip()
        if message:
            return message
    if text.strip():
        return text.strip()[:500]
    return "http %s" % status


class WgmClient:
    """本地收敛调用面：

    1. acquire_and_prepare + wait_job
    2. ensure_ready
    3. run_command
    4. run_action (WGM → RunCommand → VM 127.0.0.1 Flask /action)
    5. download_file (optional: Flask /file product extract)
    6. screenshot / screenshot_bytes（stream 或 legacy base64）
    7. release
    （模型推理仍在本地）
    """

    def __init__(
        self,
        api_base: str | None = None,
        api_token: str | None = None,
        ttl_seconds: int = DEFAULT_TTL_SECONDS,
        timeout_seconds: float = 60.0,
    ):
        self.api_base = (api_base or DEFAULT_API_BASE).rstrip("/")
        token = api_token if api_token is not None else (os.getenv("WGM_TOKEN") or "")
        self.api_token = str(token).strip()
        self.ttl_seconds = max(60, int(ttl_seconds or DEFAULT_TTL_SECONDS))
        self.timeout_seconds = float(timeout_seconds)
        if not self.api_token:
            raise ValueError("WgmClient requires WGM_TOKEN / api_token")

    def acquire_and_prepare(
        self,
        *,
        image_id: str = "",
        os_type: str = "",
        instance_ids: list[str] | None = None,
        ttl_seconds: int | None = None,
        skip_replace: bool = False,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "ttl_seconds": int(ttl_seconds if ttl_seconds is not None else self.ttl_seconds),
            "skip_replace": bool(skip_replace),
        }
        if image_id:
            body["image_id"] = image_id
        if os_type:
            body["os_type"] = os_type
        if instance_ids:
            body["instance_ids"] = list(instance_ids)
        data = self._request_json("POST", "/api/v1/sessions/acquire-and-prepare", body, accept_statuses=(200, 202))
        return data

    def get_job(self, job_id: str) -> dict[str, Any]:
        return self._request_json("GET", f"/api/v1/sessions/jobs/{job_id}")

    def wait_job(
        self,
        job_id: str,
        *,
        timeout_seconds: float = 1200.0,
        poll_seconds: float = 5.0,
        should_abort=None,
    ) -> dict[str, Any]:
        deadline = time.time() + float(timeout_seconds)
        last: dict[str, Any] = {}
        last_phase = ""
        last_log_len = 0
        while time.time() < deadline:
            if callable(should_abort) and should_abort():
                self._abort_prepare_job(job_id, last)
                raise WgmClientError(
                    f"prepare job cancelled: {job_id}",
                    payload=last or {"job_id": job_id, "status": "cancelled"},
                )
            last = self.get_job(job_id)
            status = str(last.get("status") or "")
            phase = str(last.get("phase") or "")
            step = last.get("step")
            step_total = last.get("step_total")
            message = str(last.get("message") or "")
            logs = last.get("logs") if isinstance(last.get("logs"), list) else []
            if phase != last_phase or len(logs) > last_log_len:
                progress = f"step={step}/{step_total}" if step is not None else "step=?"
                print(f"[wgm] job={job_id} status={status} phase={phase} {progress} {message}".rstrip())
                for entry in logs[last_log_len:]:
                    if not isinstance(entry, dict):
                        continue
                    print(
                        f"[wgm]   log[{entry.get('level')}] "
                        f"{entry.get('phase')}: {entry.get('message')}"
                    )
                last_phase = phase
                last_log_len = len(logs)
            if status == "succeeded":
                result = last.get("result") or {}
                merged = dict(result)
                merged.setdefault("lease_id", last.get("lease_id") or result.get("lease_id"))
                merged.setdefault("instance_id", last.get("instance_id") or result.get("instance_id"))
                merged["job_id"] = job_id
                merged["status"] = "succeeded"
                merged["phase"] = phase or "done"
                merged["warnings"] = last.get("warnings") or []
                return merged
            if status in ("failed", "cancelled"):
                failed_phase = last.get("failed_phase") or phase
                raise WgmClientError(
                    f"prepare job {job_id} {status} at {failed_phase}: {last.get('error') or 'unknown'}",
                    payload=last,
                )
            time.sleep(max(1.0, float(poll_seconds)))
        raise WgmClientError(f"prepare job timeout: {job_id}", payload=last)

    def acquire_and_prepare_wait(self, **kwargs) -> dict[str, Any]:
        timeout = float(kwargs.pop("wait_timeout_seconds", None) or os.getenv("WGM_PREPARE_TIMEOUT_SECONDS") or 1200)
        poll = float(kwargs.pop("poll_seconds", None) or os.getenv("WGM_JOB_POLL_SECONDS") or 5)
        should_abort = kwargs.pop("should_abort", None)
        submitted = self.acquire_and_prepare(**kwargs)
        job_id = str(submitted.get("job_id") or "")
        if not job_id:
            raise WgmClientError("acquire-and-prepare missing job_id", payload=submitted)
        return self.wait_job(
            job_id,
            timeout_seconds=timeout,
            poll_seconds=poll,
            should_abort=should_abort,
        )

    def cancel_job(self, job_id: str) -> dict[str, Any]:
        return self._request_json("POST", f"/api/v1/sessions/jobs/{job_id}/cancel", {})

    def release(self, lease_id: str) -> dict[str, Any]:
        return self._request_json("POST", f"/api/v1/sessions/{lease_id}/release", {})

    def release_all(self) -> dict[str, Any]:
        """释放当前 token 用户占用的全部实例。"""
        return self._request_json("POST", "/api/v1/sessions/release-all", {})

    def _abort_prepare_job(self, job_id: str, last: dict[str, Any] | None = None) -> None:
        """取消当前 prepare job，并只释放该 job 已拿到的 lease（不 release-all）。"""
        print(f"[wgm] abort prepare job={job_id}, cancelling (no release-all)")
        lease_id = str((last or {}).get("lease_id") or "")
        try:
            cancelled = self.cancel_job(job_id)
            if not lease_id:
                lease_id = str((cancelled or {}).get("lease_id") or "")
        except Exception as exc:
            print(f"[wgm] cancel_job failed: {exc}")
        if lease_id:
            try:
                self.release(lease_id)
                print(f"[wgm] released lease after abort lease_id={lease_id}")
            except Exception as release_exc:
                print(f"[wgm] release after abort failed: {release_exc}")

    def renew(self, lease_id: str, ttl_seconds: int | None = None) -> dict[str, Any]:
        body = {"ttl_seconds": int(ttl_seconds if ttl_seconds is not None else self.ttl_seconds)}
        return self._request_json("POST", f"/api/v1/sessions/{lease_id}/renew", body)

    def ensure_ready(
        self,
        lease_id: str,
        ttl_seconds: int | None = None,
        *,
        allow_heal: bool = False,
        wait_timeout_seconds: float | None = None,
        poll_seconds: float | None = None,
    ) -> dict[str, Any]:
        """调用网关 ensure-ready。

        API Gateway 对同步请求常有 ~30s 限制；网关侧若做 Flask/桌面自愈极易 504。
        默认不触发同步自愈（heal=false），并在客户端轮询重试 502/504/未就绪。
        """
        body = {
            "ttl_seconds": int(ttl_seconds if ttl_seconds is not None else self.ttl_seconds),
            "heal": bool(allow_heal),
        }
        wait_total = float(
            wait_timeout_seconds
            if wait_timeout_seconds is not None
            else (os.getenv("WGM_ENSURE_READY_WAIT_SECONDS") or "300")
        )
        poll = float(
            poll_seconds
            if poll_seconds is not None
            else (os.getenv("WGM_ENSURE_READY_POLL_SECONDS") or "5")
        )
        http_timeout = float(
            os.getenv("WGM_ENSURE_READY_TIMEOUT_SECONDS")
            or max(float(self.timeout_seconds), 90.0)
        )
        deadline = time.time() + max(1.0, wait_total)
        last: dict[str, Any] | None = None
        last_error: Exception | None = None
        attempt = 0
        while True:
            attempt += 1
            try:
                last = self._request_json(
                    "POST",
                    f"/api/v1/sessions/{lease_id}/ensure-ready",
                    body,
                    accept_statuses=(200, 409),
                    timeout_seconds=http_timeout,
                )
                last_error = None
                if bool(last.get("ready")):
                    return last
            except WgmClientError as exc:
                last_error = exc
                if not _is_transient_wgm_error(exc):
                    raise
            remaining = deadline - time.time()
            if remaining <= 0:
                break
            time.sleep(min(max(0.5, poll), remaining))
        if last is not None:
            return last
        assert last_error is not None
        raise last_error

    def run_command(
        self,
        lease_id: str,
        command: str,
        *,
        timeout: int = 120,
        command_type: str = "",
        username: str = "",
        ttl_seconds: int | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "command": command,
            "timeout": int(timeout),
            "ttl_seconds": int(ttl_seconds if ttl_seconds is not None else self.ttl_seconds),
        }
        if command_type:
            body["command_type"] = command_type
        if username:
            body["username"] = username
        return self._request_json("POST", f"/api/v1/sessions/{lease_id}/run-command", body)

    def run_action(
        self,
        lease_id: str,
        *,
        script: str = "",
        script_b64: str = "",
        action_id: str = "",
        source: str = "workflowgym_pyautogui_wrapper",
        timeout: int = 120,
        ttl_seconds: int | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "action": "python",
            "timeout": int(timeout),
            "ttl_seconds": int(ttl_seconds if ttl_seconds is not None else self.ttl_seconds),
            "source": source or "workflowgym_pyautogui_wrapper",
        }
        if action_id:
            body["id"] = action_id
        if script_b64:
            body["script_b64"] = script_b64
        elif script:
            body["script"] = script
        else:
            raise ValueError("run_action requires script or script_b64")
        # Action may wait on flask exec; keep HTTP client timeout above action timeout.
        return self._request_json(
            "POST",
            f"/api/v1/sessions/{lease_id}/run-action",
            body,
            timeout_seconds=max(float(self.timeout_seconds), float(timeout) + 30.0),
        )

    def download_file(
        self,
        lease_id: str,
        *,
        path: str = "",
        paths: list[str] | None = None,
        timeout: int = 120,
        ttl_seconds: int | None = None,
    ) -> dict[str, Any]:
        """经 WGM 代理拉取实例 Flask /file，返回 content_b64。"""
        body: dict[str, Any] = {
            "timeout": int(timeout),
            "ttl_seconds": int(ttl_seconds if ttl_seconds is not None else self.ttl_seconds),
        }
        if path:
            body["path"] = path
        if paths:
            body["paths"] = list(paths)
        if not body.get("path") and not body.get("paths"):
            raise ValueError("download_file requires path or paths")
        return self._request_json(
            "POST",
            f"/api/v1/sessions/{lease_id}/download-file",
            body,
            timeout_seconds=max(float(self.timeout_seconds), float(timeout) + 30.0),
        )

    def screenshot(self, lease_id: str, ttl_seconds: int | None = None) -> dict[str, Any]:
        """拉取控制台截图（JSON 包装，兼容旧调用）。

        默认 ``WGM_SCREENSHOT_FORMAT=stream`` 时内部走 ``screenshot_bytes``，
        仅在 ``base64`` 模式下仍请求 JSON ``screenshot_base64``。
        """
        if wgm_screenshot_format() in ("base64", "json"):
            return self._screenshot_json(lease_id, ttl_seconds)
        raw = self.screenshot_bytes(lease_id, ttl_seconds)
        return {
            "format": "stream",
            "content_type": "image/png",
            "size": len(raw),
            "lease_id": lease_id,
        }

    def screenshot_bytes(self, lease_id: str, ttl_seconds: int | None = None) -> bytes:
        """拉取控制台截图 PNG/JPEG 原始字节（流式 HTTP body，无 base64 JSON）。"""
        if wgm_screenshot_format() in ("base64", "json"):
            data = self._screenshot_json(lease_id, ttl_seconds)
            return _decode_screenshot_json_payload(data)

        lease_id = str(lease_id or "").strip()
        if not lease_id:
            raise ValueError("screenshot_bytes requires lease_id")

        body = _screenshot_body(lease_id, ttl_seconds, self)
        http_timeout = float(
            os.getenv("WGM_SCREENSHOT_TIMEOUT_SECONDS")
            or max(float(self.timeout_seconds), 180.0)
        )
        max_attempts = max(1, int(os.getenv("WGM_SCREENSHOT_MAX_ATTEMPTS") or "5"))
        retry_base = float(os.getenv("WGM_SCREENSHOT_RETRY_BASE_SECONDS") or "2")
        allow_base64_fallback = str(
            os.getenv("WGM_SCREENSHOT_FALLBACK_BASE64") or "true"
        ).strip().lower() in ("1", "true", "yes", "on")

        last_error: Exception | None = None
        for attempt in range(1, max_attempts + 1):
            try:
                return self._screenshot_bytes_once(lease_id, body, http_timeout)
            except (WgmClientError, IncompleteRead, OSError, TimeoutError) as exc:
                last_error = exc if isinstance(exc, Exception) else WgmClientError(str(exc))
                if (
                    allow_base64_fallback
                    and attempt == 1
                    and isinstance(exc, WgmClientError)
                    and exc.status in (404, 405, 501)
                ):
                    try:
                        return _decode_screenshot_json_payload(
                            self._screenshot_json(lease_id, ttl_seconds)
                        )
                    except Exception:
                        pass
                if not _is_transient_wgm_error(exc) or attempt >= max_attempts:
                    if isinstance(exc, WgmClientError):
                        raise
                    raise WgmClientError(str(exc)) from exc
                sleep_seconds = _wgm_retry_sleep_seconds(exc, attempt, retry_base)
                print(
                    "[wgm] screenshot stream retry lease_id=%s attempt=%s/%s sleep=%.1fs error=%s"
                    % (lease_id, attempt, max_attempts, sleep_seconds, exc),
                    flush=True,
                )
                if sleep_seconds > 0:
                    time.sleep(sleep_seconds)
        assert last_error is not None
        raise last_error

    def _screenshot_bytes_once(
        self,
        lease_id: str,
        body: dict[str, Any],
        http_timeout: float,
    ) -> bytes:
        stream_path = wgm_screenshot_stream_path(lease_id)
        try:
            raw = self._request_binary(
                "POST",
                stream_path,
                body,
                accept="image/png,image/jpeg,application/octet-stream",
                timeout_seconds=http_timeout,
            )
            if _is_image_bytes(raw):
                return raw
            raise WgmClientError(
                "screenshot stream returned non-image body (%s bytes)" % len(raw or b"")
            )
        except WgmClientError as exc:
            if exc.status not in (404, 405):
                raise
        raw = self._request_binary(
            "POST",
            f"/api/v1/sessions/{lease_id}/screenshot",
            body,
            accept="image/png,image/jpeg,application/octet-stream",
            timeout_seconds=http_timeout,
        )
        if _is_image_bytes(raw):
            return raw
        raise WgmClientError(
            "screenshot Accept-image response is not PNG/JPEG (%s bytes)" % len(raw or b"")
        )

    def _screenshot_json(self, lease_id: str, ttl_seconds: int | None = None) -> dict[str, Any]:
        """旧版：JSON 内嵌 screenshot_base64（大包易 IncompleteRead）。"""
        body = _screenshot_body(lease_id, ttl_seconds, self)
        http_timeout = float(
            os.getenv("WGM_SCREENSHOT_TIMEOUT_SECONDS")
            or max(float(self.timeout_seconds), 180.0)
        )
        max_attempts = max(1, int(os.getenv("WGM_SCREENSHOT_MAX_ATTEMPTS") or "5"))
        retry_base = float(os.getenv("WGM_SCREENSHOT_RETRY_BASE_SECONDS") or "2")
        last_error: Exception | None = None
        for attempt in range(1, max_attempts + 1):
            try:
                data = self._request_json(
                    "POST",
                    f"/api/v1/sessions/{lease_id}/screenshot",
                    body,
                    timeout_seconds=http_timeout,
                )
                if not str((data or {}).get("screenshot_base64") or "").strip():
                    raise WgmClientError("empty screenshot_base64 from WGM")
                return data
            except (WgmClientError, IncompleteRead, OSError, TimeoutError) as exc:
                last_error = exc if isinstance(exc, Exception) else WgmClientError(str(exc))
                if not _is_transient_wgm_error(exc) or attempt >= max_attempts:
                    if isinstance(exc, WgmClientError):
                        raise
                    raise WgmClientError(str(exc)) from exc
                sleep_seconds = _wgm_retry_sleep_seconds(exc, attempt, retry_base)
                print(
                    "[wgm] screenshot base64 retry lease_id=%s attempt=%s/%s sleep=%.1fs error=%s"
                    % (lease_id, attempt, max_attempts, sleep_seconds, exc),
                    flush=True,
                )
                if sleep_seconds > 0:
                    time.sleep(sleep_seconds)
        assert last_error is not None
        raise last_error

    def _request_binary(
        self,
        method: str,
        path: str,
        body: dict[str, Any] | None = None,
        *,
        accept: str = "image/png",
        accept_statuses: tuple[int, ...] = (200,),
        timeout_seconds: float | None = None,
    ) -> bytes:
        url = f"{self.api_base}{path}"
        headers = {
            "Authorization": f"Bearer {self.api_token}",
            "Accept": accept,
        }
        data = None
        if body is not None and method.upper() != "GET":
            headers["Content-Type"] = "application/json"
            data = json.dumps(body).encode("utf-8")
        request = Request(url, data=data, headers=headers, method=method.upper())
        wait = float(self.timeout_seconds if timeout_seconds is None else timeout_seconds)
        try:
            with urlopen(request, timeout=wait) as response:
                status = getattr(response, "status", 200)
                content_type = str(response.headers.get("Content-Type") or "").lower()
                raw = response.read()
        except HTTPError as exc:
            status = exc.code
            try:
                raw = exc.read()
            except Exception:
                raw = b""
            if status not in accept_statuses and status not in (200, 202):
                message = _http_error_message(status, raw)
                raise WgmClientError(message, status=status) from exc
            content_type = str(exc.headers.get("Content-Type") or "").lower() if exc.headers else ""
        except IncompleteRead as exc:
            raise WgmClientError(f"IncompleteRead: {exc}") from exc
        except (URLError, TimeoutError, OSError) as exc:
            raise WgmClientError(str(exc)) from exc
        else:
            if status not in accept_statuses and status not in (200, 202):
                message = _http_error_message(status, raw)
                raise WgmClientError(message, status=status)

        if "json" in content_type:
            try:
                payload = json.loads(raw.decode("utf-8") if raw else "{}")
            except json.JSONDecodeError as exc:
                raise WgmClientError("invalid JSON screenshot response") from exc
            if isinstance(payload, dict):
                nested = payload.get("data")
                if isinstance(nested, dict):
                    payload = nested
                return _decode_screenshot_json_payload(payload)
            raise WgmClientError("invalid JSON screenshot response")
        if not raw:
            raise WgmClientError("empty screenshot body")
        return raw

    def _request_json(
        self,
        method: str,
        path: str,
        body: dict[str, Any] | None = None,
        *,
        accept_statuses: tuple[int, ...] = (200,),
        timeout_seconds: float | None = None,
    ) -> dict[str, Any]:
        url = f"{self.api_base}{path}"
        headers = {
            "Authorization": f"Bearer {self.api_token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        data = None
        if body is not None and method.upper() != "GET":
            data = json.dumps(body).encode("utf-8")
        request = Request(url, data=data, headers=headers, method=method.upper())
        wait = float(self.timeout_seconds if timeout_seconds is None else timeout_seconds)
        try:
            with urlopen(request, timeout=wait) as response:
                status = getattr(response, "status", 200)
                raw = response.read().decode("utf-8")
                payload = json.loads(raw) if raw else {}
        except HTTPError as exc:
            status = exc.code
            try:
                raw = exc.read().decode("utf-8")
                payload = json.loads(raw) if raw else {"message": str(exc)}
            except Exception:
                payload = {"message": str(exc)}
            if status not in accept_statuses and status not in (200, 202):
                raise WgmClientError(
                    str(payload.get("message") or payload.get("error") or exc),
                    status=status,
                    payload=payload if isinstance(payload, dict) else {},
                )
        except IncompleteRead as exc:
            raise WgmClientError(f"IncompleteRead: {exc}") from exc
        except (URLError, TimeoutError, json.JSONDecodeError, OSError) as exc:
            raise WgmClientError(str(exc)) from exc

        if not isinstance(payload, dict):
            raise WgmClientError("invalid JSON response", status=status)
        if status not in accept_statuses and status not in (200, 202):
            raise WgmClientError(
                str(payload.get("message") or payload.get("error") or f"http {status}"),
                status=status,
                payload=payload,
            )
        data = payload.get("data")
        return data if isinstance(data, dict) else payload
