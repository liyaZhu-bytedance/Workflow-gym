from __future__ import annotations

import json
import threading
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from ..records import now_text
from .volcengine_env import (
    VolcengineEnv,
    command_decoded_output,
    instance_display_name,
    instance_image_id,
    instance_os_type,
    instance_platform_from_name,
    platform_to_os_type_label,
)


def env_exception_log_path(output_root: str) -> Path:
    return Path(output_root) / "env_exception.log"


DEFAULT_DISCOVER_PROBE_MAX_WORKERS = 8


def append_env_exception(
    log_path: str | Path,
    record: dict[str, Any],
    *,
    log_lock: threading.Lock | None = None,
) -> None:
    if log_lock is None:
        _append_env_exception_unlocked(log_path, record)
        return
    with log_lock:
        _append_env_exception_unlocked(log_path, record)


def _append_env_exception_unlocked(log_path: str | Path, record: dict[str, Any]) -> None:
    path = Path(log_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = dict(record)
    payload.setdefault("timestamp", now_text())
    with path.open("a", encoding="utf-8") as file_obj:
        file_obj.write(json.dumps(payload, ensure_ascii=False) + "\n")


def resolve_probe_max_workers(instance_count: int, max_workers: int) -> int:
    if instance_count <= 0:
        return 1
    return max(1, min(max_workers, instance_count))


def ensure_discovered_instance_running(
    env: VolcengineEnv,
    item: dict[str, Any],
    log_path: str | Path,
    *,
    log_lock: threading.Lock | None = None,
) -> tuple[str | None, dict[str, Any] | None]:
    instance_id = str(item.get("InstanceId") or item.get("instance_id") or "").strip()
    if not instance_id:
        return None, None

    record = build_instance_validation_record(item)
    try:
        instance_platform_from_name(item)
    except ValueError as exc:
        record.update(
            {
                "status": "failed",
                "stage": "name_parse",
                "message": "%s" % exc,
                "traceback": traceback.format_exc(),
            }
        )
        append_env_exception(log_path, record, log_lock=log_lock)
        return None, None

    if env.dry_run:
        return instance_id, item

    try:
        status = env.ensure_instance_running(instance_id)
        updated_item = dict(item)
        updated_item["Status"] = status
        updated_item["status"] = status
        return instance_id, updated_item
    except Exception as exc:
        record.update(
            {
                "status": "failed",
                "stage": "start_instance",
                "message": "%s" % exc,
                "traceback": traceback.format_exc(),
            }
        )
        append_env_exception(log_path, record, log_lock=log_lock)
        return None, None


def validate_single_discovered_instance(
    env: VolcengineEnv,
    item: dict[str, Any],
    log_path: str | Path,
    *,
    log_lock: threading.Lock | None = None,
) -> tuple[str | None, str | None]:
    instance_id = str(item.get("InstanceId") or item.get("instance_id") or "").strip()
    if not instance_id:
        return None, None

    record = build_instance_validation_record(item)
    try:
        name_platform = instance_platform_from_name(item)
    except ValueError as exc:
        record.update(
            {
                "status": "failed",
                "stage": "name_parse",
                "message": "%s" % exc,
                "traceback": traceback.format_exc(),
            }
        )
        append_env_exception(log_path, record, log_lock=log_lock)
        return None, None

    record["name_platform"] = name_platform
    record["expected_probe_platform"] = name_platform
    record["instance_os_type"] = instance_os_type(item) or platform_to_os_type_label(name_platform)
    if env.dry_run:
        return instance_id, name_platform

    try:
        probe_result = env.probe_cloud_assistant_platform(instance_id, name_platform)
        record["probe_output"] = command_decoded_output(probe_result)[:1000]
        return instance_id, name_platform
    except Exception as exc:
        record.update(
            {
                "status": "failed",
                "stage": "runcommand_probe",
                "message": "%s" % exc,
                "traceback": traceback.format_exc(),
            }
        )
        append_env_exception(log_path, record, log_lock=log_lock)
        return None, None


def validate_discovered_instances(
    env: VolcengineEnv,
    instances: list[dict[str, Any]],
    log_path: str | Path,
    *,
    max_workers: int = DEFAULT_DISCOVER_PROBE_MAX_WORKERS,
) -> tuple[list[str], dict[str, str]]:
    """Start eligible instances, then validate platform + RunCommand probe."""
    validated_ids: list[str] = []
    platform_by_instance: dict[str, str] = {}
    if not instances:
        return validated_ids, platform_by_instance

    probe_workers = resolve_probe_max_workers(len(instances), max_workers)
    ready_instances: list[dict[str, Any]] = []
    log_lock = threading.Lock() if probe_workers > 1 else None

    def collect_ready_instances(executor_submit) -> None:
        futures = [executor_submit(item) for item in instances]
        for future in as_completed(futures):
            instance_id, updated_item = future.result()
            if instance_id and updated_item:
                ready_instances.append(updated_item)

    if probe_workers <= 1:
        for item in instances:
            instance_id, updated_item = ensure_discovered_instance_running(env, item, log_path)
            if instance_id and updated_item:
                ready_instances.append(updated_item)
    else:
        with ThreadPoolExecutor(max_workers=probe_workers) as executor:
            collect_ready_instances(
                lambda item: executor.submit(
                    ensure_discovered_instance_running,
                    env,
                    item,
                    log_path,
                    log_lock=log_lock,
                )
            )

    if probe_workers <= 1:
        for item in ready_instances:
            instance_id, name_platform = validate_single_discovered_instance(env, item, log_path)
            if not instance_id or not name_platform:
                continue
            validated_ids.append(instance_id)
            platform_by_instance[instance_id] = name_platform
        return validated_ids, platform_by_instance

    with ThreadPoolExecutor(max_workers=probe_workers) as executor:
        futures = {
            executor.submit(
                validate_single_discovered_instance,
                env,
                item,
                log_path,
                log_lock=log_lock,
            ): item
            for item in ready_instances
        }
        for future in as_completed(futures):
            instance_id, name_platform = future.result()
            if not instance_id or not name_platform:
                continue
            validated_ids.append(instance_id)
            platform_by_instance[instance_id] = name_platform
    return validated_ids, platform_by_instance


def build_instance_validation_record(instance: dict[str, Any]) -> dict[str, Any]:
    instance_id = str(instance.get("InstanceId") or instance.get("instance_id") or "").strip()
    instance_name = instance_display_name(instance)
    return {
        "instance_id": instance_id,
        "instance_name": instance_name,
        "image_id": instance_image_id(instance),
        "instance_status": str(instance.get("Status") or instance.get("status") or ""),
        "zone_id": str(instance.get("ZoneId") or instance.get("zone_id") or ""),
        "described_os_type": instance_os_type(instance),
    }


def summarize_validated_pool(platform_by_instance: dict[str, str]) -> dict[str, int]:
    summary = {"windows": 0, "ubuntu": 0}
    for platform in platform_by_instance.values():
        if platform in summary:
            summary[platform] += 1
    return summary
