from __future__ import annotations

import os
import time
from typing import Any


def create_vpc_api(region: str):
    import volcenginesdkcore
    import volcenginesdkvpc

    configuration = volcenginesdkcore.Configuration()
    configuration.ak = os.getenv("AK")
    configuration.sk = os.getenv("SK")
    configuration.region = region
    volcenginesdkcore.Configuration.set_default(configuration)
    return volcenginesdkvpc.VPCApi()


def allocate_eip_address(api_instance: Any, billing_type: int = 2, project_name: str = "default") -> dict[str, Any]:
    import volcenginesdkvpc

    request = volcenginesdkvpc.AllocateEipAddressRequest(
        billing_type=billing_type,
        project_name=project_name,
    )
    response = api_instance.allocate_eip_address(request)
    response_data = to_plain_dict(response)
    result = get_result_payload(response_data)
    allocation_id = first_value(result, "AllocationId", "allocation_id")
    if not allocation_id:
        raise ValueError("AllocateEipAddress 响应中没有 AllocationId: %s" % response_data)
    return {
        "allocation_id": allocation_id,
        "response": response_data,
    }


def list_available_eip_addresses(api_instance: Any, project_name: str = "default", limit: int = 100) -> list[dict[str, Any]]:
    eip_addresses = describe_eip_addresses(api_instance, project_name=project_name, limit=limit)
    available = []
    for item in eip_addresses:
        if not isinstance(item, dict):
            continue
        status = str(first_value(item, "Status", "status") or "")
        instance_id = first_value(item, "InstanceId", "instance_id") or ""
        allocation_id = first_value(item, "AllocationId", "allocation_id") or ""
        if allocation_id and status.lower() == "available" and not instance_id:
            available.append(item)
    return available


def find_available_eip_address(api_instance: Any, project_name: str = "default") -> dict[str, Any] | None:
    eip_addresses = list_available_eip_addresses(api_instance, project_name=project_name, limit=100)
    for item in eip_addresses:
        allocation_id = first_value(item, "AllocationId", "allocation_id") or ""
        if allocation_id:
            return {"allocation_id": allocation_id, "response": {"Result": {"EipAddresses": eip_addresses}}, "eip": item}
    return None


def find_associated_eip_addresses(api_instance: Any, instance_id: str, project_name: str = "default") -> list[dict[str, Any]]:
    eip_addresses = describe_eip_addresses(api_instance, project_name=project_name, limit=100)
    matches = []
    for item in eip_addresses:
        if not isinstance(item, dict):
            continue
        allocation_id = first_value(item, "AllocationId", "allocation_id") or ""
        attached_instance_id = first_value(item, "InstanceId", "instance_id") or ""
        if allocation_id and attached_instance_id == instance_id:
            matches.append({"allocation_id": allocation_id, "response": {"Result": {"EipAddresses": eip_addresses}}, "eip": item})
    return matches


def describe_eip_addresses(api_instance: Any, project_name: str = "default", limit: int = 100) -> list[dict[str, Any]]:
    import volcenginesdkvpc

    eip_addresses: list[dict[str, Any]] = []
    next_token = ""
    while len(eip_addresses) < limit:
        request_kwargs: dict[str, Any] = {"max_results": min(100, max(1, limit - len(eip_addresses)))}
        if project_name:
            request_kwargs["project_name"] = project_name
        if next_token:
            request_kwargs["next_token"] = next_token
        try:
            request = volcenginesdkvpc.DescribeEipAddressesRequest(**request_kwargs)
        except TypeError:
            request_kwargs.pop("max_results", None)
            request_kwargs.pop("next_token", None)
            request_kwargs["page_number"] = 1
            request_kwargs["page_size"] = min(100, max(1, limit))
            request = volcenginesdkvpc.DescribeEipAddressesRequest(**request_kwargs)
        response = api_instance.describe_eip_addresses(request)
        response_data = to_plain_dict(response)
        result = get_result_payload(response_data)
        page_items = first_value(result, "EipAddresses", "eip_addresses") or []
        eip_addresses.extend(item for item in page_items if isinstance(item, dict))
        next_token = first_value(result, "NextToken", "next_token") or ""
        if not next_token:
            break
    return eip_addresses[:limit]


def prepare_eip_allocations(
    region: str,
    required_count: int,
    billing_type: int = 2,
    project_name: str = "default",
) -> list[dict[str, Any]]:
    api_instance = create_vpc_api(region)
    required_count = max(0, int(required_count))
    if required_count <= 0:
        return []

    prepared: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in list_available_eip_addresses(api_instance, project_name=project_name, limit=max(100, required_count)):
        allocation_id = first_value(item, "AllocationId", "allocation_id") or ""
        if not allocation_id or allocation_id in seen:
            continue
        seen.add(allocation_id)
        prepared.append({"allocation_id": allocation_id, "eip": item, "reused_existing_eip": True})
        if len(prepared) >= required_count:
            return prepared

    while len(prepared) < required_count:
        allocation = allocate_eip_address(api_instance, billing_type=billing_type, project_name=project_name)
        allocation_id = allocation["allocation_id"]
        eip = wait_for_eip_available(api_instance, allocation_id, project_name=project_name)
        prepared.append(
            {
                "allocation_id": allocation_id,
                "eip": eip,
                "reused_existing_eip": False,
                "allocate_response": allocation["response"],
            }
        )
    return prepared


def wait_for_eip_available(api_instance: Any, allocation_id: str, project_name: str = "default") -> dict[str, Any] | None:
    timeout_seconds = float(os.getenv("VOLCENGINE_EIP_ALLOCATE_WAIT_TIMEOUT_SECONDS", "120"))
    poll_seconds = float(os.getenv("VOLCENGINE_EIP_ALLOCATE_POLL_SECONDS", "3"))
    deadline = time.time() + timeout_seconds
    last_item = None
    while time.time() <= deadline:
        for item in describe_eip_addresses(api_instance, project_name=project_name, limit=200):
            item_allocation_id = first_value(item, "AllocationId", "allocation_id") or ""
            if item_allocation_id != allocation_id:
                continue
            last_item = item
            status = str(first_value(item, "Status", "status") or "").lower()
            instance_id = first_value(item, "InstanceId", "instance_id") or ""
            if status == "available" and not instance_id:
                return item
        time.sleep(poll_seconds)
    raise TimeoutError("等待 EIP 可用超时: allocation_id=%s last_item=%s" % (allocation_id, last_item))


def associate_eip_address(api_instance: Any, allocation_id: str, instance_id: str) -> dict[str, Any]:
    import volcenginesdkvpc

    request = volcenginesdkvpc.AssociateEipAddressRequest(
        allocation_id=allocation_id,
        instance_id=instance_id,
        instance_type="EcsInstance",
    )
    response = api_instance.associate_eip_address(request)
    return to_plain_dict(response)


def disassociate_eip_address(api_instance: Any, allocation_id: str) -> dict[str, Any]:
    import volcenginesdkvpc

    request = volcenginesdkvpc.DisassociateEipAddressRequest(
        allocation_id=allocation_id,
    )
    response = api_instance.disassociate_eip_address(request)
    return to_plain_dict(response)


def allocate_and_associate_eip(
    instance_id: str,
    region: str,
    billing_type: int = 2,
    project_name: str = "default",
    preferred_allocation_id: str = "",
) -> dict[str, Any]:
    api_instance = create_vpc_api(region)
    pre_disassociated = []
    for existing in find_associated_eip_addresses(api_instance, instance_id, project_name=project_name):
        response = disassociate_eip_address(api_instance, existing["allocation_id"])
        pre_disassociated.append({
            "allocation_id": existing["allocation_id"],
            "eip": existing.get("eip"),
            "disassociate_response": response,
        })
    if pre_disassociated:
        wait_seconds = float(os.getenv("VOLCENGINE_EIP_PRE_DISASSOCIATE_WAIT_SECONDS", "3"))
        if wait_seconds > 0:
            time.sleep(wait_seconds)
    reuse_available = os.getenv("VOLCENGINE_EIP_REUSE_AVAILABLE", "1").lower() not in ("0", "false", "no", "off")
    allocation = None
    if preferred_allocation_id:
        allocation = {"allocation_id": preferred_allocation_id, "response": {}, "eip": None, "reserved_existing_eip": True}
    elif reuse_available:
        allocation = find_available_eip_address(api_instance, project_name=project_name)
    reused = allocation is not None and not preferred_allocation_id
    if allocation is None:
        allocation = allocate_eip_address(api_instance, billing_type=billing_type, project_name=project_name)
    association_response = associate_eip_address_with_retry(api_instance, allocation["allocation_id"], instance_id)
    bound_eip = wait_for_bound_eip_address(api_instance, allocation["allocation_id"], instance_id, project_name=project_name)
    return {
        "instance_id": instance_id,
        "allocation_id": allocation["allocation_id"],
        "eip_address": bound_eip.get("eip_address", ""),
        "eip": bound_eip.get("eip"),
        "reused_existing_eip": reused,
        "preferred_allocation_id": preferred_allocation_id,
        "pre_disassociated_eips": pre_disassociated,
        "allocate_response": allocation["response"],
        "associate_response": association_response,
    }


def wait_for_bound_eip_address(
    api_instance: Any,
    allocation_id: str,
    instance_id: str,
    project_name: str = "default",
) -> dict[str, Any]:
    timeout_seconds = float(os.getenv("VOLCENGINE_EIP_BIND_WAIT_TIMEOUT_SECONDS", "30"))
    poll_seconds = float(os.getenv("VOLCENGINE_EIP_BIND_POLL_SECONDS", "2"))
    deadline = time.time() + timeout_seconds
    last_item = None
    while time.time() <= deadline:
        for item in describe_eip_addresses(api_instance, project_name=project_name, limit=200):
            item_allocation_id = first_value(item, "AllocationId", "allocation_id") or ""
            if item_allocation_id != allocation_id:
                continue
            last_item = item
            attached_instance_id = first_value(item, "InstanceId", "instance_id") or ""
            eip_address = first_value(item, "eip_address", "EipAddress", "ip_address") or ""
            if attached_instance_id == instance_id and eip_address:
                return {"eip_address": str(eip_address), "eip": item}
        time.sleep(poll_seconds)
    raise TimeoutError(
        "等待 EIP 绑定地址超时: allocation_id=%s instance_id=%s last_item=%s"
        % (allocation_id, instance_id, last_item)
    )


def associate_eip_address_with_retry(api_instance: Any, allocation_id: str, instance_id: str) -> dict[str, Any]:
    max_attempts = int(os.getenv("VOLCENGINE_EIP_ASSOCIATE_MAX_ATTEMPTS", "10"))
    retry_seconds = float(os.getenv("VOLCENGINE_EIP_ASSOCIATE_RETRY_SECONDS", "3"))
    last_error: Exception | None = None
    for attempt in range(1, max_attempts + 1):
        try:
            return associate_eip_address(api_instance, allocation_id, instance_id)
        except Exception as exc:
            last_error = exc
            if not is_eip_status_retryable(exc) or attempt >= max_attempts:
                raise
            time.sleep(retry_seconds)
    raise RuntimeError("associate eip exhausted allocation_id=%s last_error=%s" % (allocation_id, last_error))


def disassociate_eip(allocation_id: str, region: str) -> dict[str, Any]:
    api_instance = create_vpc_api(region)
    response = disassociate_eip_address(api_instance, allocation_id)
    return {
        "allocation_id": allocation_id,
        "disassociate_response": response,
    }


def to_plain_dict(response: Any) -> Any:
    if isinstance(response, dict):
        return response
    if hasattr(response, "to_dict"):
        return response.to_dict()
    return response


def get_result_payload(response_data: Any) -> Any:
    if isinstance(response_data, dict):
        return response_data.get("Result", response_data)
    return response_data


def first_value(data: Any, *keys: str) -> Any:
    if not isinstance(data, dict):
        return None
    for key in keys:
        value = data.get(key)
        if value:
            return value
    return None


def eip_address_from_binding_result(eip_result: dict[str, Any] | None) -> str:
    if not isinstance(eip_result, dict):
        return ""
    for key in ("eip_address", "ip_address"):
        value = eip_result.get(key)
        if isinstance(value, str) and value:
            return value
    eip = eip_result.get("eip")
    if isinstance(eip, dict):
        value = first_value(eip, "eip_address", "EipAddress", "ip_address")
        if value:
            return str(value)
    allocate_response = eip_result.get("allocate_response") or {}
    result = allocate_response.get("Result") or allocate_response.get("result") or {}
    for item in result.get("EipAddresses") or result.get("eip_addresses") or []:
        value = first_value(item, "eip_address", "EipAddress", "ip_address")
        if value:
            return str(value)
    return ""


def is_eip_status_retryable(exc: Exception) -> bool:
    text = "%s" % exc
    return (
        "InvalidEip.InvalidStatus" in text
        or "not in the correct status" in text
        or "InvalidInstance.InUse" in text
        or "already been associated with an elastic ip address" in text
    )
