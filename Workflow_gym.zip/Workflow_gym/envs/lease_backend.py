from __future__ import annotations

import datetime as dt
import os
from typing import Protocol

from ..records import InstanceLease, new_id, now_text
from ..states import InstanceStatus


class LeaseBackend(Protocol):
    def acquire(
        self,
        run_id: str,
        task_id: str,
        sample_index: int,
        required_platform: str = "",
        blocked_instance_ids: set[str] | None = None,
        image_id: str = "",
    ) -> InstanceLease | None:
        ...

    def release(self, lease_id: str, reason: str = "") -> None:
        ...

    def renew(self, lease_id: str, seconds: int) -> None:
        ...

    def expire_stale_leases(
        self,
        blocked_instance_ids: set[str] | None = None,
        store=None,
    ) -> list[InstanceLease]:
        ...


def parse_time_text(text: str) -> dt.datetime | None:
    value = str(text or "").strip()
    if not value:
        return None
    try:
        return dt.datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return None


def lease_is_expired(lease: InstanceLease, now: dt.datetime | None = None) -> bool:
    expires_at = parse_time_text(lease.expires_at)
    if expires_at is None:
        return False
    current = now or dt.datetime.now()
    return current >= expires_at


class LocalLeaseBackend:
    def __init__(
        self,
        instance_ids: list[str],
        instance_platforms: dict[str, str] | None = None,
        ttl_seconds: int = 3600,
    ):
        self.instance_ids = list(instance_ids)
        self.instance_platforms = dict(instance_platforms or {})
        self.ttl_seconds = ttl_seconds
        self._leases_by_instance: dict[str, InstanceLease] = {}

    def acquire(
        self,
        run_id: str,
        task_id: str,
        sample_index: int,
        required_platform: str = "",
        blocked_instance_ids: set[str] | None = None,
        image_id: str = "",
    ) -> InstanceLease | None:
        blocked = set(blocked_instance_ids or ())
        normalized_platform = str(required_platform or "").strip().lower()
        for instance_id in self.instance_ids:
            if instance_id in blocked:
                continue
            if instance_id in self._leases_by_instance:
                continue
            if normalized_platform and self.instance_platforms.get(instance_id) != normalized_platform:
                continue
            lease = InstanceLease(
                run_id=run_id,
                lease_id=new_id("lease"),
                instance_id=instance_id,
                task_id=task_id,
                sample_index=sample_index,
                status=InstanceStatus.LEASED.value,
                acquired_at=now_text(),
                expires_at=self._future_text(self.ttl_seconds),
            )
            self._leases_by_instance[instance_id] = lease
            return lease
        return None

    def platform_capacity(
        self,
        required_platform: str = "",
        blocked_instance_ids: set[str] | None = None,
    ) -> dict[str, int]:
        blocked = set(blocked_instance_ids or ())
        normalized_platform = str(required_platform or "").strip().lower()
        matching = [
            instance_id
            for instance_id in self.instance_ids
            if instance_id not in blocked
            and (not normalized_platform or self.instance_platforms.get(instance_id) == normalized_platform)
        ]
        idle = [instance_id for instance_id in matching if instance_id not in self._leases_by_instance]
        return {
            "total": len(matching),
            "idle": len(idle),
            "leased": len(matching) - len(idle),
        }

    def release(self, lease_id: str, reason: str = "") -> None:
        for instance_id, lease in list(self._leases_by_instance.items()):
            if lease.lease_id == lease_id:
                lease.status = InstanceStatus.IDLE.value
                lease.released_at = now_text()
                del self._leases_by_instance[instance_id]
                return

    def renew(self, lease_id: str, seconds: int) -> None:
        for lease in self._leases_by_instance.values():
            if lease.lease_id == lease_id:
                lease.expires_at = self._future_text(seconds)
                return

    def sync_expires_from_store(self, store) -> None:
        for lease in self._leases_by_instance.values():
            self.sync_lease_expires_from_store(store, lease)

    @staticmethod
    def sync_lease_expires_from_store(store, lease: InstanceLease) -> None:
        row = store.get_lease(lease.lease_id)
        if not row:
            return
        expires_at = str(row.get("expires_at") or "").strip()
        if expires_at:
            lease.expires_at = expires_at

    def expire_stale_leases(self, blocked_instance_ids: set[str] | None = None, store=None) -> list[InstanceLease]:
        blocked = set(blocked_instance_ids or ())
        expired: list[InstanceLease] = []
        for instance_id, lease in list(self._leases_by_instance.items()):
            if instance_id in blocked:
                continue
            if store is not None:
                self.sync_lease_expires_from_store(store, lease)
            if not lease_is_expired(lease):
                continue
            lease.status = InstanceStatus.QUARANTINED.value
            lease.released_at = now_text()
            del self._leases_by_instance[instance_id]
            expired.append(lease)
        return expired

    @staticmethod
    def _future_text(seconds: int) -> str:
        return (dt.datetime.now() + dt.timedelta(seconds=seconds)).strftime("%Y-%m-%d %H:%M:%S")



class RedisLeaseBackend:
    """Redis 模式：通过 WGM Session API 申请备机 / 续租 / 退租。

    不维护按 instance_id 的容量账本。申请成功登记到本 backend 实例的
    ``_active_leases``（进程内、实例级），Ctrl+C 只释放这些 lease，
    不调用用户级 WGM ``release-all``（避免同 token 其他终端被误杀）。
    """

    def __init__(
        self,
        instance_ids: list[str] | None = None,
        instance_platforms: dict[str, str] | None = None,
        ttl_seconds: int = 1800,
        api_base: str | None = None,
        api_token: str | None = None,
        timeout_seconds: float = 60.0,
    ):
        from .wgm_client import WgmClient

        # 可选提示列表（显式配置的候选机）；不用于本机占用记账。
        self.instance_ids = list(instance_ids or [])
        self.instance_platforms = dict(instance_platforms or {})
        self.ttl_seconds = max(60, int(ttl_seconds))
        self.client = WgmClient(
            api_base=api_base,
            api_token=api_token,
            ttl_seconds=self.ttl_seconds,
            timeout_seconds=timeout_seconds,
        )
        self.api_base = self.client.api_base
        self.api_token = self.client.api_token
        self._should_abort = lambda: False
        # 本进程、本 backend 实例持有的 lease_id → handle（非类变量全局表）
        self._active_leases: dict[str, InstanceLease] = {}

    def set_abort_checker(self, fn) -> None:
        self._should_abort = fn if callable(fn) else (lambda: False)

    def acquire(
        self,
        run_id: str,
        task_id: str,
        sample_index: int,
        required_platform: str = "",
        blocked_instance_ids: set[str] | None = None,
        image_id: str = "",
    ) -> InstanceLease | None:
        from .wgm_lease_handle import WgmLeaseHandle

        blocked = set(blocked_instance_ids or ())
        normalized_platform = str(required_platform or "").strip().lower()
        candidate_ids = [
            instance_id
            for instance_id in self.instance_ids
            if instance_id not in blocked
            and (
                not normalized_platform
                or self.instance_platforms.get(instance_id) == normalized_platform
            )
        ]
        try:
            remote = self.client.acquire_and_prepare_wait(
                image_id=str(image_id or "").strip(),
                os_type=normalized_platform,
                instance_ids=candidate_ids or None,
                ttl_seconds=self.ttl_seconds,
                skip_replace=not bool(str(image_id or "").strip()),
                should_abort=self._should_abort,
            )
        except Exception:
            return None

        handle = WgmLeaseHandle.from_remote(
            run_id=run_id,
            task_id=task_id,
            sample_index=sample_index,
            remote=remote,
            client=self.client,
            required_platform=normalized_platform,
            ttl_seconds=self.ttl_seconds,
        )
        if handle is None:
            return None
        if handle.instance_id in blocked:
            handle.release("blocked")
            return None
        self._active_leases[handle.lease_id] = handle
        return handle

    def release_held(self, reason: str = "shutdown") -> dict:
        """只释放本 backend 实例当前登记的租约（同用户其他进程不受影响）。"""
        released = 0
        errors: list[str] = []
        for lease_id in list(self._active_leases.keys()):
            try:
                self.release(lease_id, reason=reason)
                released += 1
            except Exception as exc:
                errors.append("%s: %s" % (lease_id, exc))
        return {
            "success": not errors,
            "released_count": released,
            "errors": errors,
            "scope": "process_held",
        }

    def release_all(self, reason: str = "shutdown") -> dict:
        """兼容旧调用名：等同 ``release_held``，不再打 WGM release-all。"""
        return self.release_held(reason=reason)

    def platform_capacity(
        self,
        required_platform: str = "",
        blocked_instance_ids: set[str] | None = None,
    ) -> dict[str, int]:
        """不造「本地 idle=1」假账；容量由 WGM acquire 成败决定。

        total/idle 用 -1 表示「未知，允许尝试申请」；acquire_status 见 InstancePool。
        """
        _ = (required_platform, blocked_instance_ids)
        return {"total": -1, "idle": -1, "leased": 0}

    def release(self, lease_id: str, reason: str = "") -> None:
        _ = reason
        lease_id = str(lease_id or "").strip()
        if not lease_id:
            return
        try:
            self.client.release(lease_id)
        except Exception:
            pass
        lease = self._active_leases.pop(lease_id, None)
        if lease is not None:
            lease.status = InstanceStatus.IDLE.value
            if not getattr(lease, "released_at", ""):
                lease.released_at = now_text()

    def renew(self, lease_id: str, seconds: int) -> None:
        lease_id = str(lease_id or "").strip()
        if not lease_id:
            return
        ttl = max(60, int(seconds))
        try:
            data = self.client.renew(lease_id, ttl_seconds=ttl)
            lease = self._active_leases.get(lease_id)
            if lease is not None and data.get("expires_at"):
                lease.expires_at = str(data["expires_at"])
        except Exception:
            pass

    def sync_expires_from_store(self, store) -> None:
        _ = store
        # 续期由 handle / LeaseRenewContext 走 WGM。

    def expire_stale_leases(self, blocked_instance_ids: set[str] | None = None, store=None) -> list[InstanceLease]:
        _ = (blocked_instance_ids, store)
        return []

    @staticmethod
    def _future_text(seconds: int) -> str:
        return (dt.datetime.now() + dt.timedelta(seconds=seconds)).strftime("%Y-%m-%d %H:%M:%S")


def create_lease_backend(
    kind: str = "local",
    *,
    instance_ids: list[str] | None = None,
    instance_platforms: dict[str, str] | None = None,
    ttl_seconds: int = 3600,
    api_base: str | None = None,
    api_token: str | None = None,
):
    normalized = str(kind or "local").strip().lower()
    if normalized in ("redis", "wgm", "remote"):
        return RedisLeaseBackend(
            instance_ids=instance_ids,
            instance_platforms=instance_platforms,
            ttl_seconds=ttl_seconds,
            api_base=api_base,
            api_token=api_token,
        )
    return LocalLeaseBackend(
        list(instance_ids or []),
        instance_platforms=instance_platforms,
        ttl_seconds=ttl_seconds,
    )
