"""Redis 模式下的环境适配：RunCommand/action/截图默认均走 WGM（只需 Token）。"""
from __future__ import annotations

import base64
import os
from pathlib import Path
from typing import Any

from ..records import now_text
from .volcengine_env import VolcengineEnv
from .wgm_client import WgmClient, WgmClientError


def screenshot_via_wgm() -> bool:
    """redis/online 模式截图是否走 WGM（默认 True = ``wgm-direct``）。

    **默认 ``wgm-direct``**：经网关二进制流（`WGM_SCREENSHOT_FORMAT=stream`），本机只需 `WGM_TOKEN`。
    显式取值：
      - ``WGM_SCREENSHOT_VIA=wgm-direct|wgm|gateway|remote`` → 走网关截图流
      - ``WGM_SCREENSHOT_VIA=pyautogui|wgm-pyautogui`` → 走网关 run-action（pyautogui.screenshot）
      - ``WGM_SCREENSHOT_VIA=local|ecs`` → 本机 ECS SDK（需 AK/SK）
      - 或 ``REDIS_SCREENSHOT_VIA_WGM=0`` / ``WGM_SCREENSHOT_VIA_WGM=0`` → 本机
    """
    via = str(os.getenv("WGM_SCREENSHOT_VIA") or "").strip().lower().replace("_", "-")
    if via in ("wgm-direct", "wgm", "gateway", "remote", "pyautogui", "wgm-pyautogui"):
        return True
    if via in ("local", "ecs", "direct", "0", "false", "no", "off"):
        return False
    for key in ("REDIS_SCREENSHOT_VIA_WGM", "WGM_SCREENSHOT_VIA_WGM"):
        if key not in os.environ:
            continue
        return str(os.environ.get(key) or "").strip().lower() in ("1", "true", "yes", "on")
    return True


def screenshot_delivery() -> str:
    """online 截图通路标签，与 action=wgm-direct 对齐。"""
    via = str(os.getenv("WGM_SCREENSHOT_VIA") or "").strip().lower().replace("_", "-")
    if via in ("pyautogui", "wgm-pyautogui"):
        return "wgm-pyautogui"
    return "wgm-direct" if screenshot_via_wgm() else "local"


class GatewayVolcengineEnv(VolcengineEnv):
    """继承 VolcengineEnv 接口，云操作默认走胖网关。

    本地 Redis 采样路径应：
    - acquire-and-prepare（lease backend）完成备机
    - sampler.initialize_sample_env → ensure-ready
    - 步循环 run_command/run_action → WGM
    - 截图默认 ``wgm-direct``（可用 ``WGM_SCREENSHOT_VIA=local`` 切回本机 ECS）
    """

    def __init__(
        self,
        region: str = "cn-guangzhou",
        dry_run: str = "",
        *,
        wgm_api_base: str | None = None,
        wgm_token: str | None = None,
        ttl_seconds: int = 1800,
    ):
        super().__init__(region=region, dry_run=dry_run)
        self.wgm = WgmClient(
            api_base=wgm_api_base,
            api_token=wgm_token,
            ttl_seconds=ttl_seconds,
        )
        self.ttl_seconds = ttl_seconds

    def _lease_id(self) -> str:
        ctx = self.lease_renew_context
        if ctx is None or not getattr(ctx, "lease_id", ""):
            raise ValueError("GatewayVolcengineEnv 需要 lease_renew_context.lease_id")
        return str(ctx.lease_id)

    def initialize_for_sample(self, *args, **kwargs) -> dict[str, Any]:
        # Redis 路径由 sampler 直接 ensure-ready；保留兼容空实现。
        return {
            "lease_backend": "redis",
            "initialize_for_sample": "skipped_use_ensure_ready",
            "at": now_text(),
        }

    def run_command(
        self,
        instance_id: str,
        command: str,
        timeout: int = 60,
        command_type: str = "",
        username: str = "",
        display_command: str = "",
    ) -> dict[str, Any]:
        if self.dry_run:
            return {"dry_run": True, "command": display_command or command}
        data = self.wgm.run_command(
            self._lease_id(),
            command,
            timeout=timeout,
            command_type=command_type,
            username=username,
            ttl_seconds=self.ttl_seconds,
        )
        result = data.get("result") if isinstance(data, dict) else data
        return result if isinstance(result, dict) else {"raw": data}

    def run_action(
        self,
        instance_id: str,
        script: str,
        timeout: int = 120,
        *,
        action_id: str = "",
        source: str = "workflowgym_pyautogui_wrapper",
    ) -> dict[str, Any]:
        if self.dry_run:
            return {
                "dry_run": True,
                "ok": True,
                "output": "",
                "results": [{"decoded_output": "", "ExitCode": 0}],
            }
        try:
            data = self.wgm.run_action(
                self._lease_id(),
                script=script,
                action_id=action_id,
                source=source,
                timeout=timeout,
                ttl_seconds=self.ttl_seconds,
            )
        except WgmClientError as exc:
            # Normalize to ValueError so sampler retry / continue-on-error paths apply.
            raise ValueError("WGM run-action failed: %s" % exc) from exc
        if not isinstance(data, dict):
            raise ValueError("WGM run-action returned non-object: %s" % type(data))
        if data.get("ok") is False:
            detail = str(data.get("error") or data.get("status") or "action_failed")
            stderr = str(data.get("stderr") or "").strip()
            output = str(data.get("output") or "").strip()
            if stderr:
                detail = "%s stderr=%s" % (detail, stderr[:800])
            elif output:
                detail = "%s output=%s" % (detail, output[:800])
            raise ValueError("workflowgym flask action failed via wgm-direct: %s" % detail)
        output = str(data.get("output") or "")
        stderr = str(data.get("stderr") or "")
        decoded = output
        if stderr:
            decoded = (decoded + ("\n" if decoded and not decoded.endswith("\n") else "") + stderr).rstrip("\n")
        return {
            "ok": bool(data.get("ok", True)),
            "output": output,
            "stderr": stderr,
            "error": str(data.get("error") or ""),
            "status": data.get("status"),
            "id": data.get("id"),
            "results": [
                {
                    "decoded_output": decoded or output,
                    "ExitCode": 0 if data.get("ok", True) else 1,
                }
            ],
            "raw": data,
        }

    def download_file(
        self,
        instance_id: str,
        paths: list[str] | str,
        timeout: int = 120,
    ) -> dict[str, Any]:
        """经 WGM→Flask /file 拉取产物字节；成功时返回 content(bytes) 与元数据。"""
        if self.dry_run:
            return {"dry_run": True, "ok": False, "error": "dry_run"}
        candidate_paths = [paths] if isinstance(paths, str) else list(paths or [])
        candidate_paths = [str(item).strip() for item in candidate_paths if str(item).strip()]
        if not candidate_paths:
            raise ValueError("download_file requires at least one path")
        try:
            data = self.wgm.download_file(
                self._lease_id(),
                paths=candidate_paths,
                timeout=timeout,
                ttl_seconds=self.ttl_seconds,
            )
        except WgmClientError as exc:
            raise ValueError("WGM download-file failed: %s" % exc) from exc
        if not isinstance(data, dict) or not data.get("ok"):
            raise ValueError("WGM download-file failed: %s" % (data if isinstance(data, dict) else type(data)))
        content_b64 = str(data.get("content_b64") or "")
        if not content_b64:
            raise ValueError("WGM download-file returned empty content_b64")
        try:
            content = base64.b64decode(content_b64)
        except Exception as exc:
            raise ValueError("WGM download-file invalid content_b64: %s" % exc) from exc
        return {
            "ok": True,
            "path": str(data.get("path") or ""),
            "name": str(data.get("name") or ""),
            "size": int(data.get("size") or len(content)),
            "content": content,
            "via": "wgm_flask_http",
            "raw": data,
        }

    def ensure_ubuntu_flask_runner(
        self,
        instance_id: str,
        sample_dir: str = "",
        desktop_metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """经 WGM ensure-ready 触发网关侧 Flask 自愈（避免本机 ECS SDK）。"""
        if self.dry_run:
            return {"dry_run": True, "ubuntu_flask_runner": "skipped"}
        ready = self.wgm.ensure_ready(self._lease_id(), ttl_seconds=self.ttl_seconds, allow_heal=True)
        meta = {
            "ubuntu_flask_runner_restart_via": "wgm_ensure_ready",
            "ensure_ready": ready,
            "at": now_text(),
        }
        for key in ("ubuntu_flask_port", "ubuntu_flask_token", "display", "xauthority", "desktop_user"):
            if key in ready and ready.get(key) not in (None, ""):
                meta[key] = ready[key]
        if not ready.get("ready"):
            raise ValueError("WGM ensure-ready after ubuntu flask restart failed: %s" % (ready.get("errors") or ready))
        return meta

    def ensure_windows_flask_runner(self, instance_id: str, sample_dir: str = "") -> dict[str, Any]:
        if self.dry_run:
            return {"dry_run": True, "windows_flask_runner": "skipped"}
        ready = self.wgm.ensure_ready(self._lease_id(), ttl_seconds=self.ttl_seconds, allow_heal=True)
        meta = {
            "windows_flask_runner_restart_via": "wgm_ensure_ready",
            "ensure_ready": ready,
            "at": now_text(),
        }
        for key in ("windows_flask_port", "windows_flask_token", "desktop_user", "platform"):
            if key in ready and ready.get(key) not in (None, ""):
                meta[key] = ready[key]
        if not ready.get("ready"):
            raise ValueError("WGM ensure-ready after windows flask restart failed: %s" % (ready.get("errors") or ready))
        return meta

    def get_console_screenshot(self, instance_id: str) -> bytes:
        if self.dry_run:
            # 1x1 png
            return base64.b64decode(
                "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
            )
        via = str(os.getenv("WGM_SCREENSHOT_VIA") or "").strip().lower().replace("_", "-")
        if via in ("pyautogui", "wgm-pyautogui"):
            return self._screenshot_via_wgm_pyautogui()
        if screenshot_via_wgm():
            return self.wgm.screenshot_bytes(self._lease_id(), ttl_seconds=self.ttl_seconds)
        # 显式 local：本机直连火山 GetConsoleScreenshot（需本机 AK/SK）
        if not (os.getenv("AK") and os.getenv("SK")):
            raise ValueError(
                "WGM_SCREENSHOT_VIA=local 需要本机设置火山 AK/SK；"
                "online/redis 默认截图为 wgm-direct，只需 WGM_TOKEN（勿设 local，或 unset WGM_SCREENSHOT_VIA）"
            )
        return super().get_console_screenshot(instance_id)

    def _screenshot_via_wgm_pyautogui(self) -> bytes:
        """通过 WGM run-action 执行 pyautogui.screenshot 并返回 PNG 字节。"""
        marker = "WORKFLOWGYM_SCREENSHOT_B64:"
        # 写桌面临时文件再 base64，比纯 BytesIO 更稳（Windows Pillow/编码问题更少）。
        script = (
            "import base64\n"
            "import traceback\n"
            "from pathlib import Path\n"
            "\n"
            "try:\n"
            "    import pyautogui\n"
            "    pyautogui.FAILSAFE = False\n"
            "    out = Path.home() / 'Desktop' / 'workflowgym_screenshot_tmp.png'\n"
            "    out.parent.mkdir(parents=True, exist_ok=True)\n"
            "    image = pyautogui.screenshot(str(out))\n"
            "    if not out.is_file() or out.stat().st_size <= 0:\n"
            "        from io import BytesIO\n"
            "        buf = BytesIO()\n"
            "        image.save(buf, format='PNG')\n"
            "        raw = buf.getvalue()\n"
            "    else:\n"
            "        raw = out.read_bytes()\n"
            "        try:\n"
            "            out.unlink(missing_ok=True)\n"
            "        except Exception:\n"
            "            pass\n"
            "    if not raw:\n"
            "        raise RuntimeError('empty screenshot bytes')\n"
            "    print(%r + base64.b64encode(raw).decode('ascii'))\n"
            "except Exception as exc:\n"
            "    traceback.print_exc()\n"
            "    raise SystemExit('pyautogui screenshot failed: %%s' %% exc)\n"
        ) % marker
        timeout = int(os.getenv("WGM_PYAUTOGUI_SCREENSHOT_TIMEOUT_SECONDS", "45"))
        result = self.run_action(
            "",
            script=script,
            timeout=timeout,
            action_id="screenshot-pyautogui",
            source="workflowgym_pyautogui_screenshot",
        )
        outputs: list[str] = []
        decoded = str(result.get("output") or "")
        if decoded:
            outputs.append(decoded)
        for item in list(result.get("results") or []):
            outputs.append(str(item.get("decoded_output") or ""))
        merged = "\n".join(part for part in outputs if part)
        index = merged.find(marker)
        if index < 0:
            raise ValueError("WGM pyautogui screenshot missing base64 marker")
        payload = merged[index + len(marker) :].strip().splitlines()[0].strip()
        if not payload:
            raise ValueError("WGM pyautogui screenshot returned empty base64")
        try:
            raw = base64.b64decode(payload, validate=True)
        except Exception as exc:
            raise ValueError("WGM pyautogui screenshot invalid base64: %s" % exc) from exc
        if not raw:
            raise ValueError("WGM pyautogui screenshot returned empty bytes")
        return raw

    def capture_screenshot(self, instance_id: str, sample_dir: str, step_index: int) -> str:
        raw = self.get_console_screenshot(instance_id)
        path = Path(sample_dir) / ("screenshot_%s.png" % step_index)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        return str(path)

    def api(self):
        # 截图本机直连需要 ECS client；其它云操作仍由本类覆写走 WGM。
        if screenshot_via_wgm():
            raise RuntimeError("GatewayVolcengineEnv 禁止本机直连 ECS SDK；请使用 WGM Session API")
        return super().api()
