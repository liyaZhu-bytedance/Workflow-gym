from __future__ import annotations

import os
import shutil
from dataclasses import dataclass

from .records import RunConfig


@dataclass(frozen=True)
class ResourceSnapshot:
    memory_usage_percent: float = 0.0
    available_memory_mb: int = 0
    free_disk_gb: float = 0.0
    run_dir_gb: float = 0.0
    worker_processes: int = 0


@dataclass(frozen=True)
class ResourceDecision:
    can_dispatch: bool
    should_shutdown: bool
    reason: str = ""


class ResourceWatchdog:
    def __init__(self, config: RunConfig):
        self.config = config

    def snapshot(self) -> ResourceSnapshot:
        usage = shutil.disk_usage(self.config.output_root or ".")
        return ResourceSnapshot(
            free_disk_gb=usage.free / (1024 ** 3),
            run_dir_gb=directory_size_gb(self.config.output_root) if self.config.output_root else 0.0,
            worker_processes=0,
        )

    def decide(self, snapshot: ResourceSnapshot | None = None) -> ResourceDecision:
        snap = snapshot or self.snapshot()
        if snap.free_disk_gb < self.config.min_free_disk_gb:
            return ResourceDecision(False, True, "free disk below hard threshold")
        if snap.run_dir_gb > self.config.max_run_dir_gb:
            return ResourceDecision(False, True, "run directory exceeds limit")
        if snap.worker_processes > self.config.max_worker_processes:
            return ResourceDecision(False, False, "worker process limit reached")
        return ResourceDecision(True, False)


def directory_size_gb(path: str) -> float:
    total = 0
    if not path or not os.path.exists(path):
        return 0.0
    for root, dirs, files in os.walk(path):
        for filename in files:
            file_path = os.path.join(root, filename)
            try:
                total += os.path.getsize(file_path)
            except OSError:
                continue
    return total / (1024 ** 3)

