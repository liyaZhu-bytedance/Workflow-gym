from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ResumeCheckResult:
    can_resume: bool
    reason: str = ""
    next_step: int = 0


class ResumeManager:
    """Reserved extension for --resume-running-samples.

    First version defaults to safe recovery and does not automatically resume
    a possibly changed desktop session.
    """

    def check(self, sample_dir: str, instance_id: str, image_id: str) -> ResumeCheckResult:
        return ResumeCheckResult(
            can_resume=False,
            reason="resume-running-samples is reserved but disabled in first version",
        )

