from __future__ import annotations

import base64
import json
import logging
import ntpath
import os
import posixpath
import re
import time
import traceback
import concurrent.futures
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from .agents.base import SampleContext
from .agents.factory import AgentFactory
from .agents.pyautogui_actions import (
    action_execution_should_continue,
    action_timeout_should_continue,
    describe_pyautogui_action_script,
    disallowed_pyautogui_action_reason,
    display_resolution_from_context,
    extract_flask_action_python_script,
    is_disallowed_pyautogui_action_error,
    is_linux_platform,
    is_remote_action_execution_error,
    is_remote_action_timeout_error,
    is_windows_file_queue_command,
    is_windows_flask_command,
    is_interactive_runner_command,
    is_ubuntu_flask_command,
    platform_from_context,
    remote_action_timeout_seconds,
    screenshot_failure_should_continue,
    should_retry_interactive_runner_error,
    wrap_pyautogui_python,
)
from .envs.volcengine_env import CloudAssistantPlatformMismatchError, VolcengineEnv, command_decoded_output, platform_to_os_type_label, windows_login_user
from .lease_renewal import (
    build_lease_renew_context,
    call_with_lease_heartbeat,
    flag_init_orphan_lease,
    model_lease_heartbeat_enabled,
)
from .records import PromptBundle, SampleJob, StepTrace, TaskFileResult, TrajectoryResult, json_dumps, now_text, to_jsonable
from .sample_log import append_sample_log
from .states import SampleStatus
from .task_files import (
    build_download_plan,
    build_prepare_input_command,
    build_prepare_output_command,
    build_tosutil_upload_commands,
    is_windows_path,
    parse_final_answer_names,
    parse_tos_urls,
    ps_quote,
    shell_quote,
    split_output_paths,
    validate_relative_output_path,
)


logger = logging.getLogger(__name__)


class InitializeForSampleTimeoutError(TimeoutError):
    def __init__(self, instance_id: str, image_id: str, timeout_seconds: int):
        self.instance_id = instance_id
        self.image_id = image_id
        self.timeout_seconds = timeout_seconds
        super().__init__(
            "initialize_for_sample 超时: instance_id=%s image_id=%s timeout=%ss"
            % (instance_id, image_id, timeout_seconds)
        )


def call_with_timeout(func: Callable[[], Any], timeout_seconds: int) -> Any:
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(func)
        return future.result(timeout=max(1, int(timeout_seconds)))


@dataclass
class SampleRunState:
    # 一次采样过程中会被多个阶段共同更新的状态集中放在这里，避免 run_sample 传递大量局部变量。
    env_metadata: dict[str, Any] = field(default_factory=dict)
    task_files: TaskFileResult = field(default_factory=TaskFileResult)
    traces: list[StepTrace] = field(default_factory=list)
    exceptions: list[dict[str, Any]] = field(default_factory=list)
    status: str = SampleStatus.SAMPLE_MAX_STEPS_REACHED.value
    error: str = ""
    last_step: int = -1
    current_trace: StepTrace | None = None
    current_workflow_node: str = "sample"
    initial_prompts: PromptBundle = field(default_factory=PromptBundle)


@dataclass
class StepActionResult:
    # 单个 step 中“模型回复 -> function_call -> 可执行代码”的结果包，后续执行和收尾都依赖它。
    response: str = ""
    parsed: dict[str, Any] = field(default_factory=dict)
    call: Any = None
    executed_code: list[str] = field(default_factory=list)
    trace: StepTrace | None = None


class Sampler:
    def __init__(self, agent_factory: AgentFactory, env: VolcengineEnv, shutdown_requested: Callable[[], bool] | None = None):
        self.agent_factory = agent_factory
        self.env = env
        self.shutdown_requested = shutdown_requested or (lambda: False)

    def run_sample(self, job: SampleJob) -> TrajectoryResult:
        self.env.lease_renew_context = build_lease_renew_context(job)
        self.env.renew_lease_now()
        sample_dir = sample_directory(job)
        os.makedirs(sample_dir, exist_ok=True)
        clear_exception_file(sample_dir)
        player = self.agent_factory.create(job.config.player)
        context = self.create_context(job, sample_dir)
        state = SampleRunState()
        append_workflow_event(state.env_metadata, "sample", "started")
        try:
            # run_sample 只保留采样主干，具体日志、workflow event 和异常记录下沉到各阶段函数。
            self.initialize_sample_env(job, sample_dir, context, state)
            self.prepare_sample(job, context, player, state)
            self.run_sampling_steps(job, sample_dir, context, player, state)
        except Exception as exc:
            self.record_sampling_exception(job, sample_dir, context, state, exc)

        self.finalize_sample(job, sample_dir, context, player, state)
        trace_sample(job, "写采样结果 status=%s last_step=%s error=%s" % (state.status, state.last_step, state.error))
        return self.write_results(
            job,
            sample_dir,
            context.prompts,
            state.initial_prompts,
            state.env_metadata,
            state.task_files,
            state.traces,
            state.exceptions,
            state.status,
            state.error,
            state.last_step,
        )

    def create_context(self, job: SampleJob, sample_dir: str) -> SampleContext:
        return SampleContext(
            run_id=job.run_id,
            task=job.task,
            sample_index=job.sample_index,
            sample_dir=sample_dir,
            metadata={
                "dry_run": job.config.dry_run,
                "player": job.config.player,
                "judger": job.config.judger,
                "step_num": job.config.step_num,
                "lease_backend": str(getattr(job.config, "lease_backend", "local") or "local"),
            },
        )

    def initialize_sample_env(self, job: SampleJob, sample_dir: str, context: SampleContext, state: SampleRunState) -> None:
        if not job.lease:
            return
        state.current_workflow_node = "initialize_env"
        requires_public_ip = sample_requires_public_ip(job)
        details = {"instance_id": job.lease.instance_id, "image_id": job.task.image_id, "requires_public_ip": requires_public_ip}
        preferred_eip_allocation_id = job.lease.reserved_eip_allocation_id
        if preferred_eip_allocation_id:
            details["preferred_eip_allocation_id"] = preferred_eip_allocation_id
        append_workflow_event(state.env_metadata, state.current_workflow_node, "started", details=details)
        self.env.renew_lease_now()
        lease_backend = str(getattr(job.config, "lease_backend", "local") or "local").strip().lower()
        if lease_backend in ("redis", "wgm", "remote"):
            # online 模式：acquire-and-prepare 已完成换盘/探测；这里只 ensure-ready。
            trace_sample(job, "Redis 模式 ensure-ready instance_id=%s" % job.lease.instance_id)
            from .envs.wgm_client import WgmClient, WgmClientError

            client = WgmClient(
                api_base=getattr(job.config, "wgm_api_base", "") or None,
                api_token=getattr(job.config, "wgm_token", "") or None,
                ttl_seconds=max(60, int(job.config.lease_ttl_seconds or 1800)),
            )
            try:
                ready = client.ensure_ready(
                    job.lease.lease_id,
                    ttl_seconds=int(job.config.lease_ttl_seconds or 1800),
                    allow_heal=True,
                )
            except WgmClientError as exc:
                raise ValueError("ensure-ready failed: %s" % exc) from exc
            init_metadata = {
                "instance_id": job.lease.instance_id,
                "image_id": job.task.image_id,
                "lease_backend": "redis",
                "ensure_ready": ready,
                "prepare_via": "wgm_acquire_and_prepare",
            }
            # Flatten WGM readiness fields into env_metadata (same keys local init uses).
            for key in (
                "platform",
                "os_type",
                "desktop_user",
                "display",
                "xauthority",
                "ubuntu_action_runner",
                "ubuntu_flask_token",
                "ubuntu_flask_port",
                "windows_action_runner",
                "windows_flask_token",
                "windows_flask_port",
            ):
                if key in ready and ready.get(key) not in (None, ""):
                    init_metadata[key] = ready[key]
            if not ready.get("ready"):
                raise ValueError("WGM ensure-ready 未通过: %s" % (ready.get("errors") or ready))
            state.env_metadata.update(init_metadata)
            context.metadata["env_metadata"] = state.env_metadata
            for key in (
                "platform",
                "computer_platform",
                "os",
                "os_type",
                "system",
                "desktop_user",
                "display",
                "xauthority",
                "windows_action_runner",
                "windows_flask_token",
                "windows_flask_port",
                "ubuntu_action_runner",
                "ubuntu_flask_token",
                "ubuntu_flask_port",
            ):
                if key in state.env_metadata and key not in context.metadata:
                    context.metadata[key] = state.env_metadata[key]
            append_workflow_event(state.env_metadata, state.current_workflow_node, "finished", details={"ready": True})
            trace_sample(job, "Redis 模式环境已 ready")
            return
        trace_sample(job, "初始化环境开始 instance_id=%s image_id=%s" % (job.lease.instance_id, job.task.image_id))
        timeout_seconds = max(1, int(job.config.sample_init_timeout_seconds))
        try:
            init_metadata = call_with_timeout(
                lambda: self.env.initialize_for_sample(
                    job.lease.instance_id,
                    job.task.image_id,
                    sample_dir,
                    requires_public_ip=requires_public_ip,
                    platform_hint=task_platform_hint(job),
                    preferred_eip_allocation_id=preferred_eip_allocation_id,
                ),
                timeout_seconds,
            )
        except concurrent.futures.TimeoutError as exc:
            reason = (
                "initialize_for_sample 超时: instance_id=%s image_id=%s timeout=%ss（云侧 Init 可能仍在后台运行）"
                % (job.lease.instance_id, job.task.image_id, timeout_seconds)
            )
            flag_init_orphan_lease(job, reason)
            trace_sample(job, reason)
            raise InitializeForSampleTimeoutError(
                job.lease.instance_id,
                job.task.image_id,
                timeout_seconds,
            ) from exc
        state.env_metadata.update(init_metadata)
        context.metadata["env_metadata"] = state.env_metadata
        for key in (
            "platform",
            "computer_platform",
            "os",
            "os_type",
            "system",
            "windows_action_runner",
            "windows_flask_token",
            "windows_flask_port",
            "ubuntu_action_runner",
            "ubuntu_flask_token",
            "ubuntu_flask_port",
        ):
            if key in state.env_metadata and key not in context.metadata:
                context.metadata[key] = state.env_metadata[key]
        append_workflow_event(state.env_metadata, state.current_workflow_node, "success", details=details)
        trace_sample(job, "初始化环境完成")

    def prepare_sample(self, job: SampleJob, context: SampleContext, player: Any, state: SampleRunState) -> None:
        state.current_workflow_node = "build_prompt"
        trace_sample(job, "构建 prompt")
        context.prompts = player.build_prompts(context)
        state.initial_prompts = context.prompts
        append_workflow_event(
            state.env_metadata,
            state.current_workflow_node,
            "success",
            details={"sp_chars": len(context.prompts.sp or ""), "up_chars": len(context.prompts.up or "")},
        )

        trace_sample(job, "准备输入文件")
        state.current_workflow_node = "prepare_input"
        state.task_files = self.prepare_inputs(job, context, state.env_metadata)
        trace_sample(job, "准备输出目录")
        state.current_workflow_node = "prepare_output"
        self.prepare_output_dir(job, state.env_metadata)

        state.current_workflow_node = "before_sample"
        trace_sample(job, "before_sample")
        player.before_sample(context)
        append_workflow_event(state.env_metadata, state.current_workflow_node, "success")

    def run_sampling_steps(self, job: SampleJob, sample_dir: str, context: SampleContext, player: Any, state: SampleRunState) -> None:
        for step_index in range(job.config.step_num):
            # 退出信号只在 step 边界检查，避免模型调用或动作执行中途被打断导致状态半写入。
            if self.stop_before_next_step(job, state, step_index):
                break
            state.last_step = step_index
            should_stop = self.run_step(job, sample_dir, context, player, state, step_index)
            self.write_step_trajectory_if_enabled(job, sample_dir, state)
            if should_stop:
                break

    def stop_before_next_step(self, job: SampleJob, state: SampleRunState, step_index: int) -> bool:
        if not self.shutdown_requested():
            return False
        state.status = SampleStatus.SAMPLE_INTERRUPTED.value
        state.error = "收到退出信号，停止派发下一步采样"
        append_workflow_event(state.env_metadata, "step", "interrupted", step_index=step_index, error=state.error)
        trace_sample(job, "step=%s %s" % (step_index, state.error))
        return True

    def run_step(self, job: SampleJob, sample_dir: str, context: SampleContext, player: Any, state: SampleRunState, step_index: int) -> bool:
        self.before_step(job, context, player, state, step_index)
        screenshot = self.capture_step_screenshot(job, sample_dir, context, state, step_index)
        if not screenshot:
            return False
        action_result = self.build_step_action(job, context, player, state, step_index, screenshot)
        self.print_step_code_if_verbose(job, step_index, action_result.executed_code)
        if self.execute_step_actions(job, sample_dir, context, player, state, action_result, step_index):
            return True
        return self.finish_step(job, context, player, state, action_result, step_index)

    def write_step_trajectory_if_enabled(self, job: SampleJob, sample_dir: str, state: SampleRunState) -> None:
        if not job.config.write_step_traj:
            return
        traj_json_path = os.path.join(sample_dir, "traj.json")
        traj_md_path = os.path.join(sample_dir, "traj.md")
        write_json(traj_json_path, [trace_payload(trace) for trace in recorded_step_traces(state.traces)])
        write_text(traj_md_path, render_traj_md(recorded_step_traces(state.traces), sample_dir, state.initial_prompts))
        trace_sample(job, "step=%s 增量写轨迹完成 traces=%s" % (state.last_step, len(state.traces)))

    def before_step(self, job: SampleJob, context: SampleContext, player: Any, state: SampleRunState, step_index: int) -> None:
        trace_sample(job, "step=%s before_step" % step_index)
        state.current_workflow_node = "before_step"
        player.before_step(context)
        append_workflow_event(state.env_metadata, state.current_workflow_node, "success", step_index=step_index)
        if player.dynamic_prompts:
            state.current_workflow_node = "build_step_prompt"
            trace_sample(job, "step=%s 构建动态 prompt" % step_index)
            context.prompts = player.build_step_prompts(context)
            append_workflow_event(
                state.env_metadata,
                state.current_workflow_node,
                "success",
                step_index=step_index,
                details={"sp_chars": len(context.prompts.sp or ""), "up_chars": len(context.prompts.up or "")},
            )

    def capture_screenshot_with_retry(
        self,
        job: SampleJob | None,
        instance_id: str,
        sample_dir: str,
        step_index: int | str,
    ) -> str:
        max_attempts = max(1, int(os.getenv("SCREENSHOT_RETRY_MAX_ATTEMPTS", "2")))
        retry_sleep_seconds = max(0.0, float(os.getenv("SCREENSHOT_RETRY_SLEEP_SECONDS", "10")))
        last_exc: Exception | None = None
        for attempt in range(1, max_attempts + 1):
            try:
                return self.env.capture_screenshot(instance_id, sample_dir, step_index)
            except Exception as exc:
                last_exc = exc
                if attempt >= max_attempts:
                    raise
                if job is not None:
                    trace_sample(
                        job,
                        "step=%s 截图失败，%ss 后重试 attempt=%s/%s error=%s"
                        % (step_index, retry_sleep_seconds, attempt, max_attempts, exc),
                    )
                if retry_sleep_seconds > 0:
                    time.sleep(retry_sleep_seconds)
        assert last_exc is not None
        raise last_exc

    def capture_step_screenshot(
        self,
        job: SampleJob,
        sample_dir: str,
        context: SampleContext,
        state: SampleRunState,
        step_index: int,
    ) -> str | None:
        trace_sample(job, "step=%s 截图开始" % step_index)
        state.current_workflow_node = "capture_screenshot"
        try:
            screenshot = self.capture_screenshot_with_retry(
                job,
                job.lease.instance_id if job.lease else "",
                sample_dir,
                step_index,
            )
        except Exception as exc:
            if not screenshot_failure_should_continue():
                raise
            fallback = self.fallback_screenshot_path(context, state)
            self.record_screenshot_error(job, sample_dir, context, state, step_index, exc, fallback)
            if fallback:
                context.current_screenshot = fallback
                return fallback
            return None
        append_workflow_event(state.env_metadata, state.current_workflow_node, "success", step_index=step_index, details={"screenshot": screenshot})
        trace_sample(job, "step=%s 截图完成 screenshot=%s" % (step_index, screenshot))
        context.current_screenshot = screenshot
        return screenshot

    def fallback_screenshot_path(self, context: SampleContext, state: SampleRunState) -> str | None:
        current = str(context.current_screenshot or "").strip()
        if current and os.path.isfile(current):
            return current
        ready = str(state.env_metadata.get("desktop_ready_screenshot") or "").strip()
        if ready and os.path.isfile(ready):
            return ready
        return None

    def record_screenshot_error(
        self,
        job: SampleJob,
        sample_dir: str,
        context: SampleContext,
        state: SampleRunState,
        step_index: int,
        exc: BaseException,
        fallback: str | None,
    ) -> None:
        error_text = "%s" % exc
        lowered = error_text.lower()
        status = "timeout" if isinstance(exc, TimeoutError) or "timed out" in lowered or "总超时" in error_text else "screenshot_error"
        trace_sample(
            job,
            "step=%s 截图%s，继续采样 fallback=%s error=%s"
            % (step_index, "超时" if status == "timeout" else "失败", fallback or "<none>", error_text),
        )
        append_workflow_event(
            state.env_metadata,
            "capture_screenshot",
            status,
            step_index=step_index,
            details={"fallback_screenshot": fallback},
            error=error_text,
        )
        exception_record = build_exception_record(
            job,
            "capture_screenshot_%s" % status,
            exc,
            step_index,
            fallback or context.current_screenshot,
            state.current_trace,
            env_metadata=state.env_metadata,
        )
        state.exceptions.append(exception_record)
        append_exception(sample_dir, exception_record)

    def build_step_action(self, job: SampleJob, context: SampleContext, player: Any, state: SampleRunState, step_index: int, screenshot: str) -> StepActionResult:
        result = StepActionResult()
        max_response_retries = model_response_retry_count()
        for response_attempt in range(max_response_retries + 1):
            # 模型回复疑似截断且没有可用 function_call 时，重试同一个 step。
            result = self.call_and_parse_model(job, context, player, state, step_index, screenshot, response_attempt)
            if should_retry_step_response(result.response, result.call, result.executed_code, context) and response_attempt < max_response_retries:
                self.record_model_response_retry(job, state, result, step_index, response_attempt, max_response_retries)
                continue
            return result
        return result

    def call_and_parse_model(
        self,
        job: SampleJob,
        context: SampleContext,
        player: Any,
        state: SampleRunState,
        step_index: int,
        screenshot: str,
        response_attempt: int,
    ) -> StepActionResult:
        attempt = response_attempt + 1
        state.current_workflow_node = "model_predict"
        trace_sample(job, "step=%s 模型调用开始 attempt=%s" % (step_index, attempt))
        if step_index == 10 and attempt == 1:
            write_step_prompt_snapshot(sample_dir=context.sample_dir, context=context, player=player, step_index=step_index)
        if model_lease_heartbeat_enabled(
            job.config.model_call_timeout_seconds,
            job.config.model_lease_heartbeat_min_seconds,
        ):
            response = call_with_lease_heartbeat(self.env, lambda: player.predict(context))
        else:
            response = player.predict(context)
        append_workflow_event(
            state.env_metadata,
            state.current_workflow_node,
            "success",
            step_index=step_index,
            details={"attempt": attempt, "response_chars": len(response or "")},
        )
        trace_sample(job, "step=%s 模型调用完成 attempt=%s response_chars=%s" % (step_index, attempt, len(response or "")))
        if job.config.verbose_steps:
            print_step_section(step_index, "model_response", response)
        return self.parse_model_action(job, context, player, state, step_index, screenshot, response, attempt)

    def parse_model_action(
        self,
        job: SampleJob,
        context: SampleContext,
        player: Any,
        state: SampleRunState,
        step_index: int,
        screenshot: str,
        response: str,
        attempt: int,
    ) -> StepActionResult:
        trace_sample(job, "step=%s 解析 function_call attempt=%s" % (step_index, attempt))
        state.current_workflow_node = "parse_function_call"
        parsed = player.parse_response(response, context)
        call = player.transform_function_call(parsed.get("function_call"), context)
        call = player.transform_coordinates(call, context)
        append_workflow_event(
            state.env_metadata,
            state.current_workflow_node,
            "success",
            step_index=step_index,
            details={"attempt": attempt, "function_call": to_jsonable(call), "has_function_call": bool(call)},
        )
        if job.config.verbose_steps:
            print_step_section(step_index, "parsed_function_call", json_dumps(call))
        trace = StepTrace(
            step_index=step_index,
            screenshot=screenshot,
            response=parsed.get("response", response),
            thought=parsed.get("thought", ""),
            function_call=parsed.get("function_call"),
            transformed_function_call=call,
        )
        trace.action_summaries.extend(extract_coordinate_summaries(call))
        state.traces.append(trace)
        executed_code = player.to_pyautogui(call, context)
        trace.executed_code = executed_code
        state.current_trace = trace
        append_workflow_event(
            state.env_metadata,
            "build_actions",
            "success",
            step_index=step_index,
            details={"attempt": attempt, "action_count": len(executed_code)},
        )
        trace_sample(job, "step=%s 生成执行代码 attempt=%s count=%s" % (step_index, attempt, len(executed_code)))
        return StepActionResult(response=response, parsed=parsed, call=call, executed_code=executed_code, trace=trace)

    def record_model_response_retry(
        self,
        job: SampleJob,
        state: SampleRunState,
        result: StepActionResult,
        step_index: int,
        response_attempt: int,
        max_response_retries: int,
    ) -> None:
        retry_error = no_executable_action_error(result.parsed.get("response", result.response), result.call)
        if result.trace:
            result.trace.error = retry_error
        if state.traces and state.traces[-1] is result.trace:
            # 重试中的无效回复不写入 traj，只保留最终用于执行或跳过的那次解析结果。
            state.traces.pop()
        append_workflow_event(
            state.env_metadata,
            "model_response_retry",
            "started",
            step_index=step_index,
            details={"attempt": response_attempt + 1, "next_attempt": response_attempt + 2},
            error=retry_error,
        )
        trace_sample(job, "step=%s 模型回复截断，重试当前 step attempt=%s/%s" % (step_index, response_attempt + 1, max_response_retries + 1))

    def print_step_code_if_verbose(self, job: SampleJob, step_index: int, executed_code: list[str]) -> None:
        if not job.config.verbose_steps:
            return
        if executed_code:
            for code_index, code in enumerate(executed_code):
                print_step_section(step_index, "python_code_%s" % code_index, code)
        else:
            print_step_section(step_index, "python_code", "<no executable code>")

    def execute_step_actions(
        self,
        job: SampleJob,
        sample_dir: str,
        context: SampleContext,
        player: Any,
        state: SampleRunState,
        action_result: StepActionResult,
        step_index: int,
    ) -> bool:
        for code_index, code in enumerate(action_result.executed_code):
            # 远程动作执行可能耗时；按约定不中途检查退出信号，等 step 结束后统一处理。
            trace_sample(job, "step=%s 远程执行开始" % step_index)
            state.current_workflow_node = "execute_action"
            command, action_script_info = prepare_remote_action_command(code, context)
            if action_script_info:
                append_workflow_event(
                    state.env_metadata,
                    "prepare_action_script",
                    "success",
                    step_index=step_index,
                    details={
                        "action_index": code_index,
                        "backend": action_script_info.get("backend"),
                        "pyautogui_code": action_script_info.get("pyautogui_code"),
                        "xdotool_code": action_script_info.get("xdotool_code"),
                        "conversions": action_script_info.get("conversions"),
                    },
                )
                append_sample_log(
                    sample_dir,
                    "step=%s action_index=%s backend=%s"
                    % (step_index, code_index, action_script_info.get("backend")),
                    source="sampler",
                    task_id=job.task_id,
                    sample_index=job.sample_index,
                    extra={
                        "step_index": step_index,
                        "action_index": code_index,
                        "backend": action_script_info.get("backend"),
                        "pyautogui_code": action_script_info.get("pyautogui_code"),
                        "xdotool_code": action_script_info.get("xdotool_code"),
                        "conversions": action_script_info.get("conversions"),
                    },
                )
                trace_sample(
                    job,
                    "step=%s action_index=%s backend=%s pyautogui_chars=%s xdotool_chars=%s"
                    % (
                        step_index,
                        code_index,
                        action_script_info.get("backend"),
                        len(str(action_script_info.get("pyautogui_code") or "")),
                        len(str(action_script_info.get("xdotool_code") or "")),
                    ),
                )
            action_timeout = remote_action_timeout_seconds(command, job.config.action_timeout_seconds)
            run_username = windows_login_user() if platform_from_context(context) == "windows" else ""
            try:
                if should_use_wgm_direct_action_delivery(job, command):
                    script = extract_flask_action_python_script(command)
                    if not script.strip():
                        raise ValueError(
                            "redis/wgm-direct 需要可提取的 python 脚本 "
                            "(flask wrap 或 bare pyautogui)"
                        )
                    command_result = self.run_step_wgm_action(
                        job,
                        sample_dir,
                        state,
                        step_index,
                        script,
                        action_timeout,
                        context,
                    )
                else:
                    command_result = self.run_step_action_command(
                        job,
                        sample_dir,
                        state,
                        step_index,
                        command,
                        action_timeout,
                        run_username,
                    )
            except (TimeoutError, ValueError) as exc:
                if self.should_continue_after_remote_action_error(exc):
                    self.record_action_execution_error(
                        job,
                        sample_dir,
                        context,
                        state,
                        action_result,
                        step_index,
                        code_index,
                        exc,
                    )
                    continue
                raise
            append_workflow_event(
                state.env_metadata,
                state.current_workflow_node,
                "success",
                step_index=step_index,
                details={"action_index": code_index, "result": to_jsonable(command_result)},
            )
            trace_sample(job, "step=%s 远程执行完成" % step_index)
            self.wait_after_action(job, sample_dir, context, state, step_index, code_index)
            if action_result.trace:
                action_result.trace.action_summaries.extend(extract_action_summaries(command_result))
                if should_capture_post_action_screenshot(player, context, action_result.trace, code_index):
                    try:
                        post_screenshot = self.capture_screenshot_with_retry(
                            job,
                            job.lease.instance_id if job.lease else "",
                            sample_dir,
                            "%s_post_%s" % (step_index, code_index),
                        )
                    except Exception as exc:
                        if not screenshot_failure_should_continue():
                            raise
                        post_screenshot = self.fallback_screenshot_path(context, state) or context.current_screenshot
                        self.record_screenshot_error(
                            job,
                            sample_dir,
                            context,
                            state,
                            step_index,
                            exc,
                            post_screenshot,
                        )
                    if post_screenshot:
                        notify_after_action(player, context, action_result.trace, code_index, post_screenshot)
            if job.config.verbose_steps:
                print_step_section(step_index, "python_response", json_dumps(command_result))
                if action_result.trace:
                    print_step_section(step_index, "action_summaries", json_dumps(action_result.trace.action_summaries))
        return False

    def should_continue_after_remote_action_error(self, exc: BaseException) -> bool:
        if is_remote_action_timeout_error(exc) and action_timeout_should_continue():
            return True
        if is_disallowed_pyautogui_action_error(exc) and action_execution_should_continue():
            return True
        if is_remote_action_execution_error(exc) and action_execution_should_continue():
            return True
        return False

    def run_step_action_command(
        self,
        job: SampleJob,
        sample_dir: str,
        state: SampleRunState,
        step_index: int,
        command: str,
        action_timeout: int,
        run_username: str,
    ) -> dict[str, Any]:
        max_attempts = 2 if is_interactive_runner_command(command) else 1
        last_error: Exception | None = None
        for attempt in range(max_attempts):
            try:
                return self.env.run_command(
                    job.lease.instance_id if job.lease else "",
                    command,
                    action_timeout,
                    username=run_username,
                )
            except ValueError as exc:
                last_error = exc
                if attempt + 1 >= max_attempts or not should_retry_interactive_runner_error(
                    exc,
                    action_script=command,
                ):
                    raise
                if is_ubuntu_flask_command(command):
                    runner_label = "ubuntu-flask"
                else:
                    runner_label = "flask" if is_windows_flask_command(command) else "file-queue"
                trace_sample(
                    job,
                    "step=%s %s runner 失败，重启 runner 后重试 attempt=%s"
                    % (step_index, runner_label, attempt + 2),
                )
                if job.lease:
                    if is_ubuntu_flask_command(command):
                        restart_metadata = self.env.ensure_ubuntu_flask_runner(
                            job.lease.instance_id,
                            sample_dir,
                            state.env_metadata,
                        )
                    elif is_windows_flask_command(command):
                        restart_metadata = self.env.ensure_windows_flask_runner(
                            job.lease.instance_id,
                            sample_dir,
                        )
                    else:
                        restart_metadata = self.env.ensure_windows_file_queue_runner(
                            job.lease.instance_id,
                            sample_dir,
                        )
                    state.env_metadata.update(restart_metadata)
        raise ValueError("remote action did not produce a command result: %s" % last_error)

    def run_step_wgm_action(
        self,
        job: SampleJob,
        sample_dir: str,
        state: SampleRunState,
        step_index: int,
        script: str,
        action_timeout: int,
        context: SampleContext,
    ) -> dict[str, Any]:
        if not hasattr(self.env, "run_action"):
            raise ValueError(
                "wgm-direct requires GatewayVolcengineEnv.run_action, got %s"
                % type(self.env).__name__
            )
        max_attempts = 2
        last_error: Exception | None = None
        for attempt in range(max_attempts):
            try:
                return self.env.run_action(
                    job.lease.instance_id if job.lease else "",
                    script,
                    timeout=action_timeout,
                    action_id="step-%s-%s" % (step_index, attempt + 1),
                )
            except ValueError as exc:
                last_error = exc
                if attempt + 1 >= max_attempts or not should_retry_interactive_runner_error(
                    exc,
                    action_script=script,
                ):
                    raise
                trace_sample(
                    job,
                    "step=%s wgm-direct flask 失败，ensure-ready 后重试 attempt=%s"
                    % (step_index, attempt + 2),
                )
                if not job.lease:
                    raise
                platform = platform_from_context(context)
                if is_linux_platform(platform):
                    restart_metadata = self.env.ensure_ubuntu_flask_runner(
                        job.lease.instance_id,
                        sample_dir,
                        state.env_metadata,
                    )
                else:
                    restart_metadata = self.env.ensure_windows_flask_runner(
                        job.lease.instance_id,
                        sample_dir,
                    )
                state.env_metadata.update(restart_metadata)
        raise ValueError("wgm-direct action did not produce a result: %s" % last_error)

    def record_action_execution_error(
        self,
        job: SampleJob,
        sample_dir: str,
        context: SampleContext,
        state: SampleRunState,
        action_result: StepActionResult,
        step_index: int,
        code_index: int,
        exc: BaseException,
    ) -> None:
        error_text = "%s" % exc
        status = "timeout" if is_remote_action_timeout_error(exc) else "action_error"
        trace_sample(
            job,
            "step=%s 远程执行%s，继续采样 action_index=%s error=%s"
            % (step_index, "超时" if status == "timeout" else "失败", code_index, error_text),
        )
        append_workflow_event(
            state.env_metadata,
            "execute_action",
            status,
            step_index=step_index,
            details={"action_index": code_index},
            error=error_text,
        )
        if action_result.trace:
            prior_error = action_result.trace.error or ""
            action_result.trace.error = ("%s\n%s" % (prior_error, error_text)).strip() if prior_error else error_text
            action_result.trace.action_summaries.append(
                {
                    "status": status,
                    "action_index": code_index,
                    "error": error_text,
                }
            )
        exception_record = build_exception_record(
            job,
            "execute_action_%s" % status,
            exc,
            step_index,
            context.current_screenshot,
            action_result.trace,
            env_metadata=state.env_metadata,
        )
        state.exceptions.append(exception_record)
        append_exception(sample_dir, exception_record)

    def wait_after_action(
        self,
        job: SampleJob,
        sample_dir: str,
        context: SampleContext,
        state: SampleRunState,
        step_index: int,
        code_index: int,
    ) -> None:
        # Default on: console screenshots lag behind GUI animations (GNOME overlays, window open).
        # Disable with ACTION_SCREEN_STABLE_WAIT=0.
        if os.getenv("ACTION_SCREEN_STABLE_WAIT", "1").lower() in ("0", "false", "no", "off"):
            return
        wait_fn = getattr(self.env, "wait_for_screen_stable", None)
        if not callable(wait_fn):
            settle = float(os.getenv("ACTION_SCREEN_STABLE_INITIAL_DELAY_SECONDS", "1.0") or "1.0")
            if settle > 0:
                time.sleep(settle)
            return
        state.current_workflow_node = "wait_screen_stable"
        trace_sample(job, "step=%s 等待界面稳定开始 action_index=%s" % (step_index, code_index))
        try:
            result = wait_fn(
                job.lease.instance_id if job.lease else "",
                sample_dir,
                "step_%s_stable_%s" % (step_index, code_index),
                previous_screenshot=context.current_screenshot,
            )
            append_workflow_event(
                state.env_metadata,
                state.current_workflow_node,
                "success",
                step_index=step_index,
                details={"action_index": code_index, "result": to_jsonable(result)},
            )
            trace_sample(job, "step=%s 等待界面稳定完成 result=%s" % (step_index, result.get("status")))
        except Exception as exc:
            append_workflow_event(
                state.env_metadata,
                state.current_workflow_node,
                "error",
                step_index=step_index,
                details={"action_index": code_index},
                error=str(exc),
            )
            trace_sample(job, "step=%s 等待界面稳定失败 error=%s" % (step_index, exc))

    def finish_step(self, job: SampleJob, context: SampleContext, player: Any, state: SampleRunState, action_result: StepActionResult, step_index: int) -> bool:
        state.current_workflow_node = "after_step"
        if action_result.trace:
            player.after_step(context, action_result.trace)
            append_workflow_event(state.env_metadata, state.current_workflow_node, "success", step_index=step_index)
        if should_player_stop_after_step(player, context, action_result.trace):
            trace_sample(job, "step=%s adapter 请求停止采样" % step_index)
            state.status = SampleStatus.SAMPLE_COMPLETED.value
            append_workflow_event(state.env_metadata, "sample", "success", step_index=step_index, details={"reason": "adapter_stop"})
            return True
        if not action_result.executed_code:
            if self.handle_no_actions(job, context, state, action_result, step_index):
                return True
        # after_step 已完成后再响应退出，保证当前 step 的 trace 和 workflow event 是闭合的。
        if self.stop_after_step(job, state, step_index):
            return True
        self.discard_failed_step_if_needed(job, state, context, player, action_result, step_index)
        return False

    def discard_failed_step_if_needed(
        self,
        job: SampleJob,
        state: SampleRunState,
        context: SampleContext,
        player: Any,
        action_result: StepActionResult,
        step_index: int,
    ) -> None:
        trace = action_result.trace
        if not trace or is_recorded_step_trace(trace):
            return
        if state.traces and state.traces[-1] is trace:
            state.traces.pop()
        if context.history and context.history[-1] is trace:
            context.history.pop()
        rollback_player_step_history(player)
        trace_sample(job, "step=%s 执行失败，已从 traj 与模型历史中移除" % step_index)

    def stop_after_step(self, job: SampleJob, state: SampleRunState, step_index: int) -> bool:
        if not self.shutdown_requested():
            return False
        state.status = SampleStatus.SAMPLE_INTERRUPTED.value
        state.error = state.error or "收到退出信号，当前步骤完成后停止采样"
        append_workflow_event(state.env_metadata, "sample", "interrupted", step_index=step_index, error=state.error)
        trace_sample(job, "step=%s %s" % (step_index, state.error))
        return True

    def handle_no_actions(self, job: SampleJob, context: SampleContext, state: SampleRunState, action_result: StepActionResult, step_index: int) -> bool:
        # 没有可执行动作并不一定失败：finished/dry-run 是正常结束，无 function_call 则跳过当前 step。
        if is_finished_call(action_result.call):
            trace_sample(job, "step=%s 收到 finished，采样完成" % step_index)
            state.status = SampleStatus.SAMPLE_COMPLETED.value
            append_workflow_event(state.env_metadata, "sample", "success", step_index=step_index, details={"reason": "finished"})
            return True
        if context.metadata.get("dry_run"):
            trace_sample(job, "step=%s dry-run 无可执行代码，采样完成" % step_index)
            state.status = SampleStatus.SAMPLE_COMPLETED.value
            append_workflow_event(state.env_metadata, "sample", "success", step_index=step_index, details={"reason": "dry_run_no_action"})
            return True
        if not action_result.call:
            step_error = no_function_call_step_error(action_result.parsed.get("response", action_result.response))
            if action_result.trace:
                action_result.trace.error = step_error
            append_workflow_event(state.env_metadata, "step", "skipped", step_index=step_index, error=step_error)
            trace_sample(job, "step=%s %s" % (step_index, step_error))
            return False
        step_error = no_executable_action_error(action_result.parsed.get("response", action_result.response), action_result.call)
        if action_result.trace:
            action_result.trace.error = step_error
        append_workflow_event(state.env_metadata, "step", "skipped", step_index=step_index, error=step_error)
        trace_sample(job, "step=%s %s" % (step_index, step_error))
        return False

    def record_sampling_exception(self, job: SampleJob, sample_dir: str, context: SampleContext, state: SampleRunState, exc: Exception) -> None:
        state.status = SampleStatus.SAMPLE_FAILED.value
        logger.exception("Sample failed: %s", exc)
        state.error = "%s" % exc
        append_workflow_event(state.env_metadata, state.current_workflow_node, "failed", step_index=state.last_step, error=state.error)
        exception_record = build_exception_record(
            job,
            "sampling",
            exc,
            state.last_step,
            context.current_screenshot,
            state.current_trace,
            env_metadata=state.env_metadata,
        )
        state.exceptions.append(exception_record)
        append_exception(sample_dir, exception_record)

    def finalize_sample(self, job: SampleJob, sample_dir: str, context: SampleContext, player: Any, state: SampleRunState) -> None:
        if state.status == SampleStatus.SAMPLE_MAX_STEPS_REACHED.value:
            append_workflow_event(state.env_metadata, "sample", "max_steps_reached", step_index=state.last_step)
        # 即使采样失败或中断，也尽量收集输出并执行 after_sample，方便排查和清理。
        self.collect_and_record_outputs(job, sample_dir, context, state)
        self.run_after_sample(job, sample_dir, context, player, state)
        self.cleanup_public_ip_binding(job, sample_dir, context, state)

    def cleanup_public_ip_binding(self, job: SampleJob, sample_dir: str, context: SampleContext, state: SampleRunState) -> None:
        if not job.lease:
            return
        try:
            state.current_workflow_node = "cleanup_public_ip"
            trace_sample(job, "解绑公网 IP 开始")
            result = self.env.cleanup_public_ip_binding(state.env_metadata, sample_dir)
            state.env_metadata["public_ip_cleanup_result"] = result
            trace_sample(job, "解绑公网 IP 完成 status=%s" % result.get("status"))
            append_workflow_event(state.env_metadata, state.current_workflow_node, "success", details=result)
        except Exception as exc:
            logger.exception("cleanup public ip failed: %s", exc)
            append_workflow_event(state.env_metadata, "cleanup_public_ip", "failed", step_index=state.last_step, error="%s" % exc)
            exception_record = build_exception_record(job, "cleanup_public_ip", exc, state.last_step, context.current_screenshot, state.current_trace)
            state.exceptions.append(exception_record)
            append_exception(sample_dir, exception_record)

    def collect_and_record_outputs(self, job: SampleJob, sample_dir: str, context: SampleContext, state: SampleRunState) -> None:
        try:
            state.current_workflow_node = "collect_outputs"
            trace_sample(job, "收集输出开始")
            output_result = self.collect_outputs(job, sample_dir=sample_dir)
            trace_sample(job, "收集输出完成")
            state.task_files.output_uploads = output_result.output_uploads
            state.task_files.final_answer_files = output_result.final_answer_files
            state.task_files.errors.extend(output_result.errors)
            append_workflow_event(
                state.env_metadata,
                state.current_workflow_node,
                "success",
                details={"output_upload_count": len(state.task_files.output_uploads), "error_count": len(state.task_files.errors)},
            )
        except Exception as exc:
            if not state.error:
                state.status = SampleStatus.SAMPLE_FAILED.value
                state.error = "%s" % exc
            append_workflow_event(state.env_metadata, "collect_outputs", "failed", step_index=state.last_step, error="%s" % exc)
            exception_record = build_exception_record(job, "collect_outputs", exc, state.last_step, context.current_screenshot, state.current_trace)
            state.exceptions.append(exception_record)
            append_exception(sample_dir, exception_record)
            state.task_files.errors.append("%s" % exc)

    def run_after_sample(self, job: SampleJob, sample_dir: str, context: SampleContext, player: Any, state: SampleRunState) -> None:
        try:
            state.current_workflow_node = "after_sample"
            trace_sample(job, "after_sample 开始")
            player.after_sample(context, {"status": state.status, "error": state.error})
            trace_sample(job, "after_sample 完成")
            append_workflow_event(state.env_metadata, state.current_workflow_node, "success")
        except Exception as exc:
            logger.exception("after_sample failed: %s", exc)
            append_workflow_event(state.env_metadata, "after_sample", "failed", step_index=state.last_step, error="%s" % exc)
            exception_record = build_exception_record(job, "after_sample", exc, state.last_step, context.current_screenshot, state.current_trace)
            state.exceptions.append(exception_record)
            append_exception(sample_dir, exception_record)

    def prepare_inputs(self, job: SampleJob, context: SampleContext, env_metadata: dict[str, Any]) -> TaskFileResult:
        result = TaskFileResult()
        urls = parse_tos_urls(job.task.tos_url)
        result.input_urls = urls
        if not urls or not job.task.input_path:
            append_env_setup_trace(
                env_metadata,
                "prepare_input",
                path=job.task.input_path,
                skipped_reason="缺少 tos_url 或输入文件路径",
            )
            return result
        plan = build_download_plan(urls)
        command = build_prepare_input_command(job.task.input_path, plan, job.config.input_download_timeout_seconds)
        if command:
            command_result = self.env.run_command(job.lease.instance_id if job.lease else "", command, job.config.input_download_timeout_seconds)
            append_env_setup_trace(
                env_metadata,
                "prepare_input",
                path=job.task.input_path,
                command=command,
                result=command_result,
            )
        result.input_downloads = [{"url": item.url, "filename": item.filename} for item in plan]
        return result

    def prepare_output_dir(self, job: SampleJob, env_metadata: dict[str, Any]) -> None:
        command = build_prepare_output_command(job.task.output_path)
        if not command:
            append_env_setup_trace(
                env_metadata,
                "prepare_output",
                path=job.task.output_path,
                skipped_reason="缺少输出文件路径",
            )
            return None
        if command:
            command_result = self.env.run_command(
                job.lease.instance_id if job.lease else "",
                command,
                job.config.tosutil_timeout_seconds,
            )
            append_env_setup_trace(
                env_metadata,
                "prepare_output",
                path=job.task.output_path,
                command=command,
                result=command_result,
            )

    def collect_outputs(self, job: SampleJob, sample_dir: str = "") -> TaskFileResult:
        result = TaskFileResult()
        final_names = parse_final_answer_names(job.task.final_answer_names)
        result.final_answer_files = final_names
        if not final_names or not job.task.output_path:
            return result
        prefix = build_sample_tos_prefix(job)
        presign_valid_period = os.getenv("TOS_PRESIGN_VALID_PERIOD", "24h")
        instance_id = job.lease.instance_id if job.lease else ""
        prefer_http = should_use_http_file_collect(job) and bool(sample_dir) and hasattr(self.env, "download_file")
        for name in final_names:
            target_path = tos_target_path(posixpath.join(prefix, name))
            candidate_paths = output_source_paths(job.task.output_path, name)
            upload_record = {
                "relative_path": name,
                "source_path": ",".join(candidate_paths),
                "candidate_source_paths": candidate_paths,
                "tos_prefix": prefix,
                "tos_path": target_path,
                "tos_url": public_tos_url(posixpath.join(prefix, name)),
                "presign_valid_period": presign_valid_period,
                "status": "pending",
            }
            if prefer_http:
                try:
                    http_result = self.env.download_file(
                        instance_id,
                        candidate_paths,
                        timeout=job.config.tosutil_timeout_seconds,
                    )
                    content = http_result.get("content") if isinstance(http_result, dict) else None
                    if isinstance(content, (bytes, bytearray)) and content:
                        safe_rel = validate_relative_output_path(name)
                        local_path = Path(sample_dir) / "production" / safe_rel
                        local_path.parent.mkdir(parents=True, exist_ok=True)
                        local_path.write_bytes(bytes(content))
                        source_path = str(http_result.get("path") or candidate_paths[0])
                        upload_record["source_path"] = source_path
                        upload_record["output_file_exists"] = True
                        upload_record["status"] = "http_downloaded"
                        upload_record["local_production_path"] = str(local_path)
                        upload_record["file_check"] = {
                            "success": True,
                            "exists": True,
                            "relative_path": name,
                            "source_path": source_path,
                            "size": int(http_result.get("size") or len(content)),
                            "via": "flask_http",
                        }
                        upload_record["http_download"] = {
                            "success": True,
                            "via": http_result.get("via") or "wgm_flask_http",
                            "path": source_path,
                            "size": int(http_result.get("size") or len(content)),
                            "local_path": str(local_path),
                        }
                        result.output_uploads.append(upload_record)
                        continue
                    upload_record["http_download"] = {
                        "success": False,
                        "error": "empty content",
                        "raw": {k: v for k, v in dict(http_result or {}).items() if k != "content"},
                    }
                except Exception as exc:
                    upload_record["http_download"] = {"success": False, "error": "%s" % exc}
                    # Fall through to RunCommand check + tosutil.

            try:
                check_result = self.env.run_command(
                    instance_id,
                    build_output_file_check_command(job.task.output_path, name),
                    job.config.tosutil_timeout_seconds,
                )
                file_check = parse_output_file_check_marker(check_result, name)
                upload_record["file_check"] = file_check
                upload_record["output_file_exists"] = bool(file_check.get("exists"))
                if file_check.get("source_path"):
                    upload_record["source_path"] = file_check["source_path"]
                if not file_check.get("exists"):
                    upload_record["status"] = "missing"
                    result.errors.append("缺少 final answer 文件: %s" % upload_record["source_path"])
                    result.output_uploads.append(upload_record)
                    continue
            except Exception as exc:
                upload_record["status"] = "file_check_failed"
                upload_record["file_check"] = {"success": False, "error": "%s" % exc}
                result.errors.append("检查 final answer 文件失败 %s: %s" % (upload_record["source_path"], exc))
                result.output_uploads.append(upload_record)
                continue

            try:
                commands = build_tosutil_upload_commands(job.task.output_path, [name], prefix, presign_valid_period)
                command_result = self.env.run_command(instance_id, commands[0], job.config.tosutil_timeout_seconds)
                presigned_urls = parse_tos_presign_markers(command_result)
                upload_record["tosutil_cp_result"] = {
                    "success": command_succeeded(command_result),
                    "command_result": command_result,
                }
                if presigned_urls.get(name):
                    upload_record["tos_url"] = presigned_urls[name]
                upload_record["status"] = "uploaded" if command_succeeded(command_result) else "upload_failed"
                if upload_record["status"] != "uploaded":
                    result.errors.append("上传 final answer 文件失败: %s" % upload_record["source_path"])
            except Exception as exc:
                upload_record["status"] = "upload_failed"
                upload_record["tosutil_cp_result"] = {"success": False, "error": "%s" % exc}
                result.errors.append("上传 final answer 文件失败 %s: %s" % (upload_record["source_path"], exc))
            result.output_uploads.append(upload_record)
        return result

    def write_results(
        self,
        job: SampleJob,
        sample_dir: str,
        prompts,
        initial_prompts: PromptBundle,
        env_metadata: dict[str, Any],
        task_files: TaskFileResult,
        traces: list[StepTrace],
        exceptions: list[dict[str, Any]],
        status: str,
        error: str,
        last_step: int,
    ) -> TrajectoryResult:
        id_path = os.path.join(sample_dir, "sample_metadata.json")
        traj_json_path = os.path.join(sample_dir, "traj.json")
        traj_md_path = os.path.join(sample_dir, "traj.md")
        exception_json_path = os.path.join(sample_dir, "exception.json")
        sample_status_path = os.path.join(sample_dir, "sample_status.json")

        id_payload = {
            "run_id": job.run_id,
            "task_id": job.task.task_id,
            "sample_index": job.sample_index,
            "player": job.config.player,
            "judger": job.config.judger,
            "sp": prompts.sp,
            "up": prompts.up,
            "tool_calls": prompts.tool_calls,
            "env": env_metadata,
            "task_files": to_jsonable(task_files),
        }
        write_json(id_path, id_payload)
        write_json(traj_json_path, [trace_payload(trace) for trace in recorded_step_traces(traces)])
        write_text(traj_md_path, render_traj_md(recorded_step_traces(traces), sample_dir, initial_prompts))
        if exceptions and not Path(exception_json_path).exists():
            write_json(exception_json_path, exceptions)
        write_json(
            sample_status_path,
            {
                "run_id": job.run_id,
                "task_id": job.task.task_id,
                "sample_index": job.sample_index,
                "status": status,
                "last_step": last_step,
                "error": error,
                "updated_at": now_text(),
            },
        )
        return TrajectoryResult(
            run_id=job.run_id,
            task_id=job.task.task_id,
            sample_index=job.sample_index,
            status=status,
            sample_dir=sample_dir,
            traj_json_path=traj_json_path,
            traj_md_path=traj_md_path,
            id_json_path=id_path,
            sample_status_path=sample_status_path,
            last_step=last_step,
            error=error,
            task_files=task_files,
            task_fields=job.task.fields,
        )


def trace_sample(job: SampleJob, message: str) -> None:
    timestamp = now_text()
    line = "[%s] sample trace task_id=%s sample_index=%s %s" % (
        timestamp,
        job.task_id,
        job.sample_index,
        message,
    )
    print(line, flush=True)
    append_sample_log(
        sample_directory(job),
        message,
        source="sampler",
        timestamp=timestamp,
        line=line,
        task_id=job.task_id,
        sample_index=job.sample_index,
    )


def sample_requires_public_ip(job: SampleJob) -> bool:
    return False


def task_platform_hint(job: SampleJob) -> str:
    for key in ("系统类型", "platform", "computer_platform", "os", "os_type", "system"):
        value = str(job.task.fields.get(key) or "").strip().lower()
        if value:
            return "windows" if value.startswith("win") or "windows" in value else "ubuntu"
    if is_windows_path(job.task.input_path) or is_windows_path(job.task.output_path):
        return "windows"
    return ""


def prepare_remote_action_command(code: str, context: SampleContext) -> tuple[str, dict[str, Any] | None]:
    stripped = str(code or "").lstrip()
    if not stripped:
        return "", None
    if stripped.startswith("#!/bin/bash") or stripped.startswith("$ErrorActionPreference"):
        return code, None
    if "pyautogui" in stripped:
        metadata = context.metadata if isinstance(getattr(context, "metadata", None), dict) else {}
        env_metadata = metadata.get("env_metadata") if isinstance(metadata.get("env_metadata"), dict) else {}
        disallowed_reason = disallowed_pyautogui_action_reason(stripped)
        if disallowed_reason:
            raise ValueError(disallowed_reason)
        platform = platform_from_context(context)
        resolved_display_size = None
        if is_linux_platform(platform):
            resolved_display_size = display_resolution_from_context(context)
        action_bundle = describe_pyautogui_action_script(
            stripped,
            screenshot_size_from_path(context.current_screenshot),
            platform=platform,
            display_size=resolved_display_size,
            context=context,
        )
        command = wrap_pyautogui_python(
            stripped,
            screenshot_size_from_path(context.current_screenshot),
            platform=platform,
            windows_runner_mode=str(metadata.get("windows_action_runner") or env_metadata.get("windows_action_runner") or ""),
            ubuntu_runner_mode=str(metadata.get("ubuntu_action_runner") or env_metadata.get("ubuntu_action_runner") or ""),
            context=context,
            prebuilt_script=str(action_bundle.get("remote_script") or ""),
        )
        action_script_info = {
            "backend": action_bundle.get("backend"),
            "pyautogui_code": action_bundle.get("pyautogui_code"),
            "xdotool_code": action_bundle.get("xdotool_code"),
            "conversions": action_bundle.get("conversions"),
        }
        return command, action_script_info
    return code, None


def should_deliver_windows_action_via_flask(context: SampleContext, command: str) -> bool:
    return False


def should_use_wgm_direct_action_delivery(job: SampleJob, command: str) -> bool:
    """redis 模式固定经 WGM→Flask /action 下发步内 pyautogui。"""
    lease_backend = str(getattr(job.config, "lease_backend", "local") or "local").strip().lower()
    if lease_backend not in ("redis", "wgm", "remote"):
        return False
    text = str(command or "")
    if is_ubuntu_flask_command(text) or is_windows_flask_command(text):
        return True
    return bool(extract_flask_action_python_script(text).strip())


def should_use_http_file_collect(job: SampleJob) -> bool:
    """redis 模式默认 tosutil；仅当 WGM_FILE_COLLECT_VIA=http 时优先 Flask /file。"""
    via = str(os.getenv("WGM_FILE_COLLECT_VIA") or "").strip().lower()
    if via not in ("http", "flask", "file"):
        return False
    lease_backend = str(getattr(job.config, "lease_backend", "local") or "local").strip().lower()
    return lease_backend in ("redis", "wgm", "remote")


def screenshot_size_from_path(path: str) -> tuple[int, int] | None:
    if not path:
        return None
    try:
        from .agents.pyautogui_actions import image_size

        return image_size(Path(path))
    except Exception:
        return None


def append_workflow_event(
    env_metadata: dict[str, Any],
    node: str,
    status: str,
    step_index: int | None = None,
    details: dict[str, Any] | None = None,
    error: str = "",
) -> None:
    event = {
        "node": node,
        "status": status,
        "timestamp": now_text(),
    }
    if step_index is not None:
        event["step_index"] = step_index
    if details:
        event["details"] = to_jsonable(details)
    if error:
        event["error"] = error
    env_metadata.setdefault("workflow_events", []).append(event)


def append_env_setup_trace(
    env_metadata: dict[str, Any],
    stage: str,
    path: str = "",
    command: str = "",
    result: Any = None,
    skipped_reason: str = "",
) -> None:
    trace = {
        "stage": stage,
        "path": path,
        "command": command,
        "result": to_jsonable(result) if result is not None else None,
        "skipped_reason": skipped_reason,
        "timestamp": now_text(),
    }
    env_metadata.setdefault("setup_traces", []).append(trace)
    append_workflow_event(
        env_metadata,
        stage,
        "skipped" if skipped_reason else "success",
        details={
            "path": path,
            "command": command,
            "result": to_jsonable(result) if result is not None else None,
            "skipped_reason": skipped_reason,
        },
    )


def is_finished_call(call: Any) -> bool:
    return isinstance(call, dict) and str(call.get("name") or "").lower() == "finished"


def should_player_stop_after_step(player: Any, context: SampleContext, trace: StepTrace | None) -> bool:
    method = getattr(player, "should_stop_after_step", None)
    if not callable(method):
        return False
    try:
        return bool(method(context, trace))
    except TypeError:
        return bool(method(context))


def no_executable_action_error(response: str, call: Any) -> str:
    if not call:
        if response_looks_truncated(response):
            return "模型回复疑似被截断，未解析到 function_call，跳过当前 step"
        return "未解析到 function_call，跳过当前 step"
    name = call.get("name") if isinstance(call, dict) else ""
    if name == "call_user":
        return "模型请求用户输入，当前自动采样无法执行该动作，跳过当前 step"
    return "function_call 没有生成可执行动作: %s，跳过当前 step" % (name or call)


def no_function_call_step_error(response: str) -> str:
    if response_looks_truncated(response):
        return "模型回复疑似被截断，重试后仍未解析到 function_call，跳过当前 step"
    return "未解析到 function_call，跳过当前 step"


def should_retry_step_response(response: str, call: Any, executed_code: list[str], context: SampleContext) -> bool:
    if context.metadata.get("dry_run"):
        return False
    return not executed_code and not call and response_looks_truncated(response)


def model_response_retry_count() -> int:
    return max(0, int(os.getenv("MODEL_RESPONSE_RETRY_COUNT", "2")))


def response_looks_truncated(response: str) -> bool:
    if not response:
        return False
    paired_tags = ("think", "tool_call", "tool_code")
    for tag in paired_tags:
        if response.count("<%s" % tag) > response.count("</%s>" % tag):
            return True
    if len(re.findall(r"<function=", response)) > response.count("</function>"):
        return True
    if len(re.findall(r"<parameter=", response)) > response.count("</parameter>"):
        return True
    return False


def sample_directory(job: SampleJob) -> str:
    return os.path.join(job.config.output_root, job.task.task_id, "sample_%s" % job.sample_index)


def build_sample_tos_prefix(job: SampleJob) -> str:
    bucket = os.getenv("TOS_UPLOAD_BUCKET", "tos://open-workflowgym-sample").rstrip("/")
    root_prefix = sanitize_tos_path_part(Path(job.config.output_root).name or job.config.output_root)
    task_id = sanitize_tos_path_part(job.task.task_id)
    sample_dir_name = "sample_%s" % sanitize_tos_path_part(str(job.sample_index))
    return "%s/%s/%s/%s/production" % (bucket, root_prefix, task_id, sample_dir_name)


def tos_target_path(path: str) -> str:
    return path if path.startswith("tos://") else "tos://" + path


def public_tos_url(path: str) -> str:
    if path.startswith("tos://"):
        bucket_and_key = path[len("tos://"):]
    else:
        bucket_and_key = path
    host = os.getenv("TOS_PUBLIC_HOST", "")
    if not host:
        return "tos://%s" % bucket_and_key
    return "https://%s/obj/%s" % (host.strip("/"), bucket_and_key.lstrip("/"))


def parse_tos_presign_markers(command_result: dict[str, Any]) -> dict[str, str]:
    output = command_decoded_output(command_result)
    if command_result.get("output"):
        output = "\n".join(item for item in (output, str(command_result.get("output") or "")) if item)
    urls: dict[str, str] = {}
    for line in output.splitlines():
        if not line.startswith("WORKFLOWGYM_TOS_PRESIGN\t"):
            continue
        parts = line.split("\t", 2)
        if len(parts) == 3 and parts[1] and parts[2]:
            urls[parts[1]] = parts[2]
    return urls


def build_output_file_check_command(output_dir: str, relative_path: str) -> str:
    source_paths = output_source_paths(output_dir, relative_path)
    if is_windows_path(output_dir) or (source_paths and is_windows_path(source_paths[0])):
        return build_windows_output_file_check_command(source_paths, relative_path)
    return build_linux_output_file_check_command(source_paths, relative_path)


def build_linux_output_file_check_command(source_paths: list[str], relative_path: str) -> str:
    lines = [
        "#!/bin/bash",
        "set -u",
        "relative_path=%s" % shell_quote(relative_path),
        "found=0",
    ]
    for source_path in source_paths:
        lines.extend(
            [
                "source_path=%s" % shell_quote(source_path),
                "if [ \"$found\" -eq 0 ] && [ -f \"$source_path\" ]; then",
                "  size=\"$(wc -c < \"$source_path\" | tr -d ' ')\"",
                "  printf 'WORKFLOWGYM_OUTPUT_FILE\\t%s\\texists\\t%s\\t%s\\n' \"$relative_path\" \"$source_path\" \"$size\"",
                "  found=1",
                "fi",
            ]
        )
    candidate_paths = ",".join(source_paths)
    lines.extend(
        [
            "if [ \"$found\" -eq 0 ]; then",
            "  printf 'WORKFLOWGYM_OUTPUT_FILE\\t%%s\\tmissing\\t%%s\\t\\n' \"$relative_path\" %s"
            % shell_quote(candidate_paths),
            "fi",
        ]
    )
    return "\n".join(lines)


def build_windows_output_file_check_command(source_paths: list[str], relative_path: str) -> str:
    # Use [char]9 (tab) — do NOT put `t inside single-quoted ps_quote strings (they stay literal).
    checks = []
    for source_path in source_paths:
        checks.append(
            "if ($found -eq 0 -and (Test-Path -LiteralPath %s -PathType Leaf)) { "
            "$item = Get-Item -LiteralPath %s; "
            "$sep = [char]9; "
            "Write-Output ('WORKFLOWGYM_OUTPUT_FILE' + $sep + %s + $sep + 'exists' + $sep + %s + $sep + $item.Length); "
            "$found = 1 "
            "}"
            % (
                ps_quote(source_path),
                ps_quote(source_path),
                ps_quote(relative_path),
                ps_quote(source_path),
            )
        )
    candidate_paths = ",".join(source_paths)
    checks.append(
        "if ($found -eq 0) { "
        "$sep = [char]9; "
        "Write-Output ('WORKFLOWGYM_OUTPUT_FILE' + $sep + %s + $sep + 'missing' + $sep + %s + $sep) "
        "}"
        % (
            ps_quote(relative_path),
            ps_quote(candidate_paths),
        )
    )
    return "$ErrorActionPreference = 'Continue'; $found = 0; " + "; ".join(checks)


def parse_output_file_check_marker(command_result: dict[str, Any], relative_path: str = "") -> dict[str, Any]:
    output = command_decoded_output(command_result)
    if command_result.get("output"):
        output = "\n".join(item for item in (output, str(command_result.get("output") or "")) if item)
    markers = []
    for line in output.splitlines():
        # Real tabs, or legacy Windows literal "`t" when format string was single-quoted.
        normalized = line.replace("`t", "\t")
        if not normalized.startswith("WORKFLOWGYM_OUTPUT_FILE\t"):
            continue
        parts = normalized.split("\t", 4)
        if len(parts) < 4:
            continue
        size_text = parts[4] if len(parts) > 4 else ""
        size = None
        if size_text:
            try:
                size = int(size_text)
            except ValueError:
                size = None
        markers.append(
            {
                "success": command_succeeded(command_result),
                "relative_path": parts[1],
                "exists": parts[2] == "exists",
                "source_path": parts[3],
                "size": size,
                "command_result": command_result,
            }
        )
    if markers:
        for marker in markers:
            if marker.get("exists"):
                return marker
        return markers[-1]
    return {
        "success": command_succeeded(command_result),
        "relative_path": relative_path,
        "exists": False,
        "source_path": "",
        "size": None,
        "command_result": command_result,
        "error": "missing WORKFLOWGYM_OUTPUT_FILE marker",
    }


def command_succeeded(command_result: dict[str, Any]) -> bool:
    if command_result.get("status") in ("dry_run", "not_executed"):
        return True
    results = command_result.get("results") or []
    if not results:
        return not bool(command_result.get("error"))
    for item in results:
        status = item.get("InvocationResultStatus") or item.get("invocation_result_status")
        exit_code = item.get("ExitCode")
        if exit_code is None:
            exit_code = item.get("exit_code")
        if status and status != "Success":
            return False
        if exit_code not in (None, 0):
            return False
    return True


def output_source_path(output_dir: str, relative_path: str) -> str:
    paths = output_source_paths(output_dir, relative_path)
    return paths[0] if paths else ""


def output_source_paths(output_dir: str, relative_path: str) -> list[str]:
    return [
        _join_output_source_path(item, relative_path)
        for item in split_output_paths(output_dir)
    ]


def _join_output_source_path(output_dir: str, relative_path: str) -> str:
    if is_windows_path(output_dir):
        return ntpath.join(output_dir, relative_path.replace("/", "\\"))
    return posixpath.join(output_dir, relative_path)


def sanitize_tos_path_part(value: str) -> str:
    value = str(value or "").strip().replace("\\", "_").replace("/", "_")
    return value or "unknown"


def write_json(path: str, value: Any) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as file_obj:
        file_obj.write(json_dumps(value))
        file_obj.write("\n")


def format_step_prompt_snapshot(value: dict[str, Any]) -> str:
    """Format step prompt snapshot with one compact JSON line per history step."""
    payload = to_jsonable(value)
    history = payload.pop("history", []) or []
    meta_lines = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True).splitlines()
    if meta_lines and meta_lines[-1] == "}":
        meta_lines = meta_lines[:-1]
    if meta_lines:
        meta_lines[-1] = "%s," % meta_lines[-1]
    lines = meta_lines + ['  "history": [']
    for index, step in enumerate(history):
        suffix = "," if index < len(history) - 1 else ""
        lines.append("    %s%s" % (json.dumps(step, ensure_ascii=False, sort_keys=True), suffix))
    lines.append("  ]")
    lines.append("}")
    return "\n".join(lines) + "\n"


def write_step_prompt_snapshot(sample_dir: str, context: SampleContext, player: Any, step_index: int) -> None:
    path = os.path.join(sample_dir, "sample_10.json")
    if Path(path).exists():
        return
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "saved_at": now_text(),
        "step_index": step_index,
        "current_screenshot": context.current_screenshot,
        "sp": truncate_prompt_images(context.prompts.sp),
        "up": truncate_prompt_images(context.prompts.up),
        "history": truncate_prompt_images(prompt_history_snapshot(context)),
        "model_input": truncate_prompt_images(model_input_snapshot(player, context)),
    }
    with open(path, "w", encoding="utf-8") as file_obj:
        file_obj.write(format_step_prompt_snapshot(payload))


def prompt_history_snapshot(context: SampleContext) -> list[dict[str, Any]]:
    return [
        {
            "step_index": trace.step_index,
            "screenshot": trace.screenshot,
            "thought": trace.thought,
            "response": trace.response,
            "function_call": trace.function_call,
        }
        for trace in context.history
    ]


def model_input_snapshot(player: Any, context: SampleContext) -> dict[str, Any]:
    try:
        if hasattr(player, "build_messages"):
            return {"builder": "build_messages", "messages": player.build_messages(context)}
        if hasattr(player, "build_request_input"):
            return {"builder": "build_request_input", "input": player.build_request_input(context)}
    except Exception as exc:
        return {"error": "%s" % exc}
    return {"builder": "", "message": "player does not expose a model input builder"}


def truncate_prompt_images(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: truncate_prompt_images(item) for key, item in value.items()}
    if isinstance(value, list):
        return [truncate_prompt_images(item) for item in value]
    if isinstance(value, tuple):
        return [truncate_prompt_images(item) for item in value]
    if isinstance(value, (bytes, bytearray)):
        return image_bytes_preview(bytes(value), "bytes")
    if isinstance(value, str):
        if value.startswith("data:image/"):
            return data_image_preview(value)
        return replace_embedded_data_images(value)
    return value


def replace_embedded_data_images(value: str) -> str:
    pattern = re.compile(r"data:image/[^;\s]+;base64,[A-Za-z0-9+/=\n\r]+")
    return pattern.sub(lambda match: json_dumps(data_image_preview(match.group(0))), value)


def data_image_preview(value: str) -> dict[str, Any]:
    header, _, encoded = value.partition(",")
    first_bytes = decode_base64_prefix(encoded, 128)
    result = image_bytes_preview(first_bytes, "data_image", original_base64_chars=len(encoded))
    if header.startswith("data:") and ";base64" in header:
        result["mime"] = header[len("data:") : header.index(";base64")]
    return result


def decode_base64_prefix(encoded: str, byte_limit: int) -> bytes:
    normalized = "".join(encoded.split())
    prefix_chars = ((byte_limit + 2) // 3) * 4
    prefix = normalized[:prefix_chars]
    padding = "=" * (-len(prefix) % 4)
    try:
        return base64.b64decode(prefix + padding)[:byte_limit]
    except Exception:
        return b""


def image_bytes_preview(value: bytes, source: str, original_base64_chars: int | None = None) -> dict[str, Any]:
    preview = value[:128]
    result: dict[str, Any] = {
        "image_truncated": True,
        "source": source,
        "kept_bytes": len(preview),
        "first_128_bytes_base64": base64.b64encode(preview).decode("ascii"),
    }
    if original_base64_chars is not None:
        result["original_base64_chars"] = original_base64_chars
    return result


def write_text(path: str, value: str) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as file_obj:
        file_obj.write(value)


def append_exception(sample_dir: str, exception_record: dict[str, Any]) -> None:
    path = os.path.join(sample_dir, "exception.json")
    exceptions = []
    if Path(path).exists():
        try:
            with open(path, "r", encoding="utf-8") as file_obj:
                loaded = json.load(file_obj)
            if isinstance(loaded, list):
                exceptions = loaded
        except Exception:
            exceptions = []
    exceptions.append(to_jsonable(exception_record))
    write_json(path, exceptions)


def clear_exception_file(sample_dir: str) -> None:
    path = Path(sample_dir) / "exception.json"
    if path.exists():
        path.unlink()


def build_exception_record(
    job: SampleJob,
    stage: str,
    exc: Exception,
    step_index: int,
    screenshot: str,
    current_trace: StepTrace | None,
    env_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    record: dict[str, Any] = {
        "run_id": job.run_id,
        "task_id": job.task.task_id,
        "sample_index": job.sample_index,
        "stage": stage,
        "step_index": step_index,
        "screenshot": screenshot,
        "exception_type": exc.__class__.__name__,
        "message": "%s" % exc,
        "traceback": traceback.format_exc(),
        "current_trace": trace_payload(current_trace) if current_trace else None,
        "timestamp": now_text(),
    }
    record.update(exception_platform_context(exc, job, env_metadata))
    return record


def exception_platform_context(
    exc: Exception,
    job: SampleJob | None = None,
    env_metadata: dict[str, Any] | None = None,
) -> dict[str, str]:
    context: dict[str, str] = {}
    if isinstance(exc, CloudAssistantPlatformMismatchError):
        context.update(exc.context())
    metadata = env_metadata if isinstance(env_metadata, dict) else {}
    if metadata.get("instance_platform") and not context.get("instance_platform"):
        context["instance_platform"] = str(metadata.get("instance_platform") or "")
    if not context.get("instance_os_type"):
        instance_platform = str(context.get("instance_platform") or "").strip()
        platform_label = platform_to_os_type_label(instance_platform) if instance_platform else ""
        context["instance_os_type"] = str(
            metadata.get("described_os_type") or metadata.get("os_type") or platform_label or ""
        )
    if metadata.get("target_image_platform") and not context.get("expected_platform"):
        context["expected_platform"] = str(metadata.get("target_image_platform") or "")
    if not context.get("expected_os_type"):
        expected_platform = str(context.get("expected_platform") or "").strip()
        expected_label = platform_to_os_type_label(expected_platform) if expected_platform else ""
        context["expected_os_type"] = str(metadata.get("target_image_os_type") or expected_label or "")
    if job:
        task_platform = task_platform_hint(job)
        if task_platform:
            context.setdefault("task_expected_platform", task_platform)
            context.setdefault("task_expected_os_type", platform_to_os_type_label(task_platform))
    return {key: value for key, value in context.items() if value}


def is_recorded_step_trace(trace: StepTrace) -> bool:
    return not str(trace.error or "").strip()


def recorded_step_traces(traces: list[StepTrace]) -> list[StepTrace]:
    return [trace for trace in traces if is_recorded_step_trace(trace)]


def rollback_player_step_history(player: Any) -> None:
    rollback = getattr(player, "rollback_last_step_history", None)
    if callable(rollback):
        rollback()


def trace_payload(trace: StepTrace) -> dict[str, Any]:
    payload = to_jsonable(trace)
    if not payload.get("error"):
        payload.pop("error", None)
    return payload


def print_step_section(step_index: int, title: str, content: str) -> None:
    print("\n===== step %s %s =====" % (step_index, title), flush=True)
    print(content, flush=True)
    print("===== end step %s %s =====\n" % (step_index, title), flush=True)


def render_traj_md(traces: list[StepTrace], sample_dir: str = "", prompts: Any = None) -> str:
    lines = ["# Trajectory", ""]
    if prompts:
        lines.extend(render_prompt_md(prompts))
    for trace in traces:
        lines.append("## Step %s" % trace.step_index)
        lines.append("")
        screenshot_link = markdown_relative_path(trace.screenshot, sample_dir)
        if screenshot_link:
            lines.append("![step %s](%s)" % (trace.step_index, screenshot_link))
            lines.append("")
        lines.append("- screenshot: `%s`" % trace.screenshot)
        if trace.action_summaries:
            for action_index, summary in enumerate(trace.action_summaries):
                raw_point = summary.get("raw_point")
                formula = summary.get("conversion_formula")
                if raw_point is not None or formula:
                    lines.append(
                        "- action %s: raw `%s`, formula `%s`, screen `%s`, actual `%s`, source `%s`"
                        % (
                            action_index,
                            raw_point if raw_point is not None else summary.get("normalized_point"),
                            formula or "actual_x = display_width * normalized_x / 1000, actual_y = display_height * normalized_y / 1000",
                            summary.get("screen_size") or summary.get("display_size"),
                            summary.get("actual_point") or summary.get("converted_point"),
                            summary.get("source") or summary.get("resolution_source") or "pyautogui",
                        )
                    )
                else:
                    lines.append(
                        "- action %s: normalized `%s`, screenshot `%s`, display `%s`, pyautogui `%s`, source `%s`, actual `%s`"
                        % (
                            action_index,
                            summary.get("normalized_point"),
                            summary.get("screenshot_size") or summary.get("coordinate_size") or summary.get("screen_size"),
                            summary.get("display_size") or summary.get("screen_size"),
                            summary.get("pyautogui_size") or summary.get("screen_size"),
                            summary.get("resolution_source") or "pyautogui",
                            summary.get("actual_point"),
                        )
                    )
        if trace.response:
            lines.append("- response: %s" % trace.response.replace("\n", " "))
        if trace.error:
            lines.append("- error: %s" % trace.error)
        lines.append("")
    return "\n".join(lines)


def render_prompt_md(prompts: Any) -> list[str]:
    lines = ["## Prompts", ""]
    prompt_items = (("System Prompt", getattr(prompts, "sp", "")), ("User Prompt", getattr(prompts, "up", "")))
    for title, content in prompt_items:
        lines.append("<details>")
        lines.append("<summary>%s</summary>" % title)
        lines.append("")
        lines.append("```text")
        lines.append(content or "")
        lines.append("```")
        lines.append("")
        lines.append("</details>")
        lines.append("")
    return lines


def markdown_relative_path(path: str, base_dir: str) -> str:
    if not path:
        return ""
    try:
        path_obj = Path(path)
        if not path_obj.is_absolute():
            path_obj = Path.cwd() / path_obj
        base_obj = Path(base_dir)
        if not base_obj.is_absolute():
            base_obj = Path.cwd() / base_obj
        return path_obj.relative_to(base_obj).as_posix()
    except Exception:
        return path


def extract_action_summaries(command_result: dict[str, Any]) -> list[dict[str, Any]]:
    summaries: list[dict[str, Any]] = []
    for item in command_result.get("results") or []:
        output = item.get("decoded_output") or ""
        for line in str(output).splitlines():
            if not line.startswith("WORKFLOWGYM_ACTION_COORD "):
                continue
            payload = line.split(" ", 1)[1]
            try:
                parsed = json.loads(payload)
            except Exception:
                continue
            if isinstance(parsed, dict):
                summaries.append(parsed)
    return summaries


def extract_coordinate_summaries(call: Any) -> list[dict[str, Any]]:
    summaries: list[dict[str, Any]] = []
    calls = call if isinstance(call, list) else [call]
    for item in calls:
        if not isinstance(item, dict):
            continue
        raw_action = item.get("raw_action")
        if not isinstance(raw_action, dict):
            continue
        conversions = raw_action.get("coordinate_conversions") or []
        if isinstance(conversions, list):
            summaries.extend(conversion for conversion in conversions if isinstance(conversion, dict))
    return summaries


def should_capture_post_action_screenshot(player: Any, context: SampleContext, trace: StepTrace, action_index: int) -> bool:
    hook = getattr(player, "needs_post_action_screenshot", None)
    if not callable(hook):
        return False
    return bool(hook(context, trace, action_index))


def notify_after_action(player: Any, context: SampleContext, trace: StepTrace, action_index: int, screenshot: str) -> None:
    hook = getattr(player, "after_action", None)
    if callable(hook):
        hook(context, trace, action_index, screenshot)



