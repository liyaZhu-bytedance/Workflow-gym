from __future__ import annotations

from typing import Any

from .envs.volcengine_env import VolcengineEnv, image_record_platform
from .records import TaskRecord
from .task_files import is_windows_path


def task_platform_from_fields(fields: dict[str, Any], input_path: str = "", output_path: str = "") -> str:
    for key in ("系统类型", "platform", "computer_platform", "os", "os_type", "system"):
        value = str(fields.get(key) or "").strip().lower()
        if value:
            return "windows" if value.startswith("win") or "windows" in value else "ubuntu"
    if is_windows_path(input_path) or is_windows_path(output_path):
        return "windows"
    return ""


def resolve_task_platform(task: TaskRecord, image_platforms: dict[str, str] | None = None) -> str:
    platform = task_platform_from_fields(task.fields, task.input_path, task.output_path)
    if platform:
        return platform
    image_id = str(task.image_id or task.fields.get("image") or "").strip()
    if image_id and image_platforms:
        cached = str(image_platforms.get(image_id) or "").strip()
        if cached:
            return cached
    return ""


def unknown_platform_reason(task: TaskRecord, image_platforms: dict[str, str] | None = None) -> str:
    if resolve_task_platform(task, image_platforms):
        return ""
    image_id = str(task.image_id or task.fields.get("image") or "").strip()
    if image_id and image_platforms is not None and image_id in image_platforms and not image_platforms.get(image_id):
        return (
            "无法解析任务平台: task_id=%s image_id=%s 的镜像平台未知，"
            "请补充任务字段(系统类型/platform)或修复镜像元数据"
            % (task.task_id, image_id)
        )
    return (
        "无法解析任务平台: task_id=%s 缺少 ubuntu/windows 平台信息，"
        "请补充系统类型/platform 字段或可用的镜像 ID"
        % task.task_id
    )


def build_image_platform_map(env: VolcengineEnv, tasks: list[TaskRecord]) -> dict[str, str]:
    platforms: dict[str, str] = {}
    for task in tasks:
        image_id = str(task.image_id or task.fields.get("image") or "").strip()
        if not image_id or image_id in platforms:
            continue
        if env.dry_run:
            continue
        try:
            platforms[image_id] = image_record_platform(env.describe_image(image_id))
        except Exception:
            platforms[image_id] = ""
    return platforms
