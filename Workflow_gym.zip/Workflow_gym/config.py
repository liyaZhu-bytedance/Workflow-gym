from __future__ import annotations

import argparse
import os
from pathlib import Path

from .records import RunConfig, new_id


# 配置了 SOURCE_FEISHU_URL（或下方 DEFAULT）时优先从飞书读任务；留空则走本地 CSV
DEFAULT_SOURCE_FEISHU_URL = ""


def normalize_sampling_mode(value: str) -> str:
    """Normalize user-facing sampling mode to lease_backend kind."""
    kind = str(value or "local").strip().lower()
    if kind in ("redis", "online", "wgm", "remote"):
        return "redis"
    if kind in ("local", ""):
        return "local"
    raise ValueError("unsupported sampling mode: %s (use local or redis/online)" % value)


def resolve_lease_backend(*, mode: str = "", lease_backend: str = "") -> str:
    """Resolve lease backend from --mode, --lease-backend, or env."""
    explicit_mode = str(mode or "").strip()
    if explicit_mode:
        return normalize_sampling_mode(explicit_mode)
    backend = str(lease_backend or "").strip()
    if backend:
        return normalize_sampling_mode(backend)
    env_mode = str(os.getenv("SAMPLING_MODE") or os.getenv("LEASE_BACKEND") or "local").strip()
    return normalize_sampling_mode(env_mode)


def finalize_parsed_args(args: argparse.Namespace) -> argparse.Namespace:
    args.lease_backend = resolve_lease_backend(
        mode=str(getattr(args, "mode", "") or ""),
        lease_backend=str(getattr(args, "lease_backend", "") or ""),
    )
    return args


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="WorkflowGym sampling supervisor")
    parser.add_argument("--source-feishu-url", default=os.getenv("SOURCE_FEISHU_URL", DEFAULT_SOURCE_FEISHU_URL))
    parser.add_argument("--source-csv-path", default=os.getenv("SOURCE_CSV_PATH", ""))
    parser.add_argument("--report-csv-dir", default=os.getenv("REPORT_CSV_DIR", ""))
    parser.add_argument("--task-replay-db", default=os.getenv("TASK_REPLAY_DB", ""))
    parser.add_argument(
        "--id",
        dest="target_id",
        nargs="+",
        default=None,
        help="Target task id(s). Multiple ids can be separated by spaces.",
    )
    parser.add_argument("--sampleNum", "--sc", type=int, default=int(os.getenv("SAMPLE_NUM", "1")))
    parser.add_argument("--stepNum", "--sn", type=int, default=int(os.getenv("STEP_NUM", "400")))
    parser.add_argument("--player", default=os.getenv("PLAYER", "gpt"))
    parser.add_argument("--judger", default=os.getenv("JUDGER", "gemini3.1"))
    parser.add_argument("--max-workers", type=int, default=int(os.getenv("MAX_WORKERS", "2")))
    parser.add_argument("--validate", dest="validate", action="store_true", default=True)
    parser.add_argument("--no-validate", dest="validate", action="store_false")
    parser.add_argument("--start-row", type=int, default=int(os.getenv("START_ROW", "2")))
    parser.add_argument("--source-range", default=os.getenv("SOURCE_RANGE", ""))
    parser.add_argument("--output-root", default=os.getenv("OUTPUT_ROOT", ""))
    parser.add_argument("--state-db-path", default=os.getenv("STATE_DB_PATH", ""))
    parser.add_argument("--dry-run", choices=("", "read", "local", "feishu", "env"), default=os.getenv("DRY_RUN", ""))
    parser.add_argument("--enable-real-feishu", dest="enable_real_feishu", action="store_true", default=os.getenv("ENABLE_REAL_FEISHU", "true").lower() == "true")
    parser.add_argument("--no-real-feishu", dest="enable_real_feishu", action="store_false")
    parser.add_argument("--enable-real-cloud", action="store_true", default=os.getenv("ENABLE_REAL_CLOUD", "true").lower() == "true")
    parser.add_argument("--region", default=os.getenv("VOLCENGINE_REGION") or os.getenv("SOURCE_REGION") or "cn-guangzhou")
    parser.add_argument("--demo-image-id", default=os.getenv("DEMO_IMAGE_ID", "image-demo"))
    parser.add_argument("--discover-instance-name-prefix", default=os.getenv("WORKFLOWGYM_INSTANCE_NAME_PREFIX", "open_workflow_gym"))
    parser.add_argument("--discover-project-name", default=os.getenv("WORKFLOWGYM_PROJECT_NAME", ""))
    parser.add_argument("--discover-instance-limit", type=int, default=int(os.getenv("WORKFLOWGYM_DISCOVER_INSTANCE_LIMIT", "30")))
    parser.add_argument(
        "--discover-probe-max-workers",
        type=int,
        default=int(os.getenv("DISCOVER_PROBE_MAX_WORKERS", "8")),
        help="启动时发现实例的 RunCommand 探测并发数，默认 8",
    )
    parser.add_argument("--resume-running-samples", action="store_true", default=os.getenv("RESUME_RUNNING_SAMPLES", "false").lower() == "true")
    parser.add_argument("--no-recover-instances", dest="recover_instances", action="store_false", default=True)
    parser.add_argument("--auto-reset-unknown-instances", action="store_true", default=False)
    parser.add_argument("--force-reset-instances", action="store_true", default=False)
    parser.add_argument("--instance-ids", default=os.getenv("INSTANCE_IDS", ""))
    parser.add_argument("--tos-output-prefix", default=os.getenv("TOS_OUTPUT_PREFIX", ""))
    parser.add_argument("--prefetch-rows", type=int, default=int(os.getenv("PREFETCH_ROWS", "100")))
    parser.add_argument("--max-pending-samples", type=int, default=int(os.getenv("MAX_PENDING_SAMPLES", "200")))
    parser.add_argument("--model-call-timeout-seconds", type=int, default=int(os.getenv("MODEL_CALL_TIMEOUT_SECONDS", "300")))
    parser.add_argument("--action-timeout-seconds", type=int, default=int(os.getenv("ACTION_TIMEOUT_SECONDS", "60")))
    parser.add_argument("--max-no-action-seconds", type=int, default=int(os.getenv("MAX_NO_ACTION_SECONDS", "1800")))
    parser.add_argument("--input-download-timeout-seconds", type=int, default=int(os.getenv("INPUT_DOWNLOAD_TIMEOUT_SECONDS", "300")))
    parser.add_argument("--tosutil-timeout-seconds", type=int, default=int(os.getenv("TOSUTIL_TIMEOUT_SECONDS", "300")))
    parser.add_argument("--max-memory-usage-percent", type=float, default=float(os.getenv("MAX_MEMORY_USAGE_PERCENT", "85")))
    parser.add_argument("--min-available-memory-mb", type=int, default=int(os.getenv("MIN_AVAILABLE_MEMORY_MB", "1024")))
    parser.add_argument("--max-worker-processes", type=int, default=int(os.getenv("MAX_WORKER_PROCESSES", "64")))
    parser.add_argument("--min-free-disk-gb", type=float, default=float(os.getenv("MIN_FREE_DISK_GB", "20")))
    parser.add_argument("--max-run-dir-gb", type=float, default=float(os.getenv("MAX_RUN_DIR_GB", "200")))
    parser.add_argument("--max-sample-dir-mb", type=float, default=float(os.getenv("MAX_SAMPLE_DIR_MB", "2048")))
    parser.add_argument("--screenshot-retention-policy", default=os.getenv("SCREENSHOT_RETENTION_POLICY", "all"))
    parser.add_argument("--screenshot-retention-every-n", type=int, default=int(os.getenv("SCREENSHOT_RETENTION_EVERY_N", "5")))
    parser.add_argument("--verbose-steps", action="store_true", default=os.getenv("WORKFLOWGYM_VERBOSE_STEPS", "false").lower() == "true")
    parser.add_argument("--write-step-traj", action="store_true", default=os.getenv("WRITE_STEP_TRAJ", "false").lower() == "true")
    parser.add_argument("--lease-ttl-seconds", type=int, default=int(os.getenv("LEASE_TTL_SECONDS", "3600")))
    parser.add_argument(
        "--mode",
        default=os.getenv("SAMPLING_MODE", ""),
        help=(
            "采样模式：local=自建 ECS；redis 或 online=共享 WGM Session 池。"
            "也可在 .env 设 SAMPLING_MODE=local|redis。优先于 --lease-backend。"
        ),
    )
    parser.add_argument(
        "--lease-backend",
        default=os.getenv("LEASE_BACKEND", "local"),
        help="兼容旧参数；未指定 --mode 时生效。local 或 redis/wgm/remote",
    )
    parser.add_argument(
        "--wgm-api-base",
        default=os.getenv("WGM_API_BASE") or os.getenv("WGM_HOST", ""),
        help="redisWebBack API base URL when --mode redis/online",
    )
    parser.add_argument(
        "--wgm-token",
        default=os.getenv("WGM_TOKEN", ""),
        help="WGM Bearer token when --mode redis/online",
    )
    parser.add_argument(
        "--fail-on-unknown-platform",
        dest="fail_on_unknown_platform",
        action="store_true",
        default=os.getenv("FAIL_ON_UNKNOWN_PLATFORM", "true").lower() == "true",
    )
    parser.add_argument("--allow-unknown-platform", dest="fail_on_unknown_platform", action="store_false")
    parser.add_argument(
        "--sample-init-timeout-seconds",
        type=int,
        default=int(os.getenv("SAMPLE_INIT_TIMEOUT_SECONDS", "3600")),
    )
    parser.add_argument(
        "--model-lease-heartbeat-min-seconds",
        type=int,
        default=int(os.getenv("MODEL_LEASE_HEARTBEAT_MIN_SECONDS", "600")),
    )
    parser.add_argument(
        "--sample-future-max-seconds",
        type=int,
        default=int(os.getenv("SAMPLE_FUTURE_MAX_SECONDS", "0")),
        help="0 means lease_ttl_seconds * 2 + sample_init_timeout_seconds",
    )
    return finalize_parsed_args(parser.parse_args(argv))


def resolve_remote_action_delivery(lease_backend: str) -> str:
    """redis 模式固定 wgm-direct；local 模式走本机 RunCommand（字段仅占位）。"""
    kind = str(lease_backend or "local").strip().lower()
    if kind in ("redis", "wgm", "remote"):
        legacy = str(os.getenv("REMOTE_ACTION_DELIVERY") or "").strip().lower()
        if legacy == "run-command":
            raise ValueError(
                "lease-backend=redis 已固定使用 wgm-direct（WGM→RunCommand→127.0.0.1 Flask /action）；"
                "REMOTE_ACTION_DELIVERY=run-command 不再支持，请 unset 该环境变量"
            )
        return "wgm-direct"
    return "run-command"


def build_run_config(args: argparse.Namespace) -> RunConfig:
    run_id = os.getenv("RUN_ID") or new_id("run")
    output_root = args.output_root or default_output_root(args.player, args.sampleNum, args.stepNum)
    state_db_path = args.state_db_path or str(Path(output_root) / "workflowgym_state.db")
    instance_ids = tuple(item.strip() for item in args.instance_ids.split(",") if item.strip())
    target_id = normalize_target_id_arg(args.target_id) or os.getenv("WORKFLOWGYM_TASK_ID", "")
    tos_output_prefix = args.tos_output_prefix or Path(output_root).name
    sample_future_max_seconds = int(args.sample_future_max_seconds)
    if sample_future_max_seconds <= 0:
        sample_future_max_seconds = int(args.lease_ttl_seconds) * 2 + int(args.sample_init_timeout_seconds)
    return RunConfig(
        run_id=run_id,
        source_feishu_url=args.source_feishu_url,
        source_csv_path=args.source_csv_path,
        report_csv_dir=args.report_csv_dir,
        task_replay_db=args.task_replay_db,
        target_id=target_id,
        sample_num=args.sampleNum,
        step_num=args.stepNum,
        player=args.player,
        judger=args.judger,
        max_workers=args.max_workers,
        validate=args.validate,
        start_row=args.start_row,
        source_range=args.source_range,
        output_root=output_root,
        state_db_path=state_db_path,
        dry_run=args.dry_run,
        enable_real_feishu=args.enable_real_feishu,
        enable_real_cloud=args.enable_real_cloud,
        region=args.region,
        demo_image_id=args.demo_image_id,
        discover_instance_name_prefix=args.discover_instance_name_prefix,
        discover_project_name=args.discover_project_name,
        discover_instance_limit=args.discover_instance_limit,
        discover_probe_max_workers=args.discover_probe_max_workers,
        resume_running_samples=args.resume_running_samples,
        recover_instances=args.recover_instances,
        auto_reset_unknown_instances=args.auto_reset_unknown_instances,
        force_reset_instances=args.force_reset_instances,
        instance_ids=instance_ids,
        tos_output_prefix=tos_output_prefix,
        prefetch_rows=args.prefetch_rows,
        max_pending_samples=args.max_pending_samples,
        model_call_timeout_seconds=args.model_call_timeout_seconds,
        action_timeout_seconds=args.action_timeout_seconds,
        max_no_action_seconds=args.max_no_action_seconds,
        input_download_timeout_seconds=args.input_download_timeout_seconds,
        tosutil_timeout_seconds=args.tosutil_timeout_seconds,
        max_memory_usage_percent=args.max_memory_usage_percent,
        min_available_memory_mb=args.min_available_memory_mb,
        max_worker_processes=args.max_worker_processes,
        min_free_disk_gb=args.min_free_disk_gb,
        max_run_dir_gb=args.max_run_dir_gb,
        max_sample_dir_mb=args.max_sample_dir_mb,
        screenshot_retention_policy=args.screenshot_retention_policy,
        screenshot_retention_every_n=args.screenshot_retention_every_n,
        verbose_steps=args.verbose_steps,
        write_step_traj=args.write_step_traj,
        lease_ttl_seconds=args.lease_ttl_seconds,
        lease_backend=str(getattr(args, "lease_backend", "local") or "local"),
        remote_action_delivery=resolve_remote_action_delivery(
            str(getattr(args, "lease_backend", "local") or "local")
        ),
        wgm_api_base=str(getattr(args, "wgm_api_base", "") or ""),
        wgm_token=str(getattr(args, "wgm_token", "") or ""),
        fail_on_unknown_platform=args.fail_on_unknown_platform,
        sample_init_timeout_seconds=args.sample_init_timeout_seconds,
        model_lease_heartbeat_min_seconds=args.model_lease_heartbeat_min_seconds,
        sample_future_max_seconds=sample_future_max_seconds,
    )


def normalize_target_id_arg(value: object) -> str:
    if isinstance(value, (list, tuple)):
        return " ".join(str(item).strip() for item in value if str(item).strip())
    return str(value or "").strip()


def default_output_root(player: str, sample_num: int, step_num: int) -> str:
    import datetime

    stamp = datetime.datetime.now().strftime("%Y%m%d%H%M")
    run_dir = "sample_%s_%s_step_%s_%s" % (player, sample_num, step_num, stamp)
    return str(Path("output") / run_dir)

